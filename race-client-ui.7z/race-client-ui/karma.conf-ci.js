var fs = require('fs');

module.exports = function (config) {

    // Browsers to run on Sauce Labs
    var customLaunchers = {
        sl_chrome: {
            base: 'SauceLabs',
            browserName: 'chrome',
            platform: 'Windows 10'
        }
    };

    config.set({
        basePath: '',
        frameworks: ['jasmine','@angular-devkit/build-angular'],
        plugins: [
            require('karma-jasmine'),
            require('karma-sauce-launcher'),
            require('sauce-connect-launcher'),
            require('karma-chrome-launcher'),
            require('karma-jasmine-html-reporter'),
            require('karma-coverage-istanbul-reporter'),
            require('@angular-devkit/build-angular/plugins/karma')
        ],
        reporters: ['progress', 'saucelabs'],
        port: 9876,
        colors: true,
        sauceLabs: {
            testName: 'RACE UI Unit Testing',
            recordScreenshots: false,
            username: "cdk-race",
            accessKey: "a8926a7d-5484-4a8b-8598-6a7c6c4fcee3",
            startConnect: false,
            tunnelIdentifier: 'race-karma',
            public: 'public'
        },
        customLaunchers: customLaunchers,
        browsers: Object.keys(customLaunchers),
        singleRun: true,
        autoWatch: true,
        browserDisconnectTimeout: 15000,
        browserDisconnectTolerance: 2,
        browserNoActivityTimeout: 45000,
        captureTimeout: 7 * 60 * 1000,
        retryLimit: 3
    })
};