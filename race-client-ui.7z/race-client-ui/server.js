var express = require("express");
var app = express();
var path = require("path");
var router = express.Router();

var fs = require("fs");
fs.writeFile(
  "dist/assets/config",
  JSON.stringify(
    (function () {
      switch (process.env.DEPLOYMENT_ENV) {
        case "dit-pdx":
          return {
            production: false,
            host: "https://raceapi-dit.connectcdk.com/",
            cshost: "https://www-dit.connectcdk.com/",
            flexApiHost:
              "https://api-int.dit.connectcdk.com/api/ds-flex-dash-config/v1/",
            refreshToken: "8adaf13a-06c5-4cd1-bca5-70edf23323fc",
            launchDarklyClientSideId: "5e3d3b64e550010729d3b092",
            setupSchemaHost:
              "https://www-dit.connectcdk.com/api/ds-setups-schema-admin-ui/v1/", 
          };
        case "dit-qa":
          return {
            production: false,
            host: "https://raceapi-qa.connectcdk.com/",
            cshost: "https://www-dit.connectcdk.com/",
            flexApiHost:
              "https://api-int.dit.connectcdk.com/api/ds-flex-dash-config/v1/",
            refreshToken: "8adaf13a-06c5-4cd1-bca5-70edf23323fc",
            launchDarklyClientSideId: "5e3d3b93e550010729d3b097",
            setupSchemaHost:
              "https://www-stage.connectcdk.com/api/ds-setups-schema-admin-ui/v1/",
          };
        case "prod-pdx":
          return {
            production: true,
            host: "https://raceapi.connectcdk.com/",
            cshost: "https://api.connectcdk.com/",
            flexApiHost:
              "https://api-int.prod.connectcdk.com/api/ds-flex-dash-config/v1/",
            refreshToken: "0868036e-87fd-4f16-81d6-7f16ff86b6fd",
            launchDarklyClientSideId: "5e3d3ae4a894c1070be6fc62",
            setupSchemaHost:
              "https://www.connectcdk.com/api/ds-setups-schema-admin-ui/v1/",
          };
        default:
          return {
            production: false,
            host: "http://localhost:8090/",
            cshost: "https://www-dit.connectcdk.com/",
            flexApiHost:
              "https://api-int.dit.connectcdk.com/api/ds-flex-dash-config/v1/",
            refreshToken: "8adaf13a-06c5-4cd1-bca5-70edf23323fc",
            launchDarklyClientSideId: "5e3d3b64e550010729d3b092",
          };
      }
    })()
  ),
  function (err) {
    if (err) {
      return console.log(err);
    }

    console.log("Config file created.");
  }
);

router.get("/health", function (req, res) {
  res.json({ status: "UP" });
});

app.use("/dot-ui", express.static(path.join(__dirname, "dist")));
app.use(express.static("dist"));

var port = process.env.PORT || 8080;

//Start the server
var server = app.listen(port, function () {
  console.log("Server running on port:" + port);
});

app.use("/", router);
