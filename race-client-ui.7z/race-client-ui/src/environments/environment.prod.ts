export const environment = {
  production: true,
   host: "https://connectcdk.com/api/ds-dot-server/v1/"
};
