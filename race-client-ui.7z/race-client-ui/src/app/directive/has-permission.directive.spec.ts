import { HttpClientTestingModule } from "@angular/common/http/testing";
import { ElementRef } from "@angular/core";
import { TestBed } from "@angular/core/testing";
import { MatDialogModule } from "@angular/material";
import { truncate } from "fs";
import { Observable } from "rxjs";
import { AuthService } from "../services/auth-service";
import { HasPermissionDirective } from "./has-permission.directive";

describe('HasPermissionDirective', () => {

    let hasPermissionDirective: HasPermissionDirective;
    let authService:AuthService;
    class MockElementRef {
    }
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule,
                MatDialogModule
            ],
            providers: [
                HasPermissionDirective,
                AuthService,
                { provide: ElementRef, useClass: MockElementRef },
            ],
        });

        authService = TestBed.get(AuthService);
        hasPermissionDirective = TestBed.get(HasPermissionDirective);
    });

    it('test ngOnInit',()=>{
        spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of({}));
        spyOn(authService,'isAuthorised').and.returnValue(true);
        hasPermissionDirective.ngOnInit();
    })
});