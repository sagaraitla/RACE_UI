import { Directive, ElementRef, OnInit, Input } from '@angular/core';
import { AuthService } from '../services/auth-service';



@Directive({
  selector: '[hasPermission]'
})
export class HasPermissionDirective {
	
  @Input('hasPermission') 
  permissionCode: string;

  constructor(private el: ElementRef, private authService: AuthService) { }
  
  ngOnInit() {
	  	this.authService.fetchLoggedInUserAndPermissions().subscribe(() => {
	  		if (!this.authService.isAuthorised(this.permissionCode)) {
		          this.el.nativeElement.style.display = 'none';
		      }
	  	});
  }

}