import { CdkTableModule } from '@angular/cdk/table';
import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule, MatCheckboxModule, MatDialogModule, MatDialogRef, MatDividerModule, MatFormFieldModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatSidenavModule, MatStepperModule, MatTableModule, MAT_DIALOG_DATA } from '@angular/material';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { ToastrModule } from 'ngx-toastr';
import { AlertDialogComponent } from './alert-dialog.component';


describe('AlertDialogComponent', () => {
    let component : AlertDialogComponent;
    let fixture: ComponentFixture<AlertDialogComponent>;

   
    beforeEach(async(() => {

        const dialogMock = {
            close: () => { }
        };

        let data= {
            messageListArray:'test'
        }

        TestBed.configureTestingModule({
          imports: [
            MatProgressSpinnerModule,
            MatMenuModule,
            MatDividerModule,
            FormsModule,
            MatCardModule,
            FormsModule,
            MatFormFieldModule,
            MatInputModule,
            CdkTableModule,
            MatMenuModule,
            MatTableModule,
            MatPaginatorModule,
            MatDialogModule,
            HttpClientTestingModule,
            ToastrModule.forRoot(),
            RouterModule.forRoot([]),
            NoopAnimationsModule,
            ReactiveFormsModule,
            CommonModule,
            MatSelectModule,
            MatRadioModule,
            ReactiveFormsModule,
            MatCheckboxModule,
            MatStepperModule,
            MatSidenavModule],
          declarations: [AlertDialogComponent],
          providers:[
           { provide: MAT_DIALOG_DATA, useValue: data },
           {provide: MatDialogRef, useValue: dialogMock},
          ]
        }).overrideModule(BrowserDynamicTestingModule,
           { set: { entryComponents: []}});

            fixture = TestBed.createComponent(AlertDialogComponent);
            component = fixture.componentInstance;
      }));


      it('test closeDialog',()=>{
          component.closeDialog();
      });
});