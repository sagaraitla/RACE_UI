
import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { SimpleChange, SimpleChanges } from "@angular/core";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormControl, FormsModule, ReactiveFormsModule, Validators } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialogModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatSelectModule, MatSortModule, MatStepperModule, MatTooltipModule } from "@angular/material";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule } from "ngx-toastr";
import { FunctionalUnitVerticalStepper } from "./vertical-stepper-fu.component";

describe('FunctionalUnitVerticalStepper',() => {

    let component : FunctionalUnitVerticalStepper;
    let fixture : ComponentFixture<FunctionalUnitVerticalStepper>;
    let _formBuilder : FormBuilder;
    beforeEach(async(() =>{
        TestBed.configureTestingModule({
           imports: [
                MatCardModule,
                MatFormFieldModule,
                MatInputModule,
                MatStepperModule,
                MatTooltipModule,
                CdkTableModule,
                MatPaginatorModule,
                MatDialogModule,
                ToastrModule.forRoot(),
                CommonModule,
                MatSelectModule,
                MatCheckboxModule,
                MatSortModule,
                MatIconModule,
                FormsModule,
                MatMenuModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                ReactiveFormsModule,
                NoopAnimationsModule,
                SortableModule,
                MatSortModule
            ],
            declarations : [FunctionalUnitVerticalStepper],
            providers : [
        
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: []}});
            fixture = TestBed.createComponent(FunctionalUnitVerticalStepper);
            component = fixture.componentInstance;
            _formBuilder = TestBed.get(FormBuilder); 

            component.formGroup = _formBuilder.group({ 
              recipientTypes: new FormControl(
              {
                  value: ["mock"],
                  disabled: true
              },
              Validators.required
              )
              });
      }));


      it('test selectFunctionalUnit',()=>{
        let event:any={}
        component.selectFunctionalUnit(event);
      })


      it('test ngOnInit',()=>{
          component.ngOnInit();
      });

});