import { Component, OnInit, Input, Output, ChangeDetectionStrategy, OnChanges, SimpleChanges, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ScreenObject } from '../model/screen-object';

@Component({
	selector: 'vertical-stepper-fu',
	templateUrl: './vertical-stepper-fu.component.html',
	styleUrls: ['./vertical-stepper-fu.component.css']
})
export class FunctionalUnitVerticalStepper implements OnChanges, OnInit {
	
	@Input() functionalUnitList: ScreenObject[];
	
	@Input() verticalStepperInput;
	
	@Output() screenChange = new EventEmitter<any>();
	formGroup: FormGroup;
	
	constructor(private _formBuilder: FormBuilder) {}
	  
	ngOnInit() {
		this.formGroup = this._formBuilder.group({
			firstCtrl: ['', Validators.required]
        });
	}
	  
	ngOnChanges(changes: SimpleChanges) {
		this.functionalUnitList = changes.functionalUnitList.currentValue;	
	}
	
	selectFunctionalUnit(event: any) {
		this.screenChange.emit(event);
	}
}