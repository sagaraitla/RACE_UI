import { CdkTableModule } from '@angular/cdk/table';
import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatDialogRef, MatDividerModule, MatFormFieldModule, MatInputModule, MatListModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatTableModule, MAT_DIALOG_DATA } from '@angular/material';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { Observable, of } from 'rxjs';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { TemplateObject } from '../model/template-object';
import { AuthService } from '../services/auth-service';
import { FunctionalAreaService } from '../services/functional-area-service';
import { StoreService } from '../services/store-service';
import { ModifyVICComponent } from './modify-vic.component';



describe('ModifyVICComponent', () => {

    let component : ModifyVICComponent;
    let fixture: ComponentFixture<ModifyVICComponent>;
    let storeService : StoreService;
    let functionalAreaService: FunctionalAreaService
    let authService: AuthService;


    beforeEach(() => {
        
      let data= {
        storeObj:{
          id:"1234",
          recordType:"e5e627f3-3ba6-4bc3-8959-38a60a0aea87"
        },
        project:{

        }
    }
    const dialogMock = {
        close: () => { },
    };
    
        TestBed.configureTestingModule({
            imports: [
              MatListModule,
              MatDividerModule,
              MatCardModule,
              FormsModule,
              MatFormFieldModule,
              MatInputModule,
              CdkTableModule,
              MatMenuModule,
              MatTableModule,
              MatPaginatorModule,
              MatDialogModule,
              HttpClientTestingModule,
              ToastrModule.forRoot(),
              NoopAnimationsModule,
              MatProgressSpinnerModule ,
              ReactiveFormsModule,
              CommonModule,
              MatSelectModule,
              MatRadioModule,
              MatCheckboxModule],
            declarations: [ModifyVICComponent,LoaderDialogueComponent],
            providers:[
             StoreService,
             FunctionalAreaService,
             AuthService,
             ToastrService,
             { provide: MAT_DIALOG_DATA, useValue: data },
             {provide: MatDialogRef, useValue: dialogMock},
            ]
          }).overrideModule(BrowserDynamicTestingModule,
             { set: { entryComponents: [LoaderDialogueComponent]}});

            authService = TestBed.get(AuthService);
            storeService = TestBed.get(StoreService);
            functionalAreaService = TestBed.get(FunctionalAreaService);

            fixture = TestBed.createComponent(ModifyVICComponent);
            component = fixture.componentInstance;
    
    });

    const functionalAreas:any=[
      {
        "functionalAreaName": "Service",
        "functionalAreaType": null,
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Work in Progress",
        "platforms": [
          {
            "id": null,
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true
          }
        ],
        "vic": {
          "firstName": "Amrita",
          "lastName": "das",
          "loginId": "Amrita.das@cdk.com",
          "employeeId": null
        },
        "secondaryVic": null,
        "clientFunctionalAreaUser": null,
        "version": 20,
        "isFailed": null,
        "inProcess": false,
        "productCode": "SVC",
        "productVersion": null,
        "masterFAId": null,
        "bpId": "63f38af3-92e3-4509-81b5-c59365cc7df1",
        "bpVersionId": "0fdfb31e-8bc2-4f59-bbc8-1ae6fba223b6",
        "bpTemplateId": "7974baeb-2d69-4ebe-a20e-da632cf38c4c",
        "isDealerApproved": false,
        "stateStandardId": null,
        "stateStandardName": null,
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": false,
        "showValidateOrTransferButton": true,
        "showProcessValidationResultsButton": false,
        "createdDate": null,
        "lastUpdatedDate": "2021-01-23T14:11:37.652+0000",
        "createdBy": null,
        "updatedBy": "Sagar.Aitla@cdk.com",
        "incorporateBpChanges": false,
        "locked": false,
        "id": "692b1762-5e44-4141-8e5a-1f26ba6fd831",
        "recordType": "8afeb798-a8e7-4c01-bf08-c7724fca3738"
      },
      {
        "functionalAreaName": "Accounting",
        "functionalAreaType": null,
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Work in Progress",
        "platforms": [
          {
            "id": null,
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true
          }
        ],
        "vic": {
          "firstName": "Bob",
          "lastName": "Bednar",
          "loginId": "bob.bednar@cdk.com",
          "employeeId": null
        },
        "secondaryVic": null,
        "clientFunctionalAreaUser": null,
        "version": 25,
        "isFailed": null,
        "inProcess": false,
        "productCode": "ACCT",
        "productVersion": null,
        "masterFAId": null,
        "bpId": "63f38af3-92e3-4509-81b5-c59365cc7df1",
        "bpVersionId": "0fdfb31e-8bc2-4f59-bbc8-1ae6fba223b6",
        "bpTemplateId": "d394cb0c-7b3f-4d6b-b82a-046570e59181",
        "isDealerApproved": false,
        "stateStandardId": null,
        "stateStandardName": null,
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": false,
        "showValidateOrTransferButton": false,
        "showProcessValidationResultsButton": true,
        "createdDate": null,
        "lastUpdatedDate": null,
        "createdBy": null,
        "updatedBy": null,
        "incorporateBpChanges": false,
        "locked": false,
        "id": "692b1762-5e44-4141-8e5a-1f26ba6fd831",
        "recordType": "dbffb934-197e-47ae-ae5e-d005c81940b3"
      }
    ]

    const usersList:any=[
      {
        user:{
          loginId:"sagar.aitla@cdk.com"
        }
      }
    ]

    const usersWithDOTVICRole:any={
        "totalMatches": 77,
        "users": [
          {
            "user": {
              "userGuid": "674AA54D2B812BFDE053440B6364465E",
              "loginId": "madhusudhan.talakokkula@cdk.com",
              "firstName": "Madhusudhan",
              "middleInitial": null,
              "lastName": "Talakokkula",
              "dmsUserIdentifier": [],
              "locked": false,
              "adminNotes": null,
              "creationDate": "2018-03-20T08:44:25+0000",
              "lastLoginDate": null,
              "locale": "en_US",
              "state": 2,
              "prefix": null,
              "suffix": null,
              "nickName": null,
              "employeeId": null,
              "jobTitle": null,
              "selfServiceEnabled": 1,
              "accountStatus": "Active",
              "communicationEdgeId": "madhusudhantalakokkulacdkcom@dit.cdkcollaborate.com",
              "uniquePrincipalName": "talakokm@ds.ad.adp.com",
              "externallyFederated": false
            },
            "contacts": [],
            "enterprise": {
              "idpName": "CDK Self Enterprise",
              "id": "E000000",
              "name": "CDK Global",
              "vanityDomain": null
            },
            "stores": [
              {
                "id": "S000000000",
                "name": "CDK Global",
                "defaultStore": true
              }
            ],
            "roles": [
              {
                "roleGuid": "6880D57A2BFA6D87E053440B6364AB6D",
                "roleName": "DOT - VIC"
              }
            ],
            "alternateIdentifiers": null,
            "warnings": [],
            "securityQuestionsStatus": false,
            "userAliases": null
          },
          {
            "user": {
              "userGuid": "66229D41543C3529E053440B63647A36",
              "loginId": "Beth.Maupin@cdk.com",
              "firstName": "Beth",
              "middleInitial": null,
              "lastName": "Maupin",
              "dmsUserIdentifier": [],
              "locked": false,
              "adminNotes": null,
              "creationDate": "2018-02-27T10:33:55+0000",
              "lastLoginDate": null,
              "locale": "en_US",
              "state": 2,
              "prefix": null,
              "suffix": null,
              "nickName": null,
              "employeeId": null,
              "jobTitle": null,
              "selfServiceEnabled": 1,
              "accountStatus": "Active",
              "communicationEdgeId": "bethmaupincdkcom@dit.cdkcollaborate.com",
              "uniquePrincipalName": "Beth.Maupin@cdk.com",
              "externallyFederated": false
            },
            "contacts": [],
            "enterprise": {
              "idpName": "CDK Self Enterprise",
              "id": "E000000",
              "name": "CDK Global",
              "vanityDomain": null
            },
            "stores": [
              {
                "id": "S000000000",
                "name": "CDK Global",
                "defaultStore": true
              }
            ],
            "roles": [
              {
                "roleGuid": "6880D57A2BFA6D87E053440B6364AB6D",
                "roleName": "DOT - VIC"
              }
            ],
            "alternateIdentifiers": null,
            "warnings": [],
            "securityQuestionsStatus": false,
            "userAliases": null
          }
        ]
    }

    const usersRole:any={
      "totalMatches": 80,
      "users": [
        {
          "user": {
            "userGuid": "674AA54D2B812BFDE053440B6364465E",
            "loginId": "madhusudhan.talakokkula@cdk.com"
          },
          "roles": [
            {
              "roleGuid": "6880D57A2BFA6D87E053440B6364AB6D",
              "roleName": "DOT - VIC"
            }
          ]
        }
      ]
    }

    const functionalAreasList : any[]=[
      {
        "functionalAreaName": "Parts",
        "functionalAreaType": null,
        "platforms": [
          {
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true
          }
        ],
        "vic":{
         "loginId":null,
        },
        "secondaryVic": null,
        "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
        "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
      }
    ]

    it('test ModifyVIC Component Created',()=>{
      expect(component).toBeTruthy()
    });

    it('test ngOnInit',()=>{
     
      let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);


      spyOn(storeService,'getFunctionalAreasOfStore').and.returnValue(functionalAreaService);
      spyOn(component,'getUSersFromCommonServices');
      fixture.detectChanges()
    });

    it('test saveModifiedVIC',()=>{

      spyOn(functionalAreaService,'saveFunctionalArea').and.returnValue(Observable.of({}));
      component.saveModifiedVIC();
      expect(functionalAreaService.saveFunctionalArea).toHaveBeenCalledTimes(1);
    });

    it('test closePopup',()=>{    
      component.closePopup();
    });

    it('test applyVICFilter',()=>{

      let vicType ="vic";
      let value="sagar.aitla@cdk.com"

      component.usersList = usersList;
      component.applyVICFilter(value,vicType);


      let vicType1 ="secondaryVic";
      component.usersList = usersList;
      component.applyVICFilter(value,vicType1);
    });

    it('test onFocusReloadVic',()=>{
      let event:any={}
      let vicType = "vic";
      let templateObject = new TemplateObject();
      component.usersList = usersList;
      component.onFocusReloadVic(event,templateObject,vicType)
      expect(component.vicUsersList.length).toEqual(1);
      
      let vicType1 = "secondaryVic";
      component.onFocusReloadVic(event,templateObject,vicType1)
      expect(component.vicUsersList.length).toEqual(1);
    
    });


    it('test onChangeVicOrSecondaryVic',()=>{
      let event:any={
        value:'test'
      }
      let vicType = "vic";
      let templateObject = new TemplateObject();
      component.onChangeVicOrSecondaryVic(event,templateObject,vicType);
      expect(templateObject[vicType]).toEqual('test');
       
    });

    it('test getUSersFromCommonServices',()=>{

      let userList:any[] =[{
        user:{
          loginId : "myLogin"
        }
      }]
      component.usersList = userList;
      const functionalAreasList : any[]=[
        {
          "functionalAreaName": "Parts",
          "functionalAreaType": null,
          "platforms": [
            {
              "platformName": "FLEX",
              "platformCode": "flex",
              "selected": true
            }
          ],
          "vic":{
           "loginId":'myLogin',
          },
          "secondaryVic": null,
          "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
          "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
        }
      ]
      component.selectedTemplates = functionalAreasList;
      spyOn(authService,'fetchCommonServicesUsersWithDotVICRole').and.returnValue(Observable.of(userList));
      component.getUSersFromCommonServices();
      expect(authService.fetchCommonServicesUsersWithDotVICRole).toHaveBeenCalledTimes(1);
    });

    
    it('test getUSersFromCommonServices where vic login not present',()=>{

      let userList:any[] =[{
        user:{
          loginId : "myLogin"
        }
      }]
      component.usersList = userList;
      const functionalAreasList : any[]=[
        {
          "functionalAreaName": "Parts",
          "functionalAreaType": null,
          "platforms": [
            {
              "platformName": "FLEX",
              "platformCode": "flex",
              "selected": true
            }
          ],
          "vic":{
           "loginId":undefined,
          },
          "secondaryVic": null,
          "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
          "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
        }
      ]
      component.selectedTemplates = functionalAreasList;
      spyOn(authService,'fetchCommonServicesUsersWithDotVICRole').and.returnValue(Observable.of(userList));
      component.getUSersFromCommonServices();
      expect(authService.fetchCommonServicesUsersWithDotVICRole).toHaveBeenCalledTimes(1);
    });

    it('test getUSersFromCommonServices where second vic login is present',()=>{

      let userList:any[] =[{
        user:{
          loginId : "myLogin"
        }
      }]
      component.usersList = userList;
      const functionalAreasList : any[]=[
        {
          "functionalAreaName": "Parts",
          "functionalAreaType": null,
          "platforms": [
            {
              "platformName": "FLEX",
              "platformCode": "flex",
              "selected": true
            }
          ],
          "vic":{
           "loginId":undefined,
          },
          "secondaryVic": {
            "loginId":"myLogin",
          },
          "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
          "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
        }
      ]
      component.selectedTemplates = functionalAreasList;
      spyOn(authService,'fetchCommonServicesUsersWithDotVICRole').and.returnValue(Observable.of(userList));
      component.getUSersFromCommonServices();
      expect(authService.fetchCommonServicesUsersWithDotVICRole).toHaveBeenCalledTimes(1);
    });


    it('test getUSersFromCommonServices throws error',()=>{

      component.selectedTemplates = functionalAreasList;
      spyOn(authService,'fetchCommonServicesUsersWithDotVICRole').and.returnValue(Observable.throwError('error'));
      component.getUSersFromCommonServices();
      expect(authService.fetchCommonServicesUsersWithDotVICRole).toHaveBeenCalledTimes(1);
    });

});