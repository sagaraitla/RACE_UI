import {forkJoin as observableForkJoin,  Observable, iif } from 'rxjs';
import { Component, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { StoreService } from '../services/store-service';
import { FunctionalAreaService } from '../services/functional-area-service';
import { StoreObject } from '../model/store-object';
import { TemplateObject } from '../model/template-object';
import { ProjectObject } from '../model/project-object';
import { AuthService } from '../services/auth-service';
import { Constants } from '../constant/constants';
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'app-modify-vic',
    templateUrl: './modify-vic.component.html',
    styleUrls: ['./modify-vic.component.css']
})

export class ModifyVICComponent {

    usersList = [];
    vicUsersList = [];
    secondaryVicUsersList = [];
    store: StoreObject = new StoreObject();
    project: ProjectObject = new ProjectObject();
    assignUserPermission = false;
    addStorePermission : boolean;
    loaderDialogRef:any;
    selectedTemplates : TemplateObject[];
    storeFunctionalAreaContext = {};
    storeId : string;
    
    constructor(private storeService : StoreService, private functionalAreaService: FunctionalAreaService,private authService: AuthService, private toastrService: ToastrService,
      private dialogRef: MatDialogRef<ModifyVICComponent>, @Inject(MAT_DIALOG_DATA) private data: any, private dialog: MatDialog) {
        dialogRef.disableClose = true;
      
    }
    ngOnInit() {

        this.assignUserPermission = this.authService.isAuthorised('DOT_ASSIGN_USERS');
        this.store = this.data.storeObj;
        this.getFunctionalAreasOfStore(this.store);
        this.storeId = this.data.storeObj.id;
        this.project = this.data.project;
        this.getUSersFromCommonServices();           
      
    }

    getUSersFromCommonServices() {
          
        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
            width: '300px',
            height: '150px',
            data: { message: "Fetching VICs..." }
        });
          
        this.authService.fetchCommonServicesUsersWithDotVICRole().subscribe((data: any) => {
            this.usersList = data;
            this.vicUsersList = this.usersList;
            this.secondaryVicUsersList = this.usersList;
            this.selectedTemplates.forEach((template, index) => {
                  if(template.vic && template.vic.loginId) {
                      let vics = this.usersList.filter(function(user) {return user.user.loginId === template.vic.loginId;});
                      if(vics.length > 0) {
                          template['selectedVic'] = vics[0].user;
                      }
                  } else {
            template['selectedVic'] = {};
                  }
                  if(template.secondaryVic && template.secondaryVic.loginId) {
                      let secondaryVics = this.usersList.filter(function(user) {return user.user.loginId === template.secondaryVic.loginId;});
                      if(secondaryVics.length > 0) {
                          template['selectedsecondaryVic'] = secondaryVics[0].user;
                      }
          } else {
            template['selectedsecondaryVic'] = {};
                  }
            });

          loaderDialogRef.close();
        },
        err => {
            console.log(err);
            loaderDialogRef.close();
        });
        
    }

    onFocusReloadVic(event: any, template: TemplateObject, vicType: string) {
        if (vicType === 'vic') {
            this.vicUsersList = this.usersList;
        }
        if (vicType === 'secondaryVic') {
            this.secondaryVicUsersList = this.usersList;
        }   
    }
  
    onChangeVicOrSecondaryVic(event: any, template: TemplateObject, vicType: string) {
        template[vicType] = event.value;
    }

    applyVICFilter(value: string, vicType: string) {
        if (value.trim()) {
            if (vicType === 'vic') {
                this.vicUsersList = Object.assign([], this.usersList).filter(
                    item => item.user.loginId.toLowerCase().indexOf(value.toLowerCase()) > -1
                );
            }
            if (vicType === 'secondaryVic') {
                this.secondaryVicUsersList = Object.assign([], this.usersList).filter(
                    item => item.user.loginId.toLowerCase().indexOf(value.toLowerCase()) > -1
                );
            }
        }
      value = "";
    }

    private getFunctionalAreasOfStore(store) {
        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
            width: '300px',
            height: '150px',
            data: { message: "Fetching functional area details." }
        });
        let storeId = store.recordType;
        let requests = [];
        if(storeId != null) {
            requests.push(this.storeService.getFunctionalAreasOfStore(storeId));
        }
            observableForkJoin(requests)
              .subscribe(data => {
                this.storeFunctionalAreaContext[storeId] = data[storeId.indexOf(storeId)];
                this.selectedTemplates = this.storeFunctionalAreaContext[storeId];
                loaderDialogRef.close();
              }, 
              ()=> {
                  this.toastrService.warning('Error occurred while saving store.');
                  loaderDialogRef.close();
              });

          
    }

    saveModifiedVIC(){
        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
            width: '300px',
            height: '150px',
            data: { message: "Updating store information..." }
        });
        this.functionalAreaService.saveFunctionalArea(this.store.recordType, this.store.storeName, this.project.projectNumber, this.selectedTemplates)
            .subscribe(data => {
                loaderDialogRef.close();
                this.dialogRef.close(); 
            }); 
    }

    closePopup() {
        this.dialogRef.close(Constants.POPUP_CANCEL);
    };
}

