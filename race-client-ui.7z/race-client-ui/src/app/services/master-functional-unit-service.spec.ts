import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, TestBed } from "@angular/core/testing"
import { MatDialogModule } from "@angular/material";
import { Observable } from "rxjs/Rx";
import { MasterFunctionalUnit } from "../model/master-functional-unit";
import { AuthService } from "./auth-service";
import { MasterFunctionalUnitService } from "./master-functional-unit-service";
import { ServerCommunicationService } from "./server-communication-service";

describe('MasterFunctionalUnitService', () => {

    let masterFunctionalUnitService: MasterFunctionalUnitService;
    beforeEach(async(() => {

        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule,
                MatDialogModule
            ],
            providers: [
                MasterFunctionalUnitService,AuthService,ServerCommunicationService
            ]
        });

        masterFunctionalUnitService = TestBed.get(MasterFunctionalUnitService);
    }));

    const master_functional_unit_post : MasterFunctionalUnit = {
        "functionalUnitName": "UI_Test",
        "functionalUnitType":null,
        "description": "UI_Test des",
        "version":null,
        "productCode": "SVC",
        "gridOptionsModel": {
          "rowSelection": "multiple",
          "animatedRows":true,
          "columnDefs": [],
          "rowData": []
        },
        "createdDate":null,
        "lastUpdatedDate":null,
        "propagationStarted": false,
        "id": null,
        "recordType": null

    }

    const master_functional_unit_response : MasterFunctionalUnit = {
        "functionalUnitType": "MasterFunctionalUnit",
        "functionalUnitName": "UI_Test",
        "gridOptionsModel": {
            "animatedRows": false,
            "rowSelection": "multiple",
             "columnDefs": [
            ],
            "rowData": []
        },
        "description": "UI_Test des",
        "version": 0,
        "productCode": "SVC",
        "createdDate": null,
        "lastUpdatedDate": null,
        "propagationStarted": false,
        "id": "3438dea1-54bd-4cb9-8c72-fca5088bed47",
        "recordType": "FunctionalUnitInfo"
    }

    const list_Of_masterfunctional_units : MasterFunctionalUnit[] = [
        {
           "functionalUnitType": "ChildFunctionalUnit",
           "id": "4093d28c-2916-4412-b5b6-c89a5a65eca7",
           "recordType": "6c44e2da-3bed-4773-87c0-ed257c861943",
           "functionalUnitName": "Departments",
           "description": "Departments",
           "gridOptionsModel": {
             "animatedRows": false,
             "rowSelection": "multiple",
             "columnDefs": [],
             "rowData": []
           },
           "createdDate":null,
           "lastUpdatedDate":null,
           "propagationStarted": false,
           "version": 0,
           "productCode": "ACCT"
         }
     ]

     const list_of_master_functional_unit_response: MasterFunctionalUnit[]=[
       {
           "functionalUnitType": "ChildFunctionalUnit",
           "functionalUnitName": "Departments",
           "gridOptionsModel": {
             "animatedRows": false,
             "rowSelection": "multiple",
             "columnDefs": [],
             "rowData": []
           },
           "description": "Departments",
           "version": 0,
           "productCode": "ACCT",
           "createdDate": null,
           "lastUpdatedDate": null,
           "propagationStarted": false,
           "id": "4093d28c-2916-4412-b5b6-c89a5a65eca7",
           "recordType": "6c44e2da-3bed-4773-87c0-ed257c861943"
         }
     ]



    it('should create the MasterFunctionalUnitService instance', () => {
        expect(masterFunctionalUnitService).toBeDefined();
    });

    it('should create the MasterFunctionalUnitService', () => {

        spyOn(masterFunctionalUnitService,'post').and.returnValue(Observable.of(master_functional_unit_response))
        masterFunctionalUnitService.createMasterFunctionalUnit(master_functional_unit_post)
                                 .subscribe((data:any)=>{
                                     expect(data).toBe(master_functional_unit_response);
                                 });
        expect(masterFunctionalUnitService.post).toHaveBeenCalledTimes(1);
        })                       

    it('should create multiple master functional units',()=>{

        spyOn(masterFunctionalUnitService,'post').and.returnValue(Observable.of(list_of_master_functional_unit_response))
        masterFunctionalUnitService.createMultipleFunctionalUnits(list_Of_masterfunctional_units)
                                   .subscribe((data:any)=>{
                                    expect(data).toBe(list_of_master_functional_unit_response);
                                   })
        expect(masterFunctionalUnitService.post).toHaveBeenCalledTimes(1);
        
    })

    it('should fetchMasterFunctionalUnitList',()=>{
        spyOn(masterFunctionalUnitService,'get').and.returnValue(Observable.of(list_of_master_functional_unit_response))
        masterFunctionalUnitService.fetchMasterFunctionalUnitList()
                                 .subscribe((data:any)=>{
                                  expect(data).toBe(list_of_master_functional_unit_response);
                                })
        expect(masterFunctionalUnitService.get).toHaveBeenCalledTimes(1);
    })

    
    it('test deleteMasterFunctionalUnit',()=>{
        spyOn(masterFunctionalUnitService,'post').and.returnValue(Observable.of())
        masterFunctionalUnitService.deleteMasterFunctionalUnit(master_functional_unit_post)
        expect(masterFunctionalUnitService.post).toHaveBeenCalledTimes(1);
    })

    it('test fetchFunctionalUnitsOfMasterFunctionalArea',()=>{
        let functionalAreaId = "4093d28c-2916-4412-b5b6-c89a5a65eca7";
        spyOn(masterFunctionalUnitService,'get').and.returnValue(Observable.of(list_of_master_functional_unit_response))
        masterFunctionalUnitService.fetchFunctionalUnitsOfMasterFunctionalArea(functionalAreaId)
                                  .subscribe((data:any)=>{
                                  expect(data).toBe(list_of_master_functional_unit_response);
                                 })
        expect(masterFunctionalUnitService.get).toHaveBeenCalledTimes(1);
    })

    it('test fetchFunctionalUnitByNameAndProductCode ',()=>{

        let functionalUnitName = "UI_Test";
        let productCode  = "SVC"; 
        
        spyOn(masterFunctionalUnitService,'get').and.returnValue(Observable.of(master_functional_unit_response))
        masterFunctionalUnitService.fetchFunctionalUnitByNameAndProductCode(functionalUnitName,productCode)
                                   .subscribe((data:any)=>{
                                       expect(data).toBe(master_functional_unit_response);
                                   })                         
        expect(masterFunctionalUnitService.get).toHaveBeenCalledTimes(1);

    })

    it('test fetchAllFunctionalUnitsByGOMModified ',()=>{
        
        spyOn(masterFunctionalUnitService,'get').and.returnValue(Observable.of(list_of_master_functional_unit_response))
        masterFunctionalUnitService.fetchAllFunctionalUnitsByGOMModified()
                                   .subscribe((data:any)=>{
                                       expect(data).toBe(list_of_master_functional_unit_response);
                                   })                         
        expect(masterFunctionalUnitService.get).toHaveBeenCalledTimes(1);

    })

    it('test fetchFUGomDifferences ',()=>{
        let functionalUnitId = "3438dea1-54bd-4cb9-8c72-fca5088bed47"
        spyOn(masterFunctionalUnitService,'get').and.returnValue(Observable.of(master_functional_unit_response))
        masterFunctionalUnitService.fetchFUGomDifferences(functionalUnitId)
                                   .subscribe((data:any)=>{
                                       expect(data).toBe(master_functional_unit_response);
                                   })                         
        expect(masterFunctionalUnitService.get).toHaveBeenCalledTimes(1);

    })

    it('test getMasterFunctionalUnitById ',()=>{
        let functionalUnitId = "5638dea1-54bd-4cb9-8c72-fca5088bed32"
        spyOn(masterFunctionalUnitService,'get').and.returnValue(Observable.of(master_functional_unit_response))
        masterFunctionalUnitService.getMasterFunctionalUnitById(functionalUnitId)
                                   .subscribe((data:any)=>{
                                       expect(data).toBe(master_functional_unit_response);
                                   })                         
        expect(masterFunctionalUnitService.get).toHaveBeenCalledTimes(1);

    })

    it('test propagateFuChangesToBP ',()=>{
        spyOn(masterFunctionalUnitService,'put').and.returnValue(Observable.of(list_of_master_functional_unit_response))
        masterFunctionalUnitService.propagateFuChangesToBP(list_Of_masterfunctional_units)
                                   .subscribe((data:any)=>{
                                       expect(data).toBe(list_of_master_functional_unit_response);
                                   })                         
        expect(masterFunctionalUnitService.put).toHaveBeenCalledTimes(1);

    })

    it('test discardModifiedFuChanges ',()=>{
        spyOn(masterFunctionalUnitService,'put').and.returnValue(Observable.of(master_functional_unit_response))
        masterFunctionalUnitService.discardModifiedFuChanges(master_functional_unit_post)
                                   .subscribe((data:any)=>{
                                    expect(data).toBe(master_functional_unit_response);
                                   })                         
        expect(masterFunctionalUnitService.put).toHaveBeenCalledTimes(1);

    })

});