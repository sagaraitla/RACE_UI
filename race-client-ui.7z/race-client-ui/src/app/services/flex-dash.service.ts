import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { AuthService } from './auth-service';
import { ScreenObject } from '../model/screen-object';
import { ProjectObject } from '../model/project-object';
import { TemplateObject } from '../model/template-object';
import { DashReport } from '../model/dash-report';
import { FlexApi } from '../model/flex-api-objects';

import {Observable, of } from 'rxjs';
import { FlexValidationService } from './flex-validation.service';
import { ServerCommunicationService } from './server-communication-service';

@Injectable()
export class FlexDashService {

    private host: string;
    private flexHost :string;
    private user: any = {};
    unsavedDataPresent = false; 
constructor(private http: HttpClient, private authService: AuthService
           ,private flexValidationService :FlexValidationService ,private serverCommunicationService :ServerCommunicationService) {
          this.http.get('assets/config',{withCredentials: true}).subscribe((data: any) => { 
          this.host = data.host;
          this.flexHost=data.flexApiHost;
          });
    this.user = this.authService.getLoggedInUser();
    }
importCOAData(cmfNumber:string,storeNumber:string) : Observable<any> {
    return this.serverCommunicationService.get_fileDownload('template/' + cmfNumber +'/'+storeNumber,'DOT_PROJECT_VIEW',true);
}

public importFlexData(flexApi:FlexApi):Observable<any>{
    return this.serverCommunicationService.flex_post(this.flexHost+"race-ui-map",flexApi,'DOT_PROJECT_VIEW', true);
}

exporPDFtReport(dashReport:DashReport) : Observable<any> {
    return this.serverCommunicationService.post_fileDownload('functionalunits/pdfReport',dashReport,'DOT_PROJECT_VIEW', true);
}
generateFileNameForExportPDF( projectNum : string, storeFullName : string, functionalArea : string ,functionalUnit : string) : string
{
    let todaysDate : any;
    let timeNow : any;
    let xlsxFileName : string;
    let functionalAreaFullName : string;
    todaysDate = new Date().toLocaleDateString();
    if( projectNum === null)
    {
        functionalAreaFullName = functionalArea;
    }
    else
    {
        functionalAreaFullName = projectNum+"-"+storeFullName+"-"+functionalArea+"-"+functionalUnit;
    }
    functionalAreaFullName = functionalAreaFullName.split(' ').join('_');
    functionalAreaFullName = functionalAreaFullName.toLowerCase();
    xlsxFileName = functionalAreaFullName+"-"+todaysDate+".pdf";
    return xlsxFileName;
}
bindFlexAPi(templateContext: any, currentScreenContext: any, gridApi:any,responseData :any){
    let funUnitObject : ScreenObject = null;
    templateContext.screenContextList.filter(
            (funUnitObject,index) => {
                let current_sheet_name = funUnitObject.screen.screenName;
                let data=responseData[current_sheet_name];
                if(data!==undefined){
                    funUnitObject.rowData = data;
                    funUnitObject.screen.rowDataEmpty = false;
                    this.dashResponse(funUnitObject,gridApi);
                    }
            gridApi.refreshCells();
            this.unsavedDataPresent = true;
            }
        );
}

dashResponse(funUnitObject,gridApi:any)
{
   this.dataSetToSave(funUnitObject).subscribe((response) =>{
    let gridOptions : any = funUnitObject.screen.gridOptionsModel;  
    this.flexValidationService.formatCharacterColumnData(gridOptions, funUnitObject.rowData);
    this.flexValidationService.formatDateColumnData(gridOptions, funUnitObject.rowData);
    this.flexValidationService.formatCurrencyColumnData(gridOptions, funUnitObject.rowData);
    this.flexValidationService.formatPercentageColumnData(gridOptions, funUnitObject.rowData,funUnitObject.screen.screenName);
    this.flexValidationService.formatBooleanColumnData(gridOptions, funUnitObject.rowData);
    this.flexValidationService.formatIntegerColumnData(gridOptions, funUnitObject.rowData);
    this.flexValidationService.formatDropDownColumnData(gridOptions, funUnitObject.rowData);
   });
}

dataSetToSave(funUnitObject):Observable<any>{
    let previousIndex : number = 0;
    let currentIndex : number = 0;
    let indexIncrementDefaultValue : number = 1000;
    let indexOfNewRow : number = indexIncrementDefaultValue;
    currentIndex =0;
    if (currentIndex !=0 && funUnitObject.rowData[currentIndex-1]) {
        previousIndex  = funUnitObject.rowData[currentIndex-1]['recordType'];
    }
    if (previousIndex == 0) { //If First Row
        indexOfNewRow = indexIncrementDefaultValue;
    }
    if (previousIndex != 0) { //If grid has some Rows already
        indexOfNewRow = Number.parseInt(previousIndex.toString()) +  Number.parseInt(indexIncrementDefaultValue.toString());
    }
    for(var i=0;i< funUnitObject.rowData.length;i++){
        funUnitObject.rowData[i]['id'] = funUnitObject.screen.recordType;
        funUnitObject.rowData[i]['recordType'] = indexOfNewRow;
        indexOfNewRow += indexIncrementDefaultValue;
        funUnitObject.rowData[i]['index'] = i;
        if(funUnitObject.rowData[i].hasOwnProperty('error')){
            delete funUnitObject.rowData[i]['error'];
        }
       if(funUnitObject.rowData[i].hasOwnProperty('rowDataId') && funUnitObject.rowData[i]['rowDataId'] !=null)
        funUnitObject.rowData[i]['isUpdated'] = true;
    }
    return of(funUnitObject);
}
isUnsavedDataPresent() : boolean{
    return this.unsavedDataPresent;
}

resetUnsavedDataPresent() {
    this.unsavedDataPresent = false;
}

statusUpdateFunctionalArea(functionalArea : TemplateObject,storeId: string, functionalAreaId: string) {
     const url = 'template/updateFAStatusOnDealerAction/'+storeId+"/"+functionalAreaId;
     if(functionalArea.status==="requestDealerForApproval"){
        return this.serverCommunicationService.put(url,functionalArea,'DOT_TEMPLATE_UPDATE', true);
     }else{
        return this.serverCommunicationService.put(url,functionalArea,'RACE_FUNCTIONAL_AREA_STATUS_UPDATE', true);
     }   
     
 }
 
 importGLRawData(cmfNumber:string,storeNumber:string) : Observable<any> {
    return this.serverCommunicationService.get_fileDownload('template/gl-account-raw-data/' + cmfNumber +'/'+storeNumber,'DOT_PROJECT_VIEW',true);
}

}