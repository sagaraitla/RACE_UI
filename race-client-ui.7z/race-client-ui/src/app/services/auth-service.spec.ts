import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AuthService } from './auth-service';
import { MatDialog, MatDialogModule, MatDialogRef } from '@angular/material';
import { of } from 'rxjs';

describe('AuthService', () => {

    let authService: AuthService;
    let httpMock: HttpTestingController;

    const hostConfig: any = {
        "production": false,
        "host": "http://localhost:8080/",
        "cshost": "https://api-dit.connectcdk.com/",
        "refreshToken": "8adaf13a-06c5-4cd1-bca5-70edf23323fc"
    }

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule,
                MatDialogModule
            ],
            providers: [
                AuthService
            ],
        });

        authService = TestBed.get(AuthService);
        httpMock = TestBed.get(HttpTestingController);

        // Catches the call from the constructor
        httpMock.expectOne({
            url: 'assets/config',
            method: 'get'
        }).flush(hostConfig);

        httpMock.verify();
        authService['user'] = user;
    });

    const getItem: any = {
        "users": [

            {
                "user": {
                    "loginId": "cdkDitUser@dit.com"
                }
            },
            {
                "user": {
                    "loginId": "samplerace@dit.com"
                }
            },
            {
                "user": {
                    "loginId": "raceQaUser@dit.com"
                }
            },
            {
                "user": {
                    "loginId": "samplerace@dit.com"
                }
            }]
    };

    const expectedOutput = [
        {
            "user": {
                "loginId": "cdkDitUser@dit.com"
            }
        },
        {
            "user": {
                "loginId": "raceQaUser@dit.com"
            }
        },
        {
            "user": {
                "loginId": "samplerace@dit.com"
            }
        },
        {
            "user": {
                "loginId": "samplerace@dit.com"
            }
        }];

    const getItemNegativeResponse: any = {
        "users": null
    }

    const user = {
        "user": {
            "loginId": "race@cdk.com"
        },
        "enterprise": {
            "id": "E000000"
        },
        "roles": [
            {
                "roleGuid": "67D36FE42B053DCCE053440B63645BAA",
                "roleName": "DOT - Developer"
            },
            {
                "roleGuid": "6880D57A2BF26D87E053440B6364AB6D",
                "roleName": "DOT - PROJECT MANAGER"
            }
        ]
    };

    const loggedInUserPermissions = [
        {
            "permission": "DOT_STORE_DELETE",
            "displayName": "Delete Store"
        },
        {
            "permission": "LNKUSERALTID",
            "displayName": "Link/Unlink User Alternate IDs"
        },
        {
            "permission": "DOT_PROJECT_VIEW_ALL",
            "displayName": "View All Projects"
        }
    ];

    const project: any = {
        "projectManager": "race@cdk.com",
        "clientProjectAdvocate": [
            {
                "loginId": "race@cdk.com"
            }
        ],
        "clientStoreAdvocate": [
            {
                "loginId": "race@cdk.com"
            }
        ],
        "clientFunctionalAreaUser": [
            {
                "loginId": "race@cdk.com"
            }
        ]
    };

    it('should create the authService', () => {
        expect(authService).toBeDefined();
    });

    it('should fetch Logged in user', () => {
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of({}), close: null });
        dialogRefSpyObj.componentInstance = { body: '' }; // attach componentInstance to the spy object...
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        authService['user'] = null;
        const loggedInUser = {
            "fullUser": {
                "user": {
                    "loginId": "race@cdk.com"
                },
                "enterprise": {
                    "id": "E000000"
                },
                "roles": [
                    {
                        "roleGuid": "67D36FE42B053DCCE053440B63645BAA",
                        "roleName": "DOT - Developer"
                    },
                    {
                        "roleGuid": "6880D57A2BF26D87E053440B6364AB6D",
                        "roleName": "DOT - PROJECT MANAGER"
                    }
                ]
            }
        };

        authService.fetchLoggedInUser()
            .subscribe((data: any) => {
                expect(data).toEqual(user);
            });

        let hostConfigReq = httpMock.expectOne('assets/config');
        expect(hostConfigReq.request.method).toBe("GET");
        hostConfigReq.flush(hostConfig);

        let getUserInfoReq = httpMock.expectOne(authService['cshost'] + 'identityservice/1.0/rest/users/me');
        expect(getUserInfoReq.request.method).toBe("GET");

        getUserInfoReq.flush(loggedInUser);
        httpMock.verify();

    });

    it('should fetch Logged in user from cache', () => {
        authService.fetchLoggedInUser()
            .subscribe((data: any) => {
                expect(data).toEqual(user);
            });
        expect(authService.fetchLoggedInUser).toHaveBeenCalled;
    });

    it('should fetch Logged in user permissions', () => {
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of({}), close: null });
        dialogRefSpyObj.componentInstance = { body: '' }; // attach componentInstance to the spy object...
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        authService.fetchLoggedInUsersPermissions()
            .subscribe((data: any) => {
                expect(data).toEqual(loggedInUserPermissions);
                expect(data.length).toBe(3);
            });

        let hostConfigReq = httpMock.expectOne('assets/config');
        expect(hostConfigReq.request.method).toBe("GET");
        hostConfigReq.flush(hostConfig);

        let authPermissionReq = httpMock.expectOne(authService['host'] + 'auth/permissions');
        expect(authPermissionReq.request.method).toBe("GET");

        authPermissionReq.flush(loggedInUserPermissions);
        httpMock.verify();

    });

    it('should fetch Logged in user permissions from cache', () => {
        authService['loggedInUserPermissions'] = loggedInUserPermissions;
        authService.fetchLoggedInUsersPermissions()
            .subscribe((data: any) => {
                expect(data).toEqual(loggedInUserPermissions);
                expect(data.length).toBe(3);
            });
        expect(authService.fetchLoggedInUsersPermissions).toHaveBeenCalled;
    });

    it('should fetch loggedIn user details and permissions', () => {

        spyOn(authService, 'fetchLoggedInUser').and.returnValue(of(user));
        spyOn(authService, 'fetchLoggedInUsersPermissions').and.returnValue(of(loggedInUserPermissions));
        authService.fetchLoggedInUserAndPermissions().subscribe((data: any) => {
            expect(authService.fetchLoggedInUser).toHaveBeenCalled;
            expect(authService.fetchLoggedInUsersPermissions).toHaveBeenCalled;

        });

    });

    it('should check logged in user has authorized or not', () => {
        authService['loggedInUserPermissions']  = loggedInUserPermissions;
        authService.isAuthorised('DOT_STORE_DELETE');
        expect(authService.isAuthorised).toBeTruthy;
    });

    it('should check logged in user has authorized or not', () => {
        authService['loggedInUserPermissions']  = loggedInUserPermissions;
        expect(authService.isAuthorised('DOT_TEMPLATE_UPDATE')).toBeFalsy;
    });

    it('should get Logged In user', () => {
        expect(authService.getLoggedInUser()).toHaveBeenCalled;
    });

    it('should fetch loggedIn user loginId', () => {
        expect(authService.getLoggedInUsersLoginId()).toEqual('race@cdk.com');

    });

    it('should not  fetch loggedIn user loginId', () => {
        authService['user'] = null;
        expect(authService.getLoggedInUsersLoginId()).toBeNull;

    });

    it(`should fetch common services dealership users`, () => {
        authService.fetchCommonServicesDealershipUsers('E000000')
            .subscribe((data: any) => {
                expect(data.length).toBe(4);
                expect(data).toEqual(expectedOutput);
            });

        let req = httpMock.expectOne(authService['host'] + 'auth/users/dealership');
        expect(req.request.method).toBe("GET");

        req.flush(getItem);
        httpMock.verify();

    });

    it(`shouldn't fetch common services users dealership users`, () => {
        authService.fetchCommonServicesDealershipUsers('E000000')
            .subscribe((data: any) => {
                expect(data).toEqual(0);
            });

        let req = httpMock.expectOne(authService['host'] + 'auth/users/dealership');
        expect(req.request.method).toBe("GET");

        req.flush(getItemNegativeResponse);
        httpMock.verify();

    });

    it(`should fetch common services users`, () => {
        authService.fetchCommonServicesUsers()
            .subscribe((data: any) => {
                expect(data).toEqual(getItem);
            });

        let req = httpMock.expectOne(authService['host'] + 'auth/users/dealership');
        expect(req.request.method).toBe("GET");

        req.flush(getItem);
        httpMock.verify();

    });

    it(`should fetch common services users with DOT - VIC role`, () => {
        authService.fetchCommonServicesUsersWithDotVICRole()
            .subscribe((data: any) => {
                expect(data.length).toBe(4);
                expect(data).toEqual(expectedOutput);
            });

        let req = httpMock.expectOne(authService['host'] + 'auth/users/role');
        expect(req.request.method).toBe("GET");

        req.flush(getItem);
        httpMock.verify();

    });

    it(`shouldn't fetch common services users DOT - VIC role`, () => {
        authService.fetchCommonServicesUsersWithDotVICRole()
            .subscribe((data: any) => {
                expect(data).toEqual(0);
            });

        let req = httpMock.expectOne(authService['host'] + 'auth/users/role');
        expect(req.request.method).toBe("GET");

        req.flush(getItemNegativeResponse);
        httpMock.verify();

    });

    it(`should fetch common services users with DOT - PROJECT MANAGER role`, () => {
        authService.fetchCommonServicesUsersWithManagerRole()
            .subscribe((data: any) => {
                expect(data.length).toBe(4);
                expect(data).toEqual(expectedOutput);
            });

        let req = httpMock.expectOne(authService['host'] + 'auth/users/role');
        expect(req.request.method).toBe("GET");

        req.flush(getItem);
        httpMock.verify();

    });

    it(`shouldn't fetch common services users with DOT - PROJECT MANAGER role`, () => {
        authService.fetchCommonServicesUsersWithManagerRole()
            .subscribe((data: any) => {
                expect(data).toEqual(0);
            });

        let req = httpMock.expectOne(authService['host'] + 'auth/users/role');
        expect(req.request.method).toBe("GET");

        req.flush(getItemNegativeResponse);
        httpMock.verify();

    });

    it(`should fetch common services users with DOT role`, () => {
        authService.fetchCommonServicesUsersWithDotRole()
            .subscribe((data: any) => {
                expect(data.length).toBe(4);
                expect(data).toEqual(expectedOutput);
            });

        let req = httpMock.expectOne(authService['host'] + 'auth/users/role');
        expect(req.request.method).toBe("GET");

        req.flush(getItem);
        httpMock.verify();

    });

    it(`shouldn't fetch common services users with DOT role`, () => {
        authService.fetchCommonServicesUsersWithDotRole()
            .subscribe((data: any) => {
                expect(data).toEqual(0);
            });

        let req = httpMock.expectOne(authService['host'] + 'auth/users/role');
        expect(req.request.method).toBe("GET");

        req.flush(getItemNegativeResponse);
        httpMock.verify();

    });

    it(`should fetch common services users with DOT - Dealer Approver role`, () => {
        authService.fetchCommonServicesUsersWithDealerApproverRole('E000000')
            .subscribe((data: any) => {
                expect(data.length).toBe(4);
                expect(data).toEqual(expectedOutput);
            });

        let req = httpMock.expectOne(authService['host'] + 'auth/users/dealerApproverRole');
        expect(req.request.method).toBe("GET");

        req.flush(getItem);
        httpMock.verify();

    });

    it('check loggedIn user has a CDK Internal User', () => {
        expect(authService.isCDKInternalUser()).toBeTruthy;
    });

    it('check loggedIn user has a CDK Internal User', () => {
        user.enterprise.id = 'E000030';
        expect(authService.isCDKInternalUser()).toBeFalsy;
    });

    it('check if logged in user has a given Role', () => {
        expect(authService.checkIfLoggedInUserHasRole('DOT - Developer')).toBeTruthy;
    });

    it('check if logged in user should not have the given Role', () => {
        expect(authService.checkIfLoggedInUserHasRole('DOT - ADMINISTRATOR')).toBeFalsy;
    });

    it('check if logged in user is client ProjectAdvocate', () => {
        expect(authService.checkIfLoggedInUserIsClientProjectAdvocate(project)).toBeTruthy;
    });

    it('check if logged in user is client StoreAdvocate', () => {
        expect(authService.checkIfLoggedInUserIsClientStoreAdvocate(project)).toBeTruthy;
    });

    it('check if logged in user is client FunctionalAreaUser', () => {
        expect(authService.checkIfLoggedInUserIsClientFunctionalAreaUser(project)).toBeTruthy;
    });

    it('check if logged in user is a Project Manager', () => {

        expect(authService.checkIfLoggedInUserIsProjectManager(project)).toBeTruthy;
    });

    it(`shouldn't fetch common services users with DOT - Dealer Approver role`, () => {
        authService.fetchCommonServicesUsersWithDealerApproverRole('E000000')
            .subscribe((data: any) => {
                expect(data).toEqual(0);
            });

        let req = httpMock.expectOne(authService['host'] + 'auth/users/dealerApproverRole');
        expect(req.request.method).toBe("GET");

        req.flush(getItemNegativeResponse);
        httpMock.verify();

    });


});