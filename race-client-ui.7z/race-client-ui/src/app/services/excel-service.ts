
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { ScreenObject } from '../model/screen-object';
import * as XLSX from 'xlsx';

import {HttpClient} from '@angular/common/http';
import { AuditLogService } from './audit-log-service';
import { ValidationService } from './validation-service';
import { FormattingService } from './formatting-service';
import {ImportDialog} from '../import-dialog/import-dialog.component';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { AlertDialogComponent } from '../alert-dialog/alert-dialog.component';
import { TemplateObject } from '../model/template-object';
import { ServerCommunicationService } from './server-communication-service';
import { Constants } from '../constant/constants';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';

@Injectable()
export class ExcelService
{
    screenDataFromXls : any[];
    unsavedDataPresent = false;    
    private host: string;   
    importScreenList : string[];
    importResult : string[];
    loaderDialog : MatDialog;
  
        constructor(private http: HttpClient, private auditLogService : AuditLogService, private validationService: ValidationService,
        		private formattingService : FormattingService, private dialog : MatDialog,private serverCommunicationService :ServerCommunicationService) {
             this.http.get('assets/config',{withCredentials: true}).subscribe((data: any) => { 
              this.host = data.host;
            });            
        }
    

// upload xlsx file to import all or some sheets of Best Practice XLSX
    importXLSXFile(files: FileList, templateContext: any, currentScreenContext: any, gridApi:any){
        this.importResult = [];
        let fileToUpload = files.item(0);
        let fileReader = new FileReader();
        var current_sheet_name;
        var worksheet;
        let validXlsStatusFlag = false;
        let arrayBuffer:any;
        let sheetNames = [];
        fileReader.readAsArrayBuffer(fileToUpload); 
        
        fileReader.onload = (event:Event) => {            
            arrayBuffer = fileReader.result;
            var data = new Uint8Array(arrayBuffer);
            var arr = new Array();
            for(var i=0;i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
            var bstr = arr.join("");
            var workbook = XLSX.read(bstr, {type:'binary', cellDates:true, cellNF:false, cellText:false});
            let funUnitObject : ScreenObject = null;
            for(let sheet of workbook.SheetNames) {
                sheetNames.push(sheet.trim());
            }
            let loaderDialog = this.dialog.open(LoaderDialogueComponent, {
                width: '300px',
                height: '150px',
                data: { message: 'Importing Data for Screens...' }
            });
            let dialogRef = this.dialog.open(ImportDialog, {
                width : '30%',
                height : 'auto',                
                data: { sheetList : sheetNames}
            });
              dialogRef.afterClosed().subscribe(result => {
                this.importScreenList = result;                    
                          
                templateContext.screenContextList.filter(
                    (funUnitObject,index) => {
                        current_sheet_name = funUnitObject.screen.screenName;
                        if (this.importScreenList && this.importScreenList.indexOf(current_sheet_name) > -1)
                        {
                            /* Updating workbook or XLSX contents is not possible, so by passing 
                               correct sheet name we try to fetch sheet name before trim of 
                               leading or trailing spaces, this sheet name is helpful for 
                               retrieving worksheet from workbook  */
                                    
                            let indexOfSheetName = sheetNames.indexOf(current_sheet_name);
                            let sheet_name_before_trim = workbook.SheetNames[indexOfSheetName];
                            worksheet = workbook.Sheets[sheet_name_before_trim];
                            validXlsStatusFlag = this.validateXlsFile(current_sheet_name, worksheet, funUnitObject);
                            if(validXlsStatusFlag)
                            {
                                this.loadSheetOfXlsFile(worksheet,funUnitObject,currentScreenContext.screen,gridApi);
                                this.importResult.push("Import Successful for FunctionalUnit ::"+current_sheet_name+"::"); 
                                let indexValue=0;                                                                                                                                                                                        
                                for(let row of funUnitObject.rowData) 
                                {
                                    row['index'] =indexValue;
                                    if(row.hasOwnProperty('error')) {
                                        let rowErrors = row['error']
                                        rowErrors.rowIndex=indexValue;
                                    }
                                    indexValue++;
                                }
                                if (funUnitObject.rowData.length !== 0) {
                                    funUnitObject.screen.rowDataEmpty = false;
                                }
                                gridApi.refreshCells();
                                
                            }
                        }
                    }
                );
                if(this.importResult.length > 0)
                {   
                    let alertDialogRef = this.dialog.open(AlertDialogComponent, {
                                            width : 'auto',
                                            height : 'auto',
                                            data : { messageListArray : this.importResult}
                    });
                }
                loaderDialog.close();
              });
        };
     }

    // Validate input xlsx sheet headers against the corresponding grid headers of Functional Unit in the UI. 
    validateXlsFile(current_sheet_name: any, currentWorkSheet: any, screenContext : any) : boolean
    {
       let gridOptions : any = screenContext.screen.gridOptionsModel;
       let validateFlag : boolean = false;
       this.screenDataFromXls = XLSX.utils.sheet_to_json(currentWorkSheet, {dateNF:'mm/dd/yyyy'});
       var screenHeaderList: any[];
       screenHeaderList = XLSX.utils.sheet_to_json(currentWorkSheet,{header:1});
       var xlsHeaders: string[] = screenHeaderList[0];
       var missingHeaders: string[]=[];
       var headerCounter:number = 0;
       for(var headerIndex=0;headerIndex<gridOptions.columnDefs.length;headerIndex++)
       {
           if (xlsHeaders.indexOf(gridOptions.columnDefs[headerIndex].headerName)>=0)
           {
              headerCounter++;              
           }
           else
           {
               missingHeaders.push(gridOptions.columnDefs[headerIndex].headerName);
           }
           
       }
       if(current_sheet_name === screenContext.screen.screenName && headerCounter === gridOptions.columnDefs.length)
       {
           validateFlag = true;
       }
       else
       {
           this.importResult.push("Import Failed for FunctionalUnit ::" + current_sheet_name + ":: due to missing Columns :"+JSON.stringify(missingHeaders));
       }

        return validateFlag;
    }

    /*
    Method Name: loadSheetOfXlsFile
    Parameters:
        currentWorkSheet : Sheet from XLSX file to process
        screenContext  : Screen Context object which is supposed to get processed
        currentScreenContext : screen of Screen Context
        gridApi : grid of Functional Area used to control its data after import.
    Method Description: This method will load one sheet at a time to the Functional Unit in the UI
    */ 
    loadSheetOfXlsFile(currentWorkSheet : any, screenContext : any, currentScreenContext : any, gridApi : any)
    {
        var screenHeaderList: any[];
        let previousIndex : number = 0;
        let currentIndex : number = 0;
        let indexIncrementDefaultValue : number = 1000;
        let indexOfNewRow : number = indexIncrementDefaultValue;
        currentIndex = screenContext.rowData.length;
        if (currentIndex !=0 && screenContext.rowData[currentIndex-1]) {
            previousIndex  = screenContext.rowData[currentIndex-1]['recordType'];
        }
        if (previousIndex == 0) { //If First Row
            indexOfNewRow = indexIncrementDefaultValue;
        }
        if (previousIndex != 0) { //If grid has some Rows already
        	indexOfNewRow = Number.parseInt(previousIndex.toString()) +  Number.parseInt(indexIncrementDefaultValue.toString());
        }
        screenHeaderList = XLSX.utils.sheet_to_json(currentWorkSheet,{header:1});
        var xlsHeaders: string[] = screenHeaderList[0];
        let gridOptions : any = screenContext.screen.gridOptionsModel;  
        
        this.formatCurrencyColumnData(gridOptions, screenHeaderList);
        
        this.formatPercentageColumnData(gridOptions, screenHeaderList);

        this.formatBooleanColumnData(gridOptions, screenHeaderList);

        this.formatIntegerColumnData(gridOptions, screenHeaderList);

        this.formatCharacterColumnData(gridOptions, screenHeaderList);

        this.formatDateColumnData(gridOptions, screenHeaderList);
        
        this.formatDropDownColumnData(gridOptions, screenHeaderList);

      
    
            for(var xlsIndex=0;xlsIndex<this.screenDataFromXls.length;xlsIndex++)
            {
                // for each single row of xls sheet rowData below code gets executed.
                for(var KeyId in xlsHeaders)
                {                        
                    var key : string= xlsHeaders[KeyId];     
                    var newKey : string = key.toLowerCase();
                    newKey = newKey.replace(/([\s]+|'|\.|\/)/g, '_');                    
                    this.screenDataFromXls[xlsIndex][newKey]=(this.screenDataFromXls[xlsIndex][key]) ? (this.screenDataFromXls[xlsIndex][key].trim()) : (this.screenDataFromXls[xlsIndex][key]);                                        
                    // iterate through all headers of grid to find right match of xls header inorder to update it.
                    for(var columnDefIndex =0 ; columnDefIndex < gridOptions.columnDefs.length ; columnDefIndex ++)
                    {
                        const currentColumnDef : any = gridOptions.columnDefs[columnDefIndex];
           
                        if (newKey === currentColumnDef.field)
                        {                           
                            if(currentColumnDef.defaultValue != undefined || currentColumnDef.defaultValue != ""  )
                            { 
                                // When column in xls has empty value but default value is not empty then set column value to default value.
                                if(this.screenDataFromXls[xlsIndex][newKey] === "" || this.screenDataFromXls[xlsIndex][newKey] === undefined)
                                {    
                                    this.screenDataFromXls[xlsIndex][newKey] = currentColumnDef.defaultValue; 
                                }
                            }                    
                        }         
                    }
                    // if newKey is different from oldKey delete the duplicate.
                    if(!(key.trim() === newKey.trim()))
                    {                            
                        delete this.screenDataFromXls[xlsIndex][key];                    
                    }
                }
	            this.unsavedDataPresent = true;
	            if(!Array.isArray(screenContext.rowData)) {
	            	screenContext.rowData = [];
                }
                this.screenDataFromXls[xlsIndex]['id'] = screenContext.screen.recordType;
                this.screenDataFromXls[xlsIndex]['recordType'] = indexOfNewRow;
                indexOfNewRow += indexIncrementDefaultValue;

                if(this.screenDataFromXls[xlsIndex].hasOwnProperty('error')) {
                    let rowErrors = this.screenDataFromXls[xlsIndex]['error']
                    rowErrors.rowIndex=screenContext.rowData.length;
                }

                screenContext.rowData.push(this.screenDataFromXls[xlsIndex]);
	            if(screenContext.screen.screenName === currentScreenContext.screenName) {
	            	gridApi.updateRowData({add: [this.screenDataFromXls[xlsIndex]]});
                    gridApi.refreshCells();
	            }
            }            
    }

    /*
    Method Name: getTemplateXls
    Body : 
        templateObject - it is the template object (or) functional area used to perform Post operation on REST URI
    This method returns XLSX file as a response of functional area with only headers for respective template object passed to this.
    */
    getTemplateXls(templateObject:TemplateObject) : Observable<any> {
        const url = this.host + 'template/excel';
        let headers = this.serverCommunicationService.getHeaders('DOT_PROJECT_VIEW','POST', true);
        headers = headers.append('Content-Type', 'application/json');
        const options : any = { headers: headers,responseType:'blob' , withCredentials: true};
        return this.http.post(url, templateObject, options);
    }

    /*
    Method Name: getTemplateXlsWithData
    Parametres : 
        templateId - it is the id of template (or) functional area used to perform GET operation on REST URI
    This method returns JSON response of functional area with headers along with rowdata for respective id passed to this. 
    */
    getTemplateXlsWithData(templateObject:TemplateObject) : Observable<any> {
        const options :any = {headers : this.serverCommunicationService.getHeaders('DOT_PROJECT_VIEW','GET', true), responseType:'blob',withCredentials:true};           
        const apiUrl = this.host+ 'template/excelwithdata';
        return this.http.post(apiUrl, templateObject, options);
    }

    /*
    Method Name: getScreenCsv
    Parametres : 
    functionalAreaId - it is the id of template (or) functional area used to perform GET operation on REST URI
    functionalUnitId - it is id of screen or functional unit used to perform GET operation on REST URI.
    This method returns JSON response of functional unit with headers along with rowdata.
    */
    getScreenCsv(functionalAreaId:string,functionalUnitId:string) : Observable<any> {
    const options :any = {headers : this.serverCommunicationService.getHeaders('DOT_PROJECT_VIEW', 'GET', true), responseType:'blob', withCredentials:true};
   return this.http.get(this.host + 'template/' + functionalAreaId + '/' + functionalUnitId + '/csvwithdata', options);
    
    }


    /*
    Method Name: generateFileNameForExportXls
    Parametres : 
        projectNum : Project Number
        storeFullName : Store Name
        functionalArea : Name of Functional Area on which export is run
    This method returns file name of xls file to be created during export operation. 
    */
    generateFileNameForExportXls( projectNum : string, storeFullName : string, functionalArea : string) : string
    {
        let todaysDate : any;
        let timeNow : any;
        let xlsxFileName : string;
        let functionalAreaFullName : string;
        todaysDate = new Date().toLocaleDateString();
        timeNow =  new Date().toLocaleTimeString();
        if( projectNum === null)
        {
            functionalAreaFullName = functionalArea;
        }
        else
        {
            functionalAreaFullName = projectNum+"-"+storeFullName+"-"+functionalArea;
        }
        functionalAreaFullName = functionalAreaFullName.split(' ').join('_');
        functionalAreaFullName = functionalAreaFullName.toLowerCase();
        xlsxFileName = functionalAreaFullName+"-"+todaysDate+"-"+timeNow+".xlsx";
        return xlsxFileName;
    }


    /*
    Method Name: generateFileNameForExportCSV
    Parametres : 
    projectNumber : Project Number
    storeName : Store Name
    functionalArea : Name of Functional Area on which export is run
    functionalUnit : Name of Functional Unit on which export csv is run
    This method returns file name of csv file to be created during export operation. 
    */
    generateFileNameForExportCSV(projectNumber: string, storeName : string, functionalArea: string, functionalUnit : string) : string
    {
        let todaysDate : any;
        let timeNow : any;
        todaysDate = new Date().toLocaleDateString();        
        timeNow =  new Date().toLocaleTimeString();
        let csvFileName : string;
        if(projectNumber === null)
        {
            csvFileName = functionalArea+"-"+functionalUnit+"-"+todaysDate+"-"+timeNow+".csv";
        }
        else
        {
            csvFileName = projectNumber+"-"+storeName+"-"+functionalArea+"-"+functionalUnit+"-"+todaysDate+"-"+timeNow+".csv";
        }
        csvFileName = csvFileName.split(' ').join('_');
        csvFileName = csvFileName.toLowerCase();
        return csvFileName;
    }

    private formatBooleanColumnData(gridOptions : any, screenHeaderList: any[]) {
        let booleanFiledValue :any;
        let headers: string[] = [];
        let headerRequiredMap = new Map();
    	let errorList = [];
    	let field: string = '';
		for(let columnDef of gridOptions.columnDefs) {
			if(columnDef.dataType == 'BOOLEAN') {
                headers.push(columnDef.headerName);
                headerRequiredMap.set(columnDef.headerName,columnDef.required);
			}
        }
        let xlsHeaders: string[] = screenHeaderList[0];
        if(headers.length > 0) {
        	for(let header of headers) {
                let headerRequired = headerRequiredMap.get(header);
        		let currentIndex = xlsHeaders.indexOf(header);
        		for(let rowIndex in screenHeaderList) {
        			let index: number = parseInt(rowIndex);
        			if(index > 0) {
                     booleanFiledValue = screenHeaderList[index][currentIndex];
                     if(this.isHeaderContainValueForNotRequiredField(headerRequired, booleanFiledValue) || headerRequired === "true" || headerRequired === true){
        				if(!this.validationService.isBooleanHeaderValueValid(booleanFiledValue)){
                            let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
        					if(columnDefs.length > 0) {
        						field = columnDefs[0].field;
        						let error = {
                                        errorDescription: 'Boolean value is invalid. Please enter correct value',
            							errorField: field,
            							errorLevel: '',
            							isUpdated: false
            					}
        						let row = this.screenDataFromXls[index - 1];
        						if(row.hasOwnProperty('error')) {
        							let rowErrors = row['error']['errors']
        							if(rowErrors) {
        								rowErrors.push(error);
        							} else {
        								row['error']['errors'] = [error];
        							}
        						} else {
        							row['error'] = {
        								rowIndex : 	index - 1,
        								timeStamp : '',
        								errors : [error]
        							}
        						}
        					}
                        } else{
                            this.screenDataFromXls[index - 1][header] = this.formattingService.getFormattedBooleanValue(booleanFiledValue);;
                        }
                      }
        			}
        		};
        	};
        }
    }
    
    private formatDropDownColumnData(gridOptions : any, screenHeaderList: any[]) {
        let formattedDropdownValue :any;
        let headers: string[] = [];
        let headerlengthMap = new Map();  
        let headerRequiredMap = new Map();
        let dropdownValueMap =new Map();
        let defaultValueMap =new Map();
        let field: string = '';
        let fieldRequiredValue: string ='';
		for(let columnDef of gridOptions.columnDefs) {
			if(columnDef.dataType == 'DROPDOWN') {
               headers.push(columnDef.headerName);
               headerlengthMap.set(columnDef.headerName,columnDef.dataLength);
               headerRequiredMap.set(columnDef.headerName,columnDef.required);
               dropdownValueMap.set(columnDef.headerName,columnDef.cellEditorParams.values);
               defaultValueMap.set(columnDef.headerName,columnDef.defaultValue);
            }
        }
        let xlsHeaders: string[] = screenHeaderList[0];
        if(headers.length > 0) {
        	for(let header of headers) {
                let headerDataLength = headerlengthMap.get(header);
                let headerRequired = headerRequiredMap.get(header);
                let dropdownValue=dropdownValueMap.get(header);
                let currentIndex = xlsHeaders.indexOf(header);
                let fieldDefaultValue=defaultValueMap.get(header);
        		for(let rowIndex in screenHeaderList) {
        			let index: number = parseInt(rowIndex);
        			if(index > 0) {
                        formattedDropdownValue = screenHeaderList[index][currentIndex];
                        if(this.isHeaderContainValueForNotRequiredField(headerRequired,formattedDropdownValue) || headerRequired === "true"|| headerRequired === true){
                            if(!this.validationService.isDropdownHeaderValueisValid(formattedDropdownValue,dropdownValue)){
                                if(!(formattedDropdownValue===undefined && fieldDefaultValue!="")){
                               let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
                               if(columnDefs.length > 0) {
                                   field = columnDefs[0].field;
                                   let error: any;
                                      if(formattedDropdownValue === undefined){
                                       error = {
                                           errorDescription: 'Dropdown value Empty. Please check the value',
                                           errorField: field,
                                           errorLevel: 'required',
                                           isUpdated: false
                                       }
                                   }else {
                                    var res=dropdownValue.find(x => x.toLocaleLowerCase()===formattedDropdownValue.toLocaleLowerCase());
                                    if(res===undefined){
                                       error = {
                                           errorDescription: 'Dropdown value is Invalid. Please check the value',
                                           errorField: field,
                                           errorLevel: 'invalid',
                                           isUpdated: false
                                       } 
                                    }
                                   }
                                
                                   let row = this.screenDataFromXls[index - 1];
                                   if(row.hasOwnProperty('error')) {
                                       let rowErrors = row['error']['errors']
                                       if(rowErrors) {
                                           rowErrors.push(error);
                                       } else {
                                           row['error']['errors'] = [error];
                                       }
                                   } else {
                                       row['error'] = {
                                           rowIndex : 	index - 1,
                                           timeStamp : '',
                                           errors : [error]
                                       }
                                   }
                               }
                            }
                           } else{
                               if(dropdownValue.includes(formattedDropdownValue)){
                               this.screenDataFromXls[index - 1][header] = formattedDropdownValue;}
                               else{
                                var res=dropdownValue.find(x => x.toLocaleLowerCase()===formattedDropdownValue.toLocaleLowerCase());
                                this.screenDataFromXls[index - 1][header] = res;
                               }
                           }
                        }  
                      }
        		};
        	};
        }
    }
    private formatIntegerColumnData(gridOptions : any, screenHeaderList: any[]) {
        let formattedIntegerValue :any;
        let headers: string[] = [];
        let headerlengthMap = new Map();  
        let headerRequiredMap = new Map();
    	let errorList = [];
        let field: string = '';
        let fieldRequiredValue: string ='';
		for(let columnDef of gridOptions.columnDefs) {
			if(columnDef.dataType == 'INT') {
               headers.push(columnDef.headerName);
               headerlengthMap.set(columnDef.headerName,columnDef.dataLength);
               headerRequiredMap.set(columnDef.headerName,columnDef.required);
			}
        }
        let xlsHeaders: string[] = screenHeaderList[0];
        if(headers.length > 0) {
        	for(let header of headers) {
                let headerDataLength = headerlengthMap.get(header);
                let headerRequired = headerRequiredMap.get(header);
                let currentIndex = xlsHeaders.indexOf(header);
        		for(let rowIndex in screenHeaderList) {
        			let index: number = parseInt(rowIndex);
        			if(index > 0) {
                        formattedIntegerValue = screenHeaderList[index][currentIndex];
                        if(this.isHeaderContainValueForNotRequiredField(headerRequired, formattedIntegerValue) || headerRequired === "true" || headerRequired === true){
                         if(!this.validationService.isIntegerHeaderValueValid(formattedIntegerValue,headerDataLength)){
                            let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);  
        					if(columnDefs.length > 0) {
                                field = columnDefs[0].field;
                                fieldRequiredValue = columnDefs[0].required;
                                let error: any;
                                if (formattedIntegerValue === undefined){
                                    error = {
                                        errorDescription: 'Integer field is empty. Please provide value',
            							errorField: field,
            							errorLevel: '',
            							isUpdated: false
            					}
                                } else if(headerDataLength != "0" && formattedIntegerValue.length > headerDataLength){
                                     error = {
                                        errorDescription: 'Integer field length is greater than the maximum allowed ('+headerDataLength+').!!',
            							errorField: field,
            							errorLevel: '',
            							isUpdated: false
            					    }
                                } else{
                                    error = {
                                        errorDescription: 'Integer value is invalid. Please enter correct value',
            							errorField: field,
            							errorLevel: '',
            							isUpdated: false
            					    }
                                }
        						let row = this.screenDataFromXls[index - 1];
        						if(row.hasOwnProperty('error')) {
        							let rowErrors = row['error']['errors']
        							if(rowErrors) {
        								rowErrors.push(error);
        							} else {
        								row['error']['errors'] = [error];
        							}
        						} else {
        							row['error'] = {
        								rowIndex : 	index - 1,
        								timeStamp : '',
        								errors : [error]
        							}
        						}
        					}
                        } else{
                            this.screenDataFromXls[index - 1][header] = formattedIntegerValue;
                        } 
                     }             
        			}
        		};
        	};
        }
    }

    private formatCharacterColumnData(gridOptions : any, screenHeaderList: any[]) {
        let formattedCharacterValue :any;
        let headers: string[] = [];
        let headerDataLength: any;
        let headerlengthMap = new Map();  
        let headerRequiredMap = new Map();
    	let errorList = [];
    	let field: string = '';
		for(let columnDef of gridOptions.columnDefs) {
			if(columnDef.dataType == 'CHAR') {
                headers.push(columnDef.headerName);
                headerlengthMap.set(columnDef.headerName,columnDef.dataLength);
                headerRequiredMap.set(columnDef.headerName,columnDef.required);
			}
        }
        let xlsHeaders: string[] = screenHeaderList[0];
        if(headers.length > 0) {
        	for(let header of headers) {
                let headerDataLength = headerlengthMap.get(header);
                let headerRequired = headerRequiredMap.get(header);
        		let currentIndex = xlsHeaders.indexOf(header);
        		for(let rowIndex in screenHeaderList) {
        			let index: number = parseInt(rowIndex);
        			if(index > 0) {
                        formattedCharacterValue = screenHeaderList[index][currentIndex];
                        if(this.isHeaderContainValueForNotRequiredField(headerRequired,formattedCharacterValue) || headerRequired === "true" || headerRequired === true){
                         if(!this.validationService.isCharacterHeaderValueisValid(formattedCharacterValue,headerDataLength)){
                            let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
        					if(columnDefs.length > 0) {
                                field = columnDefs[0].field;
                                let error: any;

                                if(formattedCharacterValue === undefined){
                                    error = {
                                        errorDescription: 'Character value Empty or Invalid. Please check the value',
            							errorField: field,
            							errorLevel: Constants.ERROR_DATA_REQUIRED,
            							isUpdated: false
            					    }
                                } else if (formattedCharacterValue.length > headerDataLength){
                                    error = {
                                        errorDescription: 'Length is greater than the maximum allowed ('+headerDataLength+').!!',
            							errorField: field,
            							errorLevel: Constants.ERROR_DATA_MORE_LENGTH,
            							isUpdated: false
            					    }
                                } else {
                                    error = {
                                        errorDescription: 'This character value is invalid. Please check the value',
            							errorField: field,
            							errorLevel: '',
            							isUpdated: false
            					    } 
                                }
        						let row = this.screenDataFromXls[index - 1];
        						if(row.hasOwnProperty('error')) {
        							let rowErrors = row['error']['errors']
        							if(rowErrors) {
        								rowErrors.push(error);
        							} else {
        								row['error']['errors'] = [error];
        							}
        						} else {
        							row['error'] = {
        								rowIndex : 	index - 1,
        								timeStamp : '',
        								errors : [error]
        							}
        						}
        					}
                        } else{
                            this.screenDataFromXls[index - 1][header] = formattedCharacterValue;
                        }
                     }  
        			}
        		};
        	};
        }
    }


    private formatDateColumnData(gridOptions : any, screenHeaderList: any[]) {
        let formattedDateValue :any;
        let headers: string[] = [];
        let headerRequiredMap = new Map();
    	let errorList = [];
    	let field: string = '';
		for(let columnDef of gridOptions.columnDefs) {
			if(columnDef.dataType == 'DATE') {
                headers.push(columnDef.headerName);
                headerRequiredMap.set(columnDef.headerName,columnDef.required);
			}
        }
        let xlsHeaders: string[] = screenHeaderList[0];
        if(headers.length > 0) {
        	for(let header of headers) {
                let currentIndex = xlsHeaders.indexOf(header);
                let headerRequired = headerRequiredMap.get(header);
        		for(let rowIndex in screenHeaderList) {
        			let index: number = parseInt(rowIndex);
        			if(index > 0) {
                        formattedDateValue = screenHeaderList[index][currentIndex];
                        if(this.isHeaderContainValueForNotRequiredField(headerRequired, formattedDateValue) || headerRequired === "true" || headerRequired === true){
                        if(!this.validationService.isDateHeaderValueValid(formattedDateValue)){  
                            let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
        					if(columnDefs.length > 0) {
        						field = columnDefs[0].field;
        						let error = {
                                        errorDescription: 'Date invalid.Please enter correct value',
            							errorField: field,
            							errorLevel: '',
            							isUpdated: false
            					}
        						let row = this.screenDataFromXls[index - 1];
        						if(row.hasOwnProperty('error')) {
        							let rowErrors = row['error']['errors']
        							if(rowErrors) {
        								rowErrors.push(error);
        							} else {
        								row['error']['errors'] = [error];
        							}
        						} else {
        							row['error'] = {
        								rowIndex : 	index - 1,
        								timeStamp : '',
        								errors : [error]
        							}
        						}
        					}
                        } else{
                            this.screenDataFromXls[index - 1][header] = formattedDateValue;
                        }
                     } 
        			}
        		};
        	};
        }
    }
    
    private formatCurrencyColumnData(gridOptions : any, screenHeaderList: any[]) {
    	let formttedValue = '';
    	let headers: string[] = [];
    	let errorList = [];
    	let field: string = '';
		for(let columnDef of gridOptions.columnDefs) {
			if(columnDef.dataType == 'CURRENCY') {
				headers.push(columnDef.headerName);
			}
		}
		let xlsHeaders: string[] = screenHeaderList[0];
		if(headers.length > 0) {
        	for(let header of headers) {
        		let currentIndex = xlsHeaders.indexOf(header);
        		for(let rowIndex in screenHeaderList) {
        			let index: number = parseInt(rowIndex);
        			if(index > 0) {
        				formttedValue = this.formattingService.formatCurrencyWithCommaAndDecimalPoint(screenHeaderList[index][currentIndex]);
        				if(formttedValue && !this.validationService.isCurrencyValueValid(formttedValue)) {
        					let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
        					if(columnDefs.length > 0) {
        						field = columnDefs[0].field;
        						let error = {
            							errorDescription: this.formattingService.getCurrencyFormatErrorMessage(formttedValue),
            							errorField: field,
            							errorLevel: '',
            							isUpdated: false
            					}
        						let row = this.screenDataFromXls[index - 1];
        						if(row && row.hasOwnProperty('error')) {
        							let rowErrors = row['error']['errors']
        							if(rowErrors) {
        								rowErrors.push(error);
        							} else {
        								row['error']['errors'] = [error];
        							}
        						} else {
        							row['error'] = {
        								rowIndex : 	index - 1,
        								timeStamp : '',
        								errors : [error]
        							}
        						}
        					}
        				}
        				this.screenDataFromXls[index - 1][header] = formttedValue;
        			}
        		};
        	};
        }
    }
    
    private formatPercentageColumnData(gridOptions : any, screenHeaderList: any[]) {
    	let formttedValue = '';
    	let headers: string[] = [];
    	let errorList = [];
        let field: string = '';
        let nameOfHeader : string = '';
		for(let columnDef of gridOptions.columnDefs) {
			if(columnDef.dataType == 'PERCENTAGE') {
				headers.push(columnDef.headerName);
			}
		}
		let xlsHeaders: string[] = screenHeaderList[0];
		if(headers.length > 0) {

        	  // Using for(let nameOfHeader of headers) is having issues when headers length is 1.
              for(let i=0;i<headers.length;i++) {
                  nameOfHeader = headers[i];                
        		  let currentIndex = xlsHeaders.indexOf(nameOfHeader);
        		  for(let rowIndex in screenHeaderList) {
                    let index: number = parseInt(rowIndex);
                    let rowIndexValue : number = 0;
                    if(gridOptions.rowData)
                    {
                        rowIndexValue = index + gridOptions.rowData.length - 1;
                    }
                    else
                    {
                        rowIndexValue = index - 1;
                    }
        			if(index > 0) {
                        formttedValue = this.formattingService.formatPercentageWithDecimalPoint(screenHeaderList[index][currentIndex], false);
                        if((formttedValue != null || formttedValue != undefined )
                         && (nameOfHeader === 'Tax Percent' || nameOfHeader === 'Sale Percentage Labor' || nameOfHeader === 'Sale Percentage Parts')){
                           formttedValue = formttedValue.replace('%','')
                        }
        				if(formttedValue===null){
        					let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === nameOfHeader);
        					if(columnDefs.length > 0) {
        						field = columnDefs[0].field;
        						let error = {
                                        errorDescription: 'Only Numbers are allowed',
            							errorField: field,
            							errorLevel: '',
            							isUpdated: false
            					}
        						let row = this.screenDataFromXls[index - 1];
        						if(row.hasOwnProperty('error')) {
        							let rowErrors = row['error']['errors']
        							if(rowErrors) {
        								rowErrors.push(error);
        							} else {
        								row['error']['errors'] = [error];
        							}
        						} else {
        							row['error'] = {
        								rowIndex : 	rowIndexValue,
        								timeStamp : '',
        								errors : [error]
        							}
                                }                                
        					}
        				}
        				else{
        					this.screenDataFromXls[index-1][nameOfHeader] = formttedValue;
        				}
        			}
        		}
        	}
        }
    }
    

    isHeaderContainValueForNotRequiredField(headerRequired:any, headerFieldValue:any): boolean{
        return (headerRequired === false || headerRequired ==="false") && headerFieldValue != undefined && headerFieldValue != "";
    }
    
    isUnsavedDataPresent() : boolean{
        return this.unsavedDataPresent;
    }
    
    resetUnsavedDataPresent() {
    	this.unsavedDataPresent = false;
    }
}