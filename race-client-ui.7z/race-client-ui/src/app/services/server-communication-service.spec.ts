import { TestBed,inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { MatDialogModule } from '@angular/material';
import { ServerCommunicationService } from './server-communication-service';
import { AuthService } from './auth-service';
import { MasterFunctionalUnit } from '../model/master-functional-unit';
import { FlexApi } from '../model/flex-api-objects';
import { DashReport } from '../model/dash-report';

describe('ServerCommunicationService', () => {

    let serverCommService: ServerCommunicationService;
    let httpMock: HttpTestingController;
    let authService: AuthService;

    class MockAuthService {    
        authenticated = false;      
        user: any[];
        getLoggedInUser() {     
         let user = {
              user :{
                  loginId :"sagar.aitla@cdk.com"
              },
              enterprise:{
                idpName: "CDK Self Enterprise",
                id: "E000000",
                name: "CDK Global"  
              }
         }   
        return user; 

        }    
      } 

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule,
                MatDialogModule
            ],
            providers: [
                ServerCommunicationService,{provide: AuthService, useClass: MockAuthService}

            ],
        });
        serverCommService = TestBed.get(ServerCommunicationService);
        authService = TestBed.get(AuthService);
        httpMock = TestBed.get(HttpTestingController);
        httpMock.expectOne({
            url: 'assets/config',
            method: 'get'
        }).flush({
            "production": false,
            "host": "http://localhost:8080/",
            "cshost": "https://api-dit.connectcdk.com/",
            "refreshToken": "8adaf13a-06c5-4cd1-bca5-70edf23323fc",
            "flexApiHost":"https://api-int.dit.connectcdk.com/api/ds-flex-dash-config/v1/"
        }); 
        httpMock.verify();
    });

    const hostConfig: any = {
        "production": false,
        "host": "http://localhost:8080/",
        "cshost": "https://api-dit.connectcdk.com/",
        "refreshToken": "8adaf13a-06c5-4cd1-bca5-70edf23323fc"
    }

    let expectedOutCome: any  = [
     {      
            "resultCode": "CDK_200",
            "resultDescription": "OK",
            "resultObj": [
              {
                "isProject": 1,
                "enterpriseId": "E000000",
                "projectNumber": "P000001",
                "dealerName": "Honda1",
                "location": null,
                "platform": {
                  "id": null,
                  "platformName": "FLEX",
                  "platformCode": "flex",
                  "selected": false
                },
                "status": "OPEN",
                "clientManager": null,
            
                "projectManager": "Dawn.Jordan@cdk.com",
                "language": "en_US",
                "country": "United States",
                "timezone": "UTC-11: Samoa Standard Time",
                "version": 12,
                "dealerApproverRequired": false,
                "createdDate": null,
                "lastUpdatedDate": "2020-08-10T09:47:00.472+0000",
                "createdBy": null,
                "updatedBy": "Kunal.Mahajan@cdk.com",
                "id": "8e728963-124c-4552-8a73-f580cf4784ca",
                "recordType": "ProjectInfo"
              }
              ]
          
    },
    {      
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [
          {
            "isProject": 1,
            "enterpriseId": "E000000",
            "projectNumber": "P000001",
            "dealerName": "Honda1",
            "location": null,
            "platform": {
              "id": null,
              "platformName": "FLEX",
              "platformCode": "flex",
              "selected": false
            },
            "status": "OPEN",
            "clientManager": null,
        
            "projectManager": "Dawn.Jordan@cdk.com",
            "language": "en_US",
            "country": "United States",
            "timezone": "UTC-11: Samoa Standard Time",
            "version": 12,
            "dealerApproverRequired": false,
            "createdDate": null,
            "lastUpdatedDate": "2020-08-10T09:47:00.472+0000",
            "createdBy": null,
            "updatedBy": "Kunal.Mahajan@cdk.com",
            "id": "8e728963-124c-4552-8a73-f580cf4784ca",
            "recordType": "ProjectInfo"
          }
          ]
      
}
    ]
      
    it('should create the Server Communication Service', () => {
        expect(serverCommService).toBeDefined();
    });

    it('should be created', inject([AuthService], (authService: AuthService) => {
        expect(authService).toBeTruthy();
    }));

    it('should fetch result on GET Request',()=>{
        let url = "projects"
        let permission = "DOT_PROJECT_VIEW";
        let user = {
            user :{
                loginId :"text"
            },
            enterprise:{
              idpName: "CDK Self Enterprise",
              id: "E000000",
              name: "CDK Global"  
            }
       }  
        spyOn(authService, 'getLoggedInUser'). and.returnValue(user);  
        serverCommService.get(url,permission,true,undefined)
                         .subscribe((data:any)=>{
                            expect(data.length).toBe(2);
                            expect(data).toEqual(expectedOutCome);
                         });

        let req = httpMock.expectOne(serverCommService['host'] + 'projects');
        expect(req.request.method).toBe("GET");
                 
        req.flush(expectedOutCome);
        httpMock.verify();
    })

    it('should fetch result on GET Request for undefined host',()=>{
        let url = "projects"
        let permission = "DOT_PROJECT_VIEW";
        let user = {
            user :{
                loginId :"text"
            },
            enterprise:{
              idpName: "CDK Self Enterprise",
              id: "E000000",
              name: "CDK Global"  
            }
       }  
        serverCommService['host'] = undefined;
       
        spyOn(authService, 'getLoggedInUser').and.returnValue(user);  

        serverCommService.get(url,permission,true,undefined)
                         .subscribe((data:any)=>{
                            expect(data.length).toBe(2);
                            expect(data).toEqual(expectedOutCome);
                         });

        let firstRequest = httpMock.expectOne('assets/config');
        expect(firstRequest.request.method).toBe("GET");
        firstRequest.flush(hostConfig);

        let secondRequest = httpMock.expectOne(serverCommService['host']+url);
        expect(secondRequest.request.method).toBe("GET");
        secondRequest.flush(expectedOutCome);

        httpMock.verify();
    })

    
    it('should fetch result on POST Request',()=>{

        const masterFunctionalUnitModel: MasterFunctionalUnit = {

            functionalUnitType: "MasterFunctionalUnit",
            functionalUnitName: "UI unit test22",
            gridOptionsModel: {
                    "animatedRows": false,
                    "rowSelection": "multiple",
                    "columnDefs": [
                                {
                                    "headerName": "sno1",
                                    "field": "sno1",
                                    "dataType": "CHAR",
                                    "required": "true",
                                    "editable": "true",
                                    "editableByCDKOnly": "true",
                                    "defaultValue": "",
                                    "clientScreen": "",
                                    "validationRule": "",
                                    "dataLength": 1,
                                    "cellEditor": "agLargeTextCellEditor",
                                    "cellEditorParams": {
                                    "maxLength": 1
                                    }
                                }
                     ],
                     rowData:null
            },
            description : "UI unit test2 desc",
            version: 0,
            productCode: "PTS",
            createdDate: null,
            lastUpdatedDate: null,
	           propagationStarted:false,
            id: "73d40305-f259-49e9-8227-8aaa65eb24b5",
            recordType: "FunctionalUnitInfo"
          }
        let url = "functionalUnit/create"
        let permission = "DOT_SCREEN_CREATE";
        let user = {
            user :{
                loginId :"suresh.vanga@cdk.com"
            },
            enterprise:{
              idpName: "CDK Self Enterprise",
              id: "E000000",
              name: "CDK Global"  
            }
       }  
        const options = {headers :'headers', withCredentials: true}; 
        spyOn(authService, 'getLoggedInUser').and.returnValue(user);  


        serverCommService.post(url,masterFunctionalUnitModel,permission,true)
                     .subscribe((data:MasterFunctionalUnit)=>{
                      expect(data.functionalUnitName).toEqual("UI unit test22");
                      expect(data).toEqual(masterFunctionalUnitModel);
         });

           
         let req = httpMock.expectOne(serverCommService['host'] + url);
        expect(req.request.method).toBe("POST");
                 
        req.flush(masterFunctionalUnitModel);
        httpMock.verify(); 
    })


   it('should fetch result on POST Request with Response undefined ***',()=>{

    
      let  masterFunctionalUnitModelResponse: MasterFunctionalUnit;


      let url = "functionalUnit/create"
      let permission = "DOT_SCREEN_CREATE";
      let user = {
          user :{
              loginId :"suresh.vanga@cdk.com"
          },
          enterprise:{
            idpName: "CDK Self Enterprise",
            id: "E000000",
            name: "CDK Global"  
          }
     }  
      const options = {headers :'headers', withCredentials: true}; 
      spyOn(authService, 'getLoggedInUser').and.returnValue(user);  

      serverCommService.post(url,masterFunctionalUnitModelResponse,permission,true)
                   .subscribe((data:any)=>{
                    expect(data).toBe(masterFunctionalUnitModelResponse);
       });
   
      let req = httpMock.expectOne(serverCommService['host'] + url);
      expect(req.request.method).toBe("POST");
      expect(req.request.responseType).toEqual('json')
      httpMock.verify(); 
  })
 

   it('should fetch result on flex_post Request',()=>{

    let flex_post_response : any = {
        "Purchase Terms": [
            {
              "contract_term_in_months": "60",
              "days_to_first_payment": "30",
              "id": "83a71061-0513-45b2-bc77-deb71dc5f770",
              "recordType": 2000,
              "index": "2000",
              "rowDataId": "b7e1f1d8-991c-4512-b262-0fa9cb737bfc"
            }
          ],
          "We Owe Options": [
            {
              "fee_option": "Fee/Option-1",
              "profit_type": "B - Back-end Item",
              "description": "ACCESSORY                ",
              "suggested_retail_price": "$200",
              "profit_type_query_field": "B",
              "dealer_cost": "$120",
              "include_in_we_owe_tax_1_total": "N"
            }
          ],
          "Lienholders": [
            {
                "lienholder_name": "FINANCE AND THRIF",
                "lienholder_address": "PO BOX 311",
                "lienholder_city": "PORTERVILLE",
                "lienholder_state": "CA",
                "lienholder_country": "USA",
                "lienholder_phone": "5595629818",
                "title_work_name": "FINANCE AND THRIFT",
                "title_work_address": "PO BOX 311",
                "title_work_city": "PORTERVILL",
                "title_work_state": "CA",
                "title_work_zip": "93258    ",
                "loss_payee_name": "FINANCE AND THRIFT",
                "loss_payee_address": "PO BOX 311",
                "loss_payee_city": "PORTERVILLE",
                "loss_payee_state": "CA",
                "loss_payee_zip": "93258    ",
                "default_purchase_finance_institution": "No",
                "default_product_sale_finance_institution": "No",
                "purchase_calc_method": "0 - STANDARD",
                "same_day_calcs": "Blank - None",
                "lender_code": "VALLEY FIRST CU",
                "purchase_calc_method_query_field": "0 ",
                "purchase_reserve_method": "80",
                "days_per_year": "365",
                "same_day_calcs_query_field": " ",
                "vsi_amount": "",
                "ppi_amount": ""
              }
            ],
            "Dealer Information - US" : [
                {
                    "name": "THOMPSON CHEVROLET BUICK GMC            ",
                    "address": "701 S. 2ND ST / PO BX 95      ",
                    "city": "PATTERSON                     ",
                    "state": "MO",
                    "zip_code": "95363    ",
                    "county": "STANISLAUS          ",
                    "phone_number": "2098923311",
                    "federal_tax_id": "94-2180090          ",
                    "state_tax_id": " 173-0603-6          ",
                    "company_number": "#CO#"
                  }
              ]

    }
    const flex_post: FlexApi={
        cmfNumber: "A39400QA5",
        functionalAreaId: "0a5dee14-0dd1-42b6-8a5b-ad2cce4171e8",
        projectId: "d6d83187-6f83-4cad-9816-7eed2d416de4",
        storeId: "edaf5a05-4978-4130-acb8-e92b1bdc441d",
        storeNumber: "01"
    }
    let url = "https://api-int.dit.connectcdk.com/api/ds-flex-dash-config/v1/race-ui-map"
    let permission = "DOT_PROJECT_VIEW";
    let user = {
        user :{
            loginId :"suresh.vanga@cdk.com"
        },
        enterprise:{
          idpName: "CDK Self Enterprise",
          id: "E000000",
          name: "CDK Global"  
        }
   }
 spyOn(authService, 'getLoggedInUser').and.returnValue(user);  
 serverCommService.flex_post(url,flex_post,permission,true)
                .subscribe((data:any)=>{
                    expect(data).toEqual(flex_post_response); 
                })
             
                        
                      let req = httpMock.expectOne(url);
                     expect(req.request.method).toBe("POST");
                              
                     req.flush(flex_post_response);
                     httpMock.verify();

   })

   it('test file download post request',()=>{

    const file_download_model:DashReport={
      projectNumber: "Demo112",
      storeId: "d6d83187-6f83-4cad-9816-7eed2d416de4",
      storeName: "qaTest",
      functionalUnitId: "d6ae02d9-251d-45c9-9786-07f4dba8e8d1",
      templateName: "Service",
      functionalAreaId: "c7c5362a-056e-4711-9ca5-6486e712a9a7",
      screenName: "Account Definition",
      columnList: [
        "Starting RO Number",
        "Ending RO Number",
        "Next RO Number",
        "RO Suffix",
        "Warn users before ending RO Number is reached?",
        "Number of ROs prior to Ending Number in which to warn user",
        "Dealer Code",
        "Pay Period",
        "Pay Period Begin Date",
        "Default Labor Type Flag",
        "Default Customer Labor Rate",
        "0"
      ]
    }

      const fakeFile = (): File => {
      const blob = new Blob([''], {type: 'application/pdf'});
      return blob as File;
      };
    let url = "functionalunits/pdfReport"
    let permission = "DOT_PROJECT_VIEW";
    let user = {
      user :{
          loginId :"suresh.vanga@cdk.com"
      },
      enterprise:{
        idpName: "CDK Self Enterprise",
        id: "E000000",
        name: "CDK Global"  
      }
     }
    spyOn(authService, 'getLoggedInUser').and.returnValue(user); 

    serverCommService.post_fileDownload(url,file_download_model,permission,true)
                      .subscribe((data:any)=>{
                        expect(data).toEqual(new Blob([JSON.stringify(fakeFile)], { type: 'application/json' })); 
                      })

                       
                      let req = httpMock.expectOne(serverCommService['host'] + url);
                     expect(req.request.method).toBe("POST");
                              
                     req.flush(new Blob([JSON.stringify(fakeFile)], { type: 'application/json' }));
                     httpMock.verify();

   })

   
 it('should fetch result on get_fileDownload Request',()=>{

  let cmfNumber = "A39400QA5";
  let storeNumber = "01"
  let url = "template/"+cmfNumber+"/"+storeNumber;
  let permission = "DOT_PROJECT_VIEW";
 
  let user = {
    user :{
        loginId :"suresh.vanga@cdk.com"
    },
    enterprise:{
      idpName: "CDK Self Enterprise",
      id: "E000000",
      name: "CDK Global"  
    }
   }
   
   const fakeFile = (): File => {
    const blob = new Blob([''], {type: 'application/vnd.ms-excel'});
    return blob as File;
    };
  spyOn(authService, 'getLoggedInUser').and.returnValue(user); 
    
     serverCommService.get_fileDownload(url,permission,true)
                              .subscribe((data:any)=>{
                                expect(data).toEqual(new Blob([JSON.stringify(fakeFile)], { type: 'application/vnd.ms-excel' })); 
                         })

    let req = httpMock.expectOne(serverCommService['host'] + url);
    expect(req.request.method).toBe("GET");                          
    req.flush(new Blob([JSON.stringify(fakeFile)], { type: 'application/vnd.ms-excel' }));
    httpMock.verify();

})

it('should fetch result on get_fileDownload Request for undefined host',()=>{

  let cmfNumber = "A39400QA5";
  let storeNumber = "01"
  let url = "template/"+cmfNumber+"/"+storeNumber;
  let permission = "DOT_PROJECT_VIEW";
 
  let user = {
    user :{
        loginId :"suresh.vanga@cdk.com"
    },
    enterprise:{
      idpName: "CDK Self Enterprise",
      id: "E000000",
      name: "CDK Global"  
    }
   }
   serverCommService['host'] = undefined;
   
   const fakeFile = (): File => {
    const blob = new Blob([''], {type: 'application/vnd.ms-excel'});
    return blob as File;
    };
  spyOn(authService, 'getLoggedInUser').and.returnValue(user); 
    
 serverCommService.get_fileDownload(url,permission,true)
                              .subscribe((data:any)=>{
                                expect(data).toEqual(new Blob([JSON.stringify(fakeFile)], { type: 'application/vnd.ms-excel' })); 
                         })


  let firstRequest = httpMock.expectOne('assets/config');
  expect(firstRequest.request.method).toBe("GET");
  firstRequest.flush(hostConfig);
                 
  let secondRequest = httpMock.expectOne(serverCommService['host']+url);
  expect(secondRequest.request.method).toBe("GET");
  secondRequest.flush(new Blob([JSON.stringify(fakeFile)], { type: 'application/vnd.ms-excel' }));
  httpMock.verify();

})

it('should fetch result on PUT Request fetch',()=>{

const  masterFunctionalUnitModel: MasterFunctionalUnit={
  
    "functionalUnitType": "MasterFunctionalUnit",
    "functionalUnitName": "Lienholder",
    "gridOptionsModel": {
      "animatedRows": false,
      "rowSelection": "multiple",
      "columnDefs": [
        {
          "headerName": "Lienholder Code",
          "field": "lienholder_code",
          "dataType": "CHAR",
          "required": "true",
          "editable": "true",
          "editableByCDKOnly": "false",
          "defaultValue": "",
          "clientScreen": "",
          "validationRule": "",
          "dataLength": 10,
          "cellEditor": "agLargeTextCellEditor",
          "cellEditorParams": {
            "maxLength": 10
          }
        }
       
      ],
      "rowData":null
    },
    "description": "Lienholder Information",
   "version": 1,
    "productCode": "SLS",
    "createdDate": new Date(),
    "lastUpdatedDate": new Date(),
    "propagationStarted": false,
    "id": "f2581928-c206-481a-9b90-584ba3050305",
    "recordType": "FunctionalUnitInfo"

}

let masterFuId = "f2581928-c206-481a-9b90-584ba3050305";
let url = "functionalUnit/"+masterFuId+"/discard";
let permission = "DOT_SCREEN_CREATE";

serverCommService.put(url,masterFunctionalUnitModel,permission,true)
        .subscribe((data:MasterFunctionalUnit)=>{
        expect(data.functionalUnitName).toEqual("Lienholder");
         expect(data).toEqual(masterFunctionalUnitModel);
});

let req = httpMock.expectOne(serverCommService['host'] + url);
expect(req.request.method).toBe("PUT");
         
req.flush(masterFunctionalUnitModel);
httpMock.verify(); 
})


});