import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';

import { AuthService } from './auth-service';
import { AuditLogsObject } from '../model/audit-logs-object';
import { AuditLogsFAObject } from '../model/audit-logsfa-object';
import { AuditLogsFUObject} from '../model/audit-logsfu-object';
import { AuditLogsVTObject } from '../model/audit-logsvt-object';
import { FieldInfoObject } from '../model/fields-info-object';
import { ResultsInfoObject } from '../model/results-info-object';

import 'rxjs/Rx';
import { ServerCommunicationService } from './server-communication-service';
import { GenericResponse } from '../model/generic-response';

@Injectable()
export class AuditLogService {

    constructor(private authService: AuthService,private serverCommunicationService :ServerCommunicationService) {}
    
    getAuditLogs(): Observable<AuditLogsObject[]> {
        return this.serverCommunicationService.get('audit/projectauditlogs', 'DOT_PROJECT_VIEW', true);  
    }

    getAuditLogsFA(): Observable<AuditLogsFAObject[]> {
        return this.serverCommunicationService.get('audit/fareaauditlogs', 'DOT_PROJECT_VIEW', true);   
    }

    getAuditLogsFU(): Observable<AuditLogsFUObject[]> {
        return this.serverCommunicationService.get('audit/funitauditlogs', 'DOT_PROJECT_VIEW', true);
    }

    getAuditLogsVT() : Observable<AuditLogsVTObject[]>{
        return this.serverCommunicationService.get('audit/validatetransfer', 'DOT_PROJECT_VIEW', true);
    }

    getAuditLogsChangePropagation() : Observable<GenericResponse>{
        return this.serverCommunicationService.get('audit/propagate', 'DOT_PROJECT_VIEW', true);
    }

    getResultsInfoById(id : string): Observable<ResultsInfoObject[]> {
    return this.serverCommunicationService.get("validatetransfer/resultsinfo/"+id,'DOT_PROJECT_VIEW', true);         
    }

    getPVRResultsInfoById(resultId : string): Observable<GenericResponse> {
        return this.serverCommunicationService.get('audit/process-validation-rule/results-info/'+resultId, 'DOT_PROJECT_VIEW', true);         
    }
 
    getAuditlogFieldsInfoById(fieldsInfoId : string): Observable<GenericResponse>{
        return this.serverCommunicationService.get('fieldsinfo/'+fieldsInfoId, 'DOT_PROJECT_VIEW', true);
    }
    
    public getAuditLogsVR(): Observable<GenericResponse> {
        return this.serverCommunicationService.get('audit/validationRule', 'DOT_PROJECT_VIEW', true);
    }

    public getAuditLogsBP(): Observable<GenericResponse> {
        return this.serverCommunicationService.get('audit/bestpractice', 'DOT_PROJECT_VIEW', true);
    }

    public createOverrideErrorsAndWarningsAuditLog(projectName:string,storeName:string,functionalAreaName:string): Observable<GenericResponse>{
        return this.serverCommunicationService.post('audit/validatetransfer/'+projectName+"/"+storeName+"/"+functionalAreaName,null, 'ACCESSDOT', true);
    }

    public getGOMAuditlogFieldsInfoById(fieldsInfoId : string): Observable<GenericResponse>{
        return this.serverCommunicationService.get('fieldsinfo/grid-option-model/'+fieldsInfoId, 'DOT_PROJECT_VIEW', true);
    }

    getPropagatedFuAuditlogById(fieldsInfoId : string): Observable<GenericResponse>{
        return this.serverCommunicationService.get('fieldsinfo/propagate/'+fieldsInfoId, 'DOT_PROJECT_VIEW', true);
    }
}