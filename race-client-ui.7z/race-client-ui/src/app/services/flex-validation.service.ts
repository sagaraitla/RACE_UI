import { Injectable } from "@angular/core";
import { ValidationService } from "./validation-service";
import { FormattingService } from "./formatting-service";

@Injectable()
export class FlexValidationService {
    constructor(private formattingService : FormattingService,private validationService: ValidationService) { }
     formatDateColumnData(gridOptions : any, screenHeaderList: any[]) {
        let formattedDateValue :any;
        let headers: string[] = [];
        let headerRequiredMap = new Map();
        let errorList = [];
        let field: string = '';
        for(let columnDef of gridOptions.columnDefs) {
            if(columnDef.dataType == 'DATE') {
                headers.push(columnDef.headerName);
                headerRequiredMap.set(columnDef.headerName,columnDef.required);
            }
        }
        if(headers.length > 0) {
            for(let header of headers) {
                let headerRequired = headerRequiredMap.get(header);
                for(var i=0;i< screenHeaderList.length;i++){
                    let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
                        field = columnDefs[0].field;
                        formattedDateValue = screenHeaderList[i][field];
                        if(this.isHeaderContainValueForNotRequiredField(headerRequired, formattedDateValue) || headerRequired === "true"){
                            if(formattedDateValue===null){
                                formattedDateValue=undefined;
                            }
                        if(!this.validationService.isDateHeaderValueValid(formattedDateValue)){  
                            let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
                            if(columnDefs.length > 0) {
                                field = columnDefs[0].field;
                                let error = {
                                        errorDescription: 'Date invalid.Please enter correct value',
                                        errorField: field,
                                        errorLevel: '',
                                        isUpdated: false
                                }
                                let row = screenHeaderList[i];
                                if(row.hasOwnProperty('error')) {
                                    let rowErrors = row['error']['errors']
                                    if(rowErrors) {
                                        rowErrors.push(error);
                                    } else {
                                        row['error']['errors'] = [error];
                                    }
                                } else {
                                    row['error'] = {
                                        rowIndex : i,
                                        timeStamp : '',
                                        errors : [error]
                                    }
                                }
                            }
                        } else{
                            screenHeaderList[i][field]= formattedDateValue;
                        }
                     } 
                  
                };
            };
        }
    }
     formatDropDownColumnData(gridOptions : any, screenHeaderList: any[]) {
        let formattedDropdownValue :any;
        let headers: string[] = [];
        let headerlengthMap = new Map();  
        let headerRequiredMap = new Map();
        let dropdownValueMap =new Map();
    	
        let field: string = '';
        let fieldRequiredValue: string ='';
		for(let columnDef of gridOptions.columnDefs) {
			if(columnDef.dataType == 'DROPDOWN') {
               headers.push(columnDef.headerName);
               headerlengthMap.set(columnDef.headerName,columnDef.dataLength);
               headerRequiredMap.set(columnDef.headerName,columnDef.required);
               dropdownValueMap.set(columnDef.headerName,columnDef.cellEditorParams.values);
            }
        }
        if(headers.length > 0) {
        	for(let header of headers) {
                let headerDataLength = headerlengthMap.get(header);
                let headerRequired = headerRequiredMap.get(header);
                let dropdownValue=dropdownValueMap.get(header);
                for(var i=0;i< screenHeaderList.length;i++){
                    let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
                        field = columnDefs[0].field;
                        formattedDropdownValue = screenHeaderList[i][field];
                        if(formattedDropdownValue===null){
                            formattedDropdownValue=undefined;}
                        if(this.isHeaderContainValueForNotRequiredField(headerRequired,formattedDropdownValue) || headerRequired === "true"){
                            if(!this.validationService.isDropdownHeaderValueisValid(formattedDropdownValue,dropdownValue)){
                               let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
                               if(columnDefs.length > 0) {
                                   field = columnDefs[0].field;
                                   let error: any;
                                      if(formattedDropdownValue === undefined){
                                       error = {
                                           errorDescription: 'Dropdown value Empty. Please check the value',
                                           errorField: field,
                                           errorLevel: 'required',
                                           isUpdated: false
                                       }
                                   }else {
                                    var res=dropdownValue.find(x => x.toLocaleLowerCase()===formattedDropdownValue.toLocaleLowerCase());
                                    if(res===undefined){
                                       error = {
                                           errorDescription: 'Dropdown value is Invalid. Please check the value',
                                           errorField: field,
                                           errorLevel: 'Invalid',
                                           isUpdated: false
                                       } 
                                    }
                                   }
                                 let row = screenHeaderList[i];
                                   if(row.hasOwnProperty('error')) {
                                       let rowErrors = row['error']['errors']
                                       if(rowErrors) {
                                           rowErrors.push(error);
                                       } else {
                                           row['error']['errors'] = [error];
                                       }
                                   } else {
                                       row['error'] = {
                                           rowIndex : 	i,
                                           timeStamp : '',
                                           errors : [error]
                                       }
                                   }
                               }
                           } else{
                               if(dropdownValue.includes(formattedDropdownValue)){
                                screenHeaderList[i][field] = formattedDropdownValue;}
                               else{
                                var res=dropdownValue.find(x => x.toLocaleLowerCase()===formattedDropdownValue.toLocaleLowerCase());
                                screenHeaderList[i][field] = res;
                               }
                           }
                        }  
                    };
        	};
        }
    }
     formatIntegerColumnData(gridOptions : any, screenHeaderList: any[]) {
        let formattedIntegerValue :any;
        let headers: string[] = [];
        let headerlengthMap = new Map();  
        let headerRequiredMap = new Map();
        let errorList = [];
        let field: string = '';
        let fieldRequiredValue: string ='';
        for(let columnDef of gridOptions.columnDefs) {
            if(columnDef.dataType == 'INT') {
               headers.push(columnDef.headerName);
               headerlengthMap.set(columnDef.headerName,columnDef.dataLength);
               headerRequiredMap.set(columnDef.headerName,columnDef.required);
            }
        }
          if(headers.length > 0) {
            for(let header of headers) {
                let headerDataLength = headerlengthMap.get(header);
                let headerRequired = headerRequiredMap.get(header);
                for(var j=0;j< screenHeaderList.length;j++){
                   let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
                        field = columnDefs[0].field;
                        formattedIntegerValue = screenHeaderList[j][field];
                         if(formattedIntegerValue===null){
                            formattedIntegerValue=undefined;
                            }
                        if(this.isHeaderContainValueForNotRequiredField(headerRequired, formattedIntegerValue) || headerRequired === "true"){
                         if(!this.validationService.isIntegerHeaderValueValid(formattedIntegerValue,headerDataLength)){
                            let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);  
                            if(columnDefs.length > 0) {
                                field = columnDefs[0].field;
                                fieldRequiredValue = columnDefs[0].required;
                                let error: any;
                                if (formattedIntegerValue === undefined){
                                    error = {
                                        errorDescription: 'Integer field is empty. Please provide value',
                                        errorField: field,
                                        errorLevel: '',
                                        isUpdated: false
                                }
                                } else if(headerDataLength != "0" && formattedIntegerValue.length > headerDataLength){
                                     error = {
                                        errorDescription: 'this Integer value length is greater than it'+'`s'+' defined length. Please give correct length value!!',
                                        errorField: field,
                                        errorLevel: '',
                                        isUpdated: false
                                    }
                                } else{
                                    error = {
                                        errorDescription: 'Integer value is invalid. Please enter correct value',
                                        errorField: field,
                                        errorLevel: '',
                                        isUpdated: false
                                    }
                                }
                                let row = screenHeaderList[j];
                                if(row.hasOwnProperty('error')) {
                                    let rowErrors = row['error']['errors']
                                    if(rowErrors) {
                                        rowErrors.push(error);
                                    } else {
                                        row['error']['errors'] = [error];
                                    }
                                } else {
                                    row['error'] = {
                                        rowIndex : 	j,
                                        timeStamp : '',
                                        errors : [error]
                                    }
                                }
                            }
                        } else{
                            screenHeaderList[j][field] = formattedIntegerValue;
                        } 
                     }             
                    
                };
            };
        }
    }
     formatBooleanColumnData(gridOptions : any, screenHeaderList: any[]) {
        let booleanFiledValue :any;
        let headers: string[] = [];
        let headerRequiredMap = new Map();
        let errorList = [];
        let field: string = '';
        for(let columnDef of gridOptions.columnDefs) {
            if(columnDef.dataType == 'BOOLEAN') {
                headers.push(columnDef.headerName);
                headerRequiredMap.set(columnDef.headerName,columnDef.required);
            }
        }
        if(headers.length > 0) {
            for(let header of headers) {
                let headerRequired = headerRequiredMap.get(header);
                 for(var j=0;j< screenHeaderList.length;j++){
                     let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
                        field = columnDefs[0].field;
                        booleanFiledValue = screenHeaderList[j][field];
                     if(booleanFiledValue===null){
                        booleanFiledValue=undefined;
                     }
                     if(this.isHeaderContainValueForNotRequiredField(headerRequired, booleanFiledValue) || headerRequired === "true"){
                        if(!this.validationService.isBooleanHeaderValueValid(booleanFiledValue)){
                            let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
                            if(columnDefs.length > 0) {
                                field = columnDefs[0].field;
                                let error = {
                                        errorDescription: 'Boolean value is invalid. Please enter correct value',
                                        errorField: field,
                                        errorLevel: '',
                                        isUpdated: false
                                }
                                let row = screenHeaderList[j];
                                if(row.hasOwnProperty('error')) {
                                    let rowErrors = row['error']['errors']
                                    if(rowErrors) {
                                        rowErrors.push(error);
                                    } else {
                                        row['error']['errors'] = [error];
                                    }
                                } else {
                                    row['error'] = {
                                        rowIndex : 	j,
                                        timeStamp : '',
                                        errors : [error]
                                    }
                                }
                            }
                        } else{
                            screenHeaderList[j][field] = this.formattingService.getFormattedBooleanValue(booleanFiledValue);;
                           
                        }
                      }
                      
                };
            };
        }
    }
    formatPercentageColumnData(gridOptions : any, screenHeaderList: any[],functionalUnitName: string) {
        let formttedValue = '';
        let headers: string[] = [];
        let errorList = [];
        let field: string = '';
        let nameOfHeader : string = '';
        for(let columnDef of gridOptions.columnDefs) {
            if(columnDef.dataType == 'PERCENTAGE') {
                headers.push(columnDef.headerName);
            }
        }
        if(headers.length > 0) {
             for(let i=0;i<headers.length;i++) {
                  nameOfHeader = headers[i];
                    for(var j=0;j< screenHeaderList.length;j++){
                        let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === nameOfHeader);
                        field = columnDefs[0].field;
                        formttedValue = screenHeaderList[j][field];
                        formttedValue = this.formattingService.formatPercentageWithDecimalPoint(formttedValue, false);
                        if(formttedValue != null && formttedValue != undefined && 
                            (functionalUnitName === 'Tax Codes' && field === 'tax_percent') || (functionalUnitName === 'Shop Charges' && (field === 'sale_percentage_labor' || field === 'sale_percentage_parts'))){
                            formttedValue = formttedValue.replace('%','')
                        }
                        if(formttedValue===null){
                            let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === nameOfHeader);
                            if(columnDefs.length > 0) {
                                field = columnDefs[0].field;
                                let error = {
                                        errorDescription: 'Only Numbers are allowed',
                                        errorField: field,
                                        errorLevel: '',
                                        isUpdated: false
                                }
                                let row = screenHeaderList[i];
                                if(row.hasOwnProperty('error')) {
                                    let rowErrors = row['error']['errors']
                                    if(rowErrors) {
                                        rowErrors.push(error);
                                    } else {
                                        row['error']['errors'] = [error];
                                    }
                                } else {
                                    row['error'] = {
                                        rowIndex : 	j,
                                        timeStamp : '',
                                        errors : [error]
                                    }
                                }                                
                            }
                        }
                        else{
                           screenHeaderList[j][field]= formttedValue;
                        }
                }
            }
        }
    }
    formatCurrencyColumnData(gridOptions : any, screenHeaderList: any[]) {
        let formttedValue = '';
        let headers: string[] = [];
        let errorList = [];
        let field: string = '';
        for(let columnDef of gridOptions.columnDefs) {
            if(columnDef.dataType == 'CURRENCY') {
                headers.push(columnDef.headerName);
            }
        }
        if(headers.length > 0) {
            for(let header of headers) {
                    for(var i=0;i< screenHeaderList.length;i++){
                    let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
                    field = columnDefs[0].field;
                    formttedValue = screenHeaderList[i][field];
                    formttedValue = this.formattingService.formatCurrencyWithCommaAndDecimalPoint(formttedValue);
                        if(formttedValue && !this.validationService.isCurrencyValueValid(formttedValue)) {
                            let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
                            if(columnDefs.length > 0) {
                                field = columnDefs[0].field;
                                let error = {
                                        errorDescription: this.formattingService.getCurrencyFormatErrorMessage(formttedValue),
                                        errorField: field,
                                        errorLevel: '',
                                        isUpdated: false
                                }
                                let row = screenHeaderList[i];
                                if(row.hasOwnProperty('error')) {
                                    let rowErrors = row['error']['errors']
                                    if(rowErrors) {
                                        rowErrors.push(error);
                                    } else {
                                        row['error']['errors'] = [error];
                                    }
                                } else {
                                    row['error'] = {
                                        rowIndex : 	i,
                                        timeStamp : '',
                                        errors : [error]
                                    }
                                }
                            }
                        }
                    screenHeaderList[i][field]= formttedValue;
                };
            };
        }
    }
    formatCharacterColumnData(gridOptions : any, screenHeaderList: any[]) {
        let formattedCharacterValue :any;
        let headers: string[] = [];
        let headerDataLength: any;
        let headerlengthMap = new Map();  
        let headerRequiredMap = new Map();
        let errorList = [];
        let field: string = '';
        for(let columnDef of gridOptions.columnDefs) {
            if(columnDef.dataType == 'CHAR') {
                headers.push(columnDef.headerName);
                headerlengthMap.set(columnDef.headerName,columnDef.dataLength);
                headerRequiredMap.set(columnDef.headerName,columnDef.required);
            }
        }
        if(headers.length > 0) {
            for(let header of headers) {
                let headerDataLength = headerlengthMap.get(header);
                let headerRequired = headerRequiredMap.get(header);
                for(var i=0;i< screenHeaderList.length;i++){
                        let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
                        field = columnDefs[0].field;
                        formattedCharacterValue = screenHeaderList[i][field];
                        if(formattedCharacterValue===null){
                            formattedCharacterValue=undefined;
                        }
                        if(this.isHeaderContainValueForNotRequiredField(headerRequired,formattedCharacterValue) || headerRequired === "true"){
                            if(!this.validationService.isCharacterHeaderValueisValid(formattedCharacterValue,headerDataLength)){
                            let columnDefs = gridOptions.columnDefs.filter(columnDef => columnDef.headerName === header);
                            if(columnDefs.length > 0) {
                                field = columnDefs[0].field;
                                let error: any;
                                let row = screenHeaderList[i];
                               if(formattedCharacterValue === undefined){
                                    error = {
                                        errorDescription: 'Character value Empty or Invalid. Please check the value',
                                        errorField: field,
                                        errorLevel: '',
                                        isUpdated: false
                                    }
                                } else if (formattedCharacterValue.length > headerDataLength){
                                    error = {
                                        errorDescription: 'this Character value length is greater than it'+'`s'+' defined length. Please give correct length value!!',
                                        errorField: field,
                                        errorLevel: '',
                                        isUpdated: false
                                    }
                                } else {
                                    error = {
                                        errorDescription: 'this Character value is Invalid. Please check the value',
                                        errorField: field,
                                        errorLevel: '',
                                        isUpdated: false
                                    } 
                                }
                               
                                if(row.hasOwnProperty('error')) {
                                    let rowErrors = row['error']['errors']
                                    if(rowErrors) {
                                        rowErrors.push(error);
                                    } else {
                                        row['error']['errors'] = [error];
                                    }
                                } else {
                                    row['error'] = {
                                        rowIndex : 	i,
                                        timeStamp : '',
                                        errors : [error]
                                    }
                                }
    
                              
                            }
                        } else{
                            screenHeaderList[i][field] = formattedCharacterValue;
                        }
                     }  
                    
                };
            };
        }
    }
    isHeaderContainValueForNotRequiredField(headerRequired:any, headerFieldValue:any): boolean{
        return (headerRequired === false || headerRequired ==="false") && headerFieldValue != undefined && headerFieldValue != "";
    }
}
