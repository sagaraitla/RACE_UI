import {HttpClient, HttpHeaders} from '@angular/common/http'
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { AuthService } from '../services/auth-service';
import 'rxjs/Rx';
import { Config } from 'protractor/built/config';
import { ScreenObject } from '../model/screen-object';
import { environment } from '../../environments/environment';

@Injectable()
export class ServerCommunicationService {
	
	private host: string;
	private user: any = {};

	constructor(private http: HttpClient, private authService: AuthService) {
		this.user = this.authService.getLoggedInUser();
		this.http.get('assets/config',{withCredentials: true}).subscribe((data: any) => { 
			this.host = data.host;
		  });
	}
	
	public get(url: string, permission: string, permissionCheckNeeded: boolean, returnResponseOnly ?: boolean): Observable<any> {
		if(this.host) {
			return this.executeGetRequest(this.host + url, permission, permissionCheckNeeded, returnResponseOnly);
		} else {
			return this.http.get('assets/config',{withCredentials: true})
	        .map((response: any) => {
				this.host = response.host;
	            return response;
	        }).flatMap((response: any) => {
	        	return this.executeGetRequest(this.host + url, permission, permissionCheckNeeded,returnResponseOnly);
	        });
		}
	}
	
	private executeGetRequest(url: string, permission: string, permissionCheckNeeded: boolean,returnResponseOnly: boolean): Observable<any> {
		const options: any = {headers : this.getHeaders(permission,'GET', permissionCheckNeeded),withCredentials: true,responseType:'json'};
		if(returnResponseOnly){
			options.responseType = 'text';
		}
		return this.http.get(url, options);
	}
	
	public post(url: string, dataToPost: any, permission: string, permissionCheckNeeded: boolean): Observable<any> {
		let headers = this.getHeaders(permission,'POST', permissionCheckNeeded);
		headers = headers.append('Content-Type', 'application/json');
		const options = {headers : headers, withCredentials: true}; 
        return this.http.post(this.host + url, dataToPost, options)
        .map(responseBody => {
        	if(responseBody != undefined && responseBody != null) {
        		return responseBody;
        	} else {
        		return '';
        	}
        });
	}
	
	public put(url: string, dataToPost: any, permission: string, permissionCheckNeeded: boolean): Observable<any> {
		let headers = this.getHeaders(permission,'PUT', permissionCheckNeeded);
		headers = headers.append('Content-Type', 'application/json');
		const options = {headers : headers, withCredentials: true}; 
		return this.http.put(this.host + url, dataToPost, options);
	};

	public getHeaders(permissionCode:string, method:string, permissionCheckNeeded: boolean){
		var permissionToCheck = 'ACCESSDOT';  
        if(permissionCheckNeeded){
        	permissionToCheck = permissionCode;
        }
        let isDealerUserFlag:boolean = true;
        this.user = this.authService.getLoggedInUser();
        if (null != this.user.enterprise && this.user.enterprise.id == 'E000000')
        {
           isDealerUserFlag = false; 
        }
        let headers = new HttpHeaders({
            'loginId':  this.user.user.loginId,
            'enterpriseId': this.user.enterprise.id,
            'permission': permissionToCheck,
            'dealerUser': isDealerUserFlag.toString(),
            'Access-Control-Request-Method':method,
			'REMOTE_USER': 'Sagar.Aitla@cdk.com'
          });
        return headers;
	}
	
	public flex_post(url: string, dataToPost: any, permission: string, permissionCheckNeeded: boolean): Observable<any> {
		let headers = this.getHeaders(permission,'POST', permissionCheckNeeded);
		headers = headers.append('Content-Type', 'application/json');
		const options : any = {headers:headers};
        return this.http.post(url, dataToPost,options)
        .map(responseBody => {
        	if(responseBody != undefined && responseBody != null) {
        		return responseBody;
        	} else {
        		return '';
        	}
        });
	}
	//==used to call get api which will return response data Blob type, mainly it will useful for file download
	public get_fileDownload(url: string, permission: string, permissionCheckNeeded: boolean, returnResponseOnly ?: boolean): Observable<any> {
		if(this.host) {
			return this.executeGetRequestForFileDownload(this.host + url, permission, permissionCheckNeeded, returnResponseOnly);
		} else {
			return this.http.get('assets/config',{withCredentials: true})
	        .map((response: any) => {
				this.host = response.host;
	            return response;
	        }).flatMap((response: any) => {
	        	return this.executeGetRequestForFileDownload(this.host + url, permission, permissionCheckNeeded,returnResponseOnly);
	        });
		}
	}

	public executeGetRequestForFileDownload(url: string, permission: string, permissionCheckNeeded: boolean,returnResponseOnly: boolean): Observable<any> {
		const options:any = {headers : this.getHeaders(permission,'GET', permissionCheckNeeded),withCredentials:true,responseType:'blob'};
		return this.http.get(url, options);
	}
	//=====used to download file which expect more inputs values forward from UI side.used for flex report functionality
	public post_fileDownload(url: string, dataToPost: any, permission: string, permissionCheckNeeded: boolean): Observable<any> {
			let headers = this.getHeaders(permission,'POST', permissionCheckNeeded);
			headers = headers.append('Content-Type', 'application/json');
			const options : any = { headers : headers,responseType:'blob', withCredentials: true }; 
			return this.http.post(this.host + url, dataToPost, options);
	};

}
