import { Injectable } from '@angular/core';
import { FormattingService } from './formatting-service';
import { DatePipe } from '@angular/common';

@Injectable()
export class ValidationService {
	
	constructor(private formattingService : FormattingService) { }
	datepipe : DatePipe = new DatePipe('en-US');
    
	isCurrencyValueValid(currencyValue: string) : boolean {
		currencyValue = this.formattingService.removeDollarSymbol(currencyValue);
		const regex = /^-?\d{1,3}(,\d{3})*(\.\d{1,2})?$/;
		return regex.test(currencyValue);
	}
	
	isBooleanHeaderValueValid(booleanValue:any): boolean{
		let boolValue: any;

		if(booleanValue === undefined || booleanValue === ""){
			return true;
		}
		boolValue = booleanValue.toLowerCase();
		if(boolValue === "1" || boolValue ==="true" || boolValue === "0" || boolValue === "false"){
			return true;
		}
		return false;
	}

	isCharacterHeaderValueisValid(formattedCharacterValue: any, headerDataLength:any){

		let flag:boolean = true;
		if(formattedCharacterValue === undefined || formattedCharacterValue === ""){
			flag = false;
			return flag
		}
		if(headerDataLength != "0" && formattedCharacterValue.length > headerDataLength){
			flag = false;
			return flag
		}
		return flag;
	}

	isDropdownHeaderValueisValid(formattedDropdownValue: any, dropdownValue:any){

		let flag:boolean = true;
		if(formattedDropdownValue === undefined || formattedDropdownValue === ""){
			flag = false;
			return flag
		}
		var res=dropdownValue.find(x => x.toLocaleLowerCase()===formattedDropdownValue.toLocaleLowerCase());
		if(res === undefined){
			flag = false;
			return flag
		}
		return flag;
	}


	isIntegerHeaderValueValid(formattedIntegerValue: any, headerDataLength:any):boolean{
		
	
		if(formattedIntegerValue === undefined || formattedIntegerValue === ""){
			return false;
		}

		if(headerDataLength != "0" && formattedIntegerValue.length > headerDataLength){
			return false;
		}

		const regex = /^\d+[0-9,.]*$/;
		console.log(regex.test(formattedIntegerValue));
		return regex.test(formattedIntegerValue);
	}

	isDropDownHeaderValueValid(formattedIntegerValue: any, dropdownValue:any):boolean{
		
	 if(formattedIntegerValue === undefined || formattedIntegerValue === ""){
			return false;
		}

	}
	isDateHeaderValueValid(formattedDateValue: any):boolean{	
		
		let date_regex = /^([0-9]{1,2})\/([0-9]{1,2})\/([0-9]{4})$/;
		if(formattedDateValue === undefined || formattedDateValue === ""){
			return false;
		}
		if(!date_regex.test(formattedDateValue))
		{
			return false;
		}
		try{
        	formattedDateValue = this.datepipe.transform(formattedDateValue, 'MM/dd/yyyy');
        }catch(error){
			return false;
		}
		return true;
	}

}