import { HttpClientTestingModule, HttpTestingController } from "@angular/common/http/testing";
import { async,TestBed } from "@angular/core/testing";
import { MatDialogModule } from "@angular/material";
import { GridApi, GridOptions, GridPanel } from "ag-grid";
import { AgGridModule } from "ag-grid-angular";
import { Observable } from "rxjs/Rx";
import { DashReport } from "../model/dash-report";
import { FlexApi } from "../model/flex-api-objects";
import { TemplateObject } from "../model/template-object";
import { AuthService } from "./auth-service";
import { FlexDashService } from "./flex-dash.service";
import { FlexValidationService } from "./flex-validation.service";
import { ServerCommunicationService } from "./server-communication-service";

describe('FlexDashService', () => {

   
    let httpMock1: HttpTestingController;
    let flexDashService: FlexDashService;
    let authService: jasmine.SpyObj<AuthService>;
    let serverCommService: jasmine.SpyObj<ServerCommunicationService>;
    let flexValidationService: jasmine.SpyObj<FlexValidationService>;
    let gridApi:any;
   

       beforeEach(async(() => {
         const serverCommunicationServiceSpy = jasmine.createSpyObj('ServerCommunicationService', ['get_fileDownload','flex_post','post_fileDownload','put']);
         const authServiceSpy = jasmine.createSpyObj('AuthService', ['getLoggedInUser']);
         const flexValidationServiceSpy = jasmine.createSpyObj('FlexValidationService', ['formatCharacterColumnData',
        'formatDateColumnData','formatCurrencyColumnData','formatPercentageColumnData','formatBooleanColumnData','formatIntegerColumnData','formatDropDownColumnData']);
         const gridApiSpy = jasmine.createSpyObj('GridApi',['refreshCells']);
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule,
                MatDialogModule,
                AgGridModule.withComponents(
                  [
                  ]),
            ],
            providers: [
              FlexDashService,{provide:ServerCommunicationService,useValue:serverCommunicationServiceSpy},
              {provide:AuthService,useValue:authServiceSpy},
              {provide:FlexValidationService,useValue:flexValidationServiceSpy},
              {provide:GridApi,useValue:gridApiSpy}
            ]
        });
           flexDashService = TestBed.get(FlexDashService)
           authService = TestBed.get(AuthService) as jasmine.SpyObj<AuthService>;
           serverCommService = TestBed.get(ServerCommunicationService) as jasmine.SpyObj<ServerCommunicationService>;
           flexValidationService = TestBed.get(FlexValidationService) as jasmine.SpyObj<FlexValidationService>;
           gridApi = TestBed.get(GridApi) as jasmine.SpyObj<GridApi>;

            httpMock1 = TestBed.get(HttpTestingController);
            httpMock1.expectOne({
              url: 'assets/config',
              method: 'get'
          }).flush(hostConfig);
          httpMock1.verify();

    }));
    
    const hostConfig: any = {
        "production": false,
        "host": "http://localhost:8080/",
        "cshost": "https://api-dit.connectcdk.com/",
        "refreshToken": "8adaf13a-06c5-4cd1-bca5-70edf23323fc"
    }


    it('test importCOAData',()=>{
         
      const fakeFile = (): File => {
        const blob = new Blob([''], { type: 'application/vnd.ms-excel' });
        return blob as File;
    };
        let cmfNumber = "A39400QA5";
        let storeNumber = "01";

       serverCommService.get_fileDownload.and.returnValue(Observable.of(fakeFile));
       
       flexDashService.importCOAData(cmfNumber,storeNumber)
                        .subscribe((data:any)=>{
                          expect(data).toBe(fakeFile,'service returned stub value')
                        })
        expect(serverCommService.get_fileDownload.calls.count()).toBe(1, 'spy method was called once');
        
    }); 

     it('test importFlexData',()=>{

          const flex_post: FlexApi={
            cmfNumber: "A39400QA5",
            functionalAreaId: "0a5dee14-0dd1-42b6-8a5b-ad2cce4171e8",
            projectId: "d6d83187-6f83-4cad-9816-7eed2d416de4",
            storeId: "edaf5a05-4978-4130-acb8-e92b1bdc441d",
            storeNumber: "01"     
        }
              const flex_post_response : any = {
                "Purchase Terms": [
                    {
                      "contract_term_in_months": "60",
                      "days_to_first_payment": "30",
                      "id": "83a71061-0513-45b2-bc77-deb71dc5f770",
                      "recordType": 2000,
                      "index": "2000",
                      "rowDataId": "b7e1f1d8-991c-4512-b262-0fa9cb737bfc"
                    }
                  ],
                  "We Owe Options": [
                    {
                      "fee_option": "Fee/Option-1",
                      "profit_type": "B - Back-end Item",
                      "description": "ACCESSORY                ",
                      "suggested_retail_price": "$200",
                      "profit_type_query_field": "B",
                      "dealer_cost": "$120",
                      "include_in_we_owe_tax_1_total": "N"
                    }
                  ],
                  "Lienholder": [
                    {
                        "lienholder_name": "FINANCE AND THRIF",
                        "lienholder_address": "PO BOX 311",
                        "lienholder_city": "PORTERVILLE",
                        "lienholder_state": "CA",
                        "lienholder_country": "USA",
                        "lienholder_phone": "5595629818",
                        "title_work_name": "FINANCE AND THRIFT",
                        "title_work_address": "PO BOX 311",
                        "title_work_city": "PORTERVILL",
                        "title_work_state": "CA",
                        "title_work_zip": "93258    ",
                        "loss_payee_name": "FINANCE AND THRIFT",
                        "loss_payee_address": "PO BOX 311",
                        "loss_payee_city": "PORTERVILLE",
                        "loss_payee_state": "CA",
                        "loss_payee_zip": "93258    ",
                        "default_purchase_finance_institution": "No",
                        "default_product_sale_finance_institution": "No",
                        "purchase_calc_method": "0 - STANDARD",
                        "same_day_calcs": "Blank - None",
                        "lender_code": "VALLEY FIRST CU",
                        "purchase_calc_method_query_field": "0 ",
                        "purchase_reserve_method": "80",
                        "days_per_year": "365",
                        "same_day_calcs_query_field": " ",
                        "vsi_amount": "",
                        "ppi_amount": ""
                      }
                    ],
                    "Dealer Information - US" : [
                        {
                            "name": "THOMPSON CHEVROLET BUICK GMC            ",
                            "address": "701 S. 2ND ST / PO BX 95      ",
                            "city": "PATTERSON                     ",
                            "state": "MO",
                            "zip_code": "95363    ",
                            "county": "STANISLAUS          ",
                            "phone_number": "2098923311",
                            "federal_tax_id": "94-2180090          ",
                            "state_tax_id": " 173-0603-6          ",
                            "company_number": "#CO#"
                          }
                      ]
            }
         
            serverCommService.flex_post.and.returnValue(Observable.of(flex_post_response));
            flexDashService.importFlexData(flex_post)
                            .subscribe((data:any)=>{
                              expect(data).toBe(flex_post_response);
                            })

            expect(serverCommService.flex_post.calls.count()).toBe(1, 'spy method was called once');                           
 
    });


    it('test exportPDFtReport',()=>{

            const file_download_model:DashReport={
              projectNumber: "Demo112",
              storeId: "d6d83187-6f83-4cad-9816-7eed2d416de4",
              storeName: "qaTest",
              functionalUnitId: "d6ae02d9-251d-45c9-9786-07f4dba8e8d1",
              templateName: "Service",
              functionalAreaId: "c7c5362a-056e-4711-9ca5-6486e712a9a7",
              screenName: "Account Definition",
              columnList: [
                "Starting RO Number",
                "Ending RO Number",
                "Next RO Number",
                "RO Suffix",
                "Warn users before ending RO Number is reached?",
                "Number of ROs prior to Ending Number in which to warn user",
                "Dealer Code",
                "Pay Period",
                "Pay Period Begin Date",
                "Default Labor Type Flag",
                "Default Customer Labor Rate",
                "0"
              ]
            }

            const fakeFile = (): File => {
              const blob = new Blob(['testing'], {type: 'application/pdf'});
              return blob as File;
              }; 

            serverCommService.post_fileDownload.and.returnValue(Observable.of(fakeFile));
            flexDashService.exporPDFtReport(file_download_model)
                            .subscribe((data:any)=>{
                              expect(data).toBe(fakeFile,'service returned stub value')
                          })
            expect(serverCommService.post_fileDownload.calls.count()).toBe(1, 'spy method was called once');        
    })
    

    it('test importGLRawData',()=>{
         
      const fakeFile = (): File => {
        const blob = new Blob([''], { type: 'application/vnd.ms-excel' });
        return blob as File;
    };
        let cmfNumber = "A39400QA5";
        let storeNumber = "01";

       serverCommService.get_fileDownload.and.returnValue(Observable.of(fakeFile));
       
       flexDashService.importGLRawData(cmfNumber,storeNumber)
                        .subscribe((data:any)=>{
                          expect(data).toBe(fakeFile,'service returned stub value')
                        })
        expect(serverCommService.get_fileDownload).toHaveBeenCalledTimes(1);
        
    }); 

    it('test generateFileNameForExportPDF ',()=>{
      let todayDay = new Date().toLocaleDateString()
      let mockFileName = "demo112-qatest-service-account_definition-"+todayDay+".pdf";
      let projectNumber = "Demo112";
      let storeFullName = "qatest";
      let functionalAreaName = "Service";
      let functionalUnitName = "Account Definition";

      let fileName = flexDashService.generateFileNameForExportPDF(projectNumber,storeFullName,functionalAreaName,functionalUnitName)
      expect(fileName).toEqual(mockFileName)
      
    })

    it('test generateFileNameForExportPDF for ProjectNumber NULL ',()=>{
      let todayDay = new Date().toLocaleDateString()
      let mockFileName = "service-"+todayDay+".pdf";
      let projectNumber = null
      let storeFullName = "qatest";
      let functionalAreaName = "Service";
      let functionalUnitName = "Account Definition";

      let fileName = flexDashService.generateFileNameForExportPDF(projectNumber,storeFullName,functionalAreaName,functionalUnitName)
      expect(fileName).toEqual(mockFileName)
      
    })

     it('test bindFlexApi',()=>{

    let templateContext: any={
        "template": {
          "functionalAreaName": "Service"
        },
        "screenContextList": [
          {
            "screen": {
              "screenName": "Tax Codes"
            }
          }
        ]
      }

      let currentScreenContext:any={
        "screen": {
          "screenName": "Tax Codes"
        }
      }
      let responseData:any={
        "Tax Codes": [
          {
            "tax_code": "#CO#",
            "agency_type": "State",
            "tax_percent": "1.2000",
            "tax_account": "324       ",
            "tax_journal": "30  "
          }
        ]
      }
      spyOn(flexDashService,'dashResponse').and.returnValue('')
      flexDashService.bindFlexAPi(templateContext,currentScreenContext,gridApi,responseData);

      expect(flexDashService.dashResponse).toHaveBeenCalledTimes(1);

    }) 
    

    it('test isUnsavedDataPresent',()=>{
      expect(flexDashService.isUnsavedDataPresent()).toBeFalsy();
    })

    it('test resetUnsavedDataPresent',()=>{
      expect(flexDashService.resetUnsavedDataPresent()).toBeFalsy();
    })

    it('test statusUpdateFunctionalArea',()=>{
      let storeId = "edaf5a05-4978-4130-acb8-e92b1bdc441d";
      let functionalAreaId= "0a5dee14-0dd1-42b6-8a5b-ad2cce4171e8";

      let functionalArea: TemplateObject={
            "functionalAreaName": "Sales",
            "functionalAreaType": null,
            "clientSignoffDate": null,
            "storeId": "edaf5a05-4978-4130-acb8-e92b1bdc441d",
            "screenIds": [
              
            ],
            "oemName": null,
            "selected": false,
            "status": "Work in Progress",
            "platforms": [
              {
                "platformName": "FLEX",
                "platformCode": "flex",
                "selected": true
              }
            ],
            "vic": {
              "firstName": "Amrita",
              "lastName": "das",
              "loginId": "Amrita.das@cdk.com",
              "employeeId": null
            },
            "secondaryVic": {
              "firstName": "Amrita",
              "lastName": "das",
              "loginId": "Amrita.das@cdk.com",
              "employeeId": null
            },
            "clientFunctionalAreaUser": null,
            "version": 10,
            "isFailed": null,
            "inProcess": false,
            "productCode": "SLS",
            "productVersion": null,
            "bpId": "95ed5d56-4dc7-4369-b172-88da3c1bbb6b",
            "bpVersionId": "fa0f49d6-674d-4c0d-b363-ef36ba69cfb6",
            "bpTemplateId": "94d4f179-d582-440a-a685-38084e6f2399",
            "isDealerApproved": false,
            "stateStandardId": "7d6b078c-dcf5-4dd2-a2fa-e2eedde6c177",
            "stateStandardName": "Auxiliary Fields",
            "stateStandardVersionRecordType": "6a7adb4c-be11-423b-91fb-21b8add7e724",
            "stateStandardVersionName": "v1- Clone",
            "copyRowData": false,
            "showValidateOrTransferButton": false,
            "showProcessValidationResultsButton": true,
            "createdDate": null,
            "lastUpdatedDate": null,
            "createdBy": "Sagar.Aitla@cdk.com",
            "updatedBy": "Sagar.Aitla@cdk.com",
            "incorporateBpChanges": false,
            "isLocked":false,
            "id": "edaf5a05-4978-4130-acb8-e92b1bdc441d",
            "recordType": "0a5dee14-0dd1-42b6-8a5b-ad2cce4171e8"
      }
        flexDashService.statusUpdateFunctionalArea(functionalArea,storeId,functionalAreaId)
        expect(serverCommService.put).toHaveBeenCalledTimes(1);


    })

    it('test statusUpdateFunctionalArea for requestDealerForApproval status',()=>{
      let storeId = "edaf5a05-4978-4130-acb8-e92b1bdc441d";
      let functionalAreaId= "0a5dee14-0dd1-42b6-8a5b-ad2cce4171e8";

      let functionalArea: TemplateObject={
            "functionalAreaName": "Sales",
            "functionalAreaType": null,
            "clientSignoffDate": null,
            "storeId": "edaf5a05-4978-4130-acb8-e92b1bdc441d",
            "screenIds": [
              
            ],
            "oemName": null,
            "selected": false,
            "status": "requestDealerForApproval",
            "platforms": [
              {
                "platformName": "FLEX",
                "platformCode": "flex",
                "selected": true
              }
            ],
            "vic": {
              "firstName": "Amrita",
              "lastName": "das",
              "loginId": "Amrita.das@cdk.com",
              "employeeId": null
            },
            "secondaryVic": {
              "firstName": "Amrita",
              "lastName": "das",
              "loginId": "Amrita.das@cdk.com",
              "employeeId": null
            },
            "clientFunctionalAreaUser": null,
            "version": 10,
            "isFailed": null,
            "inProcess": false,
            "productCode": "SLS",
            "productVersion": null,
            "bpId": "95ed5d56-4dc7-4369-b172-88da3c1bbb6b",
            "bpVersionId": "fa0f49d6-674d-4c0d-b363-ef36ba69cfb6",
            "bpTemplateId": "94d4f179-d582-440a-a685-38084e6f2399",
            "isDealerApproved": false,
            "stateStandardId": "7d6b078c-dcf5-4dd2-a2fa-e2eedde6c177",
            "stateStandardName": "Auxiliary Fields",
            "stateStandardVersionRecordType": "6a7adb4c-be11-423b-91fb-21b8add7e724",
            "stateStandardVersionName": "v1- Clone",
            "copyRowData": false,
            "showValidateOrTransferButton": false,
            "showProcessValidationResultsButton": true,
            "createdDate": null,
            "lastUpdatedDate": null,
            "createdBy": "Sagar.Aitla@cdk.com",
            "updatedBy": "Sagar.Aitla@cdk.com",
            "incorporateBpChanges": false,
            "isLocked":false,
            "id": "edaf5a05-4978-4130-acb8-e92b1bdc441d",
            "recordType": "0a5dee14-0dd1-42b6-8a5b-ad2cce4171e8"
      }
        flexDashService.statusUpdateFunctionalArea(functionalArea,storeId,functionalAreaId)
        expect(serverCommService.put).toHaveBeenCalledTimes(1);


    })


    it('test dashResponse',()=>{

      const funUnitObj : any={
        "screen": {
          "screenName": "Account Definition",
          "gridOptionsModel": {
            "animatedRows": false,
            "rowSelection": "multiple",
            "columnDefs": [
              {
                "headerName": "Starting RO Number",
                "field": "starting_ro_number",
                "dataType": "INT",
                "required": "false",
                "editable": "true",
                "editableByCDKOnly": "false",
                "defaultValue": "",
                "validationRule": "",
                "dataLength": 9,
                "cellEditor": "agLargeTextCellEditor",
                "cellEditorParams": {
                  "maxLength": 9
                }
              }
            ],
            "rowData":null
          },
          "description": "Account Definition",
          "updated": false,
          "version": 0,
          "productCode": "SVC",
          "selected":true,
          "templateId":"543fa340-21c3-4e1b-ac04-8a604eab1533",
          "index": 0,
          "bpScreenId": "54bfa340-21c3-4e1b-ac04-8a604eab1533",
          "copyRowData": false,
          "rowDataEmpty": true,
          "bpPropagationCompleted": false,
          "id": "c7c5362a-056e-4711-9ca5-6486e712a9a7",
          "recordType": "d6ae02d9-251d-45c9-9786-07f4dba8e8d1"
        }
      }
    
        spyOn(flexDashService,'dataSetToSave').and.returnValue(Observable.of({}))

        flexDashService.dashResponse(funUnitObj,gridApi);

        expect(flexValidationService.formatCharacterColumnData).toHaveBeenCalledTimes(1);
        expect(flexValidationService.formatDateColumnData).toHaveBeenCalledTimes(1);
        expect(flexValidationService.formatCurrencyColumnData).toHaveBeenCalledTimes(1);
        expect(flexValidationService.formatPercentageColumnData).toHaveBeenCalledTimes(1);
        expect(flexValidationService.formatBooleanColumnData).toHaveBeenCalledTimes(1);
        expect(flexValidationService.formatIntegerColumnData).toHaveBeenCalledTimes(1);
        expect(flexValidationService.formatDropDownColumnData).toHaveBeenCalledTimes(1);
    })
  

    it('test dataSetToSave',()=>{

      const funUnitObj : any={
        "screen": {
          "screenName": "Account Definition",
          "gridOptionsModel": {
            "columnDefs": [
              {
                "headerName": "Starting RO Number",
                "field": "starting_ro_number",
                "dataType": "INT",
                "required": "false",
                "editable": "true",
            
                "cellEditor": "agLargeTextCellEditor",
                "cellEditorParams": {
                  "maxLength": 9
                }
              }
            ],
            "rowData":null
          },
          "description": "Account Definition",
          "updated": false,
          "version": 0,
          "productCode": "SVC",
          "selected":true,
          "templateId":"543fa340-21c3-4e1b-ac04-8a604eab1533",
          "index": 0,
          "bpScreenId": "54bfa340-21c3-4e1b-ac04-8a604eab1533",
          "copyRowData": false,
          "rowDataEmpty": true,
          "bpPropagationCompleted": false,
          "id": "c7c5362a-056e-4711-9ca5-6486e712a9a7",
          "recordType": "d6ae02d9-251d-45c9-9786-07f4dba8e8d1"
        },
        "rowData": [
          {
            "rowDataId": "3f3a9b29-9e0e-4962-98da-abf48ca4006a",
            "data": {
              "dealer_code": "###",
              "starting_ro_number": "###",
              "next_ro_number": "###",
              "id": "fbc70274-96ae-4dd2-9846-cb517e142c2e",
              "recordType": 3000,
              "index": "3000",
              "default_customer_labor_rate": "",
              "rowDataId": "3f3a9b29-9e0e-4962-98da-abf48ca4006a",
              "error": {
                "rowIndex": 0,
                "timeStamp": "",
                "errors": [
                  {
                    "errorDescription": "Integer value is invalid. Please enter correct value",
                    "errorField": "starting_ro_number",
                    "errorLevel": "",
                    "isUpdated": false
                  },
                  {
                    "errorDescription": "Integer value is invalid. Please enter correct value",
                    "errorField": "next_ro_number",
                    "errorLevel": "",
                    "isUpdated": false
                  }
                ]
              }
            },
            "id": "fbc70274-96ae-4dd2-9846-cb517e142c2e",
            "recordType": "3000"
          }
        ],
        "rowDataIdsToBeDeleted": null
      }
      flexDashService.dataSetToSave(funUnitObj);
    })

});