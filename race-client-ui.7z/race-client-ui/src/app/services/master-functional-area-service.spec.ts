import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, TestBed } from "@angular/core/testing"
import { MatDialogModule } from "@angular/material";
import { Observable } from "rxjs/Rx";
import { MasterFunctionalArea } from "../model/master-functional-area";
import { AuthService } from "./auth-service";
import { MasterFunctionalAreaService } from "./master-functional-area-service";
import { ServerCommunicationService } from "./server-communication-service";

describe('MasterFunctionalAreaService', () => {
    let masterFunctionalAreaService: MasterFunctionalAreaService;
    beforeEach(async(() => {

        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule,
                MatDialogModule
            ],
            providers: [
                MasterFunctionalAreaService,AuthService,ServerCommunicationService
            ]
        });

        masterFunctionalAreaService = TestBed.get(MasterFunctionalAreaService);
    }));

    const master_functional_are_model: MasterFunctionalArea ={

        "functionalAreaName": "UI_Test",
        "functionalAreaType": "MasterFunctionalArea",
        "productCode": "SVC",
        "productVersion": "11",
        "version":null,
        "oemName": null,
        "platforms": [
            {
              "id":null,
              "platformCode": "drive",
              "platformName": "DRIVE",
              "selected": true,
              "recordType":null
            }
          ] ,
          "noOfFunctionalUnits": null,
          "propagationStarted":false,
          "id":null,
          "recordType":null
            
    }
    const master_functional_are_response: MasterFunctionalArea ={

        "functionalAreaType": "MasterFunctionalArea",
        "functionalAreaName": "UI_Test",
        "oemName": null,
        "platforms": [
          {
            "id": null,
            "platformName": "DRIVE",
            "platformCode": "drive",
            "selected": true,
            "recordType":null
          }
        ],
        "version": "0",
        "productCode": "SVC",
        "productVersion": "11",
        "propagationStarted": false,
        "noOfFunctionalUnits": null,
        "id": "ac27a733-e109-40c4-b15f-5f2909c6ff4c",
        "recordType": "FunctionalAreaInfo"
    }

    const list_of_master_functional_are_response: MasterFunctionalArea[] =[
        {
            "functionalAreaType": "MasterFunctionalArea",
            "functionalAreaName": "$FATestToday",
            "oemName": null,
            "platforms": [
              {
                "id": null,
                "platformName": "FLEX",
                "platformCode": "flex",
                "selected": true,
                "recordType":null

              }
            ],
            "productCode": "ACCT",
            "productVersion": "1",
            "noOfFunctionalUnits": null,
            "version": "0",
            "propagationStarted": false,
            "id": "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
            "recordType": "FunctionalAreaInfo"
          }
    ]     

    it('should create the MasterFunctionalAreaService instance', () => {
        expect(masterFunctionalAreaService).toBeDefined();
    });


    it('test createMasterFunctionalArea',()=>{

        spyOn(masterFunctionalAreaService,'post').and.returnValue(Observable.of(master_functional_are_response));

        masterFunctionalAreaService.createMasterFunctionalArea(master_functional_are_model)
                                   .subscribe((data:any)=>{
                                       expect(data).toBe(master_functional_are_response);
                                   })
        expect(masterFunctionalAreaService.post).toHaveBeenCalledTimes(1);
    })

    it('test fetchMasterFunctionalAreaList',()=>{

        spyOn(masterFunctionalAreaService,'get').and.returnValue(Observable.of(list_of_master_functional_are_response));
        masterFunctionalAreaService.fetchMasterFunctionalAreaList()
                                  .subscribe((data:any)=>{
                                  expect(data).toBe(list_of_master_functional_are_response);
                                  
        })
        expect(masterFunctionalAreaService.get).toHaveBeenCalledTimes(1);
    })

    it('test deleteMasterFunctionalArea',()=>{
        spyOn(masterFunctionalAreaService,'post').and.returnValue(Observable.of());
        masterFunctionalAreaService.deleteMasterFunctionalArea(master_functional_are_model);
        expect(masterFunctionalAreaService.post).toHaveBeenCalledTimes(1);
        
    })

    it('test fetchMasterFAByNameAndPlatformAndProductCode',()=>{
        let functionalAreaName = "UI_Test"
        let platformName = "DRIVE"
        let productCode = "SVC";
        spyOn(masterFunctionalAreaService,'get').and.returnValue(Observable.of(master_functional_are_response));
        masterFunctionalAreaService.fetchMasterFAByNameAndPlatformAndProductCode(functionalAreaName,platformName,productCode)
                                  .subscribe((data:any)=>{
                                   expect(data).toBe(master_functional_are_response);
                                    })
        expect(masterFunctionalAreaService.get).toHaveBeenCalledTimes(1);

        
    })

    it('test getMasterFunctionalAreaById',()=>{

        let functionalAreaId =  "ac27a733-e109-40c4-b15f-5f2909c6ff4c";
        spyOn(masterFunctionalAreaService,'get').and.returnValue(Observable.of(master_functional_are_response));
        masterFunctionalAreaService.getMasterFunctionalAreaById(functionalAreaId)
                                  .subscribe((data:any)=>{
                                   expect(data).toBe(master_functional_are_response);
                                    })
        expect(masterFunctionalAreaService.get).toHaveBeenCalledTimes(1);
    })


});