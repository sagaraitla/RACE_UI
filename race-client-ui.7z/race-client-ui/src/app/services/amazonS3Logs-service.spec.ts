import { HttpClientTestingModule } from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { of } from "rxjs";
import { AuthService } from "./auth-service";
import { AmazonS3LogsService } from "./amazonS3Logs-service";
import { ServerCommunicationService } from "./server-communication-service";

describe('AmazonS3LogsService', () => {
    let amazonS3LogsService: AmazonS3LogsService;

    beforeEach(() => {
        const serverCommunicationServiceSpy = jasmine.createSpyObj('ServerCommunicationService', ['get', 'post', 'put']);
        const authServiceSpy = jasmine.createSpyObj('AuthService', ['getLoggedInUser']);
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule
            ],
            providers: [
                AmazonS3LogsService, { provide: ServerCommunicationService, useValue: serverCommunicationServiceSpy },
                { provide: AuthService, useValue: authServiceSpy }
            ],
        });

        amazonS3LogsService = TestBed.get(AmazonS3LogsService);
    });

    const mockFileNamesResponse: any[] = [
        {
            "fileName": "COA",
            "path": "/setups/validate/2021-01-26/COA.txt"
        },
        {
            "fileName": "Cash In Bank",
            "path": "/setups/validate/2021-01-26/Cash In Bank.txt"
        }
    ];

    const mockGenericResponse: any = {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": mockFileNamesResponse,
        "executionTime": 123
    }

    const mockFileContent = "Json file content has been fetched into DMS."

    it('should fetch files names from s3 bucket by s3Path', () => {
        spyOn(amazonS3LogsService, 'get').and.returnValue(of(mockGenericResponse));
        amazonS3LogsService.getFileNamesFromS3Bucket("/setups/validate/").
            subscribe((data: any) => {
                expect(amazonS3LogsService.getFileNamesFromS3Bucket).toBeTruthy;
                expect(data).toBe(mockGenericResponse);
                expect(data.resultObj.length).toBe(2);
                expect(data.resultObj[0].fileName).toBe("COA");
                expect(data.resultObj[0].path).toBe("/setups/validate/2021-01-26/COA.txt");
                expect(amazonS3LogsService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch file content from s3 bucket by s3Path and fileName', () => {
        spyOn(amazonS3LogsService, 'get').and.returnValue(of(mockFileContent));
        amazonS3LogsService.readFileContentFromS3Bucket("/setups/validate/", "Parts.txt").
            subscribe((data: any) => {
                expect(amazonS3LogsService.readFileContentFromS3Bucket).toBeTruthy;
                expect(data).toBe(mockFileContent);
                expect(amazonS3LogsService.get).toHaveBeenCalledTimes(1);
            });
    });



});