import { HttpClientTestingModule } from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { of } from "rxjs";
import { AuthService } from "./auth-service";
import { ProjectService } from "./project-service";
import { ServerCommunicationService } from "./server-communication-service";

describe('ProjectService', () => {
    let projectService: ProjectService;

    beforeEach(() => {
        const serverCommunicationServiceSpy = jasmine.createSpyObj('ServerCommunicationService', ['get', 'post', 'put']);
        const authServiceSpy = jasmine.createSpyObj('AuthService', ['getLoggedInUser']);
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule
            ],
            providers: [
                ProjectService, { provide: ServerCommunicationService, useValue: serverCommunicationServiceSpy },
                { provide: AuthService, useValue: authServiceSpy }
            ],
        });

        projectService = TestBed.get(ProjectService);
    });

    const mockProjectListResponse: any[] = [
        {
            "projectNumber": "ProjDemo",
            "isProject": 0
        }
    ];

    const mockProjectObject: any = {
        "projectNumber": "ProjDemo",
        "isProject": 0
    }

    const mockGenericResponse: any = {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": mockProjectListResponse,
        "executionTime": 123
    }

    const mockStoreListResponse: any[] = [
        {
            "storeName": "Store1",
            "city": "Hyderabad"
        }
    ];

    it('should create the new Project', () => {
        spyOn(projectService, 'post').and.returnValue(of(mockProjectObject));
        projectService.createProject(mockProjectObject).
            subscribe((data: any) => {
                expect(projectService.createProject).toBeTruthy;
                expect(data).toBe(mockProjectObject);
                expect(data.projectNumber).toBe("ProjDemo");
                expect(data.isProject).toBe(0);
                expect(projectService.post).toHaveBeenCalledTimes(1);
            });
    });

    it('should update the existing Project', () => {
        spyOn(projectService, 'post').and.returnValue(of(mockProjectObject));
        projectService.updateProject(mockProjectObject).
            subscribe((data: any) => {
                expect(projectService.updateProject).toBeTruthy;
                expect(data).toBe(mockProjectObject);
                expect(data.projectNumber).toBe("ProjDemo");
                expect(data.isProject).toBe(0);
                expect(projectService.post).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch all projects with showProjectsAsVIC as true', () => {
        spyOn(projectService, 'get').and.returnValue(of(mockGenericResponse));
        projectService.getAllProjects(true).
            subscribe((data: any) => {
                expect(projectService.getAllProjects).toBeTruthy;
                expect(data).toBe(mockGenericResponse);
                expect(data.resultObj.length).toBe(1);
                expect(data.resultObj[0].projectNumber).toBe("ProjDemo");
                expect(data.resultObj[0].isProject).toBe(0);
                expect(projectService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch all projects with showProjectsAsVIC as false', () => {
        spyOn(projectService, 'get').and.returnValue(of(mockGenericResponse));
        projectService.getAllProjects(false).
            subscribe((data: any) => {
                expect(projectService.getAllProjects).toBeTruthy;
                expect(data).toBe(mockGenericResponse);
                expect(data.resultObj.length).toBe(1);
                expect(data.resultObj[0].projectNumber).toBe("ProjDemo");
                expect(data.resultObj[0].isProject).toBe(0);
                expect(projectService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch the project based on projectNumber ', () => {
        spyOn(projectService, 'get').and.returnValue(of(mockProjectObject));
        projectService.getProjectByNumber("ProjDemo").
            subscribe((data: any) => {
                expect(projectService.getProjectByNumber).toBeTruthy;
                expect(data).toBe(mockProjectObject);
                expect(data.projectNumber).toBe("ProjDemo");
                expect(data.isProject).toBe(0);
                expect(projectService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch all stores associated with project based on projectId', () => {
        spyOn(projectService, 'get').and.returnValue(of(mockStoreListResponse));
        projectService.getStoresOfProject("12345").
            subscribe((data: any) => {
                expect(projectService.getStoresOfProject).toBeTruthy;
                expect(data).toBe(mockStoreListResponse);
                expect(data.length).toBe(1);
                expect(data[0].storeName).toBe("Store1");
                expect(data[0].city).toBe('Hyderabad');
                expect(projectService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should delete the existing Project', () => {
        spyOn(projectService, 'post').and.returnValue(of(mockProjectObject));
        projectService.deleteProject(mockProjectObject).
            subscribe((data: any) => {
                expect(projectService.deleteProject).toBeTruthy;
                expect(data).toBe(mockProjectObject);
                expect(data.projectNumber).toBe("ProjDemo");
                expect(data.isProject).toBe(0);
                expect(projectService.post).toHaveBeenCalledTimes(1);
            });
    });


});