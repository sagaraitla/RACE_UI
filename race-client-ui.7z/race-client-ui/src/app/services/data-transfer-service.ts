import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class DataTransferService {
    public projectObject: any;
    public templateObject: any;
    public storeObject: any;
    public screenObject : any;
    public curentProject = new EventEmitter<any>();
    public currentTemplate = new EventEmitter<any>();
    public currentStore = new EventEmitter<any>();
    public currentScreen = new EventEmitter<any>();
    public templateStatusChanged : boolean = false; 
}
