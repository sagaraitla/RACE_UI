import { DatePipe } from "@angular/common";
import { HttpClientTestingModule} from "@angular/common/http/testing";
import { async,TestBed } from "@angular/core/testing";
import { MatDialogModule } from "@angular/material";
import { AgGridModule } from "ag-grid-angular";
import { FormattingService } from "./formatting-service";
import { ValidationService } from "./validation-service";

describe('ValidationService', () => {
    
    let validationService:ValidationService;
    let datePipe :DatePipe;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule,
                MatDialogModule,
                AgGridModule.withComponents(
                  [
                  ]),
            ],
            providers: [ ValidationService,FormattingService,DatePipe]
        });

        validationService = TestBed.get(ValidationService);
        datePipe = TestBed.get(DatePipe);
    }));

    it('should create the ValidationService', () => {
        expect(validationService).toBeDefined();
    });
    
    it('test isBooleanHeaderValueValid', () => {
      
        let booleanValue:any = undefined;
        let resultValue = validationService.isBooleanHeaderValueValid(booleanValue);
        expect(resultValue).toBe(true);

        let booleanValue1:any = "true";
        let resultValue1 = validationService.isBooleanHeaderValueValid(booleanValue1);
        expect(resultValue1).toBe(true);

        let booleanValue2:any = "0";
        let resultValue2 = validationService.isBooleanHeaderValueValid(booleanValue2);
        expect(resultValue2).toBe(true);

        let booleanValue3:any = "test";
        let resultValue3 = validationService.isBooleanHeaderValueValid(booleanValue3);
        expect(resultValue3).toBe(false);

    });

    it('test isCharacterHeaderValueisValid', () => {
      
        let formattedCharacterValue:any = undefined;
        let headerDataLength:any= 3;
        let resultValue = validationService.isCharacterHeaderValueisValid(formattedCharacterValue,headerDataLength);
        expect(resultValue).toBe(false);


        let formattedCharacterValue1:any = "mytest";
        let headerDataLength1:any= 3;
        let resultValue1 = validationService.isCharacterHeaderValueisValid(formattedCharacterValue1,headerDataLength1);
        expect(resultValue1).toBe(false);


        let formattedCharacterValue2:any = "mytest";
        let headerDataLength2:any= 10;
        let resultValue2 = validationService.isCharacterHeaderValueisValid(formattedCharacterValue2,headerDataLength2);
        expect(resultValue2).toBe(true);

    });

    it('test isCurrencyValueValid',()=>{

       let currencyValue: string= "$99.9";
       let resultValue = validationService.isCurrencyValueValid(currencyValue);
       expect(resultValue).toBe(true);
    })
    
    it('test isDropdownHeaderValueisValid',()=>{

       let  formattedDropdownValue: any =undefined;
       let  dropdownValue:any = "mytest";

       let resultValue = validationService.isDropdownHeaderValueisValid(formattedDropdownValue,dropdownValue);
       expect(resultValue).toBe(false);

       let  formattedDropdownValue1: any = "MYTEST";
       let  dropdownValue1:any[] = ["MYTEST"];
       let resultValue1 = validationService.isDropdownHeaderValueisValid(formattedDropdownValue1,dropdownValue1);
       expect(resultValue1).toBe(true); 

        let  formattedDropdownValue2: any = "1223";
       let  dropdownValue2:any[] = ["MYTEST"];
       let resultValue2 = validationService.isDropdownHeaderValueisValid(formattedDropdownValue2,dropdownValue2);
       expect(resultValue2).toBe(false); 
 
    });

    it('test isIntegerHeaderValueValid',()=>{

        let formattedIntegerValue: any = undefined;
        let headerDataLength:any = 5;
        let resultValue = validationService.isIntegerHeaderValueValid(formattedIntegerValue,headerDataLength);
        expect(resultValue).toBe(false)

        let formattedIntegerValue1: any = "45666";
        let headerDataLength1:any = 3;
        let resultValue1 = validationService.isIntegerHeaderValueValid(formattedIntegerValue1,headerDataLength1);
        expect(resultValue1).toBe(false)

        let formattedIntegerValue2: any = "456.66";
        let headerDataLength2:any = 0;
        let resultValue2 = validationService.isIntegerHeaderValueValid(formattedIntegerValue2,headerDataLength2);
        expect(resultValue2).toBe(true)

    });

    it('test isDateHeaderValueValid',()=>{

        let formattedDateValue: any= undefined;
        let resultValue = validationService.isDateHeaderValueValid(formattedDateValue);
        expect(resultValue).toBe(false);


        let formattedDateValue1: any= "test";
        let resultValue1 = validationService.isDateHeaderValueValid(formattedDateValue1);
        expect(resultValue1).toBe(false);

        let formattedDateValue2: any= "12/03/2020";
        let resultValue2 = validationService.isDateHeaderValueValid(formattedDateValue2);
        expect(resultValue2).toBe(true);

        
        let formattedDateValue3: any= "12-03-2020";
        spyOn(datePipe,'transform').and.throwError('error');
        let resultValue3 = validationService.isDateHeaderValueValid(formattedDateValue3);
        expect(resultValue3).toBe(false);

    });
    it('test isDateHeaderValueValid throw error',()=>{
        let pipe = new DatePipe('en-US');
        validationService.datepipe = pipe;
         let formattedDateValue3: any= "12/03/2020";
        spyOn(validationService.datepipe,'transform').and.throwError('error');
        let resultValue3 = validationService.isDateHeaderValueValid(formattedDateValue3);
        expect(resultValue3).toBe(false);
    });

    it('test isDropDownHeaderValueValid',()=>{

        let result = validationService.isDropDownHeaderValueValid(undefined,undefined);
        expect(result).toBeFalsy();
    });
});