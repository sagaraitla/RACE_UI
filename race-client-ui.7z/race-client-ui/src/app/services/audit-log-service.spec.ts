
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, TestBed } from "@angular/core/testing"
import { MatDialogModule } from "@angular/material";
import { Observable } from "rxjs";
import { AuditLogsObject } from "../model/audit-logs-object";
import { AuditLogsFAObject } from "../model/audit-logsfa-object";
import { AuditLogsFUObject } from "../model/audit-logsfu-object";
import { AuditLogsVTObject } from "../model/audit-logsvt-object";
import { ResultsInfoObject } from "../model/results-info-object";
import { AuditLogService } from "./audit-log-service";
import { AuthService } from "./auth-service";
import { ServerCommunicationService } from "./server-communication-service";

describe('AuditLogService', () => {

    let auditLogService: AuditLogService;
    let serverCommService: jasmine.SpyObj<ServerCommunicationService>;
    beforeEach(async(() => {
        const serverCommunicationServiceSpy = jasmine.createSpyObj('ServerCommunicationService', ['get','put','post']);
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule,
                MatDialogModule
            ],
            providers: [
                AuditLogService,AuthService,{provide:ServerCommunicationService,useValue:serverCommunicationServiceSpy}
            ]
        });
        auditLogService = TestBed.get(AuditLogService);
        serverCommService = TestBed.get(ServerCommunicationService) as jasmine.SpyObj<ServerCommunicationService>;
    }));


    const auditLogsForProject: AuditLogsObject[]=[
        {
            "date": new Date("2018-08-20T16:49:30.956+0000"),
            "projectNumber": "P000002",
            "user": "Beth.Maupin@cdk.com",
            "event": "New Project Created",
            "enterpriseId": "E0000022",
            "id": "444f49d1-d6ce-4c8b-9df8-7dbd8845587b",
            "updated": false,
            "recordType": "ProjectInfo",
            "validationRuleDesc":null,
            "fieldsInfo":[],
            "bestPracticeName":null
          }  
    ]

    const auditLogsFAObject: AuditLogsFAObject[]=[
        {
            "date": new Date("2019-03-15T15:38:49.308+0000"),
            "objectIdentifier": "Service",
            "user": "Jeff.Grence@cdk.com",
            "event": "Functional Area Updated",
            "id": "28896db3-4d4d-4df0-b1f5-26c730f0d561",
            "fieldsInfo":[]
          }
    ]

    const auditLogsFUObject: AuditLogsFUObject[]=[
        {
            "date": new Date("2019-03-15T15:38:08.081+0000"),
            "objectIdentifier": "Tech Data",
            "user": "Jeff.Grence@cdk.com",
            "event": "Functional Unit Modified",
            "id": "d4bbd335-9abb-4b06-9b26-5b05ee4cd5c6",
            "fieldsInfo":[]
          }
    ]

    const auditLogsVTObject: AuditLogsVTObject[]=[
        {
            "objectType": "ValidateTransfer",
            "date": new Date("2019-05-24T10:24:48.969+0000"),
            "objectIdentifier": "P2405:STORE1:TestFA_2405",
            "user": "Madhusudhan.Talakokkula@cdk.com",
            "event": "Validation in Progress",
            "s3Source": null,
            "s3LogsPath": null,
            "id": "3bef368f-ffcb-4f15-a490-d9370eb30699",
            "pvrresultsPresent": false,
            "recordType": "ValidateTransferInfo"
          }
    ]
    
    const genericResponse :any= {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [
          {
            "objectType": "Propagation",
            "date": "2020-10-29T09:56:13.635+0000",
            "objectIdentifier": "ProjOct21 : store1 : Propagate_Fu_To_BP_Drive",
            "user": "Suresh.Vanga@cdk.com",
            "event": "Functional units propagation has been completed",
            "id": "65768c40-62ff-4d0c-ade9-0ebffc74b69a",
            "recordType": "PropagationInfo"
          }
        ]
    }

    const gom_genericResponse :any= {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [
          {
            "headerName": "test3",
            "status": "Added",
            "gridOptionModelDiff": [
              {
                "fieldName": "headerName",
                "previousValue": "",
                "currentValue": "test3",
                "status": "Added"
              }
            ]
        }
      ]
    }

    const createOverrideErrorsAndWarningsAuditLog_response :any= {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": {
            "objectType": "ValidateTransfer",
            "date": "2021-01-23T14:11:37.532+0000",
            "objectIdentifier": "889864:EAGLE 2:Service",
            "user": "Sagar.Aitla@cdk.com",
            "event": "Validation Warnings/Errors Overridden",
            "s3Source": "",
            "s3LogsPath": "",
            "id": "5828191e-ebfb-45cb-92a2-33e4c94ac72c",
            "recordType": "ValidateTransferInfo",
            "pvrresultsPresent": false
        },
        "executionTime": 9
    }

    const resultsInfoObject: ResultsInfoObject[]=[
        {
            "level": "success",
            "functionalUnit": null,
            "rowIndex": null,
            "key": null,
            "value": null,
            "procedure": "dot.process.setups",
            "message": "RACE Company 400 ACDB Company ACDB400 exists in ORGDB/ORG.DATABASE",
            "timestamp": "20201230_07:25:02:358",
            "log": "/adp/logs/nj/race/20201230_072502358/20201230_072502358_dot.process.setups.log",
            "id": "9d77d45f-8642-41e2-b357-3fa01d1ad3fa",
            "recordType": "1acdad72-d15f-4a28-8c5b-b47a9bed2de3"
          }
    ] 

    const process_validation_rule_response: any= {

        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [
          {
            "status": "Failed",
            "description": "Dept deleted",
            "id": "4f41b74c-5517-4b6c-b367-b9ad69f22b97",
            "recordType": "fd11062b-7776-4c5e-9b99-fdab956c9153"
          }
        ],
        "executionTime": 8
    }

    it('should create the AuditLogService', () => {
        expect(auditLogService).toBeDefined();
    });


    it('test getAuditLogs',()=>{
        
        serverCommService.get.and.returnValue(Observable.of(auditLogsForProject));
        auditLogService.getAuditLogs()
                        .subscribe((data:any)=>{
                            expect(data).toBe(auditLogsForProject);
                        })
        expect(serverCommService.get).toHaveBeenCalledTimes(1);                

    });

    
    it('test getAuditLogsFA',()=>{
        
        serverCommService.get.and.returnValue(Observable.of(auditLogsFAObject));
        auditLogService.getAuditLogsFA()
                        .subscribe((data:any)=>{
                            expect(data).toBe(auditLogsFAObject);
                        })
        expect(serverCommService.get).toHaveBeenCalledTimes(1);                

    });

     
    it('test getAuditLogsFU',()=>{
        
        serverCommService.get.and.returnValue(Observable.of(auditLogsFUObject));
        auditLogService.getAuditLogsFU()
                        .subscribe((data:any)=>{
                            expect(data).toBe(auditLogsFUObject);
                        })
        expect(serverCommService.get).toHaveBeenCalledTimes(1);                

    });

    it('test getAuditLogsVT',()=>{
        
        serverCommService.get.and.returnValue(Observable.of(auditLogsVTObject));
        auditLogService.getAuditLogsVT()
                        .subscribe((data:any)=>{
                            expect(data).toBe(auditLogsVTObject);
                        })
        expect(serverCommService.get).toHaveBeenCalledTimes(1);                

    });

    it('test getAuditLogsChangePropagation',()=>{
        
        serverCommService.get.and.returnValue(Observable.of(genericResponse));
        auditLogService.getAuditLogsChangePropagation()
                        .subscribe((data:any)=>{
                            expect(data).toBe(genericResponse);
                        })
        expect(serverCommService.get).toHaveBeenCalledTimes(1);                

    });

    it('test getAuditLogsVR',()=>{
        
        serverCommService.get.and.returnValue(Observable.of(genericResponse));
        auditLogService.getAuditLogsVR()
                        .subscribe((data:any)=>{
                            expect(data).toBe(genericResponse);
                        })
        expect(serverCommService.get).toHaveBeenCalledTimes(1);                

    });

    it('test getAuditLogsBP',()=>{
        
        serverCommService.get.and.returnValue(Observable.of(genericResponse));
        auditLogService.getAuditLogsBP()
                        .subscribe((data:any)=>{
                         expect(data).toBe(genericResponse);
                        })
        expect(serverCommService.get).toHaveBeenCalledTimes(1);                

    });

    it('test getAuditlogFieldsInfoById',()=>{
        
        let fieldsInfoId = "20248336-c95a-4e3b-ac76-6728fdc2e5e4";
        serverCommService.get.and.returnValue(Observable.of(genericResponse));
        auditLogService.getAuditlogFieldsInfoById(fieldsInfoId)
                        .subscribe((data:any)=>{
                         expect(data).toBe(genericResponse);
                        })
        expect(serverCommService.get).toHaveBeenCalledTimes(1);                

    });

    it('test getResultsInfoById',()=>{
        
        let id = "9d77d45f-8642-41e2-b357-3fa01d1ad3fa";
        serverCommService.get.and.returnValue(Observable.of(resultsInfoObject));
        auditLogService.getResultsInfoById(id)
                        .subscribe((data:any)=>{
                         expect(data).toBe(resultsInfoObject);
                        })
        expect(serverCommService.get).toHaveBeenCalledTimes(1);                

    });

    it('test getPVRResultsInfoById',()=>{
        
        let result_id = "4f41b74c-5517-4b6c-b367-b9ad69f22b97";
        serverCommService.get.and.returnValue(Observable.of(process_validation_rule_response));
        auditLogService.getPVRResultsInfoById(result_id)
                        .subscribe((data:any)=>{
                         expect(data).toBe(process_validation_rule_response);
                        })
        expect(serverCommService.get).toHaveBeenCalledTimes(1);                

    });

    
    it('test createOverrideErrorsAndWarningsAuditLog',()=>{
        
        let projectName = "889864";
        let storeName = "EAGLE";
        let functionalAreaName = "Service";

        serverCommService.post.and.returnValue(Observable.of(createOverrideErrorsAndWarningsAuditLog_response));
        auditLogService.createOverrideErrorsAndWarningsAuditLog(projectName,storeName,functionalAreaName)
                        .subscribe((data:any)=>{
                         expect(data).toBe(createOverrideErrorsAndWarningsAuditLog_response);
                        })
        expect(serverCommService.post).toHaveBeenCalledTimes(1);                

    });
    
    it('test getGOMAuditlogFieldsInfoById',()=>{
        
        let fieldsInfoId = "5e4cf2a0-ee07-4869-92cf-1ead62800f44";
        
        serverCommService.get.and.returnValue(Observable.of(gom_genericResponse));
        auditLogService.getGOMAuditlogFieldsInfoById(fieldsInfoId)
                        .subscribe((data:any)=>{
                         expect(data).toBe(gom_genericResponse);
                        })
        expect(serverCommService.get).toHaveBeenCalledTimes(1);                

    });

    it('test getPropagatedFuAuditlogById',()=>{
        
        let fieldsInfoId = "20248336-c95a-4e3b-ac76-6728fdc2e5e4";
        
        serverCommService.get.and.returnValue(Observable.of(genericResponse));
        auditLogService.getPropagatedFuAuditlogById(fieldsInfoId)
                        .subscribe((data:any)=>{
                         expect(data).toBe(genericResponse);
                        })
        expect(serverCommService.get).toHaveBeenCalledTimes(1);                

    });
});