import { Injectable } from '@angular/core';
import { StoreObject } from '../model/store-object';
import { Observable } from 'rxjs';
import { ServerCommunicationService } from './server-communication-service';
import { TemplateObject } from '../model/template-object';


@Injectable()
export class StoreService extends ServerCommunicationService {
	
	public saveStore(store: StoreObject, selectedTemplates : TemplateObject[]): Observable<StoreObject> {
		return this.post('stores/store', {store : store, templateList : selectedTemplates}, 'DOT_STORE_CREATE', true);
	}
	
	public getStore(projectId: string, storeId: string): Observable<StoreObject> {
		return this.get('stores/store?projectId='+projectId+'&storeId='+storeId, 'DOT_STORE_VIEW', false);
	}
	
	public cloneStore(projectId: string, storeId: string): Observable<StoreObject> {
    	return this.post('stores/' + storeId + '/clone?projectId='+projectId, {}, 'DOT_STORE_CREATE', true);                
    }
	
	public deleteStore(store: StoreObject): Observable<any> {
		return this.post('stores/delete', store, 'DOT_STORE_DELETE', true);
    }
	
	public getFunctionalAreasOfStore(storeId: string): Observable<TemplateObject[]> {
		return this.get('stores/' + storeId + '/functionalAreas/all', 'DOT_STORE_VIEW', false);  
	}
}
