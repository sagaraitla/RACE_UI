import { Injectable } from '@angular/core';
import { initialize, LDClient, LDFlagSet } from 'ldclient-js';
import { Subject } from 'rxjs'

import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class LaunchDarklyService  {
    private launchDarklyClientSideId: string; 
	ldClient: LDClient;
	flags: LDFlagSet = {'race-sales-state-standards': true };
	flagChange: Subject < Object > = new Subject < Object > ();

    constructor(private http: HttpClient) {
        this.http.get('assets/config',{withCredentials: true}).subscribe((data: any) => { 
          this.launchDarklyClientSideId = data.launchDarklyClientSideId;
          this.ldClient = initialize(this.launchDarklyClientSideId, { key: "SAMPLE-USER-KEY", anonymous: true });
  		
          this.ldClient.on('initialized', (flags) => {
              if (flags['race-sales-state-standards'] !== undefined) {
                  this.flags['race-sales-state-standards'] = flags['race-sales-state-standards'];
              }
              this.flagChange.next(this.flags);
          });
  		
          this.ldClient.on('change', (flags) => {
              if (flags['race-sales-state-standards'] !== undefined) {
                  this.flags['race-sales-state-standards'] = flags['race-sales-state-standards'];
              }
              this.flagChange.next(this.flags);
          });
  		
          this.ldClient.on('ready', () => {
              this.setFlags();
          })
        });

    }
    
	setFlags() {
        this.flags = this.ldClient.allFlags();
    }
	
	changeUser(userKey) {
        this.ldClient.identify({
            key: userKey,
            name: userKey,
            anonymous: true
        });
    }
    

}