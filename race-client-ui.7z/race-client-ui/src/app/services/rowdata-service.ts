import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ServerCommunicationService } from './server-communication-service';


@Injectable()
export class RowDataService extends ServerCommunicationService {

    public getRowDataOfScreen(permissionCheckNeeded: boolean, screenId: string) {
        return this.get('rows/get/screen/' + screenId, 'DOT_PROJECT_VIEW', false);
    }

    public batchSaveAndDeleteRowData(dataToSave: any) {
        return this.post('rows/batchSave', dataToSave, 'DOT_PROJECT_VIEW', true);
    }

    public getSecRolesData(permissionCheckNeeded: boolean, platform: string): Observable<any> {
        return this.get('config/secRoles?platform=' + platform, 'DOT_SCREEN_CREATE', permissionCheckNeeded);
    }

}