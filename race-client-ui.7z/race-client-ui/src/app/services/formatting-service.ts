import { Injectable } from '@angular/core';
import { AlertDialogComponent } from '../alert-dialog/alert-dialog.component';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
@Injectable()
export class FormattingService {
	constructor(private dialog : MatDialog)
	{

	}
	//Method to add $ sign, comma and decimal point to format the value as $9,999.99
	formatCurrencyWithCommaAndDecimalPoint(value: any) : string {
		let currencyValue = '';
		if(value) {
			value = this.removeDollarSymbol(value);
			let parts = value.trim().split('.');
			if(parts.length <= 2) {
				let wholeNumberPart = parts[0].replace(/,/g, '');
				wholeNumberPart = wholeNumberPart.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				
				if(parts.length > 1) {
					let decimalPart = parts[1];
					if(decimalPart.length == 1) {
						decimalPart = decimalPart + '0';
					}
					currencyValue = '$' + wholeNumberPart + '.' + decimalPart;
				} else {
					currencyValue = '$' + wholeNumberPart + '.00';
				}
			} else {
				currencyValue = '$' + value;
			}
		}
		return currencyValue;
	}
		
	getFormattedBooleanValue(booleanFiledValue: any):string {
		let boolValue: any;
		if(booleanFiledValue === undefined){
			return "";
		}
		boolValue = booleanFiledValue.toLowerCase();
		if(boolValue === "true" || boolValue === "1"){
			return "1";
		}
		return "0";
	}

	getCurrencyFormatErrorMessage(currencyValue: string): string {
		let message: string = '';
		let parts = [];
		if(currencyValue) {
			parts = currencyValue.split('.');
			if(parts.length > 2) {
				message = 'Value with more than one decimal point is not valid!';
			} else {
				if(parts[1].length > 2) {
					message = 'Only two numbers allowed after decimal point!';
				} else {
					message = 'Currency value invalid!';
				}
			}
		}
		return message;
	}

	/**
	 * This Function is used to process cell contents to return proper formatted value.
	 * If cell contain non numeric value, then return null back to the caller.
	 * Alert message (for non numeric values) would be displayed when edit to the cell via UI and not via import.
	 * If contents of cell contain non-numeric value, then return null 
	 * @param value : value of the cell contents
	 * @param editViaUI : does the edit or update to the cell performed via UI or import
	 */
	
	formatPercentageWithDecimalPoint(value: any,editViaUI: boolean) : string {
        let percentageValue = '';
       
       if(value){
          value=this.removePercentageSymbol(value);
          if(value.includes('/')){
           	   let values=value.split('/');
               let division = (values[0]/values[1]).toFixed(4);
               percentageValue=division.toString()+ '%' ;
          }
          else{
            if(isNaN(value)){
			 	if(editViaUI) {
			 		let alertMsg : string[] = ["Please enter a number"];
			 		let alertDialogRef = this.dialog.open(AlertDialogComponent,
											{
												width : 'auto',
												height : 'auto',
												data : { messageListArray : alertMsg}
											});
				}
                return null;
		    }
          let parts=value.trim().split('.');
          let  decimalValue=null;
           if(parts.length===2){
             decimalValue=parts[1];
             if(decimalValue.length===1){
                percentageValue = value + '000'+'%';
             }
             else if(decimalValue.length===2){
                percentageValue = value + '00' +'%';
             }
             
             else if(decimalValue.length===3){
                percentageValue = value + '0' +'%';
             }
             else{
                percentageValue = value +'%';
             }
          }
          
          else if(parts.length===1){
                percentageValue = value + '.0000' +'%';
          }
         } 
       }
       return percentageValue;
    }        
	
	
	removeDollarSymbol(currencyValue: string): string {
		if(currencyValue.indexOf('$') == 0) {
			currencyValue = currencyValue.substring(1, currencyValue.length);
		}
		return currencyValue;
	}
	
	removePercentageSymbol(percentageValue: string): string {
        if(percentageValue.indexOf('%') == percentageValue.length-1) {
            percentageValue = percentageValue.substring(0, percentageValue.length-1);
        }
        return percentageValue;
    }
}