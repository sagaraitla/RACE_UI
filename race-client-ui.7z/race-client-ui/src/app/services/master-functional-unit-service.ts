import { Injectable } from '@angular/core';
import { MasterFunctionalUnit } from '../model/master-functional-unit';
import { Observable } from 'rxjs';
import { ServerCommunicationService } from './server-communication-service';
import { GenericResponse } from '../model/generic-response';

@Injectable()
export class MasterFunctionalUnitService extends ServerCommunicationService {
	
	public createMasterFunctionalUnit(functionalUnit: MasterFunctionalUnit): Observable<MasterFunctionalUnit> {
		return this.post('functionalUnit/create', functionalUnit, 'DOT_SCREEN_CREATE', true);
	}
	
	public createMultipleFunctionalUnits(functionalUnits: MasterFunctionalUnit[]): Observable<MasterFunctionalUnit[]> {
		return this.post('functionalUnit/create/multiple', functionalUnits, 'DOT_SCREEN_CREATE', true);
	}
	
	public fetchMasterFunctionalUnitList(): Observable<MasterFunctionalUnit[]> {
		return this.get('functionalUnit/all', 'DOT_SCREEN_VIEW', true);
	}
	
	public deleteMasterFunctionalUnit(functionalUnit: MasterFunctionalUnit) {
		return this.post('functionalUnit/delete', functionalUnit, 'DOT_SCREEN_DELETE', true);
	}
	
	public fetchFunctionalUnitsOfMasterFunctionalArea(functionalAreaId: string): Observable<MasterFunctionalUnit[]> {
		return this.get('functionalUnit/faId/' + functionalAreaId + '/all', 'DOT_SCREEN_VIEW', true);
	}

	public fetchFunctionalUnitByNameAndProductCode(functionalUnitName: string,productCode: string): Observable<GenericResponse> {
		return this.get('functionalUnit/' + functionalUnitName +'/'+ productCode, 'DOT_SCREEN_VIEW', true);
	}

	public fetchAllFunctionalUnitsByGOMModified():Observable<GenericResponse>{
		return this.get('functionalUnit/gom-modified','DOT_SCREEN_VIEW',true);
	}

	public fetchFUGomDifferences(functionalUnitId: string):Observable<GenericResponse>{
		return this.get('functionalUnit/'+functionalUnitId+'/gom-difference','DOT_SCREEN_VIEW',true);
	}
	
	public getMasterFunctionalUnitById(functionalUnitId: string): Observable<MasterFunctionalUnit>{
		return this.get('functionalUnit/'+functionalUnitId,'DOT_SCREEN_VIEW', true);
	}

	public propagateFuChangesToBP(modifiedFus: MasterFunctionalUnit[]): Observable<GenericResponse> {
        return this.put('functionalUnit/propagate', modifiedFus, 'DOT_SCREEN_CREATE', true);
	}
	
	public discardModifiedFuChanges(modifiedFu: MasterFunctionalUnit): Observable<GenericResponse> {
        return this.put('functionalUnit/'+modifiedFu.id+'/discard', modifiedFu, 'DOT_SCREEN_CREATE', true);
    }
}