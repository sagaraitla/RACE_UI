import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ServerCommunicationService } from './server-communication-service';
import {TemplateObject} from '../model/template-object';
import { GenericResponse } from '../model/generic-response';
import { StoreObject } from '../model/store-object';
@Injectable()
export class FunctionalAreaService extends ServerCommunicationService {

	
	public getFunctionalAreaStatus(storeId: string, functionalAreaId: string): Observable<string> {
		return this.get("template/" + storeId + "/" + functionalAreaId + "/status","DOT_PROJECT_VIEW", true, true); 
	}

	public changeProductStatus(projectid: string, storeId:string, functionalAreaId:string, status: string): Observable<any> {
		let url = 'projects/products/' + status + '?project=' + projectid + 
					'&store=' + storeId + '&functionalArea=' + functionalAreaId;
		return this.post(url, {}, 'DOT_PROJECT_VIEW', true);
	}

	public saveFunctionalArea(storeId: string, storeName:string, projectName:string, templateObjectList: TemplateObject[]): Observable<TemplateObject> {
		return this.post('template/' + storeId + '/saveBulk?storeName='+storeName+'&projectName='+projectName, templateObjectList, 'DOT_PROJECT_VIEW', false);
	}
	 
	public getFunctionalAreaById(storeId: string, functionalAreaId: string): Observable<TemplateObject> {
		let url = 'template/byId/' + storeId + '/' + functionalAreaId;
		return this.get(url, 'DOT_PROJECT_VIEW', false);
	}
	
	public validateAndTransferProduct(projectId: string,storeId: string,functionalAreaId: string,status: string): Observable<any> {
		let url = "projects/products/" + status + "?projectId=" + projectId + "&storeId=" +storeId +"&functionalAreaId=" +functionalAreaId;
		return this.post(url, {}, "DOT_PROJECT_VIEW", true);
	  }

	 public getFunctionalAreasByStoreId(permissionCheckNeeded: boolean, storeId : string): Observable<TemplateObject[]> {
		let url = 'template/byStoreId/' + storeId;
		return this.get(url,"DOT_PROJECT_VIEW",false);
	 }

	 public getFullFunctionalAreaByStoreIdAndFunctionalAreaId(storeId: string, functionalAreaId: string): Observable<any> {
		let url = 'template/fullFADetails/'  + storeId + '/' + functionalAreaId;
		return this.get(url,"DOT_PROJECT_VIEW",false);
	 }

	 public unlockFunctionalArea(storeId: string, functionalAreaId: string): Observable<any> {
		let url = 'template/unlock/'  + storeId + '/' + functionalAreaId;
		return this.post(url,{},"DOT_PROJECT_VIEW",false);
	 }

	 public getFunctionalAreasByPlatformAndProductCode(platform: string,productCode:string): Observable<GenericResponse>{
		return this.get('functionalArea/'+ platform+'/'+productCode,'DOT_ADMIN', true)
	}

	public saveSingleFunctionalArea(templateObject: TemplateObject): Observable<TemplateObject> {
		return this.post('template/save', templateObject,'DOT_PROJECT_VIEW', false);
	}

}
