import { Component } from "@angular/core";
import { async, TestBed } from "@angular/core/testing";
import { MatDialogModule } from "@angular/material";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { of } from "rxjs";
import { AlertDialogComponent } from "../alert-dialog/alert-dialog.component";
import { FormattingService } from "./formatting-service";

describe('FormattingService', () => {

    let formattingService: FormattingService;
    let alertDialogComponent: AlertDialogComponent;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                MatDialogModule,
                BrowserAnimationsModule,
            ],
            declarations: [ 
                AlertDialogComponent
            ],
            providers: [ FormattingService]
        }).overrideModule(BrowserModule, { set: { entryComponents: [AlertDialogComponent] } });;
        
        formattingService = TestBed.get(FormattingService);
    }));

    it('should create the FormattingService', () => {
        expect(formattingService).toBeDefined();
    });

    it('test removeDollarSymbol',()=>{

        let currencyValue = "$2.23";
        let formattedValue = formattingService.removeDollarSymbol(currencyValue);
        expect(formattedValue).toBe("2.23");

    });
    
    it('test removeDollarSymbol without "$" on currency value',()=>{

        let currencyValue = "2.23";
        let formattedValue = formattingService.removeDollarSymbol(currencyValue);
        expect(formattedValue).toBe("2.23");

    });

    it('test removePercentageSymbol ',()=>{

        let percentageValue = "0.0004%"
        let formattedValue = formattingService.removePercentageSymbol(percentageValue);
        expect(formattedValue).toBe(formattedValue);
    });

    it('test removePercentageSymbol  without "%" on percentage value',()=>{

        let percentageValue = "0.0004"
        let formattedValue = formattingService.removePercentageSymbol(percentageValue);
        expect(formattedValue).toBe(formattedValue);
    });
    
    it('test getFormattedBooleanValue for undefined',()=>{
        let booleanValue = undefined
        let formattedValue = formattingService.getFormattedBooleanValue(booleanValue);
        expect(formattedValue).toBe("");

    });
    it('test getFormattedBooleanValue for "true" or "1" or "0"',()=>{
        let booleanValue = "true"
        let formattedValue = formattingService.getFormattedBooleanValue(booleanValue);
        expect(formattedValue).toBe("1");

        let booleanValue1 = "1"
        let formattedValue1 = formattingService.getFormattedBooleanValue(booleanValue1);
        expect(formattedValue1).toBe("1");


        let booleanValue2 = "0"
        let formattedValue2 = formattingService.getFormattedBooleanValue(booleanValue2);
        expect(formattedValue2).toBe("0");

    });

    it('test getCurrencyFormatErrorMessage',()=>{

        let currencyValue= "$#####.00";
        let errorMessage  =formattingService.getCurrencyFormatErrorMessage(currencyValue);
        expect(errorMessage).toBe("Currency value invalid!")


        let currencyValue1= "$22.00.5";
        let errorMessage1  =formattingService.getCurrencyFormatErrorMessage(currencyValue1);
        expect(errorMessage1).toBe("Value with more than one decimal point is not valid!")

        let currencyValue2= "$22.345";
        let errorMessage2  =formattingService.getCurrencyFormatErrorMessage(currencyValue2);
        expect(errorMessage2).toBe("Only two numbers allowed after decimal point!")
        
        let currencyValue3= "";
        let errorMessage3  =formattingService.getCurrencyFormatErrorMessage(currencyValue3);
        expect(errorMessage3).toBe("")

    });

    it('test formatCurrencyWithCommaAndDecimalPoint',()=>{

        let inputPutValue = "88888";
        let formattedValue = formattingService.formatCurrencyWithCommaAndDecimalPoint(inputPutValue);
        expect(formattedValue).toBe("$88,888.00")

        let inputPutValue1 = "888.88";
        let formattedValue1 = formattingService.formatCurrencyWithCommaAndDecimalPoint(inputPutValue1);
        expect(formattedValue1).toBe('$888.88')
        
        let inputPutValue3 = "888.8";
        let formattedValue3 = formattingService.formatCurrencyWithCommaAndDecimalPoint(inputPutValue3);
        expect(formattedValue3).toBe("$888.80")
        
        let inputPutValue4 = "$5,66.00";
        let formattedValue4 = formattingService.formatCurrencyWithCommaAndDecimalPoint(inputPutValue4);
        expect(formattedValue4).toBe("$566.00")

        let inputPutValue5 = "$7.6.00";
        let formattedValue5 = formattingService.formatCurrencyWithCommaAndDecimalPoint(inputPutValue5);
        expect(formattedValue5).toBe("$7.6.00")

    });


    it('test formatPercentageWithDecimalPoint',()=>{

        let inputPutValue ="0.001234";
        let editViaUI:boolean= false;
        let formattedValue =formattingService.formatPercentageWithDecimalPoint(inputPutValue,editViaUI);
        expect(formattedValue).toBe("0.001234%");


        let inputPutValue1 ="0.004";
        let formattedValue1 =formattingService.formatPercentageWithDecimalPoint(inputPutValue1,editViaUI);
        expect(formattedValue1).toBe("0.0040%");

        let inputPutValue2 ="1.23";
        let formattedValue2 =formattingService.formatPercentageWithDecimalPoint(inputPutValue2,editViaUI);
        expect(formattedValue2).toBe("1.2300%");

        let inputPutValue3 ="4.2%";
        let formattedValue3 =formattingService.formatPercentageWithDecimalPoint(inputPutValue3,editViaUI);
        expect(formattedValue3).toBe("4.2000%");

        let inputPutValue4 ="7%";
        let formattedValue4 =formattingService.formatPercentageWithDecimalPoint(inputPutValue4,editViaUI);
        expect(formattedValue4).toBe("7.0000%");


        let inputPutValue5 ="55/3%";
        let formattedValue5 =formattingService.formatPercentageWithDecimalPoint(inputPutValue5,editViaUI);
        expect(formattedValue5).toBe("18.3333%");

    });

    it('test formatPercentageWithDecimalPoint if edit via UI is true',()=>{
    
        let inputPutValue ="100F";
        let editViaUI:boolean= true;
        let formattedValue =formattingService.formatPercentageWithDecimalPoint(inputPutValue,editViaUI);
    });



});

