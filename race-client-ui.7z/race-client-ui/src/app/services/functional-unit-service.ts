import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ServerCommunicationService } from './server-communication-service';
import {TemplateObject} from '../model/template-object';
import {ScreenObject} from '../model/screen-object';
import { GenericResponse } from '../model/generic-response';

@Injectable()
export class FunctionalUnitService extends ServerCommunicationService {

  public saveFunctionalUnits(screenObjectList: ScreenObject[], storeId: string, functionalAreaId:string): Observable<ScreenObject[]> {
	  return this.post('functionalunits/save/storeId/' + storeId + '/functionalAreaId/' + functionalAreaId, screenObjectList,'DOT_PROJECT_VIEW', false);
  }

  public getFunctionalUnitsOfFunctionalAreaForBpTree(functionalAreaId: String): Observable<any> { //keep the return type any for BP Tree
    return this.get('functionalunits/faId/' + functionalAreaId + '/all', 'DOT_PROJECT_VIEW', false);
  }
  
  public getFunctionalUnitsOfFunctionalArea(functionalAreaId: String): Observable<ScreenObject[]> {
    return this.get('functionalunits/faId/' + functionalAreaId + '/all', 'DOT_PROJECT_VIEW', false);
  }

  public getModifiedBestPracticeFus(storeId:string,functionalAreaId: String) : Observable<GenericResponse> {
    return this.get('functionalunits/'+storeId+'/' + functionalAreaId + '/modified', 'DOT_PROJECT_VIEW', false)
  } 

  public propagateFuChanges(projectId: String, storeId: String,faId:string,screenObjectList: ScreenObject[]) : Observable<GenericResponse> {
    return this.put('functionalunits/' + projectId + '/'+storeId + '/'+faId +'/propagate',screenObjectList, 'DOT_PROJECT_VIEW', false)
  } 

  public getFunctionalUnitGOMDiffs(storeId: string,faId: string,fuId: string):Observable<GenericResponse>{
		return this.get('functionalunits/'+storeId+'/'+faId+'/'+fuId+'/gom-difference','DOT_PROJECT_VIEW',false);
  }
  
  public discardPropagatedFuChanges(storeId: string,faId: string,fuId: string,screenObject:ScreenObject):Observable<GenericResponse>{
		return this.put('functionalunits/'+storeId+'/'+faId+'/'+fuId+'/discard',screenObject,'DOT_PROJECT_VIEW',false);
	}
  
}
