import { HttpClientTestingModule } from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { of } from "rxjs";
import { AuthService } from "./auth-service";
import { ValidationRuleService } from "./validation-rule-service";
import { ServerCommunicationService } from "./server-communication-service";

describe('ValidationRuleService', () => {
    let validationRuleService: ValidationRuleService;

    beforeEach(() => {
        const serverCommunicationServiceSpy = jasmine.createSpyObj('ServerCommunicationService', ['get', 'post', 'put']);
        const authServiceSpy = jasmine.createSpyObj('AuthService', ['getLoggedInUser']);
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule
            ],
            providers: [
                ValidationRuleService, { provide: ServerCommunicationService, useValue: serverCommunicationServiceSpy },
                { provide: AuthService, useValue: authServiceSpy }
            ],
        });

        validationRuleService = TestBed.get(ValidationRuleService);
    });

    const mockValidationRuleResponse: any = {
        "sourceProductCode": "ACCT",
        "sourceFunctionalAreaName": "Accounting",
        "sourceFunctionalUnitName": "COA"
    }

    const mockValidationRuleList: any[] = [
        {
            "sourceProductCode": "ACCT",
            "sourceFunctionalAreaName": "Accounting",
            "sourceFunctionalUnitName": "COA"
        }

    ];

    const mockGenericResponseWithList: any = {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": mockValidationRuleList,
        "executionTime": 123
    }

    const mockGenericResponseWithVR: any = {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": mockValidationRuleResponse,
        "executionTime": 123
    }

    it('should fetch all ValidationRules by platform name', () => {
        spyOn(validationRuleService, 'get').and.returnValue(of(mockGenericResponseWithList));
        validationRuleService.getValidationRulesByPlatformName("Drive").
            subscribe((data: any) => {
                expect(validationRuleService.getValidationRulesByPlatformName).toBeTruthy;
                expect(data).toBe(mockGenericResponseWithList);
                expect(data.resultObj.length).toBe(1);
                expect(data.resultObj[0].sourceFunctionalAreaName).toBe("Accounting");
                expect(data.resultObj[0].sourceProductCode).toBe("ACCT");
                expect(data.resultObj[0].sourceFunctionalUnitName).toBe("COA");
                expect(validationRuleService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch ValidationRule by validationRuleId', () => {
        spyOn(validationRuleService, 'get').and.returnValue(of(mockGenericResponseWithVR));
        validationRuleService.getValidationRule("3df4g5h").
            subscribe((data: any) => {
                expect(validationRuleService.getValidationRule).toBeTruthy;
                expect(data).toBe(mockGenericResponseWithVR);
                expect(data.resultObj.sourceFunctionalAreaName).toBe("Accounting");
                expect(data.resultObj.sourceProductCode).toBe("ACCT");
                expect(data.resultObj.sourceFunctionalUnitName).toBe("COA");
                expect(validationRuleService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should create the  ValidationRule', () => {
        spyOn(validationRuleService, 'post').and.returnValue(of(mockGenericResponseWithVR));
        validationRuleService.createValidationRule(mockValidationRuleResponse).
            subscribe((data: any) => {
                expect(validationRuleService.createValidationRule).toBeTruthy;
                expect(data).toBe(mockGenericResponseWithVR);
                expect(data.resultObj.sourceFunctionalAreaName).toBe("Accounting");
                expect(data.resultObj.sourceProductCode).toBe("ACCT");
                expect(data.resultObj.sourceFunctionalUnitName).toBe("COA");
                expect(validationRuleService.post).toHaveBeenCalledTimes(1);
            });
    });

    it('should delete the  ValidationRule by vrId', () => {
        spyOn(validationRuleService, 'post').and.returnValue(of(mockGenericResponseWithVR));
        validationRuleService.deleteValidationRule("e4r45").
            subscribe((data: any) => {
                expect(validationRuleService.deleteValidationRule).toBeTruthy;
                expect(data).toBe(mockGenericResponseWithVR);
                expect(data.resultObj.sourceFunctionalAreaName).toBe("Accounting");
                expect(data.resultObj.sourceProductCode).toBe("ACCT");
                expect(data.resultObj.sourceFunctionalUnitName).toBe("COA");
                expect(validationRuleService.post).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch Processing validation results by platform,productCode,faId,storeId and projectId', () => {
        spyOn(validationRuleService, 'get').and.returnValue(of(mockGenericResponseWithList));
        validationRuleService.getProcessingValidationResults("drive", "ACCT", "s34dfe", "w34re3", "d56s45").
            subscribe((data: any) => {
                expect(validationRuleService.getProcessingValidationResults).toBeTruthy;
                expect(data).toBe(mockGenericResponseWithList);
                expect(data.resultObj.length).toBe(1);
                expect(data.resultObj[0].sourceFunctionalAreaName).toBe("Accounting");
                expect(data.resultObj[0].sourceProductCode).toBe("ACCT");
                expect(data.resultObj[0].sourceFunctionalUnitName).toBe("COA");
                expect(validationRuleService.get).toHaveBeenCalledTimes(1);
            });
    });

});