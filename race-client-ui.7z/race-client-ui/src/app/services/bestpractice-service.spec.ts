import { HttpClientTestingModule } from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { of } from "rxjs";
import { AuthService } from "./auth-service";
import { BestPracticeService } from "./bestpractice-service";
import { ServerCommunicationService } from "./server-communication-service";

describe('BestPracticeService', () => {
    let bestPracticeService: BestPracticeService;

    beforeEach(() => {
        const serverCommunicationServiceSpy = jasmine.createSpyObj('ServerCommunicationService', ['get', 'post', 'put']);
        const authServiceSpy = jasmine.createSpyObj('AuthService', ['getLoggedInUser']);
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule
            ],
            providers: [
                BestPracticeService, { provide: ServerCommunicationService, useValue: serverCommunicationServiceSpy },
                { provide: AuthService, useValue: authServiceSpy }
            ],
        });

        bestPracticeService = TestBed.get(BestPracticeService);
    });

    const mockBpListResponse: any[] = [
        {
            "bestPracticeName": "SampleBP",
            "isBestPractice": 0
        }
    ];

    const mockBpObject: any = {
        "bestPracticeName": "SampleBP",
        "isBestPractice": 0,
        "version": 1
    }

    const mockBpVersionObject: any = {
        "versionName": "2020",
        "active": true,
        "objectType": "BPVersionObject"
    }

    const mockFaArtifctsListResponse: any[] = [
        {
            "functionalAreaType": "MasterFunctionalArea",
            "functionalAreaName": "Service",
        }
    ];

    const mockTemplateObjectList: any[] = [
        {
            "functionalAreaType": "BPVersionFunctionalArea",
            "functionalAreaName": "Service",
        }

    ];

    const mockMasterFUList: any[] = [
        {
            "functionalUnitType": "MasterFunctionalUnit",
            "functionalUnitName": "Cash In Bank",
            "productCode": "ACCT"
        },
        {
            "functionalUnitType": "MasterFunctionalUnit",
            "functionalUnitName": "COA",
            "productCode": "ACCT"
        }
    ]

    const mockGenericResponse: any = {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": mockBpObject,
        "executionTime": 123
    }

    it('should fetch all best practices by bp type', () => {
        spyOn(bestPracticeService, 'get').and.returnValue(of(mockBpListResponse));
        bestPracticeService.getAllBestPracticesByType("OEM", false).
            subscribe((data: any) => {
                expect(bestPracticeService.getAllBestPracticesByType).toBeTruthy;
                expect(data.length).toBe(1);
                expect(data[0].bestPracticeName).toBe("SampleBP");
                expect(bestPracticeService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch all best practices by platform', () => {
        spyOn(bestPracticeService, 'get').and.returnValue(of(mockBpListResponse));
        bestPracticeService.getAllBestPracticesByPlatform(false, "OEM").
            subscribe((data: any) => {
                expect(bestPracticeService.getAllBestPracticesByType).toBeTruthy;
                expect(data.length).toBe(1);
                expect(data[0].bestPracticeName).toBe("SampleBP");
                expect(data).toBe(mockBpListResponse);
                expect(bestPracticeService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch best practice by bpName and platform', () => {
        spyOn(bestPracticeService, 'get').and.returnValue(of(mockBpObject));
        bestPracticeService.getByBestPracticeNameAndPlatform("SampleBP", "OEM", false).
            subscribe((data: any) => {
                expect(bestPracticeService.getByBestPracticeNameAndPlatform).toBeTruthy;
                expect(data).toBe(mockBpObject);
                expect(data.bestPracticeName).toBe("SampleBP");
                expect(bestPracticeService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should save the best practice object', () => {
        spyOn(bestPracticeService, 'post').and.returnValue(of(mockBpObject));
        bestPracticeService.saveBestPractice(mockBpObject, false).
            subscribe((data: any) => {
                expect(bestPracticeService.saveBestPractice).toBeTruthy;
                expect(data).toBe(mockBpObject);
                expect(data.bestPracticeName).toBe("SampleBP");
                expect(bestPracticeService.post).toHaveBeenCalledTimes(1);
            });
    });

    it('should clone the best practice version object', () => {
        spyOn(bestPracticeService, 'post').and.returnValue(of(mockBpVersionObject));
        bestPracticeService.cloneBestPracticeVersion(mockBpVersionObject).
            subscribe((data: any) => {
                expect(bestPracticeService.cloneBestPracticeVersion).toBeTruthy;
                expect(data).toBe(mockBpVersionObject);
                expect(data.versionName).toBe("2020");
                expect(data.active).toBe(true);
                expect(bestPracticeService.post).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch all functional area artifacts', () => {
        spyOn(bestPracticeService, 'get').and.returnValue(of(mockFaArtifctsListResponse));
        bestPracticeService.getAllFunctionalAreaArtifacts().
            subscribe((data: any) => {
                expect(bestPracticeService.getAllFunctionalAreaArtifacts).toBeTruthy;
                expect(data).toBe(mockFaArtifctsListResponse);
                expect(data.length).toBe(1);
                expect(data[0].functionalAreaType).toBe("MasterFunctionalArea");
                expect(data[0].functionalAreaName).toBe("Service");
                expect(bestPracticeService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch all BP version by bpVersionId', () => {
        spyOn(bestPracticeService, 'get').and.returnValue(of(mockBpVersionObject));
        bestPracticeService.getVersionsByBestPracticeId("1234", false).
            subscribe((data: any) => {
                expect(bestPracticeService.getVersionsByBestPracticeId).toBeTruthy;
                expect(data).toBe(mockBpVersionObject);
                expect(data.versionName).toBe("2020");
                expect(data.active).toBe(true);
                expect(bestPracticeService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should save the best practice version object', () => {
        spyOn(bestPracticeService, 'post').and.returnValue(of(mockBpVersionObject));
        bestPracticeService.saveBestPracticeVersion(mockBpVersionObject, []).
            subscribe((data: any) => {
                expect(bestPracticeService.saveBestPracticeVersion).toBeTruthy;
                expect(data).toBe(mockBpVersionObject);
                expect(data.versionName).toBe("2020");
                expect(data.active).toBe(true);
                expect(bestPracticeService.post).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch all functional areas of bpVersionId', () => {
        spyOn(bestPracticeService, 'get').and.returnValue(of(mockTemplateObjectList));
        bestPracticeService.getFunctionalAreasOfBpVersion("1234", false).
            subscribe((data: any) => {
                expect(bestPracticeService.getFunctionalAreasOfBpVersion).toBeTruthy;
                expect(data).toBe(mockTemplateObjectList);
                expect(data[0].functionalAreaType).toBe("BPVersionFunctionalArea");
                expect(data[0].functionalAreaName).toBe("Service");
                expect(bestPracticeService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch BP version object by bpVersionId and bpId', () => {
        spyOn(bestPracticeService, 'get').and.returnValue(of(mockBpVersionObject));
        bestPracticeService.getVersionOfBestPractice("1234", "3456", false).
            subscribe((data: any) => {
                expect(bestPracticeService.getVersionOfBestPractice).toBeTruthy;
                expect(data).toBe(mockBpVersionObject);
                expect(data.versionName).toBe("2020");
                expect(data.active).toBe(true);
                expect(bestPracticeService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch all SSS functional units by productCode', () => {
        spyOn(bestPracticeService, 'get').and.returnValue(of(mockMasterFUList));
        bestPracticeService.getAllSSSFunctionalUnits("SSS", false).
            subscribe((data: any) => {
                expect(bestPracticeService.getAllSSSFunctionalUnits).toBeTruthy;
                expect(data).toBe(mockMasterFUList);
                expect(data.length).toBe(2);
                expect(data[0].functionalUnitName).toBe('Cash In Bank');
                expect(data[0].functionalUnitType).toBe('MasterFunctionalUnit');
                expect(bestPracticeService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should save the SSS BP object', () => {
        spyOn(bestPracticeService, 'post').and.returnValue(of(mockBpVersionObject));
        bestPracticeService.saveSSSBestPracticeVersion(mockBpVersionObject, []).
            subscribe((data: any) => {
                expect(bestPracticeService.saveSSSBestPracticeVersion).toBeTruthy;
                expect(data).toBe(mockBpVersionObject);
                expect(data.versionName).toBe("2020");
                expect(data.active).toBe(true);
                expect(bestPracticeService.post).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch all SSS functional units by bpVersionId', () => {
        spyOn(bestPracticeService, 'get').and.returnValue(of(mockTemplateObjectList));
        bestPracticeService.getSSSFunctionalUnitsOfBpVersion("1234", false).
            subscribe((data: any) => {
                expect(bestPracticeService.getSSSFunctionalUnitsOfBpVersion).toBeTruthy;
                expect(data).toBe(mockTemplateObjectList);
                expect(data[0].functionalAreaType).toBe("BPVersionFunctionalArea");
                expect(data[0].functionalAreaName).toBe("Service");
                expect(bestPracticeService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch SSS Best Practice by bpName', () => {
        spyOn(bestPracticeService, 'get').and.returnValue(of(mockBpObject));
        bestPracticeService.getSSSBPByBestPracticeName("1234", false).
            subscribe((data: any) => {
                expect(bestPracticeService.getSSSBPByBestPracticeName).toBeTruthy;
                expect(data).toBe(mockBpObject);
                expect(data.bestPracticeName).toBe("SampleBP");
                expect(bestPracticeService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should delete the Best Practice object', () => {
        spyOn(bestPracticeService, 'post').and.returnValue(of(mockBpObject));
        bestPracticeService.deleteBestPractice(mockBpObject).
            subscribe((data: any) => {
                expect(bestPracticeService.deleteBestPractice).toBeTruthy;
                expect(bestPracticeService.post).toHaveBeenCalledTimes(1);
            });
    });

    it('should clone the Best Practice object', () => {
        spyOn(bestPracticeService, 'post').and.returnValue(of(mockGenericResponse));
        bestPracticeService.cloneBestPractice(mockBpObject).
            subscribe((data: any) => {
                expect(bestPracticeService.cloneBestPractice).toBeTruthy;
                expect(data.resultCode).toBe("CDK_200");
                expect(data.resultDescription).toBe("OK");
                expect(data.resultObj.bestPracticeName).toBe("SampleBP");
                expect(bestPracticeService.post).toHaveBeenCalledTimes(1);
            });
    });

    it('should check and update the Best Practice object', () => {
        spyOn(bestPracticeService, 'post').and.returnValue(of(mockBpObject));
        bestPracticeService.checkAndUpdateBPName(mockBpObject).
            subscribe((data: any) => {
                expect(bestPracticeService.checkAndUpdateBPName).toBeTruthy;
                expect(data.bestPracticeName).toBe("SampleBP");
                expect(bestPracticeService.post).toHaveBeenCalledTimes(1);
            });
    });




















});