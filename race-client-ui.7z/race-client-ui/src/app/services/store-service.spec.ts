import { HttpClientTestingModule } from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { of } from "rxjs";
import { AuthService } from "./auth-service";
import { StoreService } from "./store-service";
import { ServerCommunicationService } from "./server-communication-service";

describe('StoreService', () => {
    let storeService: StoreService;

    beforeEach(() => {
        const serverCommunicationServiceSpy = jasmine.createSpyObj('ServerCommunicationService', ['get', 'post', 'put']);
        const authServiceSpy = jasmine.createSpyObj('AuthService', ['getLoggedInUser']);
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule
            ],
            providers: [
                StoreService, { provide: ServerCommunicationService, useValue: serverCommunicationServiceSpy },
                { provide: AuthService, useValue: authServiceSpy }
            ],
        });

        storeService = TestBed.get(StoreService);
    });

    const mockStoreResponse: any = {
        "storeName": "Store1",
        "city": "Hyderabad"
    }

    const mockTemplateObjectList: any[] = [
        {
            "functionalAreaType": "BPVersionFunctionalArea",
            "functionalAreaName": "Service",
        }

    ];

    it('should save the new Store', () => {
        spyOn(storeService, 'post').and.returnValue(of(mockStoreResponse));
        storeService.saveStore(mockStoreResponse, []).
            subscribe((data: any) => {
                expect(storeService.saveStore).toBeTruthy;
                expect(data).toBe(mockStoreResponse);
                expect(data.storeName).toBe("Store1");
                expect(data.city).toBe("Hyderabad");
                expect(storeService.post).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch the store by projectId and storeId', () => {
        spyOn(storeService, 'get').and.returnValue(of(mockStoreResponse));
        storeService.getStore("2e34rs", "hg4r53r").
            subscribe((data: any) => {
                expect(storeService.getStore).toBeTruthy;
                expect(data).toBe(mockStoreResponse);
                expect(data.storeName).toBe("Store1");
                expect(data.city).toBe("Hyderabad");
                expect(storeService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should delete the store', () => {
        spyOn(storeService, 'post').and.returnValue(of(mockStoreResponse));
        storeService.deleteStore(mockStoreResponse).
            subscribe((data: any) => {
                expect(storeService.deleteStore).toBeTruthy;
                expect(data).toBe(mockStoreResponse);
                expect(data.storeName).toBe("Store1");
                expect(data.city).toBe("Hyderabad");
                expect(storeService.post).toHaveBeenCalledTimes(1);
            });
    });

    it('should clone the store', () => {
        spyOn(storeService, 'post').and.returnValue(of(mockStoreResponse));
        storeService.cloneStore("2e34rs", "hg4r53r").
            subscribe((data: any) => {
                expect(storeService.cloneStore).toBeTruthy;
                expect(data).toBe(mockStoreResponse);
                expect(data.storeName).toBe("Store1");
                expect(data.city).toBe("Hyderabad");
                expect(storeService.post).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch all the functional areas by storeId', () => {
        spyOn(storeService, 'get').and.returnValue(of(mockTemplateObjectList));
        storeService.getFunctionalAreasOfStore("2e34rs").
            subscribe((data: any) => {
                expect(storeService.getFunctionalAreasOfStore).toBeTruthy;
                expect(data).toBe(mockTemplateObjectList);
                expect(data.length).toBe(1);
                expect(data[0].functionalAreaName).toBe("Service");
                expect(data[0].functionalAreaType).toBe("BPVersionFunctionalArea");
                expect(storeService.get).toHaveBeenCalledTimes(1);
            });
    });



});