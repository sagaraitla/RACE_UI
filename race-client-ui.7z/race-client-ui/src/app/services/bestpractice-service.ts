import { Injectable } from '@angular/core';
import { AuthService } from '../services/auth-service';
import { Observable } from 'rxjs';
import {BestPracticeObject} from '../model/bestpractice-object';
import {BestPracticeVersionObject} from '../model/bestpractice-version-object';
import {MasterFunctionalArea} from '../model/master-functional-area';
import { ServerCommunicationService } from './server-communication-service';
import { TemplateObject } from '../model/template-object';
import {MasterFunctionalUnit} from '../model/master-functional-unit';
import { ScreenObject } from '../model/screen-object';
import { platform } from 'os';
import { GenericResponse } from '../model/generic-response';

@Injectable()
export class BestPracticeService extends ServerCommunicationService {

 
    getAllBestPracticesByType(bestPracticeType:string, permissionCheckNeeded: boolean): Observable<BestPracticeObject[]> {
        return this.get('bestPractice/'+bestPracticeType,'DOT_BP_VIEW', permissionCheckNeeded);          
    }

    getAllBestPracticesByTypeInternal(bestPracticeType:string, permissionCheckNeeded: boolean): Observable<BestPracticeObject[]> {
        return this.get('bestPractice/int/'+bestPracticeType,'DOT_PROJECT_VIEW', permissionCheckNeeded);          
    }

    getAllBestPracticesByPlatform(permissionCheckNeeded: boolean, platformName:string): Observable<BestPracticeObject[]> {
        return this.get('bestPractice/platform/'+platformName,'DOT_BP_VIEW', permissionCheckNeeded);          
    }

    getByBestPracticeNameAndPlatform(bestPracticeName: string, platformCode: string, permissionCheckNeeded: boolean) : Observable<BestPracticeObject>
    {
        const url = 'bestPractice/getOne/'+bestPracticeName+'/'+platformCode;
        return this.get(url,'DOT_BP_VIEW', permissionCheckNeeded);
    }

    saveBestPractice(bestPracticeObject: BestPracticeObject, permissionCheckNeeded: boolean): Observable<BestPracticeObject> {
        return this.post('bestPractice/create',bestPracticeObject,'DOT_BP_CREATE', true);
    }

    cloneBestPracticeVersion(bestPracticeVersion: BestPracticeVersionObject): Observable<BestPracticeVersionObject> {
        return this.post('bpVersions/clone', bestPracticeVersion,'DOT_BP_CREATE', true);
    }

    getAllFunctionalAreaArtifacts(): Observable<MasterFunctionalArea[]> {
        return this.get('functionalArea/all','DOT_BP_VIEW', false);
    }

    getVersionsByBestPracticeId(bestPracticeId : string, permissionCheckNeeded: boolean): Observable<BestPracticeVersionObject[]> {
        return this.get('bestPractice/'+bestPracticeId+'/versions/all','DOT_BP_VIEW', permissionCheckNeeded);
    }

    saveBestPracticeVersion(bestPracticeVersionObject: BestPracticeVersionObject, selectedTemplates : TemplateObject[]): Observable<BestPracticeVersionObject> {
        return this.post('bpVersions/create',{bestPracticeVersion:bestPracticeVersionObject, functionalAreaList:selectedTemplates},'DOT_BP_CREATE',true);
    }

    getFunctionalAreasOfBpVersion(bpVersionId: string, permissionCheckNeeded:boolean): Observable<TemplateObject[]> {
		return this.get('bpVersions/' + bpVersionId + '/functionalAreas/all', 'DOT_BP_VIEW', permissionCheckNeeded);  
    }
    
    getVersionOfBestPractice(bestPracticeId:string,bpVersionId: string, permissionCheckNeeded:boolean) : Observable<BestPracticeVersionObject> {
        return this.get('bpVersions/getOne/'+bestPracticeId+'/'+bpVersionId,'DOT_BP_VIEW', permissionCheckNeeded);
    }

    getAllSSSFunctionalUnits(productCode:string,permissionCheckNeeded: boolean) : Observable<MasterFunctionalUnit[]>
    {
        return this.get('functionalUnit/'+productCode+'/all','DOT_BP_VIEW', permissionCheckNeeded);
    }

    saveSSSBestPracticeVersion(bestPracticeVersionObject: BestPracticeVersionObject, selectedFunctionalUnits : ScreenObject[]): Observable<BestPracticeVersionObject> {
        return this.post('bpVersions/create/statestandard',{bestPracticeVersion:bestPracticeVersionObject, functionalUnitList:selectedFunctionalUnits},'DOT_BP_CREATE',true);
    }

    getSSSFunctionalUnitsOfBpVersion(bpVersionId: string, permissionCheckNeeded:boolean): Observable<TemplateObject[]> {
		return this.get('bpVersions/' + bpVersionId + '/functional-units/all', 'DOT_BP_VIEW', permissionCheckNeeded);  
    }

    getSSSBPByBestPracticeName(bestPracticeName: string, permissionCheckNeeded: boolean) : Observable<BestPracticeObject>
    {
        const url = 'bestPractice/stateStandard/'+bestPracticeName;
        return this.get(url,'DOT_BP_VIEW', permissionCheckNeeded);
    }
    
    public deleteBestPractice(bestPracticeObject: BestPracticeObject) {
		return this.post('bestPractice/delete', bestPracticeObject, 'DOT_BP_DELETE', true);
	}

    public cloneBestPractice(bestPracticeObject: BestPracticeObject): Observable<GenericResponse> {
		return this.post('bestPractice/clone', bestPracticeObject, 'DOT_BP_CREATE', true);
    }
    public checkAndUpdateBPName(bestPracticeObject: BestPracticeObject): Observable<GenericResponse> {
		return this.post('bestPractice/checkAndUpdateBP', bestPracticeObject, 'DOT_ADMIN', true);
    }
}