import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, TestBed } from "@angular/core/testing"
import { MatDialogModule } from "@angular/material";
import { Observable } from "rxjs";
import { ScreenObject } from "../model/screen-object";
import { AuthService } from "./auth-service";
import { FunctionalUnitService } from "./functional-unit-service";
import { ServerCommunicationService } from "./server-communication-service";

describe('FunctionalUnitService', () => {

    let functionalUnitService: FunctionalUnitService;
    beforeEach(async(() => {

        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule,
                MatDialogModule
            ],
            providers: [
             FunctionalUnitService,AuthService,ServerCommunicationService
            ]
        });

        functionalUnitService = TestBed.get(FunctionalUnitService);
    }));

    const screen_model : ScreenObject = {
        "screenName": "Account Definition",
        "gridOptionsModel": {
          "animatedRows": false,
          "rowSelection": "multiple",
          "columnDefs": [
            {
              "headerName": "Starting RO Number",
              "field": "starting_ro_number",
              "dataType": "INT",
              "required": "false",
              "editable": "true",
              "editableByCDKOnly": "false",
              "defaultValue": "",
              "validationRule": "",
              "dataLength": 9,
              "cellEditor": "agLargeTextCellEditor",
              "cellEditorParams": {
                "maxLength": 9
              }
            }
          ],
          "rowData":null
        },
        "description": "Account Definition",
        "updated": false,
        "version": 0,
        "productCode": "SVC",
        "index": 0,
        "bpScreenId": "6e260b12-03d5-4a9e-854c-ea29eba80dbd",
         "selected": false,
         "templateId": null,
        "copyRowData": true,
        "rowDataEmpty": false,
        "bpPropagationCompleted": false,
        "id": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
        "recordType": "ff991af6-3c55-4642-a500-bed944b7f574"
        
    }

    const list_of_screens_model :ScreenObject[]=[
        {
            "screenName": "Account Definition",
            "gridOptionsModel": {
              "animatedRows": false,
              "rowSelection": "multiple",
              "columnDefs": [
                {
                  "headerName": "Starting RO Number",
                  "field": "starting_ro_number",
                  "dataType": "INT",
                  "required": "false",
                  "editable": "true",
                  "editableByCDKOnly": "false",
                  "defaultValue": "",
                  "validationRule": "",
                  "dataLength": 9,
                  "cellEditor": "agLargeTextCellEditor",
                  "cellEditorParams": {
                    "maxLength": 9
                  }
                }
              ],
              "rowData":null
            },
            "description": "Account Definition",
            "updated": false,
            "version": 0,
            "productCode": "SVC",
            "index": 0,
            "bpScreenId": "6e260b12-03d5-4a9e-854c-ea29eba80dbd",
             "selected": false,
             "templateId": null,
            "copyRowData": true,
            "rowDataEmpty": false,
            "bpPropagationCompleted": false,
            "id": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
            "recordType": "ff991af6-3c55-4642-a500-bed944b7f574"
          }
    ]

    const list_of_screens_response :ScreenObject[]=[
        {
            "screenName": "Account Definition",
            "gridOptionsModel": {
              "animatedRows": false,
              "rowSelection": "multiple",
              "columnDefs": [
                {
                  "headerName": "Starting RO Number",
                  "field": "starting_ro_number",
                  "dataType": "INT",
                  "required": "false",
                  "editable": "true",
                  "editableByCDKOnly": "false",
                  "defaultValue": "",
                  "validationRule": "",
                  "dataLength": 9,
                  "cellEditor": "agLargeTextCellEditor",
                  "cellEditorParams": {
                    "maxLength": 9
                  }
                }
              ],
              "rowData":null
            },
            "description": "Account Definition",
            "updated": false,
            "version": 0,
            "productCode": "SVC",
            "index": 0,
            "bpScreenId": "6e260b12-03d5-4a9e-854c-ea29eba80dbd",
            "selected": false,
            "templateId": null,
            "copyRowData": true,
            "rowDataEmpty": false,
            "bpPropagationCompleted": false,
            "id": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
            "recordType": "ff991af6-3c55-4642-a500-bed944b7f574"
          }
    ]

    it('should create the FunctionalUnitService', () => {
        expect(functionalUnitService).toBeDefined();
    });

    it('test saveFunctionalUnits',()=>{
        let functionalAreaId ="7ew64385-d12c-4398-a666-2e3ee008b4jq";
        let storeId = "klf991af6-3c55-4642-a500-bed944b7f523";
        spyOn(functionalUnitService,'post').and.returnValue(Observable.of(list_of_screens_response))
        functionalUnitService.saveFunctionalUnits(list_of_screens_model,storeId,functionalAreaId)
                              .subscribe((data:any)=>{
                                expect(data).toBe(list_of_screens_response);
                              })     
        expect(functionalUnitService.post).toHaveBeenCalledTimes(1);                     
    })

   
    it('test getFunctionalUnitsOfFunctionalAreaForBpTree',()=>{
        let functionalAreaId ="7ew64385-d12c-4398-a666-2e3ee008b4jq";  
        spyOn(functionalUnitService,'get').and.returnValue(Observable.of(list_of_screens_response))
        functionalUnitService.getFunctionalUnitsOfFunctionalAreaForBpTree(functionalAreaId)
                              .subscribe((data:any)=>{
                                expect(data).toBe(list_of_screens_response);
                              }) 
        expect(functionalUnitService.get).toHaveBeenCalledTimes(1);       
    })

    it('test getFunctionalUnitsOfFunctionalArea',()=>{
        let functionalAreaId ="7ew64385-d12c-4398-a666-2e3ee008b4jq";  
        spyOn(functionalUnitService,'get').and.returnValue(Observable.of(list_of_screens_response))
        functionalUnitService.getFunctionalUnitsOfFunctionalArea(functionalAreaId)
                              .subscribe((data:any)=>{
                                expect(data).toBe(list_of_screens_response);
                              }) 
        expect(functionalUnitService.get).toHaveBeenCalledTimes(1);                 
    })

    it('test getModifiedBestPracticeFus',()=>{
        let functionalAreaId ="7ew64385-d12c-4398-a666-2e3ee008b4jq";  
        let storeId = "klf991af6-3c55-4642-a500-bed944b7f523";
        spyOn(functionalUnitService,'get').and.returnValue(Observable.of(list_of_screens_response))
        functionalUnitService.getModifiedBestPracticeFus(storeId,functionalAreaId)
                              .subscribe((data:any)=>{
                                expect(data).toBe(list_of_screens_response);
                              }) 
        expect(functionalUnitService.get).toHaveBeenCalledTimes(1);                   
    })

    it('test propagateFuChanges',()=>{

        let projectId = "5a260b12-03d5-4a9e-854c-ea29eba80dwe";
        let functionalAreaId ="7ew64385-d12c-4398-a666-2e3ee008b4jq";
        let storeId = "klf991af6-3c55-4642-a500-bed944b7f523";
        spyOn(functionalUnitService,'put').and.returnValue(Observable.of(list_of_screens_response))
        functionalUnitService.propagateFuChanges(projectId,storeId,functionalAreaId,list_of_screens_model)
                               .subscribe((data:any)=>{
                                expect(data).toBe(list_of_screens_response);
                              })     
        expect(functionalUnitService.put).toHaveBeenCalledTimes(1);    
    })

    it('test getFunctionalUnitGOMDiffs',()=>{

        let functionalAreaId ="7ew64385-d12c-4398-a666-2e3ee008b4jq";
        let storeId = "klf991af6-3c55-4642-a500-bed944b7f523";
        let functionalUnitId = "6e260b12-03d5-4a9e-854c-ea29eba80dbd";
        spyOn(functionalUnitService,'get').and.returnValue(Observable.of(list_of_screens_response))

        functionalUnitService.getFunctionalUnitGOMDiffs(storeId,functionalAreaId,functionalUnitId)
                               .subscribe((data:any)=>{
                                expect(data).toBe(list_of_screens_response);
                              })     
        expect(functionalUnitService.get).toHaveBeenCalledTimes(1);    
    })

    it('test discardPropagatedFuChanges',()=>{

      let storeId = "7ew64385-d12c-4398-a666-2e3ee008b4jq";
      let functionalUnitId = "klf991af6-3c55-4642-a500-bed944b7f523";
      let functionalAreaId = "7ew64385-d12c-4398-a666-2e3ee008b4jq";

      spyOn(functionalUnitService,'put').and.returnValue(Observable.of(screen_model));

      functionalUnitService.discardPropagatedFuChanges(storeId,functionalAreaId,functionalUnitId,screen_model)
                          .subscribe((data:any)=>{
                           expect(data).toBe(screen_model);
                           });  

      expect(functionalUnitService.put).toHaveBeenCalledTimes(1);
    
   })


});