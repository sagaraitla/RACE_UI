import { Injectable } from '@angular/core';
import { MasterFunctionalArea } from '../model/master-functional-area';
import { Observable } from 'rxjs';
import { ServerCommunicationService } from './server-communication-service';
import {GenericResponse} from '../model/generic-response';
@Injectable()
export class MasterFunctionalAreaService extends ServerCommunicationService {
	
	public createMasterFunctionalArea(functionalArea: MasterFunctionalArea): Observable<MasterFunctionalArea> {
		return this.post('functionalArea/create', functionalArea, 'DOT_TEMPLATE_CREATE', true);
	}
	
	public fetchMasterFunctionalAreaList(): Observable<MasterFunctionalArea[]> {
		return this.get('functionalArea/all', 'DOT_TEMPLATE_VIEW', true);
	}
	
	public deleteMasterFunctionalArea(functionalArea: MasterFunctionalArea) {
		return this.post('functionalArea/delete', functionalArea, 'DOT_TEMPLATE_DELETE', true);
	}

	public fetchMasterFAByNameAndPlatformAndProductCode(faName:string,platformName:string,productCode:string): Observable<GenericResponse> {
		return this.get('functionalArea/'+faName+'/'+platformName+'/'+productCode, 'DOT_TEMPLATE_VIEW', true);
	}

	public getMasterFunctionalAreaById(functionalAreaId: string): Observable<GenericResponse>{
		return this.get('functionalArea/'+functionalAreaId,'DOT_SCREEN_VIEW', true);
	}
}