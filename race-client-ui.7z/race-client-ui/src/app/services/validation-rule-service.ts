import { Injectable } from '@angular/core';
import { ValidationRuleObject } from '../model/validation-rule-object';
import { Observable } from 'rxjs';
import { ServerCommunicationService } from './server-communication-service';
import { GenericResponse } from '../model/generic-response';

@Injectable()
export class ValidationRuleService extends ServerCommunicationService {
	
	public getValidationRulesByPlatformName(platformName: string): Observable<GenericResponse> {
		return this.get('validationrule/platform/' + platformName, 'DOT_VR_VIEW', true);
    }
	
	public getValidationRule(validationRuleId: string): Observable<GenericResponse> {
		return this.get('validationrule/' + validationRuleId, 'DOT_VR_VIEW', true);
    }
    
	public createValidationRule(validationRule: ValidationRuleObject): Observable<GenericResponse> {
		return this.post('validationrule/', validationRule, 'DOT_VR_CREATE', true);
	}
	
	public deleteValidationRule(validationRuleId: string) : Observable<GenericResponse> {
		return this.post('validationrule/'+ validationRuleId, null, 'DOT_VR_DELETE', true);
	}

	public getProcessingValidationResults(platformName:string,productCode:string,faId:string,storeId:string,projectId:string):Observable<GenericResponse>{
		return this.get('validationrule/'+platformName+"/"+productCode+"/"+faId+"/"+storeId+"/"+projectId,'DOT_ADMIN', true);
	}
}