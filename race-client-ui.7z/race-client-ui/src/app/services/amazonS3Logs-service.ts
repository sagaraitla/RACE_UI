import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ServerCommunicationService } from './server-communication-service';
import {TemplateObject} from '../model/template-object';
import { GenericResponse } from '../model/generic-response';

@Injectable()
export class AmazonS3LogsService extends ServerCommunicationService {

    public getFileNamesFromS3Bucket(s3LogsPath:string): Observable<GenericResponse> {
        return this.get('v1/aws/s3/file-names?s3LogsPath='+s3LogsPath,'DOT_PROJECT_VIEW',true);
    }
    
    public readFileContentFromS3Bucket(s3LogsPath:string, fileName:string): Observable<any> {
        return this.get('v1/aws/s3/'+fileName+"/file-content?s3LogsPath="+s3LogsPath,'DOT_PROJECT_VIEW',true,true);
	}
}
