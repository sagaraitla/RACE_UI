import { Injectable } from '@angular/core';
import { Router, CanActivate,  ActivatedRouteSnapshot} from '@angular/router';
import { AuthService } from '../services/auth-service';
import { of as observableOf, Observable } from 'rxjs';


@Injectable()
export class PermissionGuardService implements CanActivate {
  
	constructor(private authService: AuthService, public router: Router) {}
	
	canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
	    const permissionCode = route.data.expectedPermission;
	    return this.authService.fetchLoggedInUserAndPermissions().pipe(() => {
	  		if (!this.authService.isAuthorised(permissionCode)) {
	  			this.router.navigate(['**']);
	  			return observableOf(false);
		      }
	  		return observableOf(true);
	  	});
  } 
}