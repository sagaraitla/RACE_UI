import { HttpClientTestingModule } from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { of } from "rxjs";
import { AuthService } from "./auth-service";
import { RowDataService } from "./rowdata-service";
import { ServerCommunicationService } from "./server-communication-service";

describe('RowDataService', () => {
    let rowDataService: RowDataService;

    beforeEach(() => {
        const serverCommunicationServiceSpy = jasmine.createSpyObj('ServerCommunicationService', ['get', 'post', 'put']);
        const authServiceSpy = jasmine.createSpyObj('AuthService', ['getLoggedInUser']);
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule
            ],
            providers: [
                RowDataService, { provide: ServerCommunicationService, useValue: serverCommunicationServiceSpy },
                { provide: AuthService, useValue: authServiceSpy }
            ],
        });

        rowDataService = TestBed.get(RowDataService);
    });

    const mockRowDataListResponse: any[] = [
        {
            "rowId": "1",
            "index": "1000"
        },
        {
            "rowId": "2",
            "index": "2000"
        }
    ];

    it('should fetch the rowData of the screen by screenId', () => {
        spyOn(rowDataService, 'get').and.returnValue(of(mockRowDataListResponse));
        rowDataService.getRowDataOfScreen(true, "1234").
            subscribe((data: any) => {
                expect(rowDataService.getRowDataOfScreen).toBeTruthy;
                expect(data).toBe(mockRowDataListResponse);
                expect(data.length).toBe(2);
                expect(data[0].rowId).toBe("1");
                expect(data[0].index).toBe("1000");
                expect(rowDataService.get).toHaveBeenCalledTimes(1);
            });
    });

    it('should do the batch save and delete the data', () => {
        spyOn(rowDataService, 'post').and.returnValue(of(mockRowDataListResponse));
        rowDataService.batchSaveAndDeleteRowData(mockRowDataListResponse).
            subscribe((data: any) => {
                expect(rowDataService.batchSaveAndDeleteRowData).toBeTruthy;
                expect(data).toBe(mockRowDataListResponse);
                expect(data.length).toBe(2);
                expect(data[0].rowId).toBe("1");
                expect(data[0].index).toBe("1000");
                expect(rowDataService.post).toHaveBeenCalledTimes(1);
            });
    });

    it('should fetch sce roles data by pltform', () => {
        spyOn(rowDataService, 'get').and.returnValue(of(mockRowDataListResponse));
        rowDataService.getSecRolesData(false, "Drive").
            subscribe((data: any) => {
                expect(rowDataService.getSecRolesData).toBeTruthy;
                expect(data).toBe(mockRowDataListResponse);
                expect(data.length).toBe(2);
                expect(data[0].rowId).toBe("1");
                expect(data[0].index).toBe("1000");
                expect(rowDataService.get).toHaveBeenCalledTimes(1);
            });
    });

});