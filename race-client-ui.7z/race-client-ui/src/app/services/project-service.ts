import { Injectable } from '@angular/core';
import { ProjectObject } from '../model/project-object';
import { StoreObject } from '../model/store-object';
import { Observable } from 'rxjs';
import { ServerCommunicationService } from './server-communication-service';
import { GenericResponse } from '../model/generic-response';

@Injectable()
export class ProjectService extends ServerCommunicationService {
	
	public createProject(project: ProjectObject): Observable<ProjectObject> {
		return this.post('projects/project', project, 'DOT_PROJECT_CREATE', true);
	}
	
	public updateProject(project: ProjectObject): Observable<ProjectObject> {
		return this.post('projects/project', project, 'DOT_PROJECT_CREATE', true);
	}
	
	public getAllProjects(showProjectsAsVIC : boolean): Observable<GenericResponse> {
		if (showProjectsAsVIC){
			return this.get('projects/getAllProjectsforVIC', 'DOT_PROJECT_VIEW', true);
		}
		else
		{
			return this.get('projects', 'DOT_PROJECT_VIEW', true);
		}
	}
	
	public getProjectByNumber(projectNumber: string): Observable<ProjectObject> {
		return this.get('projects/' + projectNumber, 'DOT_PROJECT_VIEW', true);
    }
	
	public getStoresOfProject(projectId: string): Observable<StoreObject[]> {
		return this.get('projects/' + projectId + '/stores/all', 'DOT_PROJECT_VIEW', true);
    }
	
	public deleteProject(project: ProjectObject): Observable<any> {
		return this.post('projects/delete', project, 'DOT_PROJECT_DELETE', true);
    }
}