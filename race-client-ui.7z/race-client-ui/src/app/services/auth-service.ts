
import { of as observableOf, Observable } from 'rxjs';

import { mergeMap, map, flatMap } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { ProjectObject } from '../model/project-object';
import { StoreObject } from '../model/store-object';
import { TemplateObject } from '../model/template-object';
import { ParamObject } from '../model/httpparam-object';
import { MatDialog, MatDialogRef } from '@angular/material';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';

import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DataTransferService } from './data-transfer-service';
@Injectable()
export class AuthService {

  private host: string;
  private cshost: string;
  private user: any = {
    "user": {
      "userGuid": "9B3C736F06424969E053440B6364E043",
      "loginId": "Sagar.Aitla@cdk.com",
      "firstName": "Sagar",
      "middleInitial": null,
      "lastName": "Aitla",
      "dmsUserIdentifier": null,
      "locked": false,
      "adminNotes": null,
      "creationDate": "2020-01-09T15:20:06+0000",
      "lastLoginDate": null,
      "locale": "en_US",
      "state": 2,
      "prefix": null,
      "suffix": null,
      "nickName": null,
      "employeeId": null,
      "jobTitle": null,
      "selfServiceEnabled": 0,
      "accountStatus": "Active",
      "communicationEdgeId": "sagaraitlacdkcom@dit.cdkcollaborate.com",
      "uniquePrincipalName": "aitlas@ds.ad.adp.com",
      "externallyFederated": true
    },
    "contacts": [],
    "enterprise": {
      "idpName": "CDK Self Enterprise",
      "id": "E000000",
      "name": "CDK Global",
      "vanityDomain": null
    },
    "stores": [
      {
        "id": "S000000000",
        "name": "CDK Global",
        "defaultStore": true
      }
    ],
    "roles": [
      {
        "roleGuid": "2785ADBB08E64BF8E0532AF44E6408CE",
        "roleName": "!Super User Test"
      },
      {
        "roleGuid": "32F2A04A11EACF1EE0532AF44E6468A5",
        "roleName": "Enterprise Administrator"
      },
      {
        "roleGuid": "67D36FE42B053DCCE053440B63645BAA",
        "roleName": "DOT - Developer"
      },
      {
        "roleGuid": "6880D57A2BF26D87E053440B6364AB6D",
        "roleName": "DOT - PROJECT MANAGER"
      },
      {
        "roleGuid": "6880D57A2BFA6D87E053440B6364AB6D",
        "roleName": "DOT - VIC"
      },
      {
        "roleGuid": "6880D57A2C1C6D87E053440B6364AB6D",
        "roleName": "DOT - ADMINISTRATOR"
      },
      {
        "roleGuid": "6BB1A6CBADE33D30E053440B6364CC6B",
        "roleName": "DOT - USER"
      },
      {
        "roleGuid": "6C6D63D39C484587E053440B63647271",
        "roleName": "View Only  Common Admin"
      },
      {
        "roleGuid": "79F3EF49DD693215E053440B636478D2",
        "roleName": "Common Admin"
      }
    ],
    "alternateIdentifiers": [],
    "warnings": [],
    "securityQuestionsStatus": false,
    "userAliases": []
  };
  private roleGuid: any = {};
  private production: boolean;
  private refreshToken: string;
  private accessToken: string;
  private loggedInUserPermissions: any = {};

  constructor(private http: HttpClient, public dialog: MatDialog) {
    this.http.get('assets/config', { withCredentials: true }).subscribe((data: any) => {
      this.host = data.host;
      this.cshost = data.cshost;
      this.production = data.production;
      this.refreshToken = data.refreshToken;
    });
  }

  getHeaders(permissionCode: string, enterpriseid: string) {
    let headers = new HttpHeaders({
      'loginId': this.user.user.loginId,
      'enterpriseId': enterpriseid,
      'permission': permissionCode,
      'REMOTE_USER': this.user.user.loginId
    });

    return headers;
  }

  fetchLoggedInUserAndPermissions(): Observable<any> {
    return this.fetchLoggedInUser().pipe(
      map((data: any) => {
        return data;
      }), mergeMap((data: any) => {
        return this.fetchLoggedInUsersPermissions()
          .pipe(map((data: any) => {
            return this.user;
          }))
      }));
  }

  isAuthorised(permissionCode: string) {
    this.host = 'http://localhost:8071/';
    if (this.loggedInUserPermissions && this.loggedInUserPermissions.length > 0) {
      for (var per of this.loggedInUserPermissions) {
        if (permissionCode === per.permission) {
          return true
        }
      }
    }
    return false;
  }

  fetchLoggedInUser(): Observable<any> {
    if (null != this.user && null != this.user.user) {
      return observableOf(this.user);
    }
    else {
      return this.http.get('assets/config', { withCredentials: true })
        .pipe(map((data: any) => {
          this.host = data.host;
          this.cshost = data.cshost;
          return data;
        }), flatMap((data: any) => {
          let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
            width: '300px',
            height: '150px',
            data: { message: 'Loading ..' }
          });
          return this.http
            .get(this.cshost + 'identityservice/1.0/rest/users/me', { withCredentials: true })
            .pipe(map((data: any) => {
              this.user = data.fullUser;
              loaderDialogRef.close();
              return this.user;
            }))
        }));
    }
  }

  fetchLoggedInUsersPermissions(): Observable<any> {
    let headers = this.getHeaders('DOT_PROJECT_VIEW', 'E000000');
    headers = headers.append('Content-Type', 'application/json');

    const options = { headers: headers, withCredentials: true };
    if (this.loggedInUserPermissions && this.loggedInUserPermissions.length > 0) {
      return observableOf(this.loggedInUserPermissions);
    }
    else {
      return this.http.get('assets/config', { withCredentials: true })
        .pipe(map((data: any) => {
          this.host = data.host;
          return data;
        })
          , flatMap((data: any) => {
            let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
              width: '300px',
              height: '150px',
              data: { message: 'Loading ..' }
            });
            return this.http
              .get(this.host + 'auth/permissions', options)
              .pipe(map((data: any) => {
                this.loggedInUserPermissions = data;
                loaderDialogRef.close();
                return this.loggedInUserPermissions;
              }))
          }));
    }
  }

  getLoggedInUser() {
    return this.user;
  }

  getLoggedInUsersLoginId() {
    if (null != this.user && null != this.user.user) {
      return this.user.user.loginId;
    }
    return null;
  }

  fetchCommonServicesDealershipUsers(enterpriseId: string): Observable<any> {
    let headers = this.getHeaders('DOT_PROJECT_VIEW', enterpriseId);
    headers = headers.append('Content-Type', 'application/json');

    const options = { headers: headers, withCredentials: true };
    return this.http
      .get(this.host + 'auth/users/dealership', options)
      .pipe(map((data: any) => {
        if (data.users != null) {
          return data.users.sort((u1, u2): number => {
            if (u1.user.loginId.toLowerCase() < u2.user.loginId.toLowerCase()) return -1;
            if (u1.user.loginId.toLowerCase() > u2.user.loginId.toLowerCase()) return 1;
            return 0;
          });
        } else {
          return 0;
        }

      }));
  }

  fetchCommonServicesUsers(): Observable<any> {
    let headers = this.getHeaders('DOT_PROJECT_VIEW', 'E000000');
    headers = headers.append('Content-Type', 'application/json');

    const options = { headers: headers, withCredentials: true };
    return this.http
      .get(this.host + 'auth/users/dealership', options)
      .pipe(map(data => {
        return data;
      }));
  }

  fetchCommonServicesUsersWithDotVICRole(): Observable<any> {
    let headers = this.getHeaders('DOT_PROJECT_VIEW', 'E000000');
    headers = headers.append('Content-Type', 'application/json');
    headers = headers.append('roleName', 'DOT - VIC');

    const options = { headers: headers, withCredentials: true };
    return this.http
      .get(this.host + 'auth/users/role', options)
      .pipe(map((data: any) => {
        if (data.users != null) {
          return data.users.sort((u1, u2): number => {
            if (u1.user.loginId.toLowerCase() < u2.user.loginId.toLowerCase()) return -1;
            if (u1.user.loginId.toLowerCase() > u2.user.loginId.toLowerCase()) return 1;
            return 0;
          });
        } else {
          return 0;
        }

      }));
  }


  fetchCommonServicesUsersWithManagerRole(): Observable<any> {
    let headers = this.getHeaders('DOT_PROJECT_VIEW', 'E000000');
    headers = headers.append('Content-Type', 'application/json');
    headers = headers.append('roleName', 'DOT - PROJECT MANAGER');

    const options = { headers: headers, withCredentials: true };
    return this.http
      .get(this.host + 'auth/users/role', options)
      .pipe(map((data: any) => {
        if (data.users != null) {
          return data.users.sort((u1, u2): number => {
            if (u1.user.loginId.toLowerCase() < u2.user.loginId.toLowerCase()) return -1;
            if (u1.user.loginId.toLowerCase() > u2.user.loginId.toLowerCase()) return 1;
            return 0;
          });
        } else {
          return 0;
        }

      }));

  }

  fetchCommonServicesUsersWithDotRole(): Observable<any> {
    let headers = this.getHeaders('DOT_PROJECT_VIEW', 'E000000');
    headers = headers.append('Content-Type', 'application/json');
    headers = headers.append('roleName', 'DOT - User');

    const options = { headers: headers, withCredentials: true };
    return this.http
      .get(this.host + 'auth/users/role', options)
      .pipe(map((data: any) => {
        if (data.users != null) {
          return data.users.sort((u1, u2): number => {
            if (u1.user.loginId.toLowerCase() < u2.user.loginId.toLowerCase()) return -1;
            if (u1.user.loginId.toLowerCase() > u2.user.loginId.toLowerCase()) return 1;
            return 0;
          });
        } else {
          return 0;
        }

      }));
  }

  isCDKInternalUser(): boolean {
    if (this.user.enterprise.id === 'E000000')
      return true;
    else
      return false;
  }

  checkIfLoggedInUserHasRole(roleName: string): boolean {
    if (null != this.user && null != this.user.user && null != this.user.roles) {
      var roleObj = this.user.roles.filter(role => role.roleName === roleName);
      if (roleObj && roleObj.length > 0) {
        return true;
      }
    }
    return false;
  }

  checkIfLoggedInUserIsClientProjectAdvocate(project: ProjectObject) {
    const checkFlag = (project.clientProjectAdvocate &&
      project.clientProjectAdvocate.some(user => user.loginId == this.getLoggedInUsersLoginId()));
    return checkFlag
  }

  checkIfLoggedInUserIsClientStoreAdvocate(store: StoreObject) {
    const checkFlag = (store.clientStoreAdvocate &&
      store.clientStoreAdvocate.some(user => user.loginId == this.getLoggedInUsersLoginId()));
    return checkFlag
  }

  checkIfLoggedInUserIsClientFunctionalAreaUser(template: TemplateObject) {
    const checkFlag = (template.clientFunctionalAreaUser &&
      template.clientFunctionalAreaUser.some(user => user.loginId == this.getLoggedInUsersLoginId()));
    return checkFlag

  }

  checkIfLoggedInUserIsProjectManager(project: ProjectObject) {
    const checkFlag = (project.projectManager && project.projectManager == this.getLoggedInUsersLoginId());
    return checkFlag
  }



  //====dash import========
  fetchCommonServicesUsersWithDealerApproverRole(enterpriseId: string): Observable<any> {
    let headers = this.getHeaders('DOT_PROJECT_VIEW', enterpriseId);
    headers = headers.append('Content-Type', 'application/json');
    headers = headers.append('roleName', 'DOT - Dealer Approver');

    const options = { headers: headers, withCredentials: true };
    return this.http
      .get(this.host + 'auth/users/dealerApproverRole', options)
      .pipe(map((data: any) => {
        if (data.users != null) {
          return data.users.sort((u1, u2): number => {
            if (u1.user.loginId.toLowerCase() < u2.user.loginId.toLowerCase()) return -1;
            if (u1.user.loginId.toLowerCase() > u2.user.loginId.toLowerCase()) return 1;
            return 0;
          });
        } else {
          return 0;
        }
      }));

  }
  //=====dash import======
}