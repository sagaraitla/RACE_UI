import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, TestBed } from "@angular/core/testing"
import { MatDialogModule } from "@angular/material";
import { Observable } from "rxjs";
import { TemplateObject } from "../model/template-object";
import { AuthService } from "./auth-service";
import { FunctionalAreaService } from "./functional-area-service";
import { ServerCommunicationService } from "./server-communication-service";

describe('FunctionalAreaService', () => {

    let functionalAreaService: FunctionalAreaService;
    beforeEach(async(() => {

        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule,
                MatDialogModule
            ],
            providers: [
                FunctionalAreaService,AuthService,ServerCommunicationService
            ]
        });

        functionalAreaService = TestBed.get(FunctionalAreaService);
    }));

    const templateObjectList : TemplateObject[]=[
        {
            "functionalAreaName": "Service",
            "functionalAreaType": null,
            "oemName": null,
            "clientSignoffDate": null,
            "selected": false,
            "status": "Work in Progress",
            "platforms": [
              {
                "platformName": "FLEX",
                "platformCode": "flex",
                "selected": true
              }
            ],
            "vic": {
              "firstName": "Abraham",
              "lastName": "Joseph",
              "loginId": "Abraham.Joseph@cdk.com",
              "employeeId": null
            },
            "secondaryVic": {
              "firstName": "Amrita",
              "lastName": "das",
              "loginId": "Amrita.das@cdk.com",
              "employeeId": null
            },
            "clientFunctionalAreaUser": null,
            "version": 6,
            "isFailed": null,
            "inProcess": false,
            "productCode": "SVC",
            "productVersion": null,
            "bpId": "c0adde0a-71fe-48f0-a5c1-89c63b37029d",
            "bpVersionId": "8c68b65d-cc7a-4c3b-a91a-9d0febb5b85f",
            "bpTemplateId": "4e524a60-7103-4c84-9f34-79cfa7531dfe",
            "isDealerApproved": false,
            "stateStandardId": null,
            "stateStandardName": null,
            "stateStandardVersionRecordType": null,
            "stateStandardVersionName": null,
            "copyRowData": false,
            "showValidateOrTransferButton": false,
            "showProcessValidationResultsButton": true,
            "createdDate": null,
            "lastUpdatedDate": null,
            "createdBy": "Sagar.Aitla@cdk.com",
            "updatedBy": "Sagar.Aitla@cdk.com",
            "incorporateBpChanges": false,
            "id": "506bf3e4-9a22-4feb-b75d-4377fd6832a8",
            "recordType": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
            "isLocked":false,
            "storeId":null,
            "screenIds":[]
          }
    ]


    const templateObjectResponse : TemplateObject = {
        "functionalAreaName": "Service",
        "functionalAreaType": null,
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Work in Progress",
        "platforms": [
          {
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true
          }
        ],
        "vic": {
          "firstName": "Amrita",
          "lastName": "das",
          "loginId": "Amrita.das@cdk.com",
          "employeeId": null
        },
        "secondaryVic": null,
        "clientFunctionalAreaUser": null,
        "version": 8,
        "isFailed": null,
        "inProcess": false,
        "productCode": "SVC",
        "productVersion": null,
        "bpId": "c0adde0a-71fe-48f0-a5c1-89c63b37029d",
        "bpVersionId": "3451520f-1bc2-417b-a402-2b745d194652",
        "bpTemplateId": "b368bb72-f59e-41cb-937f-b7e2bab5d558",
        "isDealerApproved": false,
        "stateStandardId": null,
        "stateStandardName": null,
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": false,
        "showValidateOrTransferButton": true,
        "showProcessValidationResultsButton": false,
         "createdDate": null,
         "lastUpdatedDate": null,
        "createdBy": "Sagar.Aitla@cdk.com",
        "updatedBy": "Sagar.Aitla@cdk.com",
        "incorporateBpChanges": true,
        "id": "9e8d4f49-b582-49d4-9bdc-486552424253",
        "recordType": "a0df2248-efec-4f62-a351-cb544c00d39b",
        "isLocked":false,
        "storeId":null,
        "screenIds":[]
    }
    
    const templateObject: TemplateObject= {
        "functionalAreaName": "Service",
        "functionalAreaType": null,
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Work in Progress",
        "platforms": [
          {
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true
          }
        ],
        "vic": {
          "firstName": "Amrita",
          "lastName": "das",
          "loginId": "Amrita.das@cdk.com",
          "employeeId": null
        },
        "secondaryVic": null,
        "clientFunctionalAreaUser": null,
        "version": 8,
        "isFailed": null,
        "inProcess": false,
        "productCode": "SVC",
        "productVersion": null,
        "bpId": "c0adde0a-71fe-48f0-a5c1-89c63b37029d",
        "bpVersionId": "3451520f-1bc2-417b-a402-2b745d194652",
        "bpTemplateId": "b368bb72-f59e-41cb-937f-b7e2bab5d558",
        "isDealerApproved": false,
        "stateStandardId": null,
        "stateStandardName": null,
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": false,
        "showValidateOrTransferButton": false,
        "showProcessValidationResultsButton": true,
        "createdDate": null,
        "lastUpdatedDate": null,
        "createdBy": "Sagar.Aitla@cdk.com",
        "updatedBy": "Sagar.Aitla@cdk.com",
        "incorporateBpChanges": true,
        "id": "9e8d4f49-b582-49d4-9bdc-486552424253",
        "recordType": "a0df2248-efec-4f62-a351-cb544c00d39b",
        "isLocked":false,
        "storeId":null,
        "screenIds":[]
        
    }

    it('should create the FunctionalAreaService', () => {
        expect(functionalAreaService).toBeDefined();
    });

    it('test saveFunctionalArea',()=>{

        let storeId = "506bf3e4-9a22-4feb-b75d-4377fd6832a8";
        let storeName = "Unit_Store";
        let projectName = "P000176";

        spyOn(functionalAreaService,'post').and.returnValue(Observable.of());
        functionalAreaService.saveFunctionalArea(storeId,storeName,projectName,templateObjectList);
        expect(functionalAreaService.post).toHaveBeenCalledTimes(1);

    });

    it('test getFunctionalAreaById',()=>{

        let storeId = "9e8d4f49-b582-49d4-9bdc-486552424253";
        let functionalAreaId = "a0df2248-efec-4f62-a351-cb544c00d39b";
        spyOn(functionalAreaService,'get').and.returnValue(Observable.of(templateObjectResponse));
        functionalAreaService.getFunctionalAreaById(storeId,functionalAreaId)
                            .subscribe((data:any)=>{
                                expect(data).toBe(templateObjectResponse)
                            });
        expect(functionalAreaService.get).toHaveBeenCalledTimes(1);

    });

    it('test getFunctionalAreasByStoreId ',()=>{

        let permissionCheckNeeded : false;
        let storeId =  "9e8d4f49-b582-49d4-9bdc-486552424253";
        spyOn(functionalAreaService,'get').and.returnValue(Observable.of(templateObjectResponse));
        functionalAreaService.getFunctionalAreasByStoreId(permissionCheckNeeded,storeId)
                                    .subscribe((data:any)=>{
                                    expect(data).toBe(templateObjectResponse)
                                    });
        expect(functionalAreaService.get).toHaveBeenCalledTimes(1);

    })

    it('test getFullFunctionalAreaByStoreIdAndFunctionalAreaId ',()=>{


        let storeId =  "9e8d4f49-b582-49d4-9bdc-486552424253";
        let functionalAreaId = "a0df2248-efec-4f62-a351-cb544c00d39b";
        spyOn(functionalAreaService,'get').and.returnValue(Observable.of(templateObjectResponse));
        functionalAreaService.getFullFunctionalAreaByStoreIdAndFunctionalAreaId(storeId,functionalAreaId)
                                    .subscribe((data:any)=>{
                                    expect(data).toBe(templateObjectResponse)
                                    });
        expect(functionalAreaService.get).toHaveBeenCalledTimes(1);

    })

    it('test saveSingleFunctionalArea',()=>{

        spyOn(functionalAreaService,'post').and.returnValue(Observable.of(templateObject));
        functionalAreaService.saveSingleFunctionalArea(templateObject)
                             .subscribe((data:any)=>{
                              expect(data).toBe(templateObject)
                            });
        expect(functionalAreaService.post).toHaveBeenCalledTimes(1);

    });

    it('test getFunctionalAreasByPlatformAndProductCode',()=>{

        let platform = "FLEX";
        let productCode = "SVC";
        spyOn(functionalAreaService,'get').and.returnValue(Observable.of(templateObjectList));

        functionalAreaService.getFunctionalAreasByPlatformAndProductCode(platform,productCode)
                             .subscribe((data:any)=>{
                              expect(data).toBe(templateObjectList)
                            });
        expect(functionalAreaService.get).toHaveBeenCalledTimes(1);

    });

    it('test changeProductStatus',()=>{

       let projectId = "506bf3e4-9a22-4feb-b75d-4377fd6832a8";
       let storeId =  "9e8d4f49-b582-49d4-9bdc-486552424253";
       let functionalAreaId = "a0df2248-efec-4f62-a351-cb544c00d39b";
       let status = 'validate';

       spyOn(functionalAreaService,'post').and.returnValue(Observable.of());
       functionalAreaService.changeProductStatus(projectId,storeId,functionalAreaId,status);
       expect(functionalAreaService.post).toHaveBeenCalledTimes(1);
      });

      it('test getFunctionalAreaStatus',()=>{

        let storeId =  "9e8d4f49-b582-49d4-9bdc-486552424253";
        let functionalAreaId = "a0df2248-efec-4f62-a351-cb544c00d39b";
        let status:any = 'validation failed'
        spyOn(functionalAreaService,'get').and.returnValue(Observable.of(status));
        functionalAreaService.getFunctionalAreaStatus(storeId,functionalAreaId)
                              .subscribe((status:any)=>{
                                expect(status).toBe('validation failed')
                              });
        expect(functionalAreaService.get).toHaveBeenCalledTimes(1);                 
        });
    
        it('test unlockFunctionalArea',()=>{
          let storeId =  "9e8d4f49-b582-49d4-9bdc-486552424253";
          let functionalAreaId = "a0df2248-efec-4f62-a351-cb544c00d39b";
          spyOn(functionalAreaService,'post').and.returnValue(Observable.of());
          functionalAreaService.unlockFunctionalArea(storeId,functionalAreaId);
          expect(functionalAreaService.post).toHaveBeenCalledTimes(1); 
        });

        it('test validateAndTransferProduct',()=>{

          let projectId = "506bf3e4-9a22-4feb-b75d-4377fd6832a8";
          let storeId =  "9e8d4f49-b582-49d4-9bdc-486552424253";
          let functionalAreaId = "a0df2248-efec-4f62-a351-cb544c00d39b";
          let status = 'transfer';

          spyOn(functionalAreaService,'post').and.returnValue(Observable.of());
          functionalAreaService.validateAndTransferProduct(projectId,storeId,functionalAreaId,status);
          expect(functionalAreaService.post).toHaveBeenCalledTimes(1); 

        });

});