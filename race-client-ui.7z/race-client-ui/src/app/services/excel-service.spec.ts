import { HttpClientTestingModule, HttpTestingController } from "@angular/common/http/testing";
import { async, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCheckboxModule, MatDialog, MatDialogModule, MatOptionModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatSidenavModule } from "@angular/material";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { GridApi } from "ag-grid";
import { AgGridModule } from "ag-grid-angular";
import * as XLSX from 'xlsx';
import { ImportDialog } from "../import-dialog/import-dialog.component";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { TemplateObject } from "../model/template-object";
import { AuditLogService } from "./audit-log-service";
import { AuthService } from "./auth-service";
import { ExcelService } from "./excel-service";
import { FormattingService } from "./formatting-service";
import { ServerCommunicationService } from "./server-communication-service";
import { ValidationService } from "./validation-service";

describe('ExcelService', () => {

    let httpMock1: HttpTestingController;
    let excelService: ExcelService;
    let authService: jasmine.SpyObj<AuthService>;
    let serverCommService: jasmine.SpyObj<ServerCommunicationService>;
    let formattingService: FormattingService;
    let validationService:ValidationService;
    let auditLogService : jasmine.SpyObj<AuditLogService>;
  
    let gridApi:any;

    beforeEach(async(() => {
        const gridApiSpy = jasmine.createSpyObj('GridApi',['refreshCells']);
       TestBed.configureTestingModule({
           imports: [
            FormsModule,
            MatDialogModule,
            MatProgressSpinnerModule,
            ReactiveFormsModule,
            MatOptionModule,
            MatSelectModule,
            MatRadioModule,
            MatCheckboxModule,
            MatSidenavModule,
               HttpClientTestingModule,
               MatDialogModule,
               BrowserAnimationsModule,
               AgGridModule.withComponents(
                 [
                 ]),
           ],
           declarations: [ImportDialog,LoaderDialogueComponent],
           providers: [
            ExcelService,
            AuditLogService,
            FormattingService,
            ServerCommunicationService,
            AuthService,
            ValidationService,
            {provide:GridApi,useValue:gridApiSpy},
             
           ]
       }).overrideModule(BrowserDynamicTestingModule,
        { set: { entryComponents: [ImportDialog,LoaderDialogueComponent]}});
         excelService = TestBed.get(ExcelService)
         authService = TestBed.get(AuthService);
         serverCommService = TestBed.get(ServerCommunicationService);
         gridApi = TestBed.get(GridApi) as jasmine.SpyObj<GridApi>;
         formattingService = TestBed.get(FormattingService);
         validationService = TestBed.get(ValidationService); 

       /*   httpMock1 = TestBed.get(HttpTestingController);
           httpMock1.expectOne({
             url: 'assets/config',
             method: 'get'
         });
         httpMock1.verify(); */

   }));
    const hostConfig: any = {
        "production": false,
        "host": "http://localhost:8080/",
        "cshost": "https://api-dit.connectcdk.com/",
        "refreshToken": "8adaf13a-06c5-4cd1-bca5-70edf23323fc"
    }

    const screenDataFromXls:any[]=[
      {
        "Apply Shop Charges": "Yes",
        "Begin Date": "",
        "Calculate Tax": "Yes",
        "Cost Amount Percentage": "0.0000%",
        "Cost Percentage Of": "",
        "Cost Pricing Method": "Fixed",
        "Description": "Parts Discount",
        "End Date": "4/19/2021",
        "Exclude From Discounts": "Yes",
        "Fee Code": "PD",
        "Fixed Cost Amount": "$0.00",
        "Fixed Sale Amount": "$5.00",
        "GL Account": "54300",
        "GL Account Prompt Flag": "Yes",
        "GL Company": "#CO#",
        "Labor Fee Type": "Miscellaneous",
        "Maximum Amount $": "",
        "Minimum Amount $": "",
        "Sale Amount Percentage": "0.0000%",
        "Sale Percentage Of": "",
        "Sale Pricing Method": "Fixed"
      },
      {
        "Apply Shop Charges": "Yes",
        "Begin Date": "",
        "Calculate Tax": "Yes",
        "Cost Amount Percentage": "0.0000%",
        "Cost Percentage Of": "",
        "Cost Pricing Method": "Fixed",
        "Description": "Parts Discount",
        "End Date": "4/19/2021",
        "Exclude From Discounts": "Yes",
        "Fee Code": "PD",
        "Fixed Cost Amount": "$0.00",
        "Fixed Sale Amount": "$5.00",
        "GL Account": "54300",
        "GL Account Prompt Flag": "Yes",
        "GL Company": "#CO#",
        "Labor Fee Type": "Miscellaneous",
        "Maximum Amount $": "",
        "Minimum Amount $": "",
        "Sale Amount Percentage": "0.0000%",
        "Sale Percentage Of": "",
        "Sale Pricing Method": "Fixed"
      }
    ]

const screenHeaderList:any[]=[
    ["Fee Code", "Description", "Begin Date", "End Date", "Labor Fee Type", "Sale Pricing Method", "Fixed Sale Amount"],
    ["PD", "Parts Discount", "", "", "Miscellaneous", "Fixed", "$5.00"],
    ["SD", "Service Discount", "", "", "Miscellaneous", "Fixed", "$0.00"]
  ]
    
    it('test formatCurrencyColumnData',()=>{
        const gridOptions :any = {
            columnDefs:[
                {
                    dataType:  "CURRENCY",
                    headerName: "Fixed Sale Amount",
                    required: "true",
                    field: "fixed_sale_amount"
                }
            ]
        }

       const screenDataFromXls1:any[]=[
        {
            "Cash Account Company": "1",
            "Cash Account Number": "10300",
            "Journal Company": "1",
            "Journal Number": "60",
            "Offset Account Company": "",
            "Offset Account Number": "",
            "Starting Check Number": "",
            "error":[
                {
                    "rowIndex": 0,
                    "timeStamp": "",
                    "errors": [
                      {
                        "errorDescription": "Integer value is invalid. Please enter correct value",
                        "errorField": "starting_ro_number",
                        "errorLevel": "",
                        "isUpdated": false
                      },
                      {
                        "errorDescription": "Integer value is invalid. Please enter correct value",
                        "errorField": "next_ro_number",
                        "errorLevel": "",
                        "isUpdated": false
                      }
                    ]
                }
                ]
           },
           {
            "Cash Account Company": "1",
            "Cash Account Number": "10300",
            "Journal Company": "1",
            "Journal Number": "60",
            "Offset Account Company": "",
            "Offset Account Number": "",
            "Starting Check Number": "",
            "error":[
                {
                    "rowIndex": 0,
                    "timeStamp": "",
                    "errors": [
                      {
                        "errorDescription": "Integer value is invalid. Please enter correct value",
                        "errorField": "starting_ro_number",
                        "errorLevel": "",
                        "isUpdated": false
                      },
                      {
                        "errorDescription": "Integer value is invalid. Please enter correct value",
                        "errorField": "next_ro_number",
                        "errorLevel": "",
                        "isUpdated": false
                      }
                    ]
                }
                ]
           }
       ]
       const rowErrors:any[]=[
       ]
        excelService.screenDataFromXls = screenDataFromXls1;
        spyOn(formattingService,'formatCurrencyWithCommaAndDecimalPoint').and.returnValue("$5.00")
        spyOn(validationService,'isCurrencyValueValid').and.returnValue(false);
        excelService['formatCurrencyColumnData'](gridOptions,screenHeaderList);
    });

    const templateObject:TemplateObject={
      "functionalAreaName": "Service",
      "functionalAreaType": null,
      "oemName": null,
      "clientSignoffDate": null,
      "selected": false,
      "status": "Work in Progress",
      "platforms": [
        {
          "platformName": "FLEX",
          "platformCode": "flex",
          "selected": true
        }
      ],
      "vic": {
        "firstName": "Amrita",
        "lastName": "das",
        "loginId": "Amrita.das@cdk.com",
        "employeeId": null
      },
      "secondaryVic": null,
      "clientFunctionalAreaUser": null,
      "version": 8,
      "isFailed": null,
      "inProcess": false,
      "productCode": "SVC",
      "productVersion": null,
      "bpId": "c0adde0a-71fe-48f0-a5c1-89c63b37029d",
      "bpVersionId": "3451520f-1bc2-417b-a402-2b745d194652",
      "bpTemplateId": "b368bb72-f59e-41cb-937f-b7e2bab5d558",
      "isDealerApproved": false,
      "stateStandardId": null,
      "stateStandardName": null,
      "stateStandardVersionRecordType": null,
      "stateStandardVersionName": null,
      "copyRowData": false,
      "showValidateOrTransferButton": false,
      "showProcessValidationResultsButton": true,
      "createdDate": null,
      "lastUpdatedDate": null,
      "createdBy": "Sagar.Aitla@cdk.com",
      "updatedBy": "Sagar.Aitla@cdk.com",
      "incorporateBpChanges": true,
      "id": "9e8d4f49-b582-49d4-9bdc-486552424253",
      "recordType": "a0df2248-efec-4f62-a351-cb544c00d39b",
      "isLocked":false,
      "storeId":null,
      "screenIds":[]
    }

    it('test formatPercentageColumnData',()=>{
      const screenDataFromXls:any[]=[
        {
          "Code": "12",
          "Offset Account": "Cast",
          "Parent Class": "Customer",
          "Percentage": "4",
          "Target Company": "AB"
        },
        {
          "Code": "12",
          "Offset Account": "Cast",
          "Parent Class": "Customer",
          "Percentage": "4",
          "Target Company": "AB"
        }
      ]

        const gridOptions :any = {
          columnDefs:[
              {
                  dataType:  "PERCENTAGE",
                  headerName: "Percentage",
                  required: "true",
                  field: "percentage"
              }
          ]
      }

      const screenHeaderList:any[]=[
        ["Code", "Parent Class Type", "Parent Class", "Target Company", "Offset Account", "Percentage"],
        ["12", "", "Customer", "AB", "Cast", "4"]
     ]
     excelService.screenDataFromXls = screenDataFromXls;
     spyOn(formattingService,'formatCurrencyWithCommaAndDecimalPoint').and.returnValue("0.0000%")
     excelService['formatPercentageColumnData'](gridOptions,screenHeaderList);
    });

    it('test formatPercentageColumnData value is not percentage value',()=>{
      const screenDataFromXls:any[]=[
        {
          "Code": "12",
          "Offset Account": "Cast",
          "Parent Class": "Customer",
          "Percentage": null,
          "Target Company": "AB"
        },
        {
          "Code": "12",
          "Offset Account": "Cast",
          "Parent Class": "Customer",
          "Percentage": null,
          "Target Company": "AB"
        }
      ]

        const gridOptions :any = {
          columnDefs:[
              {
                  dataType:  "PERCENTAGE",
                  headerName: "Percentage",
                  required: "true",
                  field: "percentage"
              }
          ]
      }

      const screenHeaderList:any[]=[
        ["Code", "Parent Class Type", "Parent Class", "Target Company", "Offset Account", "Percentage"],
        ["12", "", "Customer", "AB", "Cast", null]
     ]
     excelService.screenDataFromXls = screenDataFromXls;
    
     spyOn(formattingService,'formatPercentageWithDecimalPoint').and.returnValue(null);
     excelService['formatPercentageColumnData'](gridOptions,screenHeaderList);
    });

    it('test formatPercentageColumnData if headerName has errors',()=>{
      const screenDataFromXls:any[]=[
        {
          "Code": "12",
          "Offset Account": "Cast",
          "Parent Class": "Customer",
          "Percentage": "4",
          "Target Company": "AB",
          "error": {
            "rowIndex": 0,
            "timeStamp": "",
            "errors": [
                {
                    "errorDescription": "Date value is invalid. Please enter correct value",
                    "errorField": "report_number",
                    "errorLevel": "",
                    "isUpdated": false
                }
            ]
        }
          
        },
        {
          "Code": "12",
          "Offset Account": "Cast",
          "Parent Class": "Customer",
          "Percentage": "4",
          "Target Company": "AB"
        }
      ]

        const gridOptions :any = {
          columnDefs:[
              {
                  dataType:  "PERCENTAGE",
                  headerName: "Percentage",
                  required: "true",
                  field: "percentage"
              }
          ]
      }

      const screenHeaderList:any[]=[
        ["Code", "Parent Class Type", "Parent Class", "Target Company", "Offset Account", "Percentage"],
        ["12", "", "Customer", "AB", "Cast", "4"]
     ]
     excelService.screenDataFromXls = screenDataFromXls;
     spyOn(formattingService,'formatPercentageWithDecimalPoint').and.returnValue(null)
     excelService['formatPercentageColumnData'](gridOptions,screenHeaderList);
    });


    it('test formatDateColumnData',()=>{

      const screenDataFromXls:any[]=[
        {
          "Apply Shop Charges": "Yes",
          "Begin Date": "",
          "Calculate Tax": "Yes",
          "Cost Amount Percentage": "0.0000%",
          "Cost Percentage Of": "",
          "Cost Pricing Method": "Fixed",
          "Description": "Parts Discount",
          "End Date": "4/19/2021",
          "Exclude From Discounts": "Yes",
          "Fee Code": "PD",
          "Fixed Cost Amount": "$0.00",
          "Fixed Sale Amount": "$5.00",
          "GL Account": "54300",
          "GL Account Prompt Flag": "Yes",
          "GL Company": "#CO#",
          "Labor Fee Type": "Miscellaneous",
          "Maximum Amount $": "",
          "Minimum Amount $": "",
          "Sale Amount Percentage": "0.0000%",
          "Sale Percentage Of": "",
          "Sale Pricing Method": "Fixed"
        },
        {
          "Apply Shop Charges": "Yes",
          "Begin Date": "",
          "Calculate Tax": "Yes",
          "Cost Amount Percentage": "0.0000%",
          "Cost Percentage Of": "",
          "Cost Pricing Method": "Fixed",
          "Description": "Parts Discount",
          "End Date": "4/19/2021",
          "Exclude From Discounts": "Yes",
          "Fee Code": "PD",
          "Fixed Cost Amount": "$0.00",
          "Fixed Sale Amount": "$5.00",
          "GL Account": "54300",
          "GL Account Prompt Flag": "Yes",
          "GL Company": "#CO#",
          "Labor Fee Type": "Miscellaneous",
          "Maximum Amount $": "",
          "Minimum Amount $": "",
          "Sale Amount Percentage": "0.0000%",
          "Sale Percentage Of": "",
          "Sale Pricing Method": "Fixed"
        }
      ]

        const gridOptions :any = {
          columnDefs:[
              {
                  dataType:  "DATE",
                  headerName: "Begin Date",
                  required: "true",
                  field: "begin_date"
              }
          ]
      }
       const screenHeaderList:any[]=[
          ["Fee Code", "Description", "Begin Date", "End Date"],
        ["PD", "Parts Discount", "", "4/19/2021"],
        ["SD", "Service Discount", "", "4/19/2021"]
      ]
      excelService.screenDataFromXls = screenDataFromXls;
      excelService['headerRequired'] = true;
      spyOn(validationService,'isDateHeaderValueValid').and.returnValue(false);
      excelService['formatDateColumnData'](gridOptions,screenHeaderList);

    });

    it('test formatDateColumnData if Data value is invalid',()=>{

      const screenDataFromXls:any[]=[
        {
          "Apply Shop Charges": "Yes",
          "Begin Date": "",
          "Calculate Tax": "Yes",
          "Cost Amount Percentage": "0.0000%",
          "Cost Percentage Of": "",
          "Cost Pricing Method": "Fixed",
          "Description": "Parts Discount",
          "End Date": "4/19/2021",
          "Exclude From Discounts": "Yes",
          "Fee Code": "PD",
          "Fixed Cost Amount": "$0.00",
          "Fixed Sale Amount": "$5.00",
          "GL Account": "54300",
          "GL Account Prompt Flag": "Yes",
          "GL Company": "#CO#",
          "Labor Fee Type": "Miscellaneous",
          "Maximum Amount $": "",
          "Minimum Amount $": "",
          "Sale Amount Percentage": "0.0000%",
          "Sale Percentage Of": "",
          "Sale Pricing Method": "Fixed"
        },
        {
          "Apply Shop Charges": "Yes",
          "Begin Date": "",
          "Calculate Tax": "Yes",
          "Cost Amount Percentage": "0.0000%",
          "Cost Percentage Of": "",
          "Cost Pricing Method": "Fixed",
          "Description": "Parts Discount",
          "End Date": "4/19/2021",
          "Exclude From Discounts": "Yes",
          "Fee Code": "PD",
          "Fixed Cost Amount": "$0.00",
          "Fixed Sale Amount": "$5.00",
          "GL Account": "54300",
          "GL Account Prompt Flag": "Yes",
          "GL Company": "#CO#",
          "Labor Fee Type": "Miscellaneous",
          "Maximum Amount $": "",
          "Minimum Amount $": "",
          "Sale Amount Percentage": "0.0000%",
          "Sale Percentage Of": "",
          "Sale Pricing Method": "Fixed"
        }
      ]

        const gridOptions :any = {
          columnDefs:[
              {
                  dataType:  "DATE",
                  headerName: "Begin Date",
                  required: "true",
                  field: "begin_date"
              }
          ]
      }
       const screenHeaderList:any[]=[
          ["Fee Code", "Description", "Begin Date", "End Date"],
        ["PD", "Parts Discount", "", "4/19/2021"],
        ["SD", "Service Discount", "", "4/19/2021"]
      ]
      excelService.screenDataFromXls = screenDataFromXls;
      excelService['headerRequired'] = true;
      spyOn(validationService,'isDateHeaderValueValid').and.returnValue(true);
      excelService['formatDateColumnData'](gridOptions,screenHeaderList);

    });


    it('test formatDateColumnData if headerName contains error ',()=>{

      const screenDataFromXls:any[]=[
        {
          "Apply Shop Charges": "Yes",
          "Begin Date": "",
          "Calculate Tax": "Yes",
          "Cost Amount Percentage": "0.0000%",
          "Cost Percentage Of": "",
          "Cost Pricing Method": "Fixed",
          "Description": "Parts Discount",
          "End Date": "4/19/2021",
          "Exclude From Discounts": "Yes",
          "Fee Code": "PD",
          "Fixed Cost Amount": "$0.00",
          "Fixed Sale Amount": "$5.00",
          "GL Account": "54300",
          "GL Account Prompt Flag": "Yes",
          "GL Company": "#CO#",
          "Labor Fee Type": "Miscellaneous",
          "Maximum Amount $": "",
          "Minimum Amount $": "",
          "Sale Amount Percentage": "0.0000%",
          "Sale Percentage Of": "",
          "Sale Pricing Method": "Fixed",
          "error": {
            "rowIndex": 0,
            "timeStamp": "",
            "errors": [
                {
                    "errorDescription": "Date value is invalid. Please enter correct value",
                    "errorField": "report_number",
                    "errorLevel": "",
                    "isUpdated": false
                }
            ]
        }
        },
        {
          "Apply Shop Charges": "Yes",
          "Begin Date": "",
          "Calculate Tax": "Yes",
          "Cost Amount Percentage": "0.0000%",
          "Cost Percentage Of": "",
          "Cost Pricing Method": "Fixed",
          "Description": "Parts Discount",
          "End Date": "4/19/2021",
          "Exclude From Discounts": "Yes",
          "Fee Code": "PD",
          "Fixed Cost Amount": "$0.00",
          "Fixed Sale Amount": "$5.00",
          "GL Account": "54300",
          "GL Account Prompt Flag": "Yes",
          "GL Company": "#CO#",
          "Labor Fee Type": "Miscellaneous",
          "Maximum Amount $": "",
          "Minimum Amount $": "",
          "Sale Amount Percentage": "0.0000%",
          "Sale Percentage Of": "",
          "Sale Pricing Method": "Fixed"
        }
      ]

        const gridOptions :any = {
          columnDefs:[
              {
                  dataType:  "DATE",
                  headerName: "Begin Date",
                  required: "true",
                  field: "begin_date"
              }
          ]
      }
       const screenHeaderList:any[]=[
          ["Fee Code", "Description", "Begin Date", "End Date"],
        ["PD", "Parts Discount", "", "4/19/2021"],
        ["SD", "Service Discount", "", "4/19/2021"]
      ]
      excelService.screenDataFromXls = screenDataFromXls;
      excelService['headerRequired'] = true;
      spyOn(validationService,'isDateHeaderValueValid').and.returnValue(false);
      excelService['formatDateColumnData'](gridOptions,screenHeaderList);

    });





    it('test formatCharacterColumnData',()=>{
      const gridOptions :any = {
        columnDefs:[
            {
                dataType:  "CHAR",
                headerName: "GL Company",
                required: "false",
                field: "gl_company"
            }
           
        ]
      }

      const screenHeaderList:any[]=[
        ["Fee Code", "Description","GL Company"],
        ["PD", "Parts Discount", "#CO#"],
        ["SD", "Service Discount", "#CO#"]
      ]
      excelService['headerRequired'] = true;
      excelService.screenDataFromXls = screenDataFromXls;
      spyOn(validationService,'isCharacterHeaderValueisValid').and.returnValue(false);
      excelService['formatCharacterColumnData'](gridOptions,screenHeaderList);
    });



    it('test formatCharacterColumnData if character value is invalid',()=>{
      const gridOptions :any = {
        columnDefs:[
            {
                dataType:  "CHAR",
                headerName: "GL Company",
                required: "false",
                field: "gl_company"
            }
        ]
      }

      const screenHeaderList:any[]=[
        ["Fee Code", "Description","GL Company"],
        ["PD", "Parts Discount", "#CO#"],
        ["SD", "Service Discount", "#CO#"]
      ]
      excelService['headerRequired'] = true;
      excelService.screenDataFromXls = screenDataFromXls;
      spyOn(validationService,'isCharacterHeaderValueisValid').and.returnValue(true);
      excelService['formatCharacterColumnData'](gridOptions,screenHeaderList);
    });


     it('test formatCharacterColumnData mandatory field is null',()=>{

      const gridOptions :any = {
        columnDefs:[
            {
                dataType:  "CHAR",
                headerName: "Company",
                required: "true",
                field: "company"
            }
        ]
      }
      const screenHeaderList:any[]=[
        [
          "Company",
          "Report Number",
          "Report Name",
          "Accounts",
          "Report Amount As",
          "Sort Option 1",
          "Sort Option 2",
          "Sort Option 3",
          "Sort Option 4",
          "Break on Journal",
          "Required for Closing"
      ],
      [
          "test",
          "",
          null,
          null,
          null,
          null,
          "",
          "",
          ""
      ]
      ]
      
      const screenDataFromXls:any[]=[
        {
           "Company":"",
          "Report Number": "",
          "Sort Option 2": "",
          "Sort Option 3": "",
          "Sort Option 4": "",
          "error": {
              "rowIndex": 0,
              "timeStamp": "",
              "errors": [
                  {
                      "errorDescription": "Integer value is invalid. Please enter correct value",
                      "errorField": "report_number",
                      "errorLevel": "",
                      "isUpdated": false
                  }
              ]
          }
      }
      ]

      excelService['headerRequired'] = true;
      excelService.screenDataFromXls = screenDataFromXls;
      spyOn(validationService,'isCharacterHeaderValueisValid').and.returnValue(false);
      excelService['formatCharacterColumnData'](gridOptions,screenHeaderList);
    }); 

    it('test formatCharacterColumnData if formatted char value is undefined',()=>{

      const gridOptions :any = {
        columnDefs:[
            {
                dataType:  "CHAR",
                headerName: "Company",
                required: "true",
                field: "company"
            }
        ]
      }
      const screenHeaderList:any[]=[
        [
          "Company",
          "Report Number",
          "Report Name",
          "Accounts",
          "Report Amount As",
          "Sort Option 1",
          "Sort Option 2",
          "Sort Option 3",
          "Sort Option 4",
          "Break on Journal",
          "Required for Closing"
      ],
      [
          undefined,
          "",
          null,
          null,
          null,
          null,
          "",
          "",
          ""
      ]
      ]
      
      const screenDataFromXls:any[]=[
        {
           "Company":"",
          "Report Number": "",
          "Sort Option 2": "",
          "Sort Option 3": "",
          "Sort Option 4": "",
          "error": {
              "rowIndex": 0,
              "timeStamp": "",
              "errors": [
                  {
                      "errorDescription": "Integer value is invalid. Please enter correct value",
                      "errorField": "report_number",
                      "errorLevel": "",
                      "isUpdated": false
                  }
              ]
          }
      }
      ]

      excelService['headerRequired'] = true;
      excelService.screenDataFromXls = screenDataFromXls;
      spyOn(validationService,'isCharacterHeaderValueisValid').and.returnValue(false);
      excelService['formatCharacterColumnData'](gridOptions,screenHeaderList);
    }); 
    


    it('test formatCharacterColumnData if formatted char value length is more',()=>{

      const gridOptions :any = {
        columnDefs:[
            {
                dataType:  "CHAR",
                headerName: "Company",
                required: "true",
                field: "company"
            }
        ]
      }
      const screenHeaderList:any[]=[
        [
          "Company",
          "Report Number",
          "Report Name",
          "Accounts",
          "Report Amount As",
          "Sort Option 1",
          "Sort Option 2",
          "Sort Option 3",
          "Sort Option 4",
          "Break on Journal",
          "Required for Closing"
      ],
      [
          "testcompanylenghthismore",
          "",
          null,
          null,
          null,
          null,
          "",
          "",
          ""
      ]
      ]
      
      const screenDataFromXls:any[]=[
        {
           "Company":"",
          "Report Number": "",
          "Sort Option 2": "",
          "Sort Option 3": "",
          "Sort Option 4": "",
          "error": {
              "rowIndex": 0,
              "timeStamp": "",
              "errors": [
                  {
                      "errorDescription": "Integer value is invalid. Please enter correct value",
                      "errorField": "report_number",
                      "errorLevel": "",
                      "isUpdated": false
                  }
              ]
          }
      }
      ]

      excelService['headerRequired'] = true;
      excelService.screenDataFromXls = screenDataFromXls;
      spyOn(validationService,'isCharacterHeaderValueisValid').and.returnValue(false);
      excelService['formatCharacterColumnData'](gridOptions,screenHeaderList);
    }); 
    
    it('test formatIntegerColumnData',()=>{

      const screenDataFromXls:any[]=[
        {
          "Begin Sold Hours": "12",
          "Cent Increment": "10",
          "Ending Sold Hours": "40",
          "Grid Name": "Nucler"
        },
        {
          "Begin Sold Hours": "12",
          "Cent Increment": "10",
          "Ending Sold Hours": "40",
          "Grid Name": "Nucler"
        }
      ]

      const gridOptions :any = {
        columnDefs:[
            {
                dataType:  "INT",
                headerName: "Cent Increment",
                required: "false",
                field: "cent_increment"
            } 
        ]
      }

      const screenHeaderList:any[]=[
        ["Grid Name", "Description", "Cent Increment", "Begin Sold Hours", "Ending Sold Hours", "Labor Rate or Forced Amount", "Calculation Type"],
        ["Nucler", "", "10", "12", "40"]
      ]
      excelService['headerRequired'] = true;
      excelService.screenDataFromXls = screenDataFromXls;
      spyOn(validationService,'isIntegerHeaderValueValid').and.returnValue(false);
      excelService['formatIntegerColumnData'](gridOptions,screenHeaderList);
    });


    it('test formatIntegerColumnData for formatted value is undefined',()=>{

      const screenDataFromXls:any[]=[
        {
          "Begin Sold Hours": "12",
          "Cent Increment": "10",
          "Ending Sold Hours": "40",
          "Grid Name": "Nucler"
        },
        {
          "Begin Sold Hours": "12",
          "Cent Increment": "10",
          "Ending Sold Hours": "40",
          "Grid Name": "Nucler"
        }
      ]


      const gridOptions :any = {
        columnDefs:[
            {
                dataType:  "INT",
                headerName: "Cent Increment",
                required: "false",
                field: "cent_increment"
            } 
        ]
      }

      const screenHeaderList:any[]=[
        ["Grid Name", "Description", "Cent Increment", "Begin Sold Hours", "Ending Sold Hours"],
        ["Nucler", "", undefined,undefined,undefined]
      ]

      spyOn(excelService,'isHeaderContainValueForNotRequiredField').and.returnValue(true);
      excelService['headerRequired'] = "true";
      excelService.screenDataFromXls = screenDataFromXls;
      spyOn(validationService,'isIntegerHeaderValueValid').and.returnValue(false);
      excelService['formatIntegerColumnData'](gridOptions,screenHeaderList);
    });

    
    it('test formatIntegerColumnData for not required field',()=>{

      const screenDataFromXls:any[]=[
        {
          "Begin Sold Hours": "12",
          "Cent Increment": "10",
          "Ending Sold Hours": "40",
          "Grid Name": "Nucler"
        },
        {
          "Begin Sold Hours": "12",
          "Cent Increment": "10",
          "Ending Sold Hours": "40",
          "Grid Name": "Nucler"
        }
      ]


      const gridOptions :any = {
        columnDefs:[
            {
                dataType:  "INT",
                headerName: "Cent Increment",
                required: "false",
                field: "cent_increment"
            } 
        ]
      }

      const screenHeaderList:any[]=[
        ["Grid Name", "Description", "Cent Increment", "Begin Sold Hours", "Ending Sold Hours"],
        ["Nucler", "", undefined,undefined,undefined]
      ]

      spyOn(excelService,'isHeaderContainValueForNotRequiredField').and.returnValue(true);
      excelService['headerRequired'] = "true";
      excelService.screenDataFromXls = screenDataFromXls;
      spyOn(validationService,'isIntegerHeaderValueValid').and.returnValue(true);
      excelService['formatIntegerColumnData'](gridOptions,screenHeaderList);
    });

    it('test formatIntegerColumnData if headerName contain errors',()=>{

      const screenDataFromXls:any[]=[
        {
          "Begin Sold Hours": "12",
          "Cent Increment": "10",
          "Ending Sold Hours": "40",
          "Grid Name": "Nucler",
          "error": {
            "rowIndex": 0,
            "timeStamp": "",
            "errors": [
                {
                    "errorDescription": "Integer value is invalid. Please enter correct value",
                    "errorField": "report_number",
                    "errorLevel": "",
                    "isUpdated": false
                }
            ]
        }
        },
        {
          "Begin Sold Hours": "12",
          "Cent Increment": "10",
          "Ending Sold Hours": "40",
          "Grid Name": "Nucler"
        }
      ]

      const gridOptions :any = {
        columnDefs:[
            {
                dataType:  "INT",
                headerName: "Cent Increment",
                required: "false",
                field: "cent_increment"
            } 
        ]
      }

      const screenHeaderList:any[]=[
        ["Grid Name", "Description", "Cent Increment", "Begin Sold Hours", "Ending Sold Hours", "Labor Rate or Forced Amount", "Calculation Type"],
        ["Nucler", "", "###", "12", "40"]
      ]
      excelService['headerRequired'] = true;
      excelService.screenDataFromXls = screenDataFromXls;
      spyOn(validationService,'isIntegerHeaderValueValid').and.returnValue(false);
      excelService['formatIntegerColumnData'](gridOptions,screenHeaderList);
    });


    it('test formatDropDownColumnData',()=>{

      const screenDataFromXls:any[]=[
        {
          "Labor Fee Type": "Miscellaneous",
          "Sale Pricing Method": "Fixed"
        },
        {
          "Labor Fee Type": "Miscellaneous",
          "Sale Pricing Method": "Fixed"
        }
      ]

      const gridOptions :any = {
        columnDefs:[
            {
                dataType:  "DROPDOWN",
                headerName: "Labor Fee Type",
                required: "false",
                field: "labor_fee_type",
                dataLength: 15,
                cellEditorParams:{
                  values:["", "Miscellaneous", "Lube", "Sublet"]
                }
            } 
        ]
      }

      const screenHeaderList:any[]=[
        ["Fee Code", "Description", "Begin Date", "End Date", "Labor Fee Type", "Sale Pricing Method"],
        ["PD", "Parts Discount", "", "4/19/2021", "Miscellaneous", "Fixed"]
      ]
      excelService['headerRequired'] = true;
      excelService.screenDataFromXls = screenDataFromXls;
      spyOn(validationService,'isDropdownHeaderValueisValid').and.returnValue(false);
      excelService['formatDropDownColumnData'](gridOptions,screenHeaderList);
    });

    it('test formatDropDownColumnData if DropDown Header value is invalid',()=>{

      const screenDataFromXls:any[]=[
        {
          "Labor Fee Type": "Miscellaneous",
          "Sale Pricing Method": "Fixed"
        },
        {
          "Labor Fee Type": "Miscellaneous",
          "Sale Pricing Method": "Fixed"
        }
      ]
      const gridOptions :any = {
        columnDefs:[
            {
                dataType:  "DROPDOWN",
                headerName: "Labor Fee Type",
                required: "false",
                field: "labor_fee_type",
                dataLength: 15,
                cellEditorParams:{
                  values:["", "Miscellaneous", "Lube", "Sublet"]
                }
            } 
        ]
      }

      const screenHeaderList:any[]=[
        ["Fee Code", "Description", "Begin Date", "End Date", "Labor Fee Type", "Sale Pricing Method"],
        ["PD", "Parts Discount", "", "4/19/2021", "Miscellaneous", "Fixed"]
      ]
      excelService['headerRequired'] = true;
      excelService.screenDataFromXls = screenDataFromXls;
      spyOn(validationService,'isDropdownHeaderValueisValid').and.returnValue(true);
      excelService['formatDropDownColumnData'](gridOptions,screenHeaderList);
    });

    it('test formatDropDownColumnData has errors in headerName',()=>{

      const screenDataFromXls:any[]=[
        {
          "Labor Fee Type": "Miscellaneous",
          "Sale Pricing Method": "Fixed",
          "error": {
            "rowIndex": 0,
            "timeStamp": "",
            "errors": [
                {
                    "errorDescription": "DropDown value is invalid. Please enter correct value",
                    "errorField": "report_number",
                    "errorLevel": "",
                    "isUpdated": false
                }
            ]
        }
        },
        {
          "Labor Fee Type": "Miscellaneous",
          "Sale Pricing Method": "Fixed"
        }
      ]

      const gridOptions :any = {
        columnDefs:[
            {
                dataType:  "DROPDOWN",
                headerName: "Labor Fee Type",
                required: "false",
                field: "labor_fee_type",
                dataLength: 15,
                cellEditorParams:{
                  values:["", "Miscellaneous", "Lube", "Sublet"]
                }
            } 
        ]
      }

      const screenHeaderList:any[]=[
        ["Fee Code", "Description", "Begin Date", "End Date", "Labor Fee Type", "Sale Pricing Method"],
        ["PD", "Parts Discount", "", "4/19/2021", "Miscellaneous", "Fixed"]
      ]
      excelService['headerRequired'] = true;
      excelService.screenDataFromXls = screenDataFromXls;
      spyOn(validationService,'isDropdownHeaderValueisValid').and.returnValue(false);
      excelService['formatDropDownColumnData'](gridOptions,screenHeaderList);
    });

    it('test formatBooleanColumnData',()=>{

      const screenHeaderList:any[]=[
           ["RestrictAccess"],
          ["1"]
      ]
      const gridOptions :any = {
        columnDefs:[
          {
            "headerName": "RestrictAccess",
            "field": "restrictaccess",
            "dataType": "BOOLEAN",
            "required": false,
            "editable": true,
            "editableByCDKOnly": "false",
            "validationRule": "",
            "dataLength": 1,
        }
        ]
      }
      excelService['headerRequired'] = true;
      excelService.screenDataFromXls = screenDataFromXls;
      spyOn(validationService,'isBooleanHeaderValueValid').and.returnValue(false);
      excelService['formatBooleanColumnData'](gridOptions,screenHeaderList);
    });

    it('test formatBooleanColumnData if boolean value is valid',()=>{

      const screenHeaderList:any[]=[
           ["RestrictAccess"],
          ["1"]
      ]
      const gridOptions :any = {
        columnDefs:[
          {
            "headerName": "RestrictAccess",
            "field": "restrictaccess",
            "dataType": "BOOLEAN",
            "required": false,
            "editable": true,
            "editableByCDKOnly": "false",
            "validationRule": "",
            "dataLength": 1,
        }
        ]
      }
      spyOn(validationService,'isBooleanHeaderValueValid').and.returnValue(true);
      spyOn(formattingService,'getFormattedBooleanValue').and.returnValue("1");
      excelService['headerRequired'] = true;
      excelService.screenDataFromXls = screenDataFromXls;
      excelService['formatBooleanColumnData'](gridOptions,screenHeaderList);
      expect(validationService.isBooleanHeaderValueValid).toHaveBeenCalledTimes(1);
      expect(formattingService.getFormattedBooleanValue).toHaveBeenCalledTimes(1);
    });

    it('test generateFileNameForExportCSV',()=>{
      let result = excelService.generateFileNameForExportCSV("P123","S456","Service","FeeCode");
    });

    it('test generateFileNameForExportCSV for project number null',()=>{
      let result = excelService.generateFileNameForExportCSV(null,"S456","Service","FeeCode");
    });

    it('test generateFileNameForExportXls',()=>{
      let result = excelService.generateFileNameForExportXls("P123","S456","Service");
    });

    it('test generateFileNameForExportXls for project is null',()=>{
      let result = excelService.generateFileNameForExportXls(null,"S456","Service");
    });

    it('test isUnsavedDataPresent',()=>{
      excelService.unsavedDataPresent = true;
      let result  =excelService.isUnsavedDataPresent();
      expect(result).toBeTruthy();

    });

    it('test resetUnsavedDataPresent',()=>{
      expect(excelService.resetUnsavedDataPresent()).toBeFalsy();
    });

    it('test isHeaderContainValueForNotRequiredField',()=>{
      let headerRequired:any = "false";
      let headerFieldValue:any = undefined;
      excelService.isHeaderContainValueForNotRequiredField(headerRequired,headerFieldValue);
    });


    it('test validateXlsFile',()=>{

      let screenHeaderList:any[]=[
        ["Tax Agency", "Description", "Calculation Method", "Per Group Base Limit", "Tax Grouping"],
        ["123", "test description", "Group", "", "STD"]
      ]
      let current_sheet_name :any="Tax Agencies"
      let currentWorkSheet :any={
        margins:{
          bottom: 0.75,
          footer: 0.3,
          header: 0.3,
          left: 0.7,
          right: 0.7,
          top: 0.75
        },
        A1:{
          h: "Tax Agency",
          r: "<t>Tax Agency</t>",
          t: "s",
          v: "Tax Agency"
        },
        A2:{
          h: "123",
          r: "<t>123</t>",
          t: "s",
          v: "123",
          w: "123"
        }
      }
      let screenContext :any={
          screen:{
            gridOptionsModel:{
              columnDefs:[
                {
                  headerName: "Tax Agency",
                  field: "tax_agency",
                  dataType: "INT",
                  required: "true",
                   editable: true,
                }
              ]
            },
            screenName: "Tax Agencies"
          }
      }
      spyOn(XLSX.utils,'sheet_to_json').and.returnValue(screenHeaderList)
      excelService['xlsHeaders'] = screenHeaderList;
      excelService.validateXlsFile(current_sheet_name,currentWorkSheet,screenContext)
    });

    
    it('test validateXlsFile columnDef is empty',()=>{

      let screenHeaderList:any[]=[
        ["Tax Agency", "Description", "Calculation Method", "Per Group Base Limit", "Tax Grouping"],
        ["123", "test description", "Group", "", "STD"]
      ]
      let current_sheet_name :any="Tax Agencies"
      let currentWorkSheet :any={ 
        A1:{
          h: "Tax Agency",
          r: "<t>Tax Agency</t>",
          t: "s",
          v: "Tax Agency"
        }
      }
      let screenContext :any={
          screen:{
            gridOptionsModel:{
              columnDefs:[]
            },
            screenName: "Tax Agencies"
          }
      }
      spyOn(XLSX.utils,'sheet_to_json').and.returnValue(screenHeaderList)
      excelService['xlsHeaders'] = screenHeaderList;
      excelService.validateXlsFile(current_sheet_name,currentWorkSheet,screenContext)      
    });


    it('test loadSheetOfXlsFile',()=>{

      let currentWorkSheet:any={
        "!ref": "A1:D2",
        "A1": {
            "t": "s",
            "v": "Employee ID",
            "r": "<t>Employee ID</t>",
            "h": "Employee ID",
            "w": "Employee ID"
        },
        "B1": {
            "t": "s",
            "v": "Last Name",
            "r": "<t>Last Name</t>",
            "h": "Last Name",
            "w": "Last Name"
        },
        "C1": {
            "t": "s",
            "v": "First Name",
            "r": "<t>First Name</t>",
            "h": "First Name",
            "w": "First Name"
        },
        "D1": {
            "t": "s",
            "v": "Job Role",
            "r": "<t>Job Role</t>",
            "h": "Job Role",
            "w": "Job Role"
        },
        "A2": {
            "t": "s",
            "v": "100",
            "r": "<t>100</t>",
            "h": "100",
            "w": "100"
        },
        "B2": {
            "t": "s",
            "v": "Smth",
            "r": "<t>Smth</t>",
            "h": "Smth",
            "w": "Smth"
        },
        "C2": {
            "t": "s",
            "v": "Doc",
            "r": "<t>Doc</t>",
            "h": "Doc",
            "w": "Doc"
        },
        "D2": {
            "t": "s",
            "v": "Technician",
            "r": "<t>Technician</t>",
            "h": "Technician",
            "w": "Technician"
        },
        "!margins": {
            "left": 0.7,
            "right": 0.7,
            "top": 0.75,
            "bottom": 0.75,
            "header": 0.3,
            "footer": 0.3
        }
      }

      let screenContext:any={
        "screen": {
          "screenName": "Service Employees",
          "gridOptionsModel": {
              "animatedRows": false,
              "rowSelection": "multiple",
              "columnDefs": [
                  {
                      "headerName": "Employee ID",
                      "field": "employee_id",
                      "dataType": "INT",
                      "required": "true",
                      "editable": true,
                      "editableByCDKOnly": "false",
                      "defaultValue": "",
                      "clientScreen": "",
                      "validationRule": "",
                      "dataLength": 7,
                      "cellEditor": "agLargeTextCellEditor",
                      "cellEditorParams": {
                          "maxLength": 7
                      },
                      "rowDrag": true,
                      "filterParams": {
                          "clearButton": true
                      },
                      "headerTooltip": "Employee ID",
                      "cellClassRules": {}
                  },
                  {
                      "headerName": "Last Name",
                      "field": "last_name",
                      "dataType": "CHAR",
                      "required": "true",
                      "editable": true,
                      "editableByCDKOnly": "false",
                      "defaultValue": "",
                      "clientScreen": "",
                      "validationRule": "",
                      "dataLength": 30,
                      "cellEditor": "agLargeTextCellEditor",
                      "cellEditorParams": {
                          "maxLength": 30
                      },
                      "filterParams": {
                          "clearButton": true
                      },
                      "headerTooltip": "Last Name",
                      "cellClassRules": {}
                  },
                  {
                      "headerName": "First Name",
                      "field": "first_name",
                      "dataType": "CHAR",
                      "required": "true",
                      "editable": true,
                      "editableByCDKOnly": "false",
                      "defaultValue": "",
                      "clientScreen": "",
                      "validationRule": "",
                      "dataLength": 20,
                      "cellEditor": "agLargeTextCellEditor",
                      "cellEditorParams": {
                          "maxLength": 20
                      },
                      "filterParams": {
                          "clearButton": true
                      },
                      "headerTooltip": "First Name",
                      "cellClassRules": {}
                  },
                  {
                      "headerName": "Job Role",
                      "field": "job_role",
                      "dataType": "DROPDOWN",
                      "required": "false",
                      "editable": true,
                      "editableByCDKOnly": "false",
                      "defaultValue": "",
                      "clientScreen": "",
                      "validationRule": "Technician,Advisor,Other",
                      "dataLength": 0,
                      "cellEditor": "agSelectCellEditor",
                      "cellEditorParams": {
                          "values": [
                              "",
                              "Technician",
                              "Advisor",
                              "Other"
                          ]
                      },
                      "filterParams": {
                          "clearButton": true
                      },
                      "headerTooltip": "Job Role",
                      "cellClassRules": {}
                  }
              ],
              "rowData": []
          },
          "description": "Service Employees",
          "updated": false,
          "version": 0,
          "productCode": "SVC",
          "index": null,
          "deleted": false,
          "bpScreenId": "a02b8016-5de2-43fd-b749-6ba3787db8f0",
          "masterScreenId": "97001e3f-0d1b-4736-9eac-de940cf68730",
          "copyRowData": false,
          "rowDataEmpty": true,
          "bpPropagationCompleted": false,
          "recordType": "952927a5-97be-41d5-81c2-9a13b12e2e27",
          "id": "57417bcf-b958-4caf-a64a-991f2714c92f"
      },
      "rowData": [
        {
          "rowDataId": "7ff415a2-f62c-4a77-a276-c06d77188844",
          "data": {
            "rowDataId": "7ff415a2-f62c-4a77-a276-c06d77188844",
            "id": "02200ce4-c178-43e0-a434-2c13ce4f47b5",
            "index": "1000"
          },
          "id": "02200ce4-c178-43e0-a434-2c13ce4f47b5",
          "recordType": "1000"
        },
        {
            "rowDataId": "8ff415a2-f62c-4a77-a276-c06d77188844",
            "data": {
              "rowDataId": "8ff415a2-f62c-4a77-a276-c06d77188844",
              "id": "12200ce4-c178-43e0-a434-2c13ce4f47b5",
              "index": "2000"
            },
            "id": "12200ce4-c178-43e0-a434-2c13ce4f47b5",
            "recordType": "2000"
          }
       ]
      }

      let currentScreenContext:any={
        "screenName": "Service Employees",
        "gridOptionsModel": {
            "animatedRows": false,
            "rowSelection": "multiple",
            "columnDefs": [
                {
                    "headerName": "Employee ID",
                    "field": "employee_id",
                    "dataType": "INT",
                    "required": "true",
                    "editable": true,
                    "editableByCDKOnly": "false",
                    "defaultValue": "",
                    "clientScreen": "",
                    "validationRule": "",
                    "dataLength": 7,
                    "cellEditor": "agLargeTextCellEditor",
                    "cellEditorParams": {
                        "maxLength": 7
                    },
                    "rowDrag": true,
                    "filterParams": {
                        "clearButton": true
                    },
                    "headerTooltip": "Employee ID",
                    "cellClassRules": {}
                },
                {
                    "headerName": "Last Name",
                    "field": "last_name",
                    "dataType": "CHAR",
                    "required": "true",
                    "editable": true,
                    "editableByCDKOnly": "false",
                    "defaultValue": "",
                    "clientScreen": "",
                    "validationRule": "",
                    "dataLength": 30,
                    "cellEditor": "agLargeTextCellEditor",
                    "cellEditorParams": {
                        "maxLength": 30
                    },
                    "filterParams": {
                        "clearButton": true
                    },
                    "headerTooltip": "Last Name",
                    "cellClassRules": {}
                },
                {
                    "headerName": "First Name",
                    "field": "first_name",
                    "dataType": "CHAR",
                    "required": "true",
                    "editable": true,
                    "editableByCDKOnly": "false",
                    "defaultValue": "",
                    "clientScreen": "",
                    "validationRule": "",
                    "dataLength": 20,
                    "cellEditor": "agLargeTextCellEditor",
                    "cellEditorParams": {
                        "maxLength": 20
                    },
                    "filterParams": {
                        "clearButton": true
                    },
                    "headerTooltip": "First Name",
                    "cellClassRules": {}
                },
                {
                    "headerName": "Job Role",
                    "field": "job_role",
                    "dataType": "DROPDOWN",
                    "required": "false",
                    "editable": true,
                    "editableByCDKOnly": "false",
                    "defaultValue": "",
                    "clientScreen": "",
                    "validationRule": "Technician,Advisor,Other",
                    "dataLength": 0,
                    "cellEditor": "agSelectCellEditor",
                    "cellEditorParams": {
                        "values": [
                            "",
                            "Technician",
                            "Advisor",
                            "Other"
                        ]
                    },
                    "filterParams": {
                        "clearButton": true
                    },
                    "headerTooltip": "Job Role",
                    "cellClassRules": {}
                }
            ],
            "rowData": []
        },
        "description": "Service Employees",
        "updated": false,
        "version": 0,
        "productCode": "SVC",
        "index": null,
        "deleted": false,
        "bpScreenId": "a02b8016-5de2-43fd-b749-6ba3787db8f0",
        "masterScreenId": "97001e3f-0d1b-4736-9eac-de940cf68730",
        "copyRowData": false,
        "rowDataEmpty": true,
        "bpPropagationCompleted": false,
        "recordType": "952927a5-97be-41d5-81c2-9a13b12e2e27",
        "id": "57417bcf-b958-4caf-a64a-991f2714c92f"
      }
      let gridApi:any={
        updateRowData,
        refreshCells
      }

      function updateRowData(){
        return {}
      }
      
      function refreshCells(){}

      let screenDataFromXls:any[]=[
        {
          "Employee ID": "100",
          "Last Name": "Smth",
          "First Name": "Doc",
          "Job Role": "Technician"
        }
      ]

      excelService.screenDataFromXls = screenDataFromXls;
     spyOn<any>(excelService,'formatCurrencyColumnData');
     spyOn<any>(excelService,'formatPercentageColumnData');
     spyOn<any>(excelService,'formatBooleanColumnData');
     spyOn<any>(excelService,'formatIntegerColumnData');
     spyOn<any>(excelService,'formatCharacterColumnData');
     spyOn<any>(excelService,'formatDateColumnData');
     spyOn<any>(excelService,'formatDropDownColumnData');
      excelService.loadSheetOfXlsFile(currentWorkSheet,screenContext,currentScreenContext,gridApi);
    
    });

    it('test getTemplateXls',()=>{

      let headers:any={
        append
      }
      function append(){
        return true;
      }
      spyOn(serverCommService,'getHeaders').and.returnValue(headers);
      excelService.getTemplateXls(templateObject);
      expect(serverCommService.getHeaders).toHaveBeenCalledTimes(1);
    });

    it('test getTemplateXlsWithData',()=>{

      let headers:any={
        append
      }
      function append(){
        return true;
      }
      spyOn(serverCommService,'getHeaders').and.returnValue(headers);
      excelService.getTemplateXlsWithData(templateObject);
      expect(serverCommService.getHeaders).toHaveBeenCalledTimes(1);
    });

    it('test getScreenCsv',()=>{
      let functionalAreaId ='FA100';
      let functionalUnitId ='U200';
      let headers:any={
        append
      }
      function append(){
        return true;
      }
      spyOn(serverCommService,'getHeaders').and.returnValue(headers);
      excelService.getScreenCsv(functionalAreaId,functionalUnitId);
    });
    
     it('test importXLSXFile',()=>{
      

      const blob = new Blob([""], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      blob["lastModifiedDate"] = "Tue Aug 24 2021 15:49:13 GMT+0530 (India Standard Time) {}";
      blob["name"] = "larmietest-larim_store-accounting-8_24_2021-12_02_54 PM.xlsx";
      const file = <File>blob;
      const fileList = {
        0: file,
        1: file,
        length: 2,
        item: (index: number) => file
      };
      let templateContext: any={
        "template": {
          "functionalAreaName": "Service"
        },
        "screenContextList": [
          {
            "screen": {
              "screenName": "Accounts Payable",
              "gridOptionsModel":{
                "columnDefs":[
                  {
                    "headerName":"Company Number"
                  }
                ]
              }
            }
          }
        ]
      }
      let currentScreenContext: any={
        'rowData':[],
        "screen": {
          "screenName": "Accounts Payable",
           "recordType": "3dcf6d6c-3dac-48bb-ab94-913f8c929206"
        }

      }
      let importScreenList:any[]=['Accounts Payable'];
      let gridApi:any={}

      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: ()=>(importScreenList), close: null });
      dialogRefSpyObj.componentInstance = { body: '' };
      dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

     let validXlsStatusFlag:boolean= true;

      
     var screenHeaderList1:any[]=[
      ["Company Number", "Account Number"],
      ["123", "3344"]
    ]
     excelService['xlsHeaders'] = screenHeaderList1;
     excelService.importXLSXFile(fileList,templateContext,currentScreenContext,gridApi)
    
    }); 


});




