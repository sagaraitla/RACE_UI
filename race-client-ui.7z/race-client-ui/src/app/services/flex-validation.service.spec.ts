import { HttpClientTestingModule } from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { MatDialogModule } from "@angular/material";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { FlexValidationService } from "./flex-validation.service";
import { FormattingService } from "./formatting-service";
import { ValidationService } from "./validation-service";

describe('FlexValidationService', () => {

    let flexValidationService: FlexValidationService;
    let formattingService : FormattingService;
    let validationService: ValidationService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule,
                MatDialogModule,
                BrowserAnimationsModule
            ],
            providers: [FlexValidationService,FormattingService,ValidationService]
        });

        flexValidationService = TestBed.get(FlexValidationService);
        formattingService = TestBed.get(FormattingService);
        validationService = TestBed.get(ValidationService);
    });

   
    it('should create the FlexValidationService', () => {
        expect(flexValidationService).toBeDefined();
    });

    it('test formatIntegerColumnData',()=>{

        const gridOptions :any = {
            columnDefs:[
                {
                    dataType:  "INT",
                    headerName: "Starting RO Number",
                    required: "true"
                }
            ]
        }
        const screenHeaderList :any = [
            {
                index: 0,
                starting_ro_number: "23000"
            }
        ]
        flexValidationService.formatIntegerColumnData(gridOptions,screenHeaderList);
    });

    it('test formatIntegerColumnData for IntegerColumn Data null',()=>{

        const gridOptions :any = {
            columnDefs:[
                {
                    dataType:  "INT",
                    field:"StartingRONumber",
                    headerName: "Starting RO Number",
                    required: "true"
                }
            ]
        }
        const screenHeaderList :any = [
            {
                index: 0,
                StartingRONumber: null
            }
        ]
        flexValidationService.formatIntegerColumnData(gridOptions,screenHeaderList);
    });

    it('test formatBooleanColumnData',()=>{

        const gridOptions :any = {
            columnDefs:[
                {
                    dataType: "BOOLEAN",
                    headerName: "Auto order",
                    required: "true"
                }
            ]
        }
        const screenHeaderList :any = [
            {
                index: 0,
                starting_ro_number: "23000"
            }
        ]
        spyOn(validationService,'isBooleanHeaderValueValid').and.returnValue(false);
        flexValidationService.formatBooleanColumnData(gridOptions,screenHeaderList);
    });

    it('test formatBooleanColumnData for boolean data value null',()=>{

        const gridOptions :any = {
            columnDefs:[
                {
                    dataType: "BOOLEAN",
                    field:"Auto_order",
                    headerName: "Auto order",
                    required: "true"
                }
            ]
        }
        const screenHeaderList :any = [
            {
                index: 0,
                Auto_order: null
            }
        ]
        spyOn(validationService,'isBooleanHeaderValueValid').and.returnValue(false);
        flexValidationService.formatBooleanColumnData(gridOptions,screenHeaderList);
    });

    it('test formatPercentageColumnData',()=>{

        const gridOptions :any = {
            columnDefs:[
                {
                    dataType: "PERCENTAGE",
                    headerName: "Cost Amount Percent",
                    required: "true"
                }
            ]
        }
        const screenHeaderList :any = [
            {
                index: 0,
                fee_codes: "WW"
            }
        ]
        flexValidationService.formatPercentageColumnData(gridOptions,screenHeaderList,undefined);
    });
    
    it('test formatPercentageColumnData for tax codes',()=>{

        const gridOptions :any = {
            columnDefs:[
                {
                    dataType: "PERCENTAGE",
                    field:"tax_percent",
                    headerName: "Tax Percent",
                    required: "true"
                }
            ]
        }
        const screenHeaderList :any = [
            {
                index: 0,
                tax_percent: "10"
            }
        ]
        spyOn(formattingService,'formatPercentageWithDecimalPoint').and.returnValue("10.2%");
        flexValidationService.formatPercentageColumnData(gridOptions,screenHeaderList,"Tax Codes");
    });

    it('test formatPercentageColumnData for formatted value is null',()=>{

        const gridOptions :any = {
            columnDefs:[
                {
                    dataType: "PERCENTAGE",
                    field:"tax_percent",
                    headerName: "Tax Percent",
                    required: "true"
                }
            ]
        }
        const screenHeaderList :any = [
            {
                index: 0,
                tax_percent: "10"
            }
        ]
        spyOn(formattingService,'formatPercentageWithDecimalPoint').and.returnValue(null);
        flexValidationService.formatPercentageColumnData(gridOptions,screenHeaderList,"Tax Codes");
    });

    it('test formatCharacterColumnData',()=>{

        const gridOptions :any = {
            columnDefs:[
                {
                    dataType: "CHAR",
                    headerName: "Dealer Code",
                    required: "true"
                }
            ]
        }
        const screenHeaderList :any = [
            {
                index: 0,
                fee_codes: "WW"
            }
        ]
        flexValidationService.formatCharacterColumnData(gridOptions,screenHeaderList);
    });

    it('test formatCharacterColumnData when character data value is null',()=>{

        const gridOptions :any = {
            columnDefs:[
                {
                    dataType: "CHAR",
                    field:"DealerCode",
                    headerName: "Dealer Code",
                    required: "true"
                }
            ]
        }
        const screenHeaderList :any = [
            {
                index: 0,
                DealerCode: null
            }
        ]
        flexValidationService.formatCharacterColumnData(gridOptions,screenHeaderList);
    });

    it('test formatCurrencyColumnData',()=>{

        const gridOptions :any = {
            columnDefs:[
                {
                    dataType: "CURRENCY",
                    headerName: "Fixed Amount $",
                    required: "true"
                }
            ]
        }
        const screenHeaderList :any = [
            {
                index: 0,
                fee_codes: "WW"
            }
        ]
        let formttedValue:any ="test.r$";
        spyOn(formattingService,'formatCurrencyWithCommaAndDecimalPoint').and.returnValue(formttedValue);
        spyOn(validationService,'isCurrencyValueValid').and.returnValue(false);
        flexValidationService.formatCurrencyColumnData(gridOptions,screenHeaderList);
    });
    
    it('test formatDateColumnData',()=>{

        const gridOptions :any = {
            columnDefs:[
                {
                    dataType: "DATE",
                    headerName: "Tax Period Beginning",
                    required: "true"
                }
            ]
        }
        const screenHeaderList :any = [
            {
                index: 0,
                fee_codes: "WW"
            }
        ]
        flexValidationService.formatDateColumnData(gridOptions,screenHeaderList);
    });

    it('test formatDateColumnData for Date value null',()=>{

        const gridOptions :any = {
            columnDefs:[
                {
                    dataType: "DATE",
                    field: "starting_invoice",
                    headerName: null,
                    required: "true"
                }
            ]
        }
        const screenHeaderList :any = [
            {
                index: 0,
                starting_invoice:null
            }
        ]
        flexValidationService.formatDateColumnData(gridOptions,screenHeaderList);
    });

    it('test formatDropDownColumnData for DropDown Value null',()=>{

        const gridOptions :any = {
            columnDefs:[
                {
                    dataType: "DROPDOWN",
                    field:"UseNegative",
                    headerName: "UseNegative",
                    required: "true",
                    cellEditorParams:[
                        "YES",
                        "NO",
                        ""
                    ]
                }
            ]
        }
        const screenHeaderList :any = [
            {
                index: 0,
                UseNegative:null
            }
        ]
        flexValidationService.formatDropDownColumnData(gridOptions,screenHeaderList);
    });
 
    it('test formatDropDownColumnData',()=>{

        const gridOptions :any = {
            columnDefs:[
                {
                    dataType: "DROPDOWN",
                    headerName: "Use Negative",
                    required: "true",
                    cellEditorParams:[
                        "YES",
                        "NO",
                        ""
                    ]
                }
            ]
        }
        const screenHeaderList :any = [
            {
                index: 0,
                fee_codes: "WW"
            }
        ]
        flexValidationService.formatDropDownColumnData(gridOptions,screenHeaderList);
    });


});
