export class Constants {
	​
	public static PRODUCT_CODES = [
		{ value: 'ACCT', viewValue: 'Accounting' },
		{ value: 'SVC', viewValue: 'Service' },
		{ value: 'PTS', viewValue: 'Parts' },
		{ value: 'SLS', viewValue: 'Sales' },
		{ value: 'EMP', viewValue: 'Employees' },
		{ value: 'VINV', viewValue: 'Vehicle Inventory' },
		{ value: 'FRM', viewValue: 'eForms' },
		{ value: 'SSS', viewValue: 'Sales State Standards' }
	];
​
	public static CONDITONS = [
		{ name: 'Must Exist In' },
		{ name: 'Must Not Exist In' },
	];
​
	public static PLATFOMRS = [
		{ name: 'DRIVE' },
		{ name: 'FLEX' }
	];
​
	public static CONDITION_TYPES = [
		{ name: 'Error' },
		{ name: 'Warning' }
	];
	
	public static CDK_200: string = "CDK_200";
	public static CDK_500: string = "CDK_500";
	public static POPUP_CANCEL: String = "POPUP_CANCEL";
	
	public static CDKU_COORDINATORS = [
		{ name: 'COX' },
		{ name: 'FLOYD' },
		{ name: 'FISHER' },
		{ name: 'M\'BOUP' },
		{ name: 'BENNEWITZ' }
	];
	
	public static COUNTRIES = [
		{ name: 'United States' },
		{ name: 'Canada' },
		{ name: 'Other' }
	];
	
	public static CDKU_DOMAINS = [
		{ name: 'AN' },
		{ name: 'ARNA' },
		{ name: 'AS' },
		{ name: 'Auto' },
		{ name: 'BH' },
		{ name: 'CAN' },
		{ name: 'Cochran' },
		{ name: 'DASH' },
		{ name: 'HE' },
		{ name: 'INTL' },
		{ name: 'LM' }
	];
	
	public static CDKU_LOGINS = [
		{ name: 'PWD' },
		{ name: 'SSO' }
	];
	
	public static TIMEZONES  = [
		{ name: 'UTC-4: Atlantic Standard Time (AST)' },
		{ name: 'UTC-5: Eastern Standard Time (EST)' },
		{ name: 'UTC-6: Central Standard Time (CST)' },
		{ name: 'UTC-7: Mountain Standard Time (MST)' },
		{ name: 'UTC-8: Pacific Standard Time (PST)' },
		{ name: 'UTC-9: Alaska Standard Time (AKST)' },
		{ name: 'UTC-10: Hawaii-Aleutian Standard Time (HAST)' },
		{ name: 'UTC-11: Samoa Standard Time' },
		{ name: 'UTC+10: Chamorro Standard Time' },
		{ name: 'UTC+12: Wake Island Time Zone' }
	];
	
	public static PROJECT_ENV = [
		{ name: 'DASH' }
	];
	
	public static LANGUAGES = [
		{ name: 'en_US' },
		{ name: 'fr_CA' }
	];
	
	public static PROJECT_STATUS = [
		{ statusName: 'OPEN' },
		{ statusName: 'FINISHED' },
		{ statusName: 'CANCELLED' },
		{ statusName: 'POSTPONED' },
		{ statusName: 'INACTIVE' }
	];
	
	public static PLATFORMS = [
		{ platformCode: 'drive', platformName: 'DRIVE', selected: false },
		{ platformCode: 'flex', platformName: 'FLEX', selected: false }
	];
​
	public static UNITED_STATES = [
		{ name: 'Alabama' },
		{ name: 'Alaska' },
		{ name: 'Arizona' },
		{ name: 'Arkansas' },
		{ name: 'California' },
		{ name: 'Colorado' },
		{ name: 'Connecticut' },
		{ name: 'Delaware' },
		{ name: 'Florida' },
		{ name: 'Georgia' },
		{ name: 'Hawaii' },
		{ name: 'Idaho' },
		{ name: 'Illinois' },
		{ name: 'Indiana' },
		{ name: 'Iowa' },
		{ name: 'Kansas' },
		{ name: 'Kentucky' },
		{ name: 'Louisiana' },
		{ name: 'Maine' },
		{ name: 'Maryland' },
		{ name: 'Massachusetts' },
		{ name: 'Michigan' },
		{ name: 'Minnesota' },
		{ name: 'Mississippi' },
		{ name: 'Missouri' },
		{ name: 'Montana' },
		{ name: 'Nebraska' },
		{ name: 'Nevada' },
		{ name: 'New Hampshire' },
		{ name: 'New Jersey' },
		{ name: 'New Mexico' },
		{ name: 'New York' },
		{ name: 'North Carolina' },
		{ name: 'North Dakota' },
		{ name: 'Ohio' },
		{ name: 'Oklahoma' },
		{ name: 'Oregon' },
		{ name: 'Pennsylvania' },
		{ name: 'Rhode Island' },
		{ name: 'South Carolina' },
		{ name: 'South Dakota' },
		{ name: 'Tennessee' },
		{ name: 'Texas' },
		{ name: 'Utah' },
		{ name: 'Vermont' },
		{ name: 'Virginia' },
		{ name: 'Washington' },
		{ name: 'West Virginia' },
		{ name: 'Wisconsin' },
		{ name: 'Wyoming' },
	];
​
	public static CANADA = [
		{ name: 'Alberta' },
		{ name: 'British Columbia' },
		{ name: 'Manitoba' },
		{ name: 'New Brunswick' },
		{ name: 'Newfoundland and Labrador' },
		{ name: 'Northwest Territories' },
		{ name: 'Nova Scotia' },
		{ name: 'Nunavut' },
		{ name: 'Ontario' },
		{ name: 'Prince Edward Island' },
		{ name: 'Quebec' },
		{ name: 'Saskatchewan' },
		{ name: 'Yukon' },
	];
	
	public static BESTPRACTICE_TYPES  = ['OEM', 'State Standard'];
	
	public static OEMS  = [
		{ value: 'honda', viewValue: 'Honda' },
		{ value: 'gm', viewValue: 'GM' },
		{ value: 'Hyundai', viewValue: 'Hyundai' },
		{ value: 'bmw', viewValue: 'BMW' },
		{ value: 'audi', viewValue: 'Audi' },
		{ value: 'porsche', viewValue: 'Porsche' }
	];
	
	public static ERROR_DATA_REQUIRED: string = "required";
	public static ERROR_DATA_MORE_LENGTH: string = "data more than length";
	public static BP_AUDITLOG = "Best Practice";
}