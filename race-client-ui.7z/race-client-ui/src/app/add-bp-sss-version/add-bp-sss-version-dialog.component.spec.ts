import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatDialogRef, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatSelectModule, MatSortModule, MatStepperModule, MAT_DIALOG_DATA } from "@angular/material";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { of } from "rxjs";
import { Observable } from "rxjs";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { BestPracticeVersionObject } from "../model/bestpractice-version-object";
import { MasterFunctionalUnit } from "../model/master-functional-unit";
import { ScreenObject } from "../model/screen-object";
import { AuthService } from "../services/auth-service";
import { BestPracticeService } from '../services/bestpractice-service';
import { AddBPSSSVersionComponent } from "./add-bp-sss-version-dialog.component";
import { FormBuilder, FormControl, FormsModule, ReactiveFormsModule, Validators } from "@angular/forms";
import { TemplateObject } from "../model/template-object";
import { BestPracticeObject } from "../model/bestpractice-object";
import { Platform } from "../model/master-platform";
describe('AddBPSSSVersionComponent',() => {

    let component : AddBPSSSVersionComponent;
    let fixture : ComponentFixture<AddBPSSSVersionComponent>;
    let bestPracticeService: BestPracticeService;
    let authService : AuthService;
    let dialogRef: MatDialog;
    let _formBuilder : FormBuilder;

    const testUrl  = 'dashboard';
    const dialogMock = {
        close: () => { }
    };
    beforeEach(async(() =>{

        let data= {
          bpVersionName:"2021",
          project:"testProject"
        }
        let mockRouter = {navigate: jasmine.createSpy('navigateByUrl')} 

        TestBed.configureTestingModule({
           imports: [
                MatCardModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatPaginatorModule,
                MatDialogModule,
                ToastrModule.forRoot(),
                CommonModule,
                MatSelectModule,
                MatCheckboxModule,
                MatSortModule,
                MatIconModule,
                FormsModule,
                MatMenuModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                SortableModule,
                MatSortModule,
                ReactiveFormsModule,
                MatStepperModule
            ],
            declarations : [AddBPSSSVersionComponent,LoaderDialogueComponent],
            providers : [
                BestPracticeService,
                AuthService,
                ToastrService,
                { provide: Router, useValue: {url:testUrl} },
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: dialogMock},
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent]}});
         
            authService = TestBed.get(AuthService);
            bestPracticeService = TestBed.get(BestPracticeService);
            fixture = TestBed.createComponent(AddBPSSSVersionComponent);
            component = fixture.componentInstance;
      }));

      beforeEach(() =>{
        fixture = TestBed.createComponent(AddBPSSSVersionComponent);
        component = fixture.componentInstance;
        _formBuilder = TestBed.get(FormBuilder); 
        component.firstFormGroup = _formBuilder.group({ 
          recipientTypes: new FormControl(
          {
              value: ["mock"],
              disabled: true
          },
          Validators.required
          )
          });
          component.secondFormGroup = _formBuilder.group({ 
              recipientTypes: new FormControl(
              {
                  value: ["mock"],
                  disabled: true
              },
              Validators.required
              )
              });
        fixture.detectChanges();
    })

    let platForm :Platform={
      "platformName": "FLEX",
      "platformCode": "flex",
      "selected": false,
      "id":"1",
      "recordType":"platform"
    }

    const currentBestPractice: BestPracticeObject={
      isBestPractice : 1,
      bestPracticeName : "testbp",
      platform : platForm,	
      version : 123,
      failed : false,
      isSSS : 0,
      id:"1",
      recordType:null
    }

      const master_functionalUnit_list: MasterFunctionalUnit[] =[
        {
            "functionalUnitType": "MasterFunctionalUnit",
            "functionalUnitName": "BP_Tree_Check_PropagationTQAIG",
            "gridOptionsModel": {
              "animatedRows": false,
              "rowSelection": "multiple",
              "columnDefs": [
              ],
              "rowData":null
            },
            "description": "BP_Tree_Check_Propagation",
            "version": 0,
            "productCode": "PTS",
            "createdDate": null,
            "lastUpdatedDate": null,
            "propagationStarted": false,
            "id": "ad5b9464-5839-4c84-aac3-c66f2398f6ad",
            "recordType": "FunctionalUnitInfo"
          }
    ]  
      const functionalUnitsList:any[]=[
        {
            "screenName": "Account Definition",
            "gridOptionsModel": {
              "animatedRows": false,
              "rowSelection": "multiple",
              "columnDefs": [
                {
                  "headerName": "Starting RO Number",
                  "field": "starting_ro_number",
                  "dataType": "INT",
                  "required": "false",
                  "editable": "true",
                  "editableByCDKOnly": "false",
                  "defaultValue": "",
                  "validationRule": "",
                  "dataLength": 9,
                  "cellEditor": "agLargeTextCellEditor",
                  "cellEditorParams": {
                    "maxLength": 9
                  }
                }
              ],
              "rowData":null
            },
            "description": "Account Definition",
            "updated": false,
            "version": 0,
            "productCode": "SVC",
            "index": 0,
            "bpScreenId": "6e260b12-03d5-4a9e-854c-ea29eba80dbd",
             "selected": false,
             "templateId": null,
            "copyRowData": true,
            "rowDataEmpty": false,
            "bpPropagationCompleted": false,
            "id": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
            "recordType": "ff991af6-3c55-4642-a500-bed944b7f574" 
        }
      ]

      const screenObjectList :ScreenObject[]=[
        {
        "screenName": "Account Definition",
        "gridOptionsModel": {
          "animatedRows": false,
          "rowSelection": "multiple",
          "columnDefs": [
            {
              "headerName": "Starting RO Number",
              "field": "starting_ro_number",
              "dataType": "INT",
              "required": "false",
              "editable": "true",
              "editableByCDKOnly": "false",
              "defaultValue": "",
              "validationRule": "",
              "dataLength": 9,
              "cellEditor": "agLargeTextCellEditor",
              "cellEditorParams": {
                "maxLength": 9
              }
            }
          ],
          "rowData":null
        },
        "description": "Account Definition",
        "updated": false,
        "version": 0,
        "productCode": "SVC",
        "index": 0,
        "bpScreenId": "6e260b12-03d5-4a9e-854c-ea29eba80dbd",
         "selected": false,
         "templateId": null,
        "copyRowData": true,
        "rowDataEmpty": false,
        "bpPropagationCompleted": false,
        "id": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
        "recordType": "ff991af6-3c55-4642-a500-bed944b7f574" 
      }
      ]

      const screenObject : ScreenObject = {
        "screenName": "Account Definition",
        "gridOptionsModel": {
          "animatedRows": false,
          "rowSelection": "multiple",
          "columnDefs": [
            {
              "headerName": "Starting RO Number",
              "field": "starting_ro_number",
              "dataType": "INT",
              "required": "false",
              "editable": "true",
              "editableByCDKOnly": "false",
              "defaultValue": "",
              "validationRule": "",
              "dataLength": 9,
              "cellEditor": "agLargeTextCellEditor",
              "cellEditorParams": {
                "maxLength": 9
              }
            }
          ],
          "rowData":null
        },
        "description": "Account Definition",
        "updated": false,
        "version": 0,
        "productCode": "SVC",
        "index": 0,
        "bpScreenId": "6e260b12-03d5-4a9e-854c-ea29eba80dbd",
         "selected": false,
         "templateId": null,
        "copyRowData": true,
        "rowDataEmpty": false,
        "bpPropagationCompleted": false,
        "id": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
        "recordType": "ff991af6-3c55-4642-a500-bed944b7f574" 
    }

    
    const bpVersionList: BestPracticeVersionObject[]=[
        {
          id : "123",
          recordType : "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
          versionName : "2021",
          active : true,
          objectType : "test",
          functionalAreaList : null,
          propagationStarted:true, 
        }
    ]

    const bestPracticeVersionObjectList: BestPracticeVersionObject[]=[
        {
            id : "444",
            recordType : "BestPracticeVersionObject",
            versionName : "2021",
            active : false,
            objectType : null,
            functionalAreaList : null,
            propagationStarted:false
          }
      ]

    const bestPracticeVersionObject: BestPracticeVersionObject={
        id : "444",
        recordType : "BestPracticeVersionObject",
        versionName : "2021",
        active : false,
        objectType : null,
        functionalAreaList : null,
        propagationStarted:false
      }

      it('test setVersionForEdit',()=>{
        let templateObject = new TemplateObject();
        spyOn(bestPracticeService,'getSSSFunctionalUnitsOfBpVersion').and.returnValue(Observable.of(templateObject));
        component.setVersionForEdit(bpVersionList);
      });

      it('test checkActiveVersion',()=>{
        let event : any={checked : true}
        component.checkActiveVersion(event);
        expect(component.bpVersionObj.active).toBeTruthy();
    });

    it('test checkActiveVersion event checked false',()=>{
        let event : any={
            checked : false
        }
        component.checkActiveVersion(event);
        expect(component.bpVersionObj.active).toBeFalsy();
    });

    it('test selectFunctionalUnit event checked false',()=>{
        let event : any={checked : false}
        let selectedFunctionalUnits:any[]=[
            {
             "screenName": "Account Definition"  
            }
        ]
        component.selectedFunctionalUnits = selectedFunctionalUnits;
        component.selectFunctionalUnit(event,screenObject)
        expect(component.selectedFunctionalUnits.length).toEqual(0);
    });

    it('test selectFunctionalUnit event checked true',()=>{
        let event : any={checked : true}
       
        let selectedFunctionalUnits:any[]=[
            {
             "screenName": "Account Definition"  
            }
        ]
        component.storeFunctionalUnits = selectedFunctionalUnits;
        component.selectFunctionalUnit(event,screenObject)
        expect(component.selectedFunctionalUnits.length).toEqual(1);
    });

    
    it('test selectFunctionalUnit event checked true and empty functionalUnit list',()=>{
        let event : any={checked : true}
       
        let selectedFunctionalUnits:any[]=[
            {
             "screenName": "COA"  
            }
        ]
        component.storeFunctionalUnits = selectedFunctionalUnits;
        component.selectFunctionalUnit(event,screenObject)
        expect(component.selectedFunctionalUnits.length).toEqual(1);
    });

    it('test selectFunctionalUnit event checked true empty selected functional unit list',()=>{
        let event : any={checked : true}
       
        let selectedFunctionalUnits:any[];
        let storeFunctionalUnits:any[]=[
            {
             "screenName": "COA"  
            }
        ]
        component.selectedFunctionalUnits = selectedFunctionalUnits;
        component.storeFunctionalUnits = storeFunctionalUnits;
        component.selectFunctionalUnit(event,screenObject)
        expect(component.selectedFunctionalUnits.length).toEqual(1);
    });

    it('test selectAllFunctionalUnits',()=>{
        let event : any={checked : true}
        component.functionalUnitsList = functionalUnitsList;
        component.selectAllFunctionalUnits(event);
        expect(component.isAllChecked).toBeTruthy();
     });

     it('test selectAllFunctionalUnits event false',()=>{
        let event : any={checked : false}
        component.selectAllFunctionalUnits(event);
        expect(component.isAllChecked).toBeFalsy();
        expect(component.deSelectAll).toBeTruthy();
     });

     it('test isFunctionalUnitChecked',()=>{  
        component.deSelectAll = false;
        component.bpVersionObj = new BestPracticeVersionObject();
        let storeFunctionalUnits:any[]=[
            {
                "screenName": "Account Definition"
            }
        ]
        let selectedFunctionalUnits:any[];
        component.selectedFunctionalUnits = selectedFunctionalUnits;
        component.storeFunctionalUnits = storeFunctionalUnits;
        let checked  = component.isFunctionalUnitChecked('Account Definition');
         expect(checked).toBeTruthy();
     });

     
     it('test isFunctionalUnitChecked for SelectAll',()=>{ 
        component.deSelectAll = true;
        component.bpVersionObj = new BestPracticeVersionObject();
        let checked  = component.isFunctionalUnitChecked('Account Definition');
        expect(checked).toBeFalsy();
     });

     it('test isAllFunctionalUnitChecked',()=>{ 
        component.bpVersionObj = new BestPracticeVersionObject();
        let storeFunctionalUnits:any[]=[
            {
                "screenName": "Account Definition" 
            }
        ]
        let selectedFunctionalUnits:any[];
        component.selectedFunctionalUnits = selectedFunctionalUnits;
        component.storeFunctionalUnits = storeFunctionalUnits;
        let checked  = component.isAllFunctionalUnitChecked(functionalUnitsList);
        expect(checked).toBeTruthy();
     });

     it('test getAllSSSFunctionalUnitsArtifacts',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(bestPracticeService,'getAllSSSFunctionalUnits').and.returnValue(Observable.of(master_functionalUnit_list));
        spyOn(component,'transformMaserFUToScreenObject');
        component.getAllSSSFunctionalUnitsArtifacts();  
     });

     it('test transformMaserFUToScreenObject',()=>{

        let screenList = component.transformMaserFUToScreenObject(master_functionalUnit_list);
        expect(screenList.length).toEqual(1);
        
    });

    it('loadData',()=>{
        let event : any={selectedIndex : 1}
        spyOn(component,'getAllSSSFunctionalUnitsArtifacts');
        component.loadData(event);
        expect(component.isButtonDisabled).toBeFalsy();
     });

     it('test saveBestPracticeVersion',()=>{
        component.isEdit = true;
        component.existingVersionName = "2021";
        component.bpVersionObj= bestPracticeVersionObject;
        spyOn(bestPracticeService,'getSSSBPByBestPracticeName').and.returnValue(Observable.of({}));
        spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.of(bpVersionList));
        component.saveBestPracticeVersion();
        expect(component.isButtonDisabled).toBeTruthy();
     });

     it('test saveBestPracticeVersion for Propagation false',()=>{

        let bpVersionList1: BestPracticeVersionObject[]=[
            {
              id : "123",
              recordType : "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
              versionName : "2021",
              active : true,
              objectType : "test",
              functionalAreaList : null,
              propagationStarted:false, 
            }
        ]
        component.isEdit = true;
        component.existingVersionName = "2021";
        component.bpVersionObj= bestPracticeVersionObject;
        spyOn(component,'callBestPracticeServiceBPVersionSave');
        spyOn(bestPracticeService,'getSSSBPByBestPracticeName').and.returnValue(Observable.of({}));
        spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.of(bpVersionList1));
        component.saveBestPracticeVersion();
        expect(component.isButtonDisabled).toBeFalsy();
     });

     it('test saveBestPracticeVersion version name are different',()=>{

        let bpVersionList1: BestPracticeVersionObject[]=[
            {
              id : "123",
              recordType : "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
              versionName : "2023",
              active : true,
              objectType : "test",
              functionalAreaList : null,
              propagationStarted:false, 
            }
        ]
        component.isEdit = true;
        component.existingVersionName = "2026";
        component.bpVersionObj= bestPracticeVersionObject;
        spyOn(component,'duplicateBpVersionCheckAndSave');
        spyOn(bestPracticeService,'getSSSBPByBestPracticeName').and.returnValue(Observable.of({}));
        spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.of(bpVersionList1));
        component.saveBestPracticeVersion();
        expect(component.isButtonDisabled).toBeFalsy();
     });

     it('test saveBestPracticeVersion for create',()=>{

        let bpVersionList1: BestPracticeVersionObject[]=[
            {
              id : "123",
              recordType : "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
              versionName : "2023",
              active : true,
              objectType : "test",
              functionalAreaList : null,
              propagationStarted:false, 
            }
        ]
        component.isEdit = false;
        component.existingVersionName = "2026";
        component.bpVersionObj= bestPracticeVersionObject;
        spyOn(component,'duplicateBpVersionCheckAndSave');
        spyOn(bestPracticeService,'getSSSBPByBestPracticeName').and.returnValue(Observable.of({}));
        spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.of(bpVersionList1));
        component.saveBestPracticeVersion();
        expect(component.isButtonDisabled).toBeFalsy();
     });

     it('test saveBestPracticeVersion best practice versions length empty',()=>{

        let bpVersionList1: BestPracticeVersionObject[]=[]
        component.bpVersionObj= bestPracticeVersionObject;
        spyOn(component,'callBestPracticeServiceBPVersionSave');
        spyOn(bestPracticeService,'getSSSBPByBestPracticeName').and.returnValue(Observable.of({}));
        spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.of(bpVersionList1));
        component.saveBestPracticeVersion();
        expect(component.isButtonDisabled).toBeFalsy();
     }); 

     it('test saveBestPracticeVersion throws error',()=>{

      let bpVersionList1: BestPracticeVersionObject[]=[]
      component.bpVersionObj= bestPracticeVersionObject;
      spyOn(component,'callBestPracticeServiceBPVersionSave');
      spyOn(bestPracticeService,'getSSSBPByBestPracticeName').and.returnValue(Observable.throwError('error'));
      component.saveBestPracticeVersion();
      expect(component.isButtonDisabled).toBeFalsy();
   }); 

      it('test validateNameFromDB',()=>{
        spyOn(bestPracticeService,'getSSSBPByBestPracticeName').and.returnValue(Observable.of({}));
        spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.of(bestPracticeVersionObjectList));
        component.validateNameFromDB('2021');
     });

     it('test duplicateBpVersionCheckAndSave',()=>{      
      let bestPracticeVersionObject:BestPracticeVersionObject={
        id : "123",
        recordType : "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
        versionName : "2021",
        active : true,
        objectType : "test",
        functionalAreaList : null,
        propagationStarted:false, 
    };
    component.bpVersionObj = bestPracticeVersionObject;
    component.duplicateBpVersionCheckAndSave(bpVersionList,"test");
    expect(component.isButtonDisabled).toBeTruthy();
 }); 

 it('test duplicateBpVersionCheckAndSave if duplicate BP Version Does not exist',()=>{      
  let bestPracticeVersionObject:BestPracticeVersionObject={
    id : "123",
    recordType : "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
    versionName : "2025",
    active : true,
    objectType : "test",
    functionalAreaList : null,
    propagationStarted:false, 
  };
  component.bpVersionObj = bestPracticeVersionObject;
  spyOn(component,'callBestPracticeServiceBPVersionSave');
  component.duplicateBpVersionCheckAndSave(bpVersionList,"test");
  expect(component.isButtonDisabled).toBeFalsy();
}); 

it('test closePopup',()=>{
  component.closePopup();
});


it('test callBestPracticeServiceBPVersionSave',()=>{

  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  component.currentBestPractice = currentBestPractice;
  spyOn(bestPracticeService,'saveSSSBestPracticeVersion').and.returnValue(Observable.of({}));
  component.callBestPracticeServiceBPVersionSave(bestPracticeVersionObject,screenObjectList);
});

});