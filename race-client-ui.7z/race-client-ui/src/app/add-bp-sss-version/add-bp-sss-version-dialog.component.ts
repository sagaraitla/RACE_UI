import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';

import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';

import { TemplateObject } from '../model/template-object';
import { BestPracticeObject } from '../model/bestpractice-object';
import { AuthService } from '../services/auth-service';
import { BestPracticeService } from '../services/bestpractice-service';
import { BestPracticeVersionObject } from '../model/bestpractice-version-object';
import { ScreenObject } from '../model/screen-object';
import { MasterFunctionalUnit } from '../model/master-functional-unit';
import { Constants } from '../constant/constants';
import { ToastrService } from 'ngx-toastr'; 

@Component({
	selector: 'app-add-sss-bp-version-dialog',
	templateUrl: './add-bp-sss-version-dialog.component.html',
	styleUrls: ['./add-bp-sss-version-dialog.component.css']
})

export class AddBPSSSVersionComponent {

	firstFormGroup: FormGroup;
	secondFormGroup: FormGroup;
	allTemplates = [];
	genericTemplates = [];
	storeFunctionalUnits = [];
	functionalUnitsList = [];
	usersList = [];
	vicUsersList = [];
	secondaryVicUsersList = [];
	selectedFunctionalUnits = [];
	allowOemSelection = false;
	bpVersionObj: BestPracticeVersionObject = new BestPracticeVersionObject();
	currentBestPractice: BestPracticeObject = new BestPracticeObject();
	templateType: string = '';
	isEdit = false;
	isFUSetForFirstTime = false;
	dialogLabel: string = 'Add Version';
	loaderDialogRef: any;
	templateObj: TemplateObject = new TemplateObject();
	isAllChecked: boolean = false;
	deSelectAll: boolean = false;
	isButtonDisabled:boolean = false;
	existingVersionName:string;
	
	constructor(private bestPracticeService: BestPracticeService, private dialogRef: MatDialogRef<AddBPSSSVersionComponent>, private authService: AuthService,
		private _formBuilder: FormBuilder, @Inject(MAT_DIALOG_DATA) private data: any, private dialog: MatDialog, private toastrService: ToastrService,
	    private router: Router) {
		dialogRef.disableClose = true;
	}

	ngOnInit() {

		this.loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
			width: '300px',
			height: '150px',
			data: { message: "Fetching version information" }
				});   

		this.firstFormGroup = this._formBuilder.group({
			versionName: ['', Validators.required],
		});

		this.secondFormGroup = this._formBuilder.group({
			secondCtrl: ''
		});

		this.currentBestPractice = JSON.parse(JSON.stringify(this.data.project));
		if (this.data.bpVersionName) {
			this.isEdit = true;
			this.dialogLabel = this.isEdit ? 'Edit Version' : 'Add Version';
			this.existingVersionName = this.data.bpVersionName;
			this.bestPracticeService.getVersionsByBestPracticeId(this.currentBestPractice.id, true).subscribe(bpVersionList => this.setVersionForEdit(bpVersionList));
		}else{
			this.loaderDialogRef.close();
		}
	};

	setVersionForEdit(bpVersionList: BestPracticeVersionObject[]) {
		bpVersionList.forEach(bpVersion => {
			if (bpVersion.versionName === this.data.bpVersionName) {
				this.bpVersionObj = bpVersion;
				this.bestPracticeService.getSSSFunctionalUnitsOfBpVersion(this.bpVersionObj.recordType, true).subscribe(functionalUnits => {
					this.storeFunctionalUnits = functionalUnits;
					this.loaderDialogRef.close();
				});
			}
		});
	}

	checkActiveVersion(event: any) {
		if (event.checked) {
			this.bpVersionObj.active = true;
			this.toastrService.warning('If this version is marked as Active, existing Active Version, if any, will be marked as Inactive');
		}

		else {
			this.bpVersionObj.active = false;
		}
	}

	selectFunctionalUnit(event: any, functionalUnit: ScreenObject) {
		this.isFUSetForFirstTime = true;			
		if (event.checked) {
			if (!Array.isArray(this.selectedFunctionalUnits)) {
				this.selectedFunctionalUnits = [];
			}
			let funUnitList = this.storeFunctionalUnits.filter(function (funUnit) { return funUnit.screenName === functionalUnit.screenName; });
			if (funUnitList.length > 0) {
				this.selectedFunctionalUnits.push(funUnitList[0]);
			} else {
				this.selectedFunctionalUnits.push(functionalUnit);
			}
		} else {
			let deleteFunctionalUnits = this.selectedFunctionalUnits.filter(function (funUnit) { return funUnit.screenName === functionalUnit.screenName; });
			if (deleteFunctionalUnits.length > 0) {
				this.selectedFunctionalUnits.splice(this.selectedFunctionalUnits.indexOf(deleteFunctionalUnits[0]), 1);
			}
		}
	
	}


	selectAllFunctionalUnits(event) {
		if(event.checked){
			this.isAllChecked = true;
			this.selectedFunctionalUnits = [];
			this.functionalUnitsList.forEach(funUnit => 
				this.selectedFunctionalUnits.push(funUnit));
		}
		else if(!event.checked){
			this.isAllChecked = false;	
			this.selectedFunctionalUnits = [];
			this.deSelectAll = true;
		}
	  }

	saveBestPracticeVersion() {
		let existFlag = false;
		let currentVersionName = "";
		this.loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
			width: '300px',
			height: '150px',
			data: { message: 'Saving Best Practice Version.' }
		});
		this.bestPracticeService
			.getSSSBPByBestPracticeName(this.currentBestPractice.bestPracticeName, true)
			.subscribe(data => {
				this.bestPracticeService.getVersionsByBestPracticeId(data.id, true)
					.subscribe(bpVersions => {
						if(bpVersions.length !== 0 ) {
							if(this.isEdit){ //For edit section 
								if(this.bpVersionObj.versionName === this.existingVersionName){ //Version Name not modified in edit
									bpVersions.filter(bpVersion => bpVersion.versionName === this.bpVersionObj.versionName).forEach(bpVersion => {
										this.bpVersionObj.propagationStarted = bpVersion.propagationStarted;
										if(bpVersion.propagationStarted){
											this.toastrService.error('Best Practice Version '+this.bpVersionObj.versionName+' Change Propagation is underway. No modifications can take place at this time. Please try later');
											this.loaderDialogRef.close();
											this.isButtonDisabled = true;
										}else{
											this.callBestPracticeServiceBPVersionSave(this.bpVersionObj, this.selectedFunctionalUnits);
										}
									});
									
								}else{ // Version name modified in edit section
									//Duplicate version check and save the version
									this.duplicateBpVersionCheckAndSave(bpVersions,data.bestPracticeName);
								}
							}else{ // For New Bp Version 
								//Duplicate version check and save the version
								this.duplicateBpVersionCheckAndSave(bpVersions,data.bestPracticeName);
							}
						   }
						else {
							this.callBestPracticeServiceBPVersionSave(this.bpVersionObj, this.selectedFunctionalUnits);               
						}
					});
			},
				error => {
					this.toastrService.error("got error" + error);
					this.loaderDialogRef.close();
				});
	}

	callBestPracticeServiceBPVersionSave(bestPracticeVersionObject: BestPracticeVersionObject, selectedFunctionalUnits: ScreenObject[]) {
		this.bpVersionObj.id = this.currentBestPractice.id;
		this.bestPracticeService.saveSSSBestPracticeVersion(bestPracticeVersionObject, selectedFunctionalUnits)
			.subscribe(storeData => {
				this.loaderDialogRef.close();
				this.dialogRef.close();
			});
	}


	closePopup() {
		this.dialogRef.close(Constants.POPUP_CANCEL);
	};

	validateNameFromDB(versionName: string) {
		let existFlag = false;
		this.bestPracticeService
			.getSSSBPByBestPracticeName(this.currentBestPractice.bestPracticeName, false)
			.subscribe(data => {
				this.bestPracticeService.getVersionsByBestPracticeId(this.currentBestPractice.id, true).subscribe(bpVersions => {
					bpVersions.forEach((bpVersion, index) => {
						if (bpVersion.versionName === versionName) {
							existFlag = true;
							this.toastrService.error('Version with Name ' + versionName + ' already exists!');
							this.toastrService.error("Best Practice Version with name " + versionName + " already exists!!!!");
						}
					});
				});
			});

	}

	isFunctionalUnitChecked(functionalUnitName: string) {
		 let checked = false;
		 if (this.bpVersionObj) {
			if(this.deSelectAll){
				return false;
			 }
			let templateList = this.storeFunctionalUnits.filter(function (funUnit) { return funUnit.screenName === functionalUnitName; });
			checked = templateList.length > 0;
			if (checked) {
				if (!Array.isArray(this.selectedFunctionalUnits)) {
					this.selectedFunctionalUnits = [];
				}
				let tmplts = this.selectedFunctionalUnits.filter(function (tmpl) { return tmpl.screenName === functionalUnitName; });
				if (tmplts.length == 0 && !this.isFUSetForFirstTime) {
					this.selectedFunctionalUnits.push(templateList[0]);
				}
			}
		}
		return checked;
	}

	
	isAllFunctionalUnitChecked(functionalUnitsList) {
		let checked = false;
		let checkedCount = 0;
	    for(var i = 0; i < functionalUnitsList.length;i++){
			if (this.bpVersionObj) {
				let templateList = this.storeFunctionalUnits.filter(function (funUnit) { return funUnit.screenName === functionalUnitsList[i].screenName; });
				if(templateList.length > 0)
					checkedCount++;			
				if (checkedCount > 0) {
					if (!Array.isArray(this.selectedFunctionalUnits)) {
						this.selectedFunctionalUnits = [];
					}
				}
			}
		}
		if(checkedCount == functionalUnitsList.length)
			checked = true;
 		return checked;
   }

	loadData(event) {

		if (event.selectedIndex == 1) {
			this.getAllSSSFunctionalUnitsArtifacts();
			this.isButtonDisabled = false;
		}
	}

	getAllSSSFunctionalUnitsArtifacts() {
		if (this.allTemplates.length === 0) {
			let dialogRef = this.dialog.open(LoaderDialogueComponent, {
				width: '300px',
				height: '150px',
				data: { message: 'Fetching SSS functional units.' }
			});
			this.bestPracticeService.getAllSSSFunctionalUnits('SSS', false).subscribe(
				functionalUnitArtifacts => {
					if (functionalUnitArtifacts != null) {
						this.functionalUnitsList = this.transformMaserFUToScreenObject(functionalUnitArtifacts);
					}
					dialogRef.close();
				}
			);
		}
	}

	

	transformMaserFUToScreenObject(masterFunctionalUnit: MasterFunctionalUnit[]): ScreenObject[] {
		let screenList: ScreenObject[] = [];
		let tempScreenObj: ScreenObject;
		masterFunctionalUnit.forEach(masterFU => {
			tempScreenObj = new ScreenObject();
			tempScreenObj.screenName = masterFU.functionalUnitName;
			tempScreenObj.gridOptionsModel = masterFU.gridOptionsModel;
			tempScreenObj.description = masterFU.description;
			tempScreenObj.version = masterFU.version;
			tempScreenObj.productCode = masterFU.productCode;
			tempScreenObj.id = masterFU.id;
			tempScreenObj.recordType = masterFU.recordType;
			screenList.push(tempScreenObj);

		});
		return screenList;
	}

	duplicateBpVersionCheckAndSave(bpVersions:BestPracticeVersionObject[],bestPracticeName:string){
		const result = bpVersions.filter(bpVersionFromDB => bpVersionFromDB.versionName === this.bpVersionObj.versionName);
		if(result != undefined && result.length>0){
			this.toastrService.error("Best Practice Version with name "+ this.bpVersionObj.versionName+" already exists!!!!");
			this.loaderDialogRef.close();
			this.isButtonDisabled = true;
		}else{
			this.callBestPracticeServiceBPVersionSave(this.bpVersionObj, this.selectedFunctionalUnits);
		}
	  }
}