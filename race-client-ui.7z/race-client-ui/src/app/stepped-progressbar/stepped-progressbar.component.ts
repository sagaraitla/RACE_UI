import  {Component, Inject, Input, ChangeDetectionStrategy, OnChanges, SimpleChanges } from '@angular/core';

@Component({
	  selector: 'stepped-progressbar',
	  templateUrl: './stepped-progressbar.component.html',
	  styleUrls: ['./stepped-progressbar.component.css'],
	  changeDetection: ChangeDetectionStrategy.OnPush

})

export class SteppedProgressbarComponent implements OnChanges {

  message: string;
  @Input() statusList: string[];
  @Input() status : string;
  activeIdx: number;
  @Input() firstStepLeftMarginInPercent: string;
  @Input() lastStepRightMarginInPercent: string;

  constructor() {
  }
  
  ngOnInit() {
  }
  
  ngOnChanges(changes: SimpleChanges) {
	  this.activeIdx = this.statusList.indexOf(changes.status.currentValue);
  }
}