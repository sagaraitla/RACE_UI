import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog,MatDialogRef } from '@angular/material';
import { NewFunctionalAreaComponent } from '../new-functional-area/new-functional-area.component';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { AuthService } from '../services/auth-service';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { MasterFunctionalAreaService } from '../services/master-functional-area-service';
import { MasterFunctionalArea } from '../model/master-functional-area';
import { Constants } from '../constant/constants';
import { platform } from 'os';
import { ToastrService } from 'ngx-toastr';
import { GenericResponse } from '../model/generic-response';


@Component({
  selector: 'app-existing-functional-area',
  templateUrl: './existing-functional-area.component.html',
  styleUrls: ['./existing-functional-area.component.css']
})
export class ExistingFunctionalAreaComponent implements OnInit {
	
	createFunctionalAreaPermission : boolean = false;
    deleteFunctionalAreaPermission : boolean = false;
	dataSource : any;
    filter : any;
	displayedColumns = ['functionalAreaName', 'productCode', 'platforms', 'actions'];
	@ViewChild(MatPaginator,{static: false}) paginator: MatPaginator;
    @ViewChild(MatSort,{static: false}) sort: MatSort;
    
    constructor(private router:Router, private dialog:MatDialog, private functionalAreaService: MasterFunctionalAreaService, 
    		private authService: AuthService,private toastrService : ToastrService){
    }
    
	ngOnInit() {
       this.filter = ''; 
       let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
              width: '300px',
              height: '150px',
              data: { message: 'Fetching Functional Areas ..' }
        });
       
        this.authService.fetchLoggedInUserAndPermissions().subscribe((data: any) => {
            this.createFunctionalAreaPermission = this.authService.isAuthorised('DOT_TEMPLATE_CREATE');
            this.deleteFunctionalAreaPermission = this.authService.isAuthorised('DOT_TEMPLATE_DELETE');
            
        	this.functionalAreaService.fetchMasterFunctionalAreaList().subscribe(functionalAreas => {
                this.dataSource=new MatTableDataSource<MasterFunctionalArea>(functionalAreas);
                this.dataSource.filterPredicate = function(data, filter: string): boolean {
                    return (data.functionalAreaName && data.functionalAreaName.toLowerCase().includes(filter))
                    || (data.productCode && data.productCode.toLowerCase().includes(filter))
                    || (JSON.stringify(data.platforms) && JSON.stringify(data.platforms).toLowerCase().includes(filter));
                };
        		this.dataSource.sortingDataAccessor = (item, property) => {
	                switch(property) {
	                	case 'functionalAreaName': return item.functionalAreaName ? item.functionalAreaName.toLowerCase(): item;
                        case 'productCode': return item.productCode ? item.productCode.toLowerCase(): item;
                        case 'platforms': return item.platforms[0].platformName ? item.platforms[0].platformName.toLowerCase(): item;
	                	default: return item[property];
	                }
        		};     
        		this.dataSource.paginator = this.paginator;
        		this.dataSource.sort = this.sort;
        		loaderDialogRef.close();
        	});
	    });	
	}
    
    openDialogToCreateEditCloneFunctionalArea(functionalArea : any, isClone: boolean) {
    	let data = {};
    	if(functionalArea) {
    		data['functionalArea'] = functionalArea;
    		let fieldName = isClone ? 'clone' : 'edit'; 
    		data[fieldName] = true;
    	}
    	let dialogRef=this.dialog.open(NewFunctionalAreaComponent,{
    		width :'80%',
  		  	height :'90%',
  		  	data : data
            });
            
  	dialogRef.afterClosed().subscribe(result=>{
            this.ngOnInit();
  	  	});
    }
	
	applyFilter(filterValue: string) {
        filterValue = filterValue.trim(); 
        filterValue = filterValue.toLowerCase(); 
        this.dataSource.filter = filterValue;
    }
	
	gotoDashboard() {
       this.router.navigateByUrl('dashboard');
    }
    
    deleteFunctionalArea(functionalArea: MasterFunctionalArea) {
        this.functionalAreaService.getMasterFunctionalAreaById(functionalArea.id).subscribe(genericResponse=>{
            if(genericResponse != null && genericResponse != undefined && genericResponse.resultDescription == "OK" 
                   && genericResponse.resultDescription != null){
                functionalArea = genericResponse.resultObj;

                if(!functionalArea.propagationStarted){
                    let confirmDialogRef = this.dialog.open(ConfirmDialogComponent, {
                        width: '300px',
                        height: '160px',
                        data: { message: 'Are you sure you want to delete this Functional Area ?' }
                    });
                    confirmDialogRef.afterClosed().subscribe(result => {
                        if (result) {
                            let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
                                width: '300px',
                                height: '150px',
                                data: { message: 'Deleting Functional Area..' }
                            });
                            this.functionalAreaService.deleteMasterFunctionalArea(functionalArea).subscribe((data: any) => {
                                loaderDialogRef.close();
                                this.ngOnInit();
                            });
                        }
                    });  
                }else{
                    this.toastrService.error('Functional Area '+functionalArea.functionalAreaName+' Change Propagation is underway. No modifications can take place at this time. Please try later');
                }   
               
            }
        })
    }
}
