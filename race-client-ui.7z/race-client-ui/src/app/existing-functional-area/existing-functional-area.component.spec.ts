import { CdkTableModule } from '@angular/cdk/table';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatFormFieldModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatTableDataSource, MatTableModule, MatTabsModule } from '@angular/material';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { MasterFunctionalArea } from '../model/master-functional-area';
import { AuthService } from '../services/auth-service';
import { MasterFunctionalAreaService } from '../services/master-functional-area-service';
import { ExistingFunctionalAreaComponent } from './existing-functional-area.component';
import { of } from 'rxjs';
import { FunctionalAreaService } from '../services/functional-area-service';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { NewFunctionalAreaComponent } from '../new-functional-area/new-functional-area.component';
import { CommonModule } from '@angular/common';
import { MasterFunctionalUnitService } from '../services/master-functional-unit-service';

describe('ExistingFunctionalAreaComponent', () => {

    let component : ExistingFunctionalAreaComponent;
    let fixture: ComponentFixture<ExistingFunctionalAreaComponent>;
    let authService: AuthService;
    let masterFunctionalAreaService: MasterFunctionalAreaService;
    let router : Router;

    class MatDialogMock {
      open() {
        return {
          afterClosed: () => Observable.of(true)
        };
      }
    };

    const testUrl = 'dashboard';
    beforeEach(async(() => {

        let mockRouter = {
           navigate: jasmine.createSpy('navigateByUrl')
       } 

       const masterFunctionalAreaServiceSpy = jasmine.createSpyObj('MasterFunctionalAreaService', 
       ['fetchMasterFunctionalAreaList','deleteMasterFunctionalArea']);

        TestBed.configureTestingModule({
          imports: [
            MatCardModule,
            FormsModule,
            MatFormFieldModule,
            MatInputModule,
            CdkTableModule,
            MatMenuModule,
            MatTableModule,
            MatPaginatorModule,
            MatDialogModule,
            HttpClientTestingModule,
            ToastrModule.forRoot(),
            NoopAnimationsModule,
            MatProgressSpinnerModule ,
            ReactiveFormsModule,
            CommonModule,
            MatSelectModule,
            MatRadioModule,
            MatCheckboxModule],
          declarations: [ ExistingFunctionalAreaComponent,LoaderDialogueComponent,ConfirmDialogComponent,NewFunctionalAreaComponent],
          providers:[
           MasterFunctionalAreaService,
           MasterFunctionalUnitService,
           AuthService,
           ToastrService,{ provide: Router, useValue: {url:testUrl} }
          ]
        }).overrideModule(BrowserDynamicTestingModule,
           { set: { entryComponents: [LoaderDialogueComponent,ConfirmDialogComponent,NewFunctionalAreaComponent]}});

            authService = TestBed.get(AuthService);
            masterFunctionalAreaService = TestBed.get(MasterFunctionalAreaService);
      }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ExistingFunctionalAreaComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();

    });
    
    const list_of_master_functional_are_response: MasterFunctionalArea[] =[
      {
          "functionalAreaType": "MasterFunctionalArea",
          "functionalAreaName": "FATestToday",
          "oemName": null,
          "platforms": [
            {
              "id": null,
              "platformName": "FLEX",
              "platformCode": "flex",
              "selected": true,
              "recordType":null

            }
          ],
          "productCode": "ACCT",
          "productVersion": "1",
          "noOfFunctionalUnits": null,
          "version": "0",
          "propagationStarted": false,
          "id": "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
          "recordType": "FunctionalAreaInfo"
        }
  ]  

const master_functional_area:any={
  
    "resultCode": "CDK_200",
    "resultDescription": "OK",
    "resultObj": {
      "functionalAreaType": "MasterFunctionalArea",
      "functionalAreaName": "5nov1",
      "oemName": null,
      "platforms": [
        {
          "id": null,
          "platformName": "FLEX",
          "platformCode": "flex",
          "selected": true
        }
      ],
      "version": 0,
      "productCode": "PTS",
      "productVersion": "11",
      "propagationStarted": false,
      "id": "40a4a74b-5296-4dea-b109-214f718ea6f6",
      "recordType": "FunctionalAreaInfo"
    },
    "executionTime": 431
}


  const master_functional_are_response: MasterFunctionalArea ={

    "functionalAreaType": "MasterFunctionalArea",
    "functionalAreaName": "UI_Test",
    "oemName": null,
    "platforms": [
      {
        "id": null,
        "platformName": "DRIVE",
        "platformCode": "drive",
        "selected": true,
        "recordType":null
      }
    ],
    "version": "0",
    "productCode": "SVC",
    "productVersion": "11",
    "propagationStarted": false,
    "noOfFunctionalUnits": null,
    "id": "ac27a733-e109-40c4-b15f-5f2909c6ff4c",
    "recordType": "FunctionalAreaInfo"
}

    it('should create ExistingFunctionalAreaComponent ', async(() => {

      let filter:string = 'FATestToday';
      let data:{

      }
      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
      dialogRefSpyObj.componentInstance = { body: '' };
      dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data))
        spyOn(authService,'isAuthorised').and.returnValue(Observable.of(false));
        spyOn(masterFunctionalAreaService,'fetchMasterFunctionalAreaList').and.returnValue(Observable.of(list_of_master_functional_are_response));
        fixture.detectChanges();
        component.ngOnInit();
        expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(1);
        expect(authService.isAuthorised).toHaveBeenCalledTimes(2);
        expect(component).toBeTruthy();
      }));  


      it('test deleteFunctionalArea',()=>{

        spyOn(masterFunctionalAreaService,'getMasterFunctionalAreaById').and.returnValue(Observable.of(master_functional_area));

        spyOn(masterFunctionalAreaService,'deleteMasterFunctionalArea').and.returnValue(Observable.of({}));

         let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        component.deleteFunctionalArea(master_functional_area);

      });

      it('test deleteFunctionalArea for FA that that started Propagation ',()=>{

        const master_functional_area_propagation:any = {
  
          "resultCode": "CDK_200",
          "resultDescription": "OK",
          "resultObj": {
            "functionalAreaType": "MasterFunctionalArea",
            "functionalAreaName": "5nov1",
            "productCode": "PTS",
            "productVersion": "11",
            "propagationStarted": true,
            "id": "40a4a74b-5296-4dea-b109-214f718ea6f6",
            "recordType": "FunctionalAreaInfo"
          },
          "executionTime": 431
      }
        spyOn(masterFunctionalAreaService,'getMasterFunctionalAreaById').and.returnValue(Observable.of(master_functional_area_propagation));

        spyOn(masterFunctionalAreaService,'deleteMasterFunctionalArea').and.returnValue(Observable.of({}));

         let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        component.deleteFunctionalArea(master_functional_area_propagation);

        expect(masterFunctionalAreaService.getMasterFunctionalAreaById).toHaveBeenCalledTimes(1);
        expect(masterFunctionalAreaService.deleteMasterFunctionalArea).toHaveBeenCalledTimes(0);

      });

      it('test openDialogToCreateEditCloneFunctionalArea',()=>{
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        component.openDialogToCreateEditCloneFunctionalArea(master_functional_area,false);
      });

      it('test applyFilter',()=>{
        component.dataSource= new MatTableDataSource<MasterFunctionalArea>(list_of_master_functional_are_response); 
        component.applyFilter("Test");
        expect(component.dataSource.filter).toEqual('test');
 
       });
      
}); 