import { Component,Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

@Component({
  selector: 'app-multivalue-dropdown-dialog',
  templateUrl: './multivalue-dropdown-dialog.component.html',
  styleUrls: ['./multivalue-dropdown-dialog.component.css']
})
export class MultivalueDropdownDialogComponent {
  selectedValues : string[]=[];
  values : string [] =[];
  result : string = "";

  constructor(
    public dialogRef: MatDialogRef<MultivalueDropdownDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;
	  this.values=data.values;   
	  this.selectedValues=data.fieldId.split(",");
	  dialogRef.disableClose = true;
    }

  onOkClick(): void {
	  this.result=this.selectedValues.toString();
      this.dialogRef.close(this.result);
  }

    onClose(result : string) : any {
      return result;      
    }

}
