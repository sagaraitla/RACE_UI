import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialogModule, MatDialogRef, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatSelectModule, MatSortModule, MAT_DIALOG_DATA } from "@angular/material";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule } from "ngx-toastr";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { AuthService } from "../services/auth-service";
import { MultivalueDropdownDialogComponent } from "./multivalue-dropdown-dialog.component";


describe('MultivalueDropdownDialogComponent',() => {

    let component : MultivalueDropdownDialogComponent;
    let fixture : ComponentFixture<MultivalueDropdownDialogComponent>;

    const dialogMock = {close: () => { }};
    beforeEach(async(() =>{

        const testUrl  = 'dashboard';
        let data= {
            values:['value1', 'value2', 'value3'],
            fieldId:"12,3"
        }
        TestBed.configureTestingModule({
           imports: [
                MatCardModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatPaginatorModule,
                MatDialogModule,
                ToastrModule.forRoot(),
                CommonModule,
                MatSelectModule,
                MatCheckboxModule,
                MatSortModule,
                MatIconModule,
                FormsModule,
                MatMenuModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                SortableModule,
                MatSortModule
            ],
            declarations : [MultivalueDropdownDialogComponent,LoaderDialogueComponent],
            providers : [
                AuthService,
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: dialogMock},
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent]}});
      }));

      beforeEach(() => {
        fixture = TestBed.createComponent(MultivalueDropdownDialogComponent);
        component = fixture.componentInstance;
        expect(component).toBeTruthy();
    });


    it('test onClose',()=>{
       let result = component.onClose('test');
       expect(result).toEqual('test');
    });

    it('test onOkClick',()=>{
        component.onOkClick();
    });

});