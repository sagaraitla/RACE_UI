import { Component, Inject, ViewChild } from '@angular/core';
import { AmazonS3LogsService } from '../services/amazonS3Logs-service';
import { GenericResponse } from '../model/generic-response';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar, MatTableDataSource , MatSort} from '@angular/material';
import { AuditLogsVTObject } from '../model/audit-logsvt-object';
import { Router } from '@angular/router';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'app-fetch-s3log-content',
    templateUrl: './fetch-s3log-content.html',
    styleUrls: ['./fetch-s3log-content.css']
})

export class AuditLogsS3LogContent {

    auditLogVT : AuditLogsVTObject; 
    content: any;
    fileName : string;
    displayName:string;

    constructor(private amazonS3LogService: AmazonS3LogsService, private dialogRef: MatDialogRef<AuditLogsS3LogContent>,
        @Inject(MAT_DIALOG_DATA) private data: any,  private dialog: MatDialog, private amazonS3LogsService: AmazonS3LogsService, private router:Router, private toastrService: ToastrService){
            dialogRef.disableClose = true;
          this.auditLogVT = JSON.parse(JSON.stringify(this.data.auditLogVT));
          this.displayName = this.data.displayName;
    }
    ngOnInit(){
        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
            width: '300px',
            height: '150px',
            data: { message: 'Fetching file contents...' }
      });
        this.fileName = this.data.fileName;
        this.amazonS3LogsService.readFileContentFromS3Bucket(this.auditLogVT.s3LogsPath,this.fileName)
        .subscribe(fileContent => {
            this.content = fileContent;
           loaderDialogRef.close();
        },error => {
            this.toastrService.error('Error while fetching the data ' + error.error.message);
            loaderDialogRef.close();
        }
        );
    }

    closeDialog() {
        this.dialogRef.close();
    };
    
}
