import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialogModule, MatDialogRef, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatSelectModule, MatSortModule, MAT_DIALOG_DATA } from "@angular/material";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { Observable } from 'rxjs';
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { AmazonS3LogsService } from '../services/amazonS3Logs-service';
import { AuthService } from "../services/auth-service";
import { AuditLogsS3LogContent } from './fetch-s3log-content.component';

describe('AuditLogsS3LogContent',() => {
    let component : AuditLogsS3LogContent;
    let fixture : ComponentFixture<AuditLogsS3LogContent>;
    let amazonS3LogService: AmazonS3LogsService;
    let content : any;

    const dialogMock = {close: () => { }};
    beforeEach(async(() =>{

        const testUrl  = 'dashboard';
        let data= {
            displayName:"test",
            auditLogVT:{
                id : "9ebc3dcf-ba8b-41e5-b566-d4fb978c1843",
                recordType : "ValidateTransferInfo",
                objectType : "ValidateTransfer",
                date : null,
                objectIdentifier: "889524:Certified Select Motors:Accounting",
                user : "System",
                event : "Validation Failed",
                s3Source : "Dot/SetupsValidate/C208001/889524/Certified Select Motors/ACCT.json",
                pvrresultsPresent : false,
                s3LogsPath : null
            }
        }
        TestBed.configureTestingModule({
           imports: [
                MatCardModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatPaginatorModule,
                MatDialogModule,
                ToastrModule.forRoot(),
                CommonModule,
                MatSelectModule,
                MatCheckboxModule,
                MatSortModule,
                MatIconModule,
                FormsModule,
                MatMenuModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                SortableModule,
                MatSortModule
            ],
            declarations : [AuditLogsS3LogContent,LoaderDialogueComponent],
            providers : [
                AmazonS3LogsService,
                AuthService,
                ToastrService,{ provide: Router, useValue: {url:testUrl} },
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: dialogMock},
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent]}});

            amazonS3LogService = TestBed.get(AmazonS3LogsService);
      }));

      beforeEach(() => {
        fixture = TestBed.createComponent(AuditLogsS3LogContent);
        component = fixture.componentInstance;
        expect(component).toBeTruthy();
    });

      it("test ngOnInit",()=>{
          let fileContent ={fileName:"TestFile"}
          spyOn(amazonS3LogService,'readFileContentFromS3Bucket').and.returnValue(Observable.of({fileContent}));
          fixture.detectChanges();
          expect(component.content.fileContent.fileName).toEqual("TestFile");
      })
      
      it("test closeDialog",()=>{
        spyOn(component['dialogRef'], "close");
        component.closeDialog();
        expect(component['dialogRef'].close).toHaveBeenCalledTimes(1);
    });
    
});