import { Component, OnInit, ViewChild } from '@angular/core';

import {BestPracticeService} from '../services/bestpractice-service';
import { DataTransferService } from '../services/data-transfer-service';
import { AuthService } from '../services/auth-service';
import { Router } from '@angular/router';
import {BestPracticeObject} from '../model/bestpractice-object';
import { PlatformObject } from '../model/platform-object';
import { MatPaginator, MatTableDataSource, MatSort , MatRadioChange } from '@angular/material';
import { MatDialog, MatDialogRef } from '@angular/material';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { LaunchDarklyService } from '../services/launchdarkly-service';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { Constants } from '../constant/constants';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-bestpractice-maintenance',
  templateUrl: './bestpractice-maintenance.component.html',
  styleUrls: ['./bestpractice-maintenance.component.css']
})
export class BestPracticeMaintenanceComponent implements OnInit {
    
    @ViewChild(MatPaginator,{static: false}) paginator: MatPaginator;
    
    @ViewChild(MatSort,{static: false}) sort: MatSort;
    
    dataSource : any;
    dotUsersList = {};
    createBPPermission = false;

    loggedInUser: string;
    showSelectedProject = false;
    emptyStoreIdsList: string[] = [];
    cdkInternalUser : boolean = false;
    nothingTOShow : boolean = false;
    showOpenProject: boolean = true;

    bestPracticeType: string;
    bestPracticeTypes: string[] ;
    sssBpTypeSelected: boolean = false;
    stateStandardFlagStatus : any;
    deleteBPPermission : boolean = false;
    loaderDialogRef: any;
    constructor(private bestPracticeService: BestPracticeService, private dataTransferService: DataTransferService, 
           private authService: AuthService, private router: Router, private dialog: MatDialog,private launchDarklyService : LaunchDarklyService, private toastrService: ToastrService) { 
           this.bestPracticeTypes=Constants.BESTPRACTICE_TYPES;
          }

    displayedColumns = ['bestPracticeName', 'platform.platformName', 'actions'];
  
    ngOnInit() {
    	
    	if (typeof this.bestPracticeType == 'undefined' || this.bestPracticeType == null) {
    		 this.bestPracticeType = 'OEM';
    	}
        
        this.authService.fetchLoggedInUserAndPermissions().subscribe((data: any) => {
	    	    this.createBPPermission = this.authService.isAuthorised('DOT_ADMIN');
	    	    this.deleteBPPermission = this.authService.isAuthorised('DOT_ADMIN');
	            this.loggedInUser = this.authService.getLoggedInUsersLoginId();
	            this.fetchAllBestPractices(this.bestPracticeType);
            	this.cdkInternalUser = this.authService.isCDKInternalUser();
            });

      this.stateStandardFlagStatus = this.launchDarklyService.flags['race-sales-state-standards'];
      if(this.stateStandardFlagStatus.current != undefined && this.stateStandardFlagStatus.current != null){
        this.stateStandardFlagStatus = this.stateStandardFlagStatus.current;
      }
      this.launchDarklyService.flagChange.subscribe((flags) => {
        this.stateStandardFlagStatus = flags['race-sales-state-standards'].current;
        this.resetBpType();
      });
      this.resetBpType();
    }

    bestPracticeChange(event: MatRadioChange){
      this.bestPracticeType = event.value;
      if(event.value !== 'OEM'){
        this.displayedColumns = ['bestPracticeName', 'actions'];
      }
      (event.value == 'OEM') ? this.sssBpTypeSelected = false : this.sssBpTypeSelected = true;
      this.fetchAllBestPractices(this.bestPracticeType);
    }
    
    fetchAllBestPractices(bestPracticeType:string) {
        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
          width: '400px',
          height: '150px',
          data: { message: 'Fetching '+bestPracticeType+' Best Practice details ..' }
        });
        this.bestPracticeService.getAllBestPracticesByType(bestPracticeType, true)
            .subscribe(data => {
               data.forEach(bestPractice => {
                      
                      if(!bestPractice.platform) {
                        bestPractice.platform = new PlatformObject();
                      }
                 });
                 
               this.dataSource =  new MatTableDataSource<BestPracticeObject>(data);
               if(bestPracticeType === 'OEM'){
                     this.dataSource.filterPredicate = (data: any, filter) => {
                     const dataStr =JSON.stringify(data).toLowerCase();
                     return dataStr.indexOf(filter) != -1; 
                   }
                     this.dataSource.filterPredicate = function(data, filter: string): boolean {
                       return (data.bestPracticeName && data.bestPracticeName.toLowerCase().includes(filter))
                        || (data.platform.platformName && data.platform.platformName.toLowerCase().includes(filter));
                      };   
                }
                  if(bestPracticeType !== 'OEM'){
                     this.dataSource.filterPredicate = function(data, filter: string): boolean {
                    return data.bestPracticeName.toLowerCase().includes(filter)
                  }; 
                }
               this.nothingTOShow = data.length == 0;
               this.dataSource.sortingDataAccessor = (item, property) => {
                switch(property) {
                  case 'bestPracticeName': return item.bestPracticeName;  
                  case 'platform.platformName': return item.platform.platformName;
                  default: return item[property];
                }
              };
               this.paginator.pageIndex = 0;
               this.dataSource.paginator = this.paginator;
               this.dataSource.sort = this.sort;
               loaderDialogRef.close();
        },
        error =>{
            this.toastrService.warning("Something went wrong...");
            loaderDialogRef.close();    
        });
    }
    
    newBestPractice() {
      this.router.navigateByUrl('bestpractice/create');
    }
    
    applyFilter(filterValue: string) {
            filterValue = filterValue.trim(); // Remove whitespace
            filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
            this.dataSource.filter = filterValue;
    }
   
    getBestPractice(bestpracticeName : string, platformCode : string) {
      if(this.sssBpTypeSelected){
        this.router.navigate(['bestPractice/stateStandard/' +  bestpracticeName+'/true'])
      } else {
        this.router.navigate(['bestpractice/getOne/' +  bestpracticeName + '/' + platformCode]);
      }
    }

    resetBpType(){
      if(!this.stateStandardFlagStatus){ 
          this.bestPracticeTypes.splice(1,1);
      }
    }
    
    deleteBestPractice(bestPractice: BestPracticeObject) {
        let confirmDialogRef = this.dialog.open(ConfirmDialogComponent, {
            width: '300px',
            height: '160px',
            data: { message: 'Are you sure you want to delete this Best Practice ?' }
        });
        confirmDialogRef.afterClosed().subscribe(result => {
            if (result) {
                let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
                    width: '300px',
                    height: '150px',
                    data: { message: 'Deleting Best Practice.' }
                });
                this.bestPracticeService.deleteBestPractice(bestPractice).subscribe((data: any) => {
                    loaderDialogRef.close();
                    this.fetchAllBestPractices(this.bestPracticeType);
                });
            }
        });
    }

    cloneBestPractice(bestPractice: BestPracticeObject){
      this.loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
            width: '300px',
            height: '150px',
            data: { message: 'Cloning Bestpractice...' }
        });
        this.bestPracticeService.cloneBestPractice(bestPractice)
        .subscribe(genericResponse => {
          if(genericResponse != null && genericResponse.resultCode===Constants.CDK_200){
            this.loaderDialogRef.close();
            this.fetchAllBestPractices(this.bestPracticeType);
          }else{
            this.loaderDialogRef.close();
            this.toastrService.info(genericResponse.resultDescription);
            }                   
        },
        error => {
          this.loaderDialogRef.close();
          this.toastrService.error('Error while Cloning Best Practice');
        });      
    }
}