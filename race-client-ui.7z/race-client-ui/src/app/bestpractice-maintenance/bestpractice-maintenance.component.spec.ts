import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatMenuModule, MatPaginator, MatPaginatorModule, MatProgressSpinnerModule, MatRadioButton, MatRadioChange, MatRadioModule, MatSelectModule, MatSort, MatSortModule, MatTableDataSource } from "@angular/material";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { BrowserAnimationsModule, NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router, RouterModule } from "@angular/router";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { Observable, of } from 'rxjs';
import { AuditLogGomDialogComponent } from "../audit-log-gom-dialog-details/audit-log-gom-dialog.component";
import { ConfirmDialogComponent } from "../confirm-dialog/confirm-dialog.component";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { BestPracticeObject } from "../model/bestpractice-object";
import { GenericResponse } from "../model/generic-response";
import { Platform } from "../model/master-platform";
import { PropagationAcknowledgementComponent } from "../propagation-acknowledgement/propagation-acknowledgement.component";
import { AuthService } from "../services/auth-service";
import { BestPracticeService } from "../services/bestpractice-service";
import { DataTransferService } from "../services/data-transfer-service";
import { LaunchDarklyService } from "../services/launchdarkly-service";
import { MasterFunctionalUnitService } from "../services/master-functional-unit-service";
import { BestPracticeMaintenanceComponent } from './bestpractice-maintenance.component';

describe('BestPracticeMaintenanceComponent',() => {

    let component : BestPracticeMaintenanceComponent;
    let fixture : ComponentFixture<BestPracticeMaintenanceComponent>;
    let masterFuSrevice : MasterFunctionalUnitService;
    let authService : AuthService;
    let bestPracticeService: BestPracticeService;
    let router : Router;
    let routerStub: Router;

    class MatDialogMock {
        open() {
          return {
            afterClosed: () => Observable.of(true)
          };
        }
      };

      const testUrl  = 'dashboard';
      beforeEach(async(() =>{
        let mockRouter = { navigate: jasmine.createSpy('navigateByUrl')
        } 
        const masterFunctionalUnitServiceSpy = jasmine.createSpyObj('MasterFunctionalUnitService',
        ['fetchAllFunctionalUnitsByGOMModified','discardModifiedFuChanges']);

        TestBed.configureTestingModule({
           imports: [
            BrowserAnimationsModule,
            MatSortModule,
             MatPaginatorModule,
                MatCardModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatPaginatorModule,
                MatDialogModule,
                ToastrModule.forRoot(),
                CommonModule,
                MatSelectModule,
                MatCheckboxModule,
                MatRadioModule,
                MatSortModule,
                MatIconModule,
                FormsModule,
                MatMenuModule,
                MatDividerModule,
                RouterModule.forRoot([]),
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                SortableModule,
                MatSortModule
            ],
            declarations : [
                BestPracticeMaintenanceComponent, AuditLogGomDialogComponent, LoaderDialogueComponent, ConfirmDialogComponent,
                PropagationAcknowledgementComponent
            ],
            providers : [
              MasterFunctionalUnitService,
                BestPracticeService,
                DataTransferService,
                LaunchDarklyService,
                AuthService,
                ToastrService
                //{ provide: Router, useValue: {url:testUrl} }
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent,ConfirmDialogComponent,AuditLogGomDialogComponent,PropagationAcknowledgementComponent]}});
            authService = TestBed.get(AuthService);
            routerStub  = TestBed.get(Router);
            bestPracticeService = TestBed.get(BestPracticeService);
            masterFuSrevice = TestBed.get(MasterFunctionalUnitService);
      }));

      beforeEach(() => {
        
        fixture = TestBed.createComponent(BestPracticeMaintenanceComponent);
        component = fixture.componentInstance;
          component.bestPracticeType = null;
          let stateStandardFlagStatus1 :any = {
          current :"test"
        } 
        component.stateStandardFlagStatus = stateStandardFlagStatus1;
        spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of({}));
        spyOn(authService, 'isAuthorised').and.returnValue(false);
        spyOn(authService,'getLoggedInUsersLoginId').and.returnValue('sagar.aitla@cdk.com')
        spyOn(authService,'isCDKInternalUser').and.returnValue('Harika.G@cdk.com');
        //spyOn(component,'fetchAllBestPractices')
          fixture.detectChanges();
       
    });

    let platForm :Platform={
      "platformName": "FLEX",
      "platformCode": "flex",
      "selected": false,
      "id":"1",
      "recordType":"platform"
    }
    const currentBestPractice: BestPracticeObject={
      isBestPractice : 1,
      bestPracticeName : "testbp",
      platform : platForm,	
      version : 123,
      failed : false,
      isSSS : 0,
      id:"1",
      recordType:null
    }

    const bestPractices_by_types = [
        {
          "isBestPractice": 1,
          "isSSS": 0,
          "bestPracticeName": "21AugBP",
          "platform": {
            "id": null,
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true
          },
          "versionCount": 0,
          "version": 0,
          "failed": false,
          "id": "baa890d3-28bf-4ca7-942c-2488a033adab",
          "recordType": "BestPracticeInfo"
        }
    ]

    
const generic_response : GenericResponse = {
  "resultCode": "CDK_200",
  "resultDescription": "OK",
  "resultObj": [],
    "executionTime" : null
}

    it('test cloneBestPractice',()=>{
      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
      dialogRefSpyObj.componentInstance = { body: '' };
      dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
      spyOn(component,'fetchAllBestPractices');
      spyOn(bestPracticeService,'cloneBestPractice').and.returnValue(Observable.of(generic_response));
      component.cloneBestPractice(currentBestPractice);
      expect(bestPracticeService.cloneBestPractice).toHaveBeenCalledTimes(1);
    });


    it('test cloneBestPractice if generic response is null',()=>{

      const genericResponse1 : GenericResponse = {
        "resultCode": "CDK_2001",
        "resultDescription": "OK",
        "resultObj": [],
          "executionTime" : null
      }
      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
      dialogRefSpyObj.componentInstance = { body: '' };
      dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
      spyOn(component,'fetchAllBestPractices');
      spyOn(bestPracticeService,'cloneBestPractice').and.returnValue(Observable.of(genericResponse1));
      component.cloneBestPractice(currentBestPractice);
      expect(bestPracticeService.cloneBestPractice).toHaveBeenCalledTimes(1);
    });

    it('test cloneBestPractice gives error',()=>{

      const genericResponse1 : GenericResponse = {
        "resultCode": "CDK_2001",
        "resultDescription": "OK",
        "resultObj": [],
          "executionTime" : null
      }
      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
      dialogRefSpyObj.componentInstance = { body: '' };
      dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
      spyOn(component,'fetchAllBestPractices');
      spyOn(bestPracticeService,'cloneBestPractice').and.returnValue(Observable.throwError('error'));
      component.cloneBestPractice(currentBestPractice);
      expect(bestPracticeService.cloneBestPractice).toHaveBeenCalledTimes(1);
    });

    it('test resetBpType',()=>{
      let bestPracticeTypes =['OEM','SSS']
      component.bestPracticeTypes = bestPracticeTypes;
      component.stateStandardFlagStatus= false;
      component.resetBpType();
      expect(component.bestPracticeTypes[0]).toEqual('OEM');  
    });
  
    it('test getBestPractice SSS BP selected',()=>{
      component.sssBpTypeSelected = true;
      spyOn(routerStub, 'navigate');
      component.getBestPractice('SSSBPFirst','SVC');
      expect(routerStub.navigate).toHaveBeenCalledWith(['bestPractice/stateStandard/SSSBPFirst/true']);
    });

    it('test getBestPractice OEM BP selected',()=>{
      component.sssBpTypeSelected = false;
      spyOn(routerStub, 'navigate');
      component.getBestPractice('OEMBPFirst','SVC');
      expect(routerStub.navigate).toHaveBeenCalledWith(['bestpractice/getOne/OEMBPFirst/SVC']);
    });

    it('test newBestPractice',()=>{
      component.newBestPractice();
    });

    it('test apply filter module', ()=>{
      const currentBestPractice: BestPracticeObject[]=
      [{
        isBestPractice : 1,
        bestPracticeName : "testbp",
        platform : platForm,	
        version : 123,
        failed : false,
        isSSS : 0,
        id:"1",
        recordType:null
      }
    ]
      component.dataSource = new MatTableDataSource<BestPracticeObject>(currentBestPractice);
      component.applyFilter("first oem bp");
    });

    it('test deleteBestPractice',()=>{
      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
      dialogRefSpyObj.componentInstance = { body: '' };
      dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
      spyOn(bestPracticeService,'deleteBestPractice').and.returnValue(Observable.of(currentBestPractice));
      component.deleteBestPractice(currentBestPractice);
      expect(bestPracticeService.deleteBestPractice).toHaveBeenCalledTimes(1);

    });

    it('test bestPracticeChange',()=>{
   
      let radioButton:any={
        _changeDetector:'',
        _focusMonitor:''
      }
      let event:MatRadioChange ={
        source:radioButton,
        value:'State Standard'
      }
      spyOn(component,'fetchAllBestPractices');
      component.bestPracticeChange(event);
    });

    it('test fetchAllBestPractices',()=>{

      const currentBestPractice: BestPracticeObject[]=
      [{
        isBestPractice : 1,
        bestPracticeName : "testbp",
        platform : platForm,	
        version : 123,
        failed : false,
        isSSS : 0,
        id:"1",
        recordType:null
      }
    ]
        component.dataSource = new MatTableDataSource<BestPracticeObject>(currentBestPractice);
        spyOn(bestPracticeService,'getAllBestPracticesByType').and.returnValue(Observable.of(bestPractices_by_types));
        component.fetchAllBestPractices('OEM');
      }); 
  
      it('test fetchAllBestPractices throws error',()=>{
  
        const currentBestPractice: BestPracticeObject[]=
        [{
          isBestPractice : 1,
          bestPracticeName : "testbp",
          platform : platForm,	
          version : 123,
          failed : false,
          isSSS : 0,
          id:"1",
          recordType:null
        }
      ]
          component.dataSource = new MatTableDataSource<BestPracticeObject>(currentBestPractice);
          spyOn(bestPracticeService,'getAllBestPracticesByType').and.returnValue(Observable.throwError('error'));
          component.fetchAllBestPractices('OEM');
        }); 
});