import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatTableModule } from "@angular/material";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { ToastrModule } from "ngx-toastr";
import { AuthService } from "../services/auth-service";
import { MasterFunctionalAreaService } from "../services/master-functional-area-service";
import { MasterFunctionalUnitService } from "../services/master-functional-unit-service";
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material/dialog';
import { Observable, of } from "rxjs";
import { Constants } from "ag-grid";
import { MasterFunctionalArea } from "../model/master-functional-area";
import { Platform } from "../model/master-platform";
import { MasterFunctionalUnit } from "../model/master-functional-unit";
import { compilePipeFromMetadata } from "@angular/compiler";
import { ValidationRuleService } from "../services/validation-rule-service";
import { AuditLogService } from "../services/audit-log-service";
import { ServerCommunicationService } from "../services/server-communication-service";
import { ProcessValidationResults } from "../model/process-validation-results";
import { WarningAcknowledgementComponent } from "../warning-acknowledgement/warning-acknowledgement.component";
import { PropagationAcknowledgementComponent } from "./propagation-acknowledgement.component";
import { FunctionalUnitService } from "../services/functional-unit-service";

describe('PropagationAcknowledgementComponent', () => {

    let component : PropagationAcknowledgementComponent;
    let fixture: ComponentFixture<PropagationAcknowledgementComponent>;
    let functionalUnitService: FunctionalUnitService
    let  masterFunctionalUnitService: MasterFunctionalUnitService
   
    beforeEach(() => {

        let data= {
            message:"test",
            selectedFuList:[],
            storeId:"store123",
            projectId:"project321",
            faId:"fa444"
        }
        const dialogMock = {
            close: () => { },
        };
        
        TestBed.configureTestingModule({
            imports: [
                MatDialogModule,
                MatFormFieldModule,
                MatRadioModule,
                FormsModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatInputModule,
                MatTableModule,
                MatPaginatorModule,
                MatDialogModule,
                HttpClientTestingModule,
                ToastrModule.forRoot(),
                NoopAnimationsModule,
                MatProgressSpinnerModule ,
                ReactiveFormsModule,
                CommonModule,
                MatSelectModule,
                MatCheckboxModule,
                MatCardModule
            ],
            declarations: [PropagationAcknowledgementComponent,LoaderDialogueComponent],
            providers:[
                FunctionalUnitService,
                MasterFunctionalUnitService,
                ServerCommunicationService,
                AuthService,
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: dialogMock},
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent]}});

            functionalUnitService = TestBed.get(FunctionalUnitService);
            masterFunctionalUnitService = TestBed.get(MasterFunctionalUnitService);
            fixture = TestBed.createComponent(PropagationAcknowledgementComponent);
            component = fixture.componentInstance;
    });

    const genericResponse1 :any ={
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [
            {
            }
        ],
         "executionTime": 101
      }

      
    const genericResponse_null :any = null;
    
    
    it('test ngOnInit',()=>{
       
        fixture.detectChanges();
        console.log(component.incorporateBPChanges);
        expect(component.incorporateBPChanges).toBeTruthy();
        expect(component.storeId).toEqual('store123')
        expect(component.projectId).toEqual('project321')
        expect(component.faId).toEqual('fa444')
       
    });

    it('test confirm on incorporateBPChanges false',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
       
        component.incorporateBPChanges = false;
        spyOn(masterFunctionalUnitService,'propagateFuChangesToBP').and.returnValue(Observable.of(genericResponse1));
        component.confirm();
        expect(masterFunctionalUnitService.propagateFuChangesToBP).toHaveBeenCalledTimes(1);
  
    });


    it('test confirm on incorporateBPChanges if generic response is null',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
       
        component.incorporateBPChanges = false;
        spyOn(masterFunctionalUnitService,'propagateFuChangesToBP').and.returnValue(Observable.of(genericResponse_null));
        component.confirm();
        expect(masterFunctionalUnitService.propagateFuChangesToBP).toHaveBeenCalledTimes(1);
  
    });


     it('test confirm on incorporateBPChanges in case of error',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
       
        component.incorporateBPChanges = false;
        spyOn(masterFunctionalUnitService,'propagateFuChangesToBP').and.returnValue(Observable.throw('error'));
        component.confirm();
        expect(masterFunctionalUnitService.propagateFuChangesToBP).toHaveBeenCalledTimes(1);
  
    });
    
    it('test confirm if  incorporateBPChanges true',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
       
        component.incorporateBPChanges = true;
        spyOn(functionalUnitService,'propagateFuChanges').and.returnValue(Observable.of(genericResponse1));
        component.confirm();
        expect(functionalUnitService.propagateFuChanges).toHaveBeenCalledTimes(1);
  
    }); 

    it('test confirm if  incorporateBPChanges true and generic response is null',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
       
        component.incorporateBPChanges = true;
        spyOn(functionalUnitService,'propagateFuChanges').and.returnValue(Observable.of(genericResponse_null));
        component.confirm();
        expect(functionalUnitService.propagateFuChanges).toHaveBeenCalledTimes(1);
  
    }); 

    it('test confirm on incorporateBPChanges true and throw error',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
       
        component.incorporateBPChanges = true;
        spyOn(functionalUnitService,'propagateFuChanges').and.returnValue(Observable.throw('error'));
        component.confirm();
        expect(functionalUnitService.propagateFuChanges).toHaveBeenCalledTimes(1);
  
    });

    it('test closeDialog',()=>{
        component.closeDialog();
    });

});