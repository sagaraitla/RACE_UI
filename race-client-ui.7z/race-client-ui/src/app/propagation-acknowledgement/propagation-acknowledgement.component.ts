import { Component, Inject, OnInit } from "@angular/core";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { GenericResponse } from "../model/generic-response";
import { MasterFunctionalUnitService } from "../services/master-functional-unit-service";
import { ToastrService } from "ngx-toastr";
import { Router, RouterLink } from "@angular/router";
import { FunctionalUnitService } from "../services/functional-unit-service";


@Component({
    selector: 'app-propagation-acknowledgement',
    templateUrl: './propagation-acknowledgement.component.html',
    styleUrls: ['./propagation-acknowledgement.component.css']
}
)
export class PropagationAcknowledgementComponent implements OnInit{

    selectedFuList: any = [];
    message : string;
    incorporateBPChanges : boolean = false;
    storeId: string;
    projectId: string;
    faId:string;

    constructor(private dialogRef: MatDialogRef<PropagationAcknowledgementComponent>,
        @Inject(MAT_DIALOG_DATA) private data: any, private dialog: MatDialog,private functionalUnitService: FunctionalUnitService,
        private masterFunctionalUnitService: MasterFunctionalUnitService,private toastrService: ToastrService) {
        dialogRef.disableClose = true;
    }
    ngOnInit(){
        this.message = this.data.message;
        if(this.message != null || this.message != undefined){
            this.incorporateBPChanges = true;
            this.selectedFuList = this.data.selectedFuList;
            this.storeId = this.data.storeId;
            this.projectId = this.data.projectId;
            this.faId = this.data.faId;
        }
        this.selectedFuList = this.data.selectedFuList;
    }    
    confirm(){
      
        if(!this.incorporateBPChanges){
            let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
                width: '300px',
                height: '150px',
                data: { message: 'Propagating FU changes to BP ..' }
              });
    
           this.masterFunctionalUnitService.propagateFuChangesToBP(this.selectedFuList)
            .subscribe(data => {
                let  genericResponse =  data;
                if (genericResponse != null && genericResponse != undefined && genericResponse.resultDescription == "OK" && genericResponse.resultDescription != null) {
                    loaderDialogRef.close();
                    this.dialogRef.close({event:'Confirm'});
                }else{
                    loaderDialogRef.close();
                    this.dialogRef.close({event:'Close'});
                }
            },error => {
                console.log(error);
                loaderDialogRef.close();
                this.dialogRef.close({event:'Close'});
                this.toastrService.error('Error Occurred while Propagating FU changes to BP');
            }) 
        }else{
            let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
                width: '300px',
                height: '150px',
                data: { message: 'Incorporating BP Changes..' }
              });
              this.functionalUnitService.propagateFuChanges(this.projectId,this.storeId,this.faId,this.selectedFuList).subscribe(data => {
                  let  genericResponse =  data;
                  if (genericResponse != null && genericResponse != undefined && genericResponse.resultDescription == "OK" && genericResponse.resultDescription != null) {
                      loaderDialogRef.close();
                      this.dialogRef.close({event:'Confirm'});
                  }else{
                      loaderDialogRef.close();
                      this.dialogRef.close({event:'Close'});
                  }
              },error => {
                  console.log(error);
                  loaderDialogRef.close();
                  this.dialogRef.close({event:'Close'});
                  this.toastrService.error('Error Occurred while Incorporating BP Changes');
              }) 
        }
          
    }
    closeDialog(){
        this.dialogRef.close({event:'Close'});
    }
}