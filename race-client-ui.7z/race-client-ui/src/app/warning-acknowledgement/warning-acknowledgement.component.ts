import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import {AuditLogService} from '../services/audit-log-service';

@Component({
    selector: 'app-warning-acknowledgement',
    templateUrl: './warning-acknowledgement.component.html',
    styleUrls: ['./warning-acknowledgement.component.css']
}
)
export class WarningAcknowledgementComponent implements OnInit{

    projectName:string;
    storeName:string;
    functionalAreaName:string;

    constructor(private dialogRef: MatDialogRef<WarningAcknowledgementComponent>,
        @Inject(MAT_DIALOG_DATA) private data: any, private dialog: MatDialog,private auditLogService:AuditLogService) {
        dialogRef.disableClose = true;
    }

    ngOnInit(){
        this.projectName = this.data.projectName;
        this.storeName = this.data.storeName;
        this.functionalAreaName = this.data.functionalAreaName;
    }

    showValidateOrTransferButton(){
        let processValidationCompleteOrOverridden:boolean = true;
        this.auditLogService.createOverrideErrorsAndWarningsAuditLog(this.projectName,this.storeName,this.functionalAreaName).
        subscribe(genericResponse => {
            if (genericResponse != null && genericResponse != undefined && genericResponse.resultDescription == "OK") {
                console.log('Audit log added for Validation Warnings/Errors Overridden');
            }
        },error => {
            console.log(error);
        });
        this.dialogRef.close({event:'Acknowledge',processValidationCompleteOrOverridden});
    }

    closeDialog(){
        let overrideWarningsSelected:boolean = false;
        this.dialogRef.close({event:'Close',overrideWarningsSelected});
    }

}