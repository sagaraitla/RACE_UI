import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialogModule, MatDialogRef, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatSelectModule, MatSortModule, MAT_DIALOG_DATA } from "@angular/material";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { Observable } from 'rxjs';
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { GenericResponse } from "../model/generic-response";
import { AmazonS3LogsService } from '../services/amazonS3Logs-service';
import { AuditLogService } from "../services/audit-log-service";
import { AuthService } from "../services/auth-service";
import { ServerCommunicationService } from "../services/server-communication-service";
import { WarningAcknowledgementComponent } from "./warning-acknowledgement.component";

describe('WarningAcknowledgementComponent',() => {
    let component : WarningAcknowledgementComponent;
    let fixture : ComponentFixture<WarningAcknowledgementComponent>;
    let auditLogService:AuditLogService;

    const dialogMock = {close: () => { }};
    beforeEach(async(() =>{

        let data= {
            projectName:'Project123',
            storeName:'Store123',
            functionalAreaName:'Service'

        }
        TestBed.configureTestingModule({
           imports: [
                MatCardModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatPaginatorModule,
                MatDialogModule,
                ToastrModule.forRoot(),
                CommonModule,
                MatSelectModule,
                MatCheckboxModule,
                MatSortModule,
                MatIconModule,
                FormsModule,
                MatMenuModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                SortableModule,
                MatSortModule
            ],
            declarations : [WarningAcknowledgementComponent,LoaderDialogueComponent],
            providers : [
                ServerCommunicationService,
                AuditLogService,
                AuthService,
                ToastrService,
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: dialogMock},
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent]}});
            auditLogService = TestBed.get(AuditLogService);
      }));

      beforeEach(() => {
        fixture = TestBed.createComponent(WarningAcknowledgementComponent);
        component = fixture.componentInstance;
        expect(component).toBeTruthy();
    });

    const generic_response : GenericResponse = {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [],
          "executionTime" : null
      }

    it('test ngOnInit',()=>{
        fixture.detectChanges();
        expect(component.projectName).toEqual('Project123');
        expect(component.functionalAreaName).toEqual('Service');
    });

    it('test showValidateOrTransferButton',()=>{
        spyOn(auditLogService,'createOverrideErrorsAndWarningsAuditLog').and.returnValue(Observable.of(generic_response));
        component.showValidateOrTransferButton();
        expect(auditLogService.createOverrideErrorsAndWarningsAuditLog).toHaveBeenCalledTimes(1);
    });

    it('test showValidateOrTransferButton throws error',()=>{
        spyOn(auditLogService,'createOverrideErrorsAndWarningsAuditLog').and.returnValue(Observable.throwError('error'));
        component.showValidateOrTransferButton();
        expect(auditLogService.createOverrideErrorsAndWarningsAuditLog).toHaveBeenCalledTimes(1);
    });

    it('test closeDialog',()=>{
        component.closeDialog();
    });
});