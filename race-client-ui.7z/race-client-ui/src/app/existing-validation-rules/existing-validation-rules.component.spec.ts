import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { AuthService } from "../services/auth-service";
import { ValidationRuleService } from "../services/validation-rule-service";
import { ExistingValidationRulesComponent } from "./existing-validation-rules.component";
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatFormFieldModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatSort, MatTableDataSource, MatTableModule } from "@angular/material";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CdkTableModule } from "@angular/cdk/table";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { CommonModule } from "@angular/common";
import { Router } from "@angular/router";
import { Observable } from "rxjs/Rx";
import { ValidationRuleObject } from "../model/validation-rule-object";
import { of } from "rxjs";
import { GenericResponse } from "../model/generic-response";

describe('ExistingValidationRulesComponent', () => {

    let component : ExistingValidationRulesComponent;
    let fixture: ComponentFixture<ExistingValidationRulesComponent>;
    let authService: AuthService;
    let validationRuleService: ValidationRuleService;
    let router : Router;
    let dataSource :any;
    let filter:any;
    beforeEach(async(() => {
        let mockRouter = {
            navigate: jasmine.createSpy('navigateByUrl')
        } 
        TestBed.configureTestingModule({
            imports: [
                MatCardModule,
                FormsModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatInputModule,
                MatTableModule,
                MatPaginatorModule,
                MatDialogModule,
                HttpClientTestingModule,
                ToastrModule.forRoot(),
                NoopAnimationsModule,
                MatProgressSpinnerModule ,
                ReactiveFormsModule,
                CommonModule,
                MatSelectModule,
                MatRadioModule,
                MatCheckboxModule,
                MatMenuModule
            ],
            declarations: [ExistingValidationRulesComponent,LoaderDialogueComponent],
            providers:[
                 ValidationRuleService,
                 AuthService,
                 ToastrService,
                 { provide: Router, useValue: mockRouter }
               ]
        }).overrideModule(BrowserDynamicTestingModule,{ set: { entryComponents: [LoaderDialogueComponent]}});

        authService = TestBed.get(AuthService);
        validationRuleService = TestBed.get(ValidationRuleService);
        
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ExistingValidationRulesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    const validationRuleRespone:any={
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": {
          "isVR": 1,
          "sourceProductCode": "PTS",
          "sourceFunctionalAreaName": "Parts",
          "sourceFunctionalUnitName": "Price Codes",
          "sourceFieldHeaderName": "Description",
          "condition": "Must Exist In",
          "conditionType": "Error",
          "validationMessage": "Price code missing or not valid",
          "targetProductCode": "PTS",
          "targetFunctionalAreaName": "Parts",
          "targetFunctionalUnitName": "Price Codes",
          "targetFieldHeaderName": "Description",
          "platformName": "DRIVE",
          "active": true,
          "id": "68f94261-69e8-4916-ae86-ab746477260e",
          "recordType": "ValidationRule"
        },
        "executionTime": 30
    }

    const validationRules:ValidationRuleObject[]=[
        {
        
            "isVR": 1,
            "sourceProductCode": "PTS",
            "sourceFunctionalAreaName": "Parts",
            "sourceFunctionalUnitName": "Price Codes",
            "sourceFieldHeaderName": "Description",
            "condition": "Must Exist In",
            "conditionType": "Error",
            "validationMessage": "Price code missing or not valid",
            "targetProductCode": "PTS",
            "targetFunctionalAreaName": "Parts",
            "targetFunctionalUnitName": "Price Codes",
            "targetFieldHeaderName": "Description",
            "platformName": "DRIVE",
            "active": true,
            "status":null,
            "id": "68f94261-69e8-4916-ae86-ab746477260e",
            "recordType": "ValidationRule"
        }
    ]


    const generic_response : GenericResponse = {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [
          {
            "isVR": 1,
            "sourceProductCode": "PTS",
            "sourceFunctionalAreaName": "Parts",
            "sourceFunctionalUnitName": "Price Codes",
            "sourceFieldHeaderName": "Description",
            "condition": "Must Exist In",
            "conditionType": "Error",
            "validationMessage": "Price code missing or not valid",
            "targetProductCode": "PTS",
            "targetFunctionalAreaName": "Parts",
            "targetFunctionalUnitName": "Price Codes",
            "targetFieldHeaderName": "Description",
            "platformName": "DRIVE",
            "active": true,
            "status":null,
            "id": "68f94261-69e8-4916-ae86-ab746477260e",
            "recordType": "ValidationRule"
          }
          ],
          "executionTime" : null
      }
    const validationRule: ValidationRuleObject={
        
        "isVR": 1,
        "sourceProductCode": "PTS",
        "sourceFunctionalAreaName": "Parts",
        "sourceFunctionalUnitName": "Price Codes",
        "sourceFieldHeaderName": "Description",
        "condition": "Must Exist In",
        "conditionType": "Error",
        "validationMessage": "Price code missing or not valid",
        "targetProductCode": "PTS",
        "targetFunctionalAreaName": "Parts",
        "targetFunctionalUnitName": "Price Codes",
        "targetFieldHeaderName": "Description",
        "platformName": "DRIVE",
        "active": true,
        "status":null,
        "id": "68f94261-69e8-4916-ae86-ab746477260e",
        "recordType": "ValidationRule"
    }

    it('test ngOnInit',()=>{
        spyOn(component,'fetchValidationRules');
        spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of({}));
        spyOn(authService,'isAuthorised').and.returnValue(Observable.of(false));
        component.ngOnInit();
        expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(1);
        expect(authService.isAuthorised).toHaveBeenCalledTimes(2);
    });

    it('test fetchValidationRules',()=>{
        
        spyOn(validationRuleService,'getValidationRulesByPlatformName').and.returnValue(Observable.of(generic_response));
        component.dataSource = new MatTableDataSource<ValidationRuleObject>(generic_response.resultObj);
        component.sort = new MatSort();
        component.dataSource.sort = component.sort;
        component.fetchValidationRules();
        expect(validationRuleService.getValidationRulesByPlatformName).toHaveBeenCalledTimes(1);
    });

    it('test platformChange',()=>{
        spyOn(component,'fetchValidationRules');
        component.selectedPlatform="DRIVE";
        component.platformChange();

        component.selectedPlatform="FLEX";
        component.platformChange();
    });


    it('test deleteValidationRule',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        spyOn(validationRuleService,'deleteValidationRule').and.returnValue(Observable.of(validationRuleRespone));
        spyOn(component,'fetchValidationRules');
        component.deleteValidationRule(validationRule);

        expect(validationRuleService.deleteValidationRule).toHaveBeenCalledTimes(1);
    });


    it('test openDialogToEditValidationRule',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        spyOn(component,'fetchValidationRules');

        component.openDialogToEditValidationRule(validationRule);

    });

    it('test openDialogToCopyVRToOtherPlatform',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        spyOn(component,'fetchValidationRules');

        component.openDialogToCopyVRToOtherPlatform(validationRule);

    });

    it('test openDialogToAddValidationRule',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(component,'fetchValidationRules');

        component.openDialogToAddValidationRule(validationRule);

    });


});