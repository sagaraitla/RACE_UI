import { Component, OnInit, ViewChild } from '@angular/core';
import { Router} from '@angular/router';
import { MatDialog,MatDialogRef } from '@angular/material';
import { NewValidationRuleComponent } from '../new-validation-rule/new-validation-rule.component';
import { MatPaginator, MatTableDataSource, MatSort, Sort } from '@angular/material';
import { ValidationRuleObject } from '../model/validation-rule-object';
import { ValidationRuleService } from '../services/validation-rule-service';
import { AuthService } from '../services/auth-service';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { Constants } from '../constant/constants';


@Component({
  selector: 'app-existing-validation-rules',
  templateUrl: './existing-validation-rules.component.html',
  styleUrls: ['./existing-validation-rules.component.css']
})
export class ExistingValidationRulesComponent implements OnInit {
	createValidationRulePermission : boolean = false;
	deleteValidationRulePermission : boolean = false;
	dataSource : any;
    filter : any;
	selectedPlatform : string;
	displayedColumns = ['sourceFunctionalAreaName','sourceFunctionalUnitName', 'sourceFieldHeaderName', 'condition', 'targetFunctionalAreaName','targetFunctionalUnitName','targetFieldHeaderName', 'active', 'actions'];
	validationRuleObject : ValidationRuleObject;

	@ViewChild(MatPaginator,{static: false}) paginator: MatPaginator;
    @ViewChild(MatSort,{static: false}) sort: MatSort;
	platforms : any = [];
	copyLabel : any;
    
    constructor(private router:Router, private dialog:MatDialog, private validationRuleService: ValidationRuleService, private authService: AuthService ){
    	this.platforms = Constants.PLATFOMRS;	 
    }

	ngOnInit() {
		this.selectedPlatform = 'DRIVE';
		this.authService.fetchLoggedInUserAndPermissions().subscribe((data: any) => {
       		 this.createValidationRulePermission = this.authService.isAuthorised('DOT_ADMIN');
        	this.deleteValidationRulePermission = this.authService.isAuthorised('DOT_ADMIN');
			this.fetchValidationRules();
		});
		if(this.selectedPlatform === 'DRIVE'){
			this.copyLabel = 'FLEX';
		}
	}
	
	fetchValidationRules(){
	   let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
         width: '300px',
         height: '150px',
         data: { message: 'Fetching Validation Rules ..' }
       });
		this.validationRuleService.getValidationRulesByPlatformName(this.selectedPlatform).subscribe(genericResponse=>{
			if(genericResponse != null && genericResponse != undefined && genericResponse.resultDescription == "OK" && genericResponse.resultDescription != null){
				genericResponse.resultObj.forEach(element => {
                    if(element.active === true){
                        element.status = 'Active';
                    }else{
                        element.status = 'Inactive';
					}
                });
				this.dataSource = new MatTableDataSource<ValidationRuleObject>(genericResponse.resultObj);
				this.dataSource.data.forEach(element => {
					for (const key in element) {
					  if (!element[key] || element[key] === null || element[key] === undefined) {
						element[key] = '';
					  }
					}
				  });
				this.dataSource.filterPredicate = function(data, filter: string): boolean {
					return (data.sourceFunctionalAreaName && data.sourceFunctionalAreaName.toLowerCase().includes(filter))
					|| (data.sourceFunctionalUnitName && data.sourceFunctionalUnitName.toLowerCase().includes(filter))
					|| (data.sourceFieldHeaderName && data.sourceFieldHeaderName.toLowerCase().includes(filter))
					|| (data.condition && data.condition.toLowerCase().includes(filter))
					|| (data.targetFunctionalAreaName && data.targetFunctionalAreaName.toLowerCase().includes(filter))
					|| (data.targetFunctionalUnitName && data.targetFunctionalUnitName.toLowerCase().includes(filter))
					|| (data.targetFieldHeaderName && data.targetFieldHeaderName.toLowerCase().includes(filter))
					|| (data.status && data.status.toLowerCase().includes(filter));
				};
				this.dataSource.sortingDataAccessor = (item, property) => {
					
	                switch(property) {
	                  case 'sourceFunctionalAreaName': return item.sourceFunctionalAreaName ? item.sourceFunctionalAreaName.toLowerCase(): item;
	                  case 'sourceFunctionalUnitName': return item.sourceFunctionalUnitName ? item.sourceFunctionalUnitName.toLowerCase() : item;
					  case 'sourceFieldHeaderName': return item.sourceFieldHeaderName ? item.sourceFieldHeaderName.toLowerCase() : item;
	                  default: return item[property];
	                }
	             }; 
	    		this.dataSource.paginator = this.paginator;
				this.dataSource.sort = this.sort;
				const sortState: Sort = {active: 'sourceFunctionalAreaName', direction: 'asc'};
				this.sort.active = sortState.active;
				this.sort.direction = sortState.direction;
				this.sort.sortChange.emit(sortState); 
	            if (this.filter) {
	                this.applyFilter(this.filter);
	            }
	            loaderDialogRef.close();
			}
			else{
				loaderDialogRef.close();
			}
		}, error => {
			console.log(error);
        	loaderDialogRef.close();
        });	
		
	}
	
	createNewNavigationRule(){
		this.router.navigateByUrl('validationRule/newValidationRule');
	}
	
	openDialogToAddValidationRule(validationRuleObject:ValidationRuleObject){
	  let dialogRef=this.dialog.open(NewValidationRuleComponent,{
		  width :'80%',
		  height :'80%',
		  data : {
			  edit :false
		  }
	  });
	  
	  dialogRef.afterClosed().subscribe(result=>{
		  if(result !== Constants.POPUP_CANCEL)
		  		this.fetchValidationRules();
	  });
	}
	
	openDialogToEditValidationRule(validationRuleObject:ValidationRuleObject){

	      validationRuleObject.platformName = this.selectedPlatform;
		  let dialogRef=this.dialog.open(NewValidationRuleComponent,{
			  width :'80%',
			  height :'80%',
			  data : {
				  validationRule : validationRuleObject,
				  edit :true
			  }
		  });
		  
		  dialogRef.afterClosed().subscribe(result=>{
			  this.fetchValidationRules();
		  });
		}
	

	openDialogToCopyVRToOtherPlatform(validationRuleObject:ValidationRuleObject){
		let initialPlatform = this.selectedPlatform;
		let dialogRef=this.dialog.open(NewValidationRuleComponent,{
			width :'80%',
			height :'80%',
			data : {
				validationRule : validationRuleObject,
				copy   :true,
				initial : initialPlatform
			}
		});
		dialogRef.afterClosed().subscribe(result=>{
			this.fetchValidationRules();
		});
	}


	getValidationRuleDetails(validationRuleId : string){
		 this.router.navigate(['validationRule/' +  validationRuleId]);
	}
	
	applyFilter(filterValue: string) {
        filterValue = filterValue.trim(); 
        filterValue = filterValue.toLowerCase(); 
        this.dataSource.filter = filterValue;
    }
	
	gotoDashboard() {
       this.router.navigateByUrl('dashboard');
    }
	
    deleteValidationRule(validationRuleObject: ValidationRuleObject) {
        let confirmDialogRef = this.dialog.open(ConfirmDialogComponent, {
            width: '300px',
            height: '160px',
            data: { message: 'Are you sure you want to delete this Validation Rule ?' }
        });
        confirmDialogRef.afterClosed().subscribe(result => {
            if (result) {
                let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
                    width: '300px',
                    height: '150px',
                    data: { message: 'Deleting Validation Rule..' }
                });
                this.validationRuleService.deleteValidationRule(validationRuleObject.id).subscribe((genericResponse: any) => {
                	if(genericResponse != null && genericResponse != undefined && genericResponse.resultDescription == "OK"){
                    	loaderDialogRef.close();
                    	this.fetchValidationRules();
					}
                });
            }
        });
    }
    

	platformChange(){
		this.fetchValidationRules();
		if(this.selectedPlatform === 'DRIVE'){
			this.copyLabel = 'FLEX';
		} else if(this.selectedPlatform === 'FLEX'){
			this.copyLabel = 'DRIVE';
		}
	}
   
}
