import { CdkTableModule } from '@angular/cdk/table';
import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { compilePipeFromMetadata, syntaxError } from '@angular/compiler';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatDialogRef, MatDividerModule, MatFormFieldModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatSidenavModule, MatTableModule } from '@angular/material';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router, RouterModule } from '@angular/router';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { Observable,of} from 'rxjs';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { BestPracticeObject } from '../model/bestpractice-object';
import { PlatformObject } from '../model/platform-object';
import { AuthService } from '../services/auth-service';
import { BestPracticeService } from '../services/bestpractice-service';
import { LaunchDarklyService } from '../services/launchdarkly-service';
import { CreateBestPracticeComponent } from './create-bestpractice.component';

describe('CreateBestPracticeComponent', () => {

    let component : CreateBestPracticeComponent;
    let fixture: ComponentFixture<CreateBestPracticeComponent>;
    let bestPracticeService: BestPracticeService;
    let launchDarklyService : LaunchDarklyService;
    let authService: AuthService;
    let routerStub: Router;
    let toastrService : ToastrService;

    const dialogMock = {close: () => { }};

    beforeEach(async(() => {

        TestBed.configureTestingModule({
          imports: [
            MatProgressSpinnerModule,
            MatMenuModule,
            MatDividerModule,
            FormsModule,
            MatCardModule,
            FormsModule,
            MatFormFieldModule,
            MatInputModule,
            CdkTableModule,
            MatMenuModule,
            MatTableModule,
            MatPaginatorModule,
            MatDialogModule,
            HttpClientTestingModule,
            ToastrModule.forRoot(),
            RouterModule.forRoot([]),
            NoopAnimationsModule,
            ReactiveFormsModule,
            CommonModule,
            MatSelectModule,
            MatRadioModule,
            MatCheckboxModule,
            MatSidenavModule],
          declarations: [ CreateBestPracticeComponent,LoaderDialogueComponent],
          providers:[
            BestPracticeService,
            LaunchDarklyService,
            AuthService,
           ToastrService,
           {provide: MatDialogRef, useValue: dialogMock}
          ]
        }).overrideModule(BrowserDynamicTestingModule,
           { set: { entryComponents: [LoaderDialogueComponent]}});

            authService = TestBed.get(AuthService);
            bestPracticeService = TestBed.get(BestPracticeService);
            launchDarklyService = TestBed.get(LaunchDarklyService);
            routerStub  = TestBed.get(Router);
            toastrService  = TestBed.get(ToastrService);

            fixture = TestBed.createComponent(CreateBestPracticeComponent);
            component = fixture.componentInstance;
      }));

    const platforms:any=
        {
            platformName: "FLEX",
            platformCode :"FLEX",
        }
    

    const bestPracticeObject : BestPracticeObject={
        isBestPractice : 1,
        bestPracticeName : 'testBP',
        platform : platforms,
        version : 1.1,
        failed : false,
        isSSS : 1,
        id:'123',
        recordType:'BestPractice'
    }
      
    it('should create Create Best Practice Component',()=>{
        expect(component).toBeTruthy();
      });


    it('test ngOnInit',()=>{
        fixture.detectChanges();
    });
    it('test create BestPractice for OEM ',()=>{

        component.selectedPlatform = 'FLEX';
        component.selectedBpType = 'OEM';
        component.isOEMSelected = true;
        component.selectedPlatform = platforms;
        component.createBestPractice({});
        expect(component.bestPracticeObject.isBestPractice).toEqual(1);
    
    });

    it('test create BestPractice for SSS ',()=>{

        component.selectedPlatform = 'FLEX';
        component.selectedBpType = 'SSS';
        component.isOEMSelected = false;
        spyOn(component,'isValidForm').and.returnValue(false);
        component.createBestPractice({});
        expect(component.bestPracticeObject.isSSS).toEqual(1);
    
    });

    it('test create BestPractice for SSS  with valid form data',()=>{

        component.selectedPlatform = 'FLEX';
        component.selectedBpType = 'SSS';
        component.isOEMSelected = false;
        spyOn(component,'isValidForm').and.returnValue(true);
        spyOn(component,'validateNameFromDB');
        component.createBestPractice({});
        expect(component.bestPracticeObject.isSSS).toEqual(1);
    
    });

    it('test create BestPractice selected BPType not given',()=>{

        component.selectedBpType = undefined;
        component.createBestPractice({});

    });

    it('test isValidForm for SSS',()=>{

       component.isOEMSelected = false;
       component.bestPracticeObject.bestPracticeName = "test";
       let flag = component.isValidForm();
       expect(flag).toBeTruthy();

    });

    it('test isValidForm for OEM',()=>{
 
        component.isOEMSelected = true;
        component.bestPracticeObject.bestPracticeName = "test";
        component.bestPracticeObject.platform = platforms;
        let flag1 = component.isValidForm();
        expect(flag1).toBeTruthy(); 
 
     });
 
     it('test enablePlatformSelection',()=>{
        component.enablePlatformSelection('OEM');
        expect(component.isOEMSelected).toBeTruthy();

        component.enablePlatformSelection('SSS');
        expect(component.isOEMSelected).toBeFalsy();
     });

     it('test resetBpType',()=>{
         component.stateStandardFlagStatus = false;
         component.resetBpType();
         expect(component.selectedBpType).toEqual('OEM');
         expect(component.isOEMSelected).toBeTruthy();
     });

     it('test resetBpType for SSS',()=>{
        component.stateStandardFlagStatus = true;
        component.resetBpType();
        expect(component.selectedBpType).toEqual('');
        expect(component.isOEMSelected).toBeFalsy();
    });

    it('test getBestPracticeDetailsByName',()=>{
        component.isOEMSelected = false;
        component.getBestPracticeDetailsByName('test',true);
    });

    it('test getBestPracticeDetailsByName for OEM BP',()=>{
        component.bestPracticeObject.platform = platforms;
        component.isOEMSelected = true;
        spyOn(bestPracticeService,'getByBestPracticeNameAndPlatform').and.returnValue(Observable.of({}));
        component.getBestPracticeDetailsByName('test',true);
    });

    it('test createNewBestPractice',()=>{
        let dialogRef ={close: () => { }}
        component.dialogRef = dialogRef;
        spyOn(routerStub, 'navigate');
        component.isOEMSelected = true;
        component.bestPracticeObject = bestPracticeObject;
        const platform:PlatformObject={
            platformName: "FLEX",
            platformCode :"FLEX",
            selected : true
        }
        component.bestPracticeObject.platform = platform;
        spyOn(bestPracticeService,'saveBestPractice').and.returnValue(Observable.of({}));
        component.createNewBestPractice();
        expect(routerStub.navigate).toHaveBeenCalledWith(['bestpractice/getOne/testBP/FLEX']);
    });

    it('test createNewBestPractice for SSS',()=>{
        let dialogRef ={close: () => { }}
        component.dialogRef = dialogRef;
        spyOn(routerStub, 'navigate');
        component.isOEMSelected = false;
        component.bestPracticeObject = bestPracticeObject;
        const platform:PlatformObject={
            platformName: "FLEX",
            platformCode :"FLEX",
            selected : true
        }
        component.bestPracticeObject.platform = platform;
        spyOn(bestPracticeService,'saveBestPractice').and.returnValue(Observable.of({}));
        component.createNewBestPractice();
        expect(routerStub.navigate).toHaveBeenCalledWith(['bestPractice/stateStandard/testBP/true']);
    });
  
    it('test createNewBestPractice api throw error',()=>{
        let dialogRef ={close: () => { }}
        component.dialogRef = dialogRef;
        spyOn(bestPracticeService,'saveBestPractice').and.returnValue(Observable.throwError('error'));
        component.createNewBestPractice();
        expect(component['toastrService'].previousToastMessage).toBe('Error while creating Best Practice')
    });

    it('test validateNameFromDB',()=>{
        let data:any={
            platform:{
                platformName:'FLEX'
            }
        }
        let dialogRef ={close: () => { }}
        component.dialogRef = dialogRef;
        component.bestPracticeObject = bestPracticeObject;
        spyOn(component,'getBestPracticeDetailsByName').and.returnValue(Observable.of(data));
        component.validateNameFromDB();
        expect(component['toastrService'].previousToastMessage).toBe('Best Practice testBP with platform FLEX already exists.')
        expect(component.isValidBestPractice).toBeTruthy();
    });

    it('test validateNameFromDB In case best practice details by name are null',()=>{
        let data:any=null;
        let dialogRef ={close: () => { }}
        component.dialogRef = dialogRef;
        component.bestPracticeObject = bestPracticeObject;
        spyOn(component,'createNewBestPractice');
        spyOn(component,'getBestPracticeDetailsByName').and.returnValue(Observable.of(data));
        component.validateNameFromDB();
    });

    it('test gotoBPMaintenance',()=>{
        const navigateSpy = spyOn(routerStub, 'navigateByUrl');
        component.gotoBPMaintenance();
        expect(navigateSpy).toHaveBeenCalledWith('bestpractice');
    });

    it('test validateNameFromDB api throw error',()=>{
        let dialogRef ={close: () => { }}
        component.dialogRef = dialogRef;
        component.bestPracticeObject = bestPracticeObject;
        spyOn(component,'getBestPracticeDetailsByName').and.returnValue(Observable.throwError('error'));
        component.validateNameFromDB();
        expect(component['toastrService'].previousToastMessage).toBe('Error while creating Best Practice')
    });

    it('test cancelBestPracticeCreation',()=>{
        const navigateSpy = spyOn(routerStub, 'navigateByUrl');
        component.cancelBestPracticeCreation();
        expect(navigateSpy).toHaveBeenCalledWith('bestpractice');
    });
});