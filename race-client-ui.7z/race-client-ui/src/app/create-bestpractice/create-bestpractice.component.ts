import { Component, OnInit, ɵConsole } from '@angular/core';

import { BestPracticeService } from '../services/bestpractice-service';
import { AuthService } from '../services/auth-service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';

import { ProjectObject } from '../model/project-object';
import { BestPracticeObject } from '../model/bestpractice-object';

import { FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { LaunchDarklyService } from '../services/launchdarkly-service';
import { Constants } from '../constant/constants';
import { ToastrService } from 'ngx-toastr';



@Component({
  selector: 'app-bestpractice-project',
  templateUrl: './create-bestpractice.component.html',
  styleUrls: ['./create-bestpractice.component.css']
})
export class CreateBestPracticeComponent implements OnInit {

  bestPracticeObject: BestPracticeObject = new BestPracticeObject();

  selectedPlatform: string;

  createBPPermission = false;

  private user: any = {};

  bestPracticeTypes = [
    { bpType: 'OEM' },
    { bpType: 'State Standard' }
  ];

  platforms = [];

  selectedBpType: string;
  isOEMSelected: boolean = false;
  isValidBestPractice: boolean = true;
  dialogRef: any;
  stateStandardFlagStatus : any;

  constructor(private bestPracticeService: BestPracticeService, private authService: AuthService,
    private route: ActivatedRoute, private router: Router, private dialog: MatDialog, private launchDarklyService : LaunchDarklyService, private toastrService : ToastrService) {
    this.user = this.authService.getLoggedInUser().user;
    this.platforms=Constants.PLATFORMS;
  }

  ngOnInit() {
    this.createBPPermission = this.authService.isAuthorised('DOT_ADMIN');
    this.stateStandardFlagStatus = this.launchDarklyService.flags['race-sales-state-standards'];
    if(this.stateStandardFlagStatus.current != undefined && this.stateStandardFlagStatus.current != null){
      this.stateStandardFlagStatus = this.stateStandardFlagStatus.current;
    }
	  this.launchDarklyService.flagChange.subscribe((flags) => {
      this.stateStandardFlagStatus = flags['race-sales-state-standards'].current;
      this.resetBpType();
    });
    this.resetBpType();
   
    
  }

  createBestPractice(formData: any) {
    this.bestPracticeObject.recordType = this.selectedBpType;
    if (this.bestPracticeObject.recordType != undefined && this.bestPracticeObject.recordType != null && this.bestPracticeObject.recordType !='')  {
      if (this.isOEMSelected) {
        const platform = this.selectedPlatform;
        const selectedPlatforms = this.platforms.filter(function (e) {
          return e.platformName === platform;
        });
        this.bestPracticeObject.platform = selectedPlatforms[0];
        this.bestPracticeObject.isBestPractice = 1;
      } else {
        this.bestPracticeObject.isSSS = 1;
      }
      if (this.isValidForm()) {
        this.dialogRef = this.dialog.open(LoaderDialogueComponent, {
          width: '300px',
          height: '150px',
          data: { message: 'Creating new Best Practice.' }
        });
        this.validateNameFromDB();
      } else {
        this.toastrService.error('Error! Required field value missing.');
      }
    } else {
      this.toastrService.error('Please select Best Practice Type.');
    }
  }

  isValidForm() {
    let flag = false;
    if (this.isOEMSelected) {
      if (this.bestPracticeObject.bestPracticeName && this.bestPracticeObject.platform != null) {
        flag = true;
      }
    } else {
      if (this.bestPracticeObject.bestPracticeName != null) {
        flag = true;
      }
    }

    return flag;
  }

  cancelBestPracticeCreation() {
    this.router.navigateByUrl('bestpractice');
  }
  
  validateNameFromDB() {
    let isValidBestPractice: boolean = false;
    this.getBestPracticeDetailsByName(this.bestPracticeObject.bestPracticeName,true)
      .subscribe(data => {
        if (data !== null) {
          this.dialogRef.close();
          this.toastrService.error('Best Practice ' + this.bestPracticeObject.bestPracticeName + ' with platform ' + data.platform.platformName +' already exists.');
          this.isValidBestPractice = true;

        } else {
          this.createNewBestPractice();
        }
      },
        error => {
          /* if (this.bestPracticeObject.bestPracticeName.match('^[A-Za-z0-9_-\\s]+$' ) == null ) {
             this.isValidBestPractice =true;
           }*/
          this.dialogRef.close();
          this.toastrService.warning('Error while creating Best Practice');

        });
  }

  enablePlatformSelection(name: string) {
    if (name != undefined && name != null && name === 'OEM') {
      this.isOEMSelected = true;
    } else {
      this.isOEMSelected = false;
    }
  }

  getBestPracticeDetailsByName(bestPracticeName: string, permissionCheckNeeded: boolean): Observable<BestPracticeObject> {
    let bestPracticeObject: Observable<BestPracticeObject>;
    if (this.isOEMSelected) {
      bestPracticeObject = this.bestPracticeService
        .getByBestPracticeNameAndPlatform(bestPracticeName, this.bestPracticeObject.platform.platformCode, permissionCheckNeeded);
    } else {
      bestPracticeObject = this.bestPracticeService
        .getSSSBPByBestPracticeName(bestPracticeName, permissionCheckNeeded);
    }
    return bestPracticeObject;
  }

  gotoBPMaintenance() {
    this.router.navigateByUrl('bestpractice');
  }

  createNewBestPractice() {


    // Post request for Rest endpoint
    this.bestPracticeService
      .saveBestPractice(this.bestPracticeObject, true)
      .subscribe(data => {
        this.dialogRef.close();
        if (this.isOEMSelected) {
          this.router.navigate(['bestpractice/getOne/' + this.bestPracticeObject.bestPracticeName + '/' + this.bestPracticeObject.platform.platformCode]);
        } else {
          this.router.navigate(['bestPractice/stateStandard/' + this.bestPracticeObject.bestPracticeName + '/true']);
        }
      },
        error => {
          this.dialogRef.close();
          this.toastrService.warning('Error while creating Best Practice');
        });


  }

  resetBpType(){
    if(!this.stateStandardFlagStatus){ 
      this.bestPracticeTypes.splice(1,1);
      this.selectedBpType = 'OEM';
      this.isOEMSelected = true;
    }else{
      this.selectedBpType = '';
      this.isOEMSelected = false;
    }
  }

}
