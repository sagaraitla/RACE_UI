import {Component, Inject, ViewChild} from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {FormControl} from '@angular/forms';
import {MatOption} from '@angular/material';

@Component({
    selector: 'import-dialog',
    templateUrl: 'import-dialog.component.html',
  })
  export class ImportDialog {

    selectedSheets = new FormControl();
    public finalListSelected : string[];
    private sheetList : string[];
    @ViewChild('allSelected',{static: false}) private allSelected: MatOption;
    constructor(
      public dialogRef: MatDialogRef<ImportDialog>,
      @Inject(MAT_DIALOG_DATA) public data: any) {
        this.sheetList = data.sheetList;        
        this.finalListSelected = [];
        }

        onOkClick(sheetsSelected : string): void {
          if(sheetsSelected)
          {

            this.finalListSelected = sheetsSelected.toString().split(',');
          }
          this.dialogRef.close(this.finalListSelected);    
        }
        onClose(finalListSelected : string[]) : any[] {          
            return finalListSelected;              
          }
        
          toggleAllSelection() {
            if (this.allSelected.selected) {
              this.selectedSheets
                .patchValue([...this.sheetList.map(item => item), 0]);
            } else {
              this.selectedSheets.patchValue([]);
            }
          }

          /**
           * This Method is to select 'All' checkbox when all of the screens are selected from import list.
           * Also to unselect 'All' checkbox when one or more of the functional units are unselected from import list.
           */
          tosslePerOne() {
            if(this.allSelected.selected)
            {
              this.allSelected.deselect();
              return false;              
            }
            if(this.selectedSheets.value.length == this.sheetList.length)
            {
              this.allSelected.select();
            }

          }
    
      }