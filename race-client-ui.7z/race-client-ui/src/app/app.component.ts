import { Component, OnInit } from '@angular/core';
import { DataTransferService } from './services/data-transfer-service';
import { AuthService } from './services/auth-service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit {
  title = 'Angular Material Example';
  viewFunctionalUnitsPermission = false;
  viewFunctionalAreasPermission = false;
  hasAdminRole:boolean = false;
  cdkInternalUser : boolean = false;
  displaySideBar : boolean = false;
  private host: string;
  private setupSchemaHost :string;

  constructor( private dataTransferService: DataTransferService,
    private authService: AuthService, private router: Router,private http: HttpClient) {
      this.http.get('assets/config',{withCredentials: true}).subscribe((data: any) => { 
        this.setupSchemaHost=data.setupSchemaHost;
        });

  }

  ngOnInit() {
	this.authService.fetchLoggedInUserAndPermissions().subscribe((data: any) => {  
        this.viewFunctionalUnitsPermission = this.authService.isAuthorised('DOT_SCREEN_VIEW');
        this.viewFunctionalAreasPermission = this.authService.isAuthorised('DOT_TEMPLATE_VIEW');
        this.hasAdminRole = this.authService.isAuthorised('DOT_ADMIN');
      this.cdkInternalUser = this.authService.isCDKInternalUser();
	});
  }

  navigate( endpoint : string){
    if(endpoint === 'setupSchema'){
      window.open(this.setupSchemaHost,'_blank');
    }else{
      this.router.navigateByUrl(endpoint);
    }
	  
  }
  
  toggleSideBarDisplay() {
	  this.displaySideBar = !this.displaySideBar;
  }
}
