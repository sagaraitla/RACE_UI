import {Component} from "@angular/core";
import {ICellEditorAngularComp} from "ag-grid-angular/main";

@Component({
    selector: 'date-editor-cell',
    template: `
        <div>
        <datepicker (selectionDone)="onClick($event)" [showWeeks]="false" style="width:1px; height:1px"></datepicker>
        <button  class="btn btn-primary btn-sm" style="align-self: center;" (click)="clear()">Clear</button>
        </div>
    `
})
export class BootstrapDatePickerComponent implements ICellEditorAngularComp {
    private params: any;

    public selectedDate: Date = new Date();
    public d = new Date();

    agInit(params: any): void {
        this.params = params;
    }

    getValue(): any {
        if (this.selectedDate) {
            return `${this.selectedDate.getMonth() + 1}/${this.selectedDate.getDate()}/${this.selectedDate.getFullYear()}`;
        }
        else {
            return '';
        }
    }
    
    isPopup(): boolean {
        return true;
    }

    clear() {
        this.params.value = '';
        this.params.api.refreshCells();
        this.selectedDate = null;
        this.params.api.stopEditing();
    }

    onClick(date:Date) {
        this.selectedDate = date;
        this.params.api.stopEditing();
    }
}