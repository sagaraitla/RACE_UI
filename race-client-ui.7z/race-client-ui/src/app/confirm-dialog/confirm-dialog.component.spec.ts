import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { ConfirmDialogComponent } from "../confirm-dialog/confirm-dialog.component";


describe('ConfirmDialogComponent',() => {
    let component : ConfirmDialogComponent;
    let fixture : ComponentFixture<ConfirmDialogComponent>;
    const dialogMock = {close: () => { }};
    beforeEach(async(() =>{

        let data= {}

        TestBed.configureTestingModule({
           imports: [MatDialogModule],
            declarations : [ConfirmDialogComponent],
            providers : [
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: dialogMock},
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: []}});
      }));
      beforeEach(() => {
        fixture = TestBed.createComponent(ConfirmDialogComponent);
        component = fixture.componentInstance;
        expect(component).toBeTruthy();
    });

    it('test action',()=>{
        component.action(true);
    });
});