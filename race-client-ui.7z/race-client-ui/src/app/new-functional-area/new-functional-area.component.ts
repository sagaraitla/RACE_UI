import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GridOptionsModel } from '../model/grid-options-object';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import * as moment from 'moment';
import { ExcelService } from '../services/excel-service';
import { MasterFunctionalArea } from '../model/master-functional-area';
import { MasterFunctionalUnit } from '../model/master-functional-unit';
import { Platform } from '../model/master-platform';
import { MasterFunctionalAreaService } from '../services/master-functional-area-service';
import { MasterFunctionalUnitService } from '../services/master-functional-unit-service';
import { Constants } from '../constant/constants';
import { ToastrService } from 'ngx-toastr';
import { GenericResponse } from '../model/generic-response';

@Component({
    selector: 'app-new-functional-area',
    templateUrl: './new-functional-area.component.html',
    styleUrls: ['./new-functional-area.component.css']
})
export class NewFunctionalAreaComponent implements OnInit {

    editMode: boolean = false;
    cloneMode: boolean = false;
    firstFormGroup: FormGroup;
    functionalUnits: Array<MasterFunctionalUnit> = new Array<MasterFunctionalUnit>();
    filteredFunctionalUnits: Array<MasterFunctionalUnit> = new Array<MasterFunctionalUnit>();
    selectedFunctionalUnits: Array<MasterFunctionalUnit> = new Array<MasterFunctionalUnit>();
    functionalArea: MasterFunctionalArea = new MasterFunctionalArea();
    dialogLabel: string = 'New Functional Area';
    oems = [];
    productCodes = [];

    platforms: Platform[] = <Platform[]>Constants.PLATFORMS;

    selectedPlatform: string;
    existingFaName: string;

    constructor(private functionalAreaService: MasterFunctionalAreaService, private functionalUnitService: MasterFunctionalUnitService,
        private _formBuilder: FormBuilder, @Inject(MAT_DIALOG_DATA) private data: any, private dialog: MatDialog, private toastrService: ToastrService,
        private dialogRef: MatDialogRef<NewFunctionalAreaComponent>) {
        dialogRef.disableClose = true;
        if (this.data.edit) {
            this.functionalArea = this.data.functionalArea;
            this.editMode = true;
            this.dialogLabel = 'Edit Functional Area';
            this.existingFaName = this.data.functionalArea.functionalAreaName;
        }
        if (this.data.clone) {
            this.functionalArea = this.data.functionalArea;
            this.cloneMode = true;
            this.editMode = false;
            this.dialogLabel = 'Clone Functional Area';
            this.functionalArea.id = null;
            this.functionalArea.functionalAreaName = this.functionalArea.functionalAreaName + ' - Clone';
        }
        this.oems=Constants.OEMS;
        this.productCodes=Constants.PRODUCT_CODES;
    }

    ngOnInit() {
        this.firstFormGroup = this._formBuilder.group({
            functionalAreaName: ['', Validators.required],
            templateType: ['', Validators.required],
            productCode: ['', Validators.required],
            productVersion: []
        });
        this.fetchFunctionalUnits();
        if (this.editMode || this.cloneMode) {
            this.platforms.forEach(platform => {
                this.functionalArea.platforms.forEach(platformSelected => {
                    if (platformSelected.platformCode == platform.platformCode) {
                        this.selectedPlatform = platform.platformName;
                    }
                });
            });
        }
    }

    fetchFunctionalUnits() {
        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
            width: '300px',
            height: '150px',
            data: { message: 'Fetching Functional Units ..' }
        });
        this.functionalUnitService
            .fetchMasterFunctionalUnitList()
            .subscribe(functionalUnits => {
                this.functionalUnits = functionalUnits.sort((s1, s2): number => {
                    if (s1.functionalUnitName < s2.functionalUnitName) return -1;
                    if (s1.functionalUnitName > s2.functionalUnitName) return 1;
                    return 0;
                });
                this.functionalUnits.forEach(fu => {
                    fu['selected'] = false;
                });
                this.filteredFunctionalUnits = this.functionalUnits;
                if (this.editMode || this.cloneMode) {
                    if (this.functionalArea.productCode) {
                        this.onProductChange(this.functionalArea.productCode);
                    }
                    this.functionalUnitService.fetchFunctionalUnitsOfMasterFunctionalArea(this.functionalArea.id)
                        .subscribe(functionalUnits => {
                            this.selectedFunctionalUnits = functionalUnits;
                            this.filteredFunctionalUnits.forEach(filteredFunctionalUnit => {
                                let foundFUs = functionalUnits.filter(functionalUnit => functionalUnit.recordType === filteredFunctionalUnit.id);
                                if (foundFUs.length > 0) {
                                    filteredFunctionalUnit['selected'] = true;
                                }
                            });
                            loaderDialogRef.close();
                        }, error => {
                            loaderDialogRef.close();
                        });
                } else {
                    loaderDialogRef.close();
                }
            }, error => {
                loaderDialogRef.close();
            });
    }

    onChange(fu: MasterFunctionalUnit, event: any) {
        if (!event.checked) {
            if (this.selectedFunctionalUnits.indexOf(fu) != -1) {
                this.selectedFunctionalUnits.splice(this.selectedFunctionalUnits.indexOf(fu), 1);
            }
        } else {
            this.selectedFunctionalUnits.push(fu);
        }
    }

    submitFunctionalArea(loaderDialogRef: any) {

        var req: MasterFunctionalArea = new MasterFunctionalArea();
        req.platforms = [];

        const platform = this.selectedPlatform;
        const selectedPlatforms = this.platforms.filter(function (e) {
            return e.platformName === platform;
        });
        selectedPlatforms.forEach(platform => platform.selected=true);
        
        const selectedFunctionalUnits = this.filteredFunctionalUnits.filter(function (e) {
            return e['selected'] === true;
        });

        if (this.editMode || this.cloneMode) {
            req = Object.assign({}, this.functionalArea);
        }
        else {
            req.functionalAreaName = this.functionalArea.functionalAreaName;
            req.functionalAreaType = "MasterFunctionalArea";
            req.oemName = this.functionalArea.oemName;
            req.version = this.functionalArea.version;
            req.productCode = this.functionalArea.productCode;
            req.productVersion = this.functionalArea.productVersion;
        }
        req.platforms = selectedPlatforms;

        this.functionalAreaService.createMasterFunctionalArea(req)
            .subscribe((functionalArea: any) => {
                let functionalUnitsToSave: MasterFunctionalUnit[] = [];
                selectedFunctionalUnits.forEach(functionalUnit => {
                    if (functionalUnit.recordType === 'FunctionalUnitInfo') {
                        let fu = new MasterFunctionalUnit();
                        fu.id = functionalArea.id;
                        fu.recordType = functionalUnit.id;
                        fu.functionalUnitType = 'ChildFunctionalUnit';
                        fu.functionalUnitName = functionalUnit.functionalUnitName;
                        fu.description = functionalUnit.description;
                        fu.gridOptionsModel = functionalUnit.gridOptionsModel;
                        fu.version = 0;
                        fu.productCode = functionalUnit.productCode;
                        functionalUnitsToSave.push(fu);
                    }
                });
                this.functionalUnitService.createMultipleFunctionalUnits(functionalUnitsToSave)
                    .subscribe(savedFunctionalUnits => {
                        loaderDialogRef.close();
                        this.dialogRef.close();
                    }, error => {
                        loaderDialogRef.close();
                        this.dialogRef.close();
                    });
            });
    }

    onProductChange(productCode: string) {
        this.filteredFunctionalUnits = Object.assign([], this.functionalUnits).filter(
            item => item.productCode && item.productCode.indexOf(productCode) > -1
        );
        this.selectedFunctionalUnits = [];
    }

    closePopup() {
        this.dialogRef.close(Constants.POPUP_CANCEL);
    }

    disableSaveButton() {
        const platform = this.selectedPlatform;
        const selectedPlatforms = this.platforms.filter(function (e) {
            return e.platformName === platform;
        });
        const selectedFunctionalUnits = this.filteredFunctionalUnits.filter(function (e) {
            return e['selected'] === true;
        });
        if (this.functionalArea.functionalAreaName && this.functionalArea.productCode &&
            selectedFunctionalUnits.length > 0 && selectedPlatforms.length > 0) {
            return false;
        }
        return true;
    }

    checkDuplicateFunctionalArea() {
        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
            width: '300px',
            height: '150px',
            data: { message: 'Saving Functional Area ..' }
        });
        this.functionalAreaService.fetchMasterFAByNameAndPlatformAndProductCode(this.functionalArea.functionalAreaName, this.selectedPlatform, this.functionalArea.productCode)
        .subscribe(genericResponse => {
            if(genericResponse != null && genericResponse != undefined && genericResponse.resultDescription == "OK" && genericResponse.resultDescription != null){
                if(this.data.edit){
                    if (this.existingFaName === this.functionalArea.functionalAreaName) {
                        if(genericResponse.resultObj.propagationStarted){
                            this.functionalArea.propagationStarted = true;
                            this.toastrService.error('Functional Area '+this.existingFaName+ ' Change Propagation is underway. No modifications can take place at this time. Please try later');
                            loaderDialogRef.close();
                        } else{
                            this.submitFunctionalArea(loaderDialogRef);
                        }
                    }else{
                        if(genericResponse.resultObj != null){
                            this.toastrService.error('Functional Area with this Name, Product Code and Platform combination already exists.');  
                            loaderDialogRef.close();
                        }else{
                            this.submitFunctionalArea(loaderDialogRef); 
                        }   
                    }
                }else{
                    if(genericResponse.resultObj !=null){
                        this.toastrService.error('Functional Area with this Name, Product Code and Platform combination already exists.');  
                        loaderDialogRef.close();
                    }else{
                        this.submitFunctionalArea(loaderDialogRef);  
                    }      
                }  
            }else{
                this.submitFunctionalArea(loaderDialogRef);  
            }
       },error => {
                loaderDialogRef.close();
                this.toastrService.warning('Error occurred while checking the duplicate functional area.');
            });
    }
}
