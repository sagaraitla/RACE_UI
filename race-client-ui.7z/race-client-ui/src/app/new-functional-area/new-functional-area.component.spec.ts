import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCheckboxModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatTableModule } from "@angular/material";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { ToastrModule } from "ngx-toastr";
import { Observable, of } from "rxjs";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { MasterFunctionalArea } from "../model/master-functional-area";
import { MasterFunctionalUnit } from "../model/master-functional-unit";
import { Platform } from "../model/master-platform";
import { AuthService } from "../services/auth-service";
import { MasterFunctionalAreaService } from "../services/master-functional-area-service";
import { MasterFunctionalUnitService } from "../services/master-functional-unit-service";
import { NewFunctionalAreaComponent } from "./new-functional-area.component";


describe('NewFunctionalAreaComponent', () => {

    let component : NewFunctionalAreaComponent;
    let fixture: ComponentFixture<NewFunctionalAreaComponent>;
    let masterFunctionalAreaService: MasterFunctionalAreaService;
    let masterFunctionalUnitService: MasterFunctionalUnitService;


    beforeEach(async(() => {

        let data= {
            edit:true,
            functionalArea:{
                functionalAreaName :"test"
            }
        }
        let data1= {
            clone:true,
            functionalArea:{
                functionalAreaName :"test"
            }
        }
        
        let data2 = {
          edit:false,
          functionalArea:{
              functionalAreaName :"test"
          }
      }
        TestBed.configureTestingModule({
            imports: [
                MatDialogModule,
                MatFormFieldModule,
                MatRadioModule,
                FormsModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatInputModule,
                MatTableModule,
                MatPaginatorModule,
                MatDialogModule,
                HttpClientTestingModule,
                ToastrModule.forRoot(),
                NoopAnimationsModule,
                MatProgressSpinnerModule ,
                ReactiveFormsModule,
                CommonModule,
                MatSelectModule,
                MatCheckboxModule
            ],
            declarations: [NewFunctionalAreaComponent,LoaderDialogueComponent],
            providers:[
                MasterFunctionalAreaService,
                MasterFunctionalUnitService,
                AuthService,
                { provide: MatDialogRef, useFactory: () => jasmine.createSpyObj('MatDialogRef', ['close', 'afterClosed']) },
                { provide: MAT_DIALOG_DATA, useValue: data }
             
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent]}});   

            masterFunctionalUnitService = TestBed.get(MasterFunctionalUnitService);
            masterFunctionalAreaService = TestBed.get(MasterFunctionalAreaService);
            fixture = TestBed.createComponent(NewFunctionalAreaComponent);
            component = fixture.componentInstance;

    }));

    const list_of_master_functional_unit_response: MasterFunctionalUnit[] =[
        {
            "functionalUnitType": "MasterFunctionalUnit",
            "functionalUnitName": "-A Configurations",
            "gridOptionsModel": {
              "animatedRows": false,
              "rowSelection": "multiple",
              "columnDefs": [
              ],
              "rowData":null
            },
            "description": "-A Configurations",
            "version": 0,
            "productCode": "SVC",
            "createdDate": null,
            "lastUpdatedDate": null,
            "propagationStarted": false,
            "id":"6eadd998-944b-44d9-a973-7e9159c26db7",
            "recordType": "FunctionalUnitInfo",
          },
          {
            "functionalUnitType": "MasterFunctionalUnit",
            "functionalUnitName": "Account Definition",
            "gridOptionsModel": {
              "animatedRows": false,
              "rowSelection": "multiple",
              "columnDefs": [
              ],
              "rowData":null
            },
            "description": "Account Definition",
            "version": 0,
            "productCode": "SVC",
            "createdDate": null,
            "lastUpdatedDate": null,
            "propagationStarted": false,
            "id": "6eadd998-944b-44d9-a973-7e9159c26db7",
            "recordType": "FunctionalUnitInfo"
          }
    ]  

    const functionalArea : MasterFunctionalArea ={
      "functionalAreaType": "MasterFunctionalArea",
          "functionalAreaName": "UI_Test",
          "oemName": null,
          "platforms": [
            {
              "id": null,
              "platformName": "DRIVE",
              "platformCode": "drive",
              "selected": true,
              "recordType":null
            }
          ],
          "version": "0",
          "productCode": "SVC",
          "productVersion": "11",
          "propagationStarted": false,
          "noOfFunctionalUnits": null,
          "id": "ac27a733-e109-40c4-b15f-5f2909c6ff4c",
          "recordType": "FunctionalAreaInfo"
    };

    const genericResponse_null : any =null;

    const genericResponse :any ={
      "resultCode": "CDK_200",
      "resultDescription": "OK",
      "resultObj": {},
      "executionTime": 9
    }
    
    const genericResponse1 :any ={
      "resultCode": "CDK_200",
      "resultDescription": "OK",
      "resultObj":null,
      "executionTime": 9
    }

    const genericResponse2 :any ={
      "resultCode": "CDK_200",
      "resultDescription": "OK",
      "resultObj":{
        propagationStarted: true
      },
      "executionTime": 9
    }

    const genericResponse3 : any ={
      "resultCode": "CDK_200",
      "resultDescription": "OK",
      "resultObj":{
        propagationStarted: false
      },
      "executionTime": 9
    }

    
    const genericResponse4 : any ={
      "resultCode": "CDK_200",
      "resultDescription": "OK",
      "resultObj":null,
      "executionTime": 9
    }
    it('should be created', async(() => {

       let myPlatforms: Platform[] = [
            {
                    id:"01",
                    recordType:"11111",
                    platformName: "FLEX",
                    platformCode: "flex",
                    selected: true,      
            }
        ]

        
        let  functionalArea = new MasterFunctionalArea();
        functionalArea.platforms = myPlatforms;

        fixture = TestBed.createComponent(NewFunctionalAreaComponent);
        component = fixture.componentInstance;
        component.functionalArea = functionalArea;
        spyOn(component, 'fetchFunctionalUnits').and.returnValue({code:'success'});
        fixture.detectChanges();
        expect(component.fetchFunctionalUnits).toHaveBeenCalledTimes(1);
        expect(component).toBeTruthy();

      }));


      it('test fetchFunctionalUnits',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        component.functionalArea.productCode = "SVC";
        spyOn(component,'onProductChange')
        spyOn(masterFunctionalUnitService,'fetchMasterFunctionalUnitList').and.returnValue(Observable.of(list_of_master_functional_unit_response));
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitsOfMasterFunctionalArea').and.returnValue(Observable.of(list_of_master_functional_unit_response));
    
        component.fetchFunctionalUnits();

        expect(masterFunctionalUnitService.fetchMasterFunctionalUnitList).toHaveBeenCalledTimes(1);
        expect(masterFunctionalUnitService.fetchFunctionalUnitsOfMasterFunctionalArea).toHaveBeenCalledTimes(1);
      });

      it('test fetchFunctionalUnits not in either edit or clone mode',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        component.editMode = false;
        component.cloneMode = false;
        component.functionalArea.productCode = "SVC";
         spyOn(component,'onProductChange')
        spyOn(masterFunctionalUnitService,'fetchMasterFunctionalUnitList').and.returnValue(Observable.of(list_of_master_functional_unit_response));
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitsOfMasterFunctionalArea').and.returnValue(Observable.of(list_of_master_functional_unit_response));
     
        component.fetchFunctionalUnits();
        
        expect(masterFunctionalUnitService.fetchMasterFunctionalUnitList).toHaveBeenCalledTimes(1);
        expect(masterFunctionalUnitService.fetchFunctionalUnitsOfMasterFunctionalArea).toHaveBeenCalledTimes(0);
      });

      it('should  fetchFunctionalUnitsOfMasterFunctionalArea throw error in fetchFunctionalUnits ' ,()=> {

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        component.functionalArea.productCode = "SVC";
        spyOn(component,'onProductChange')
        spyOn(masterFunctionalUnitService,'fetchMasterFunctionalUnitList').and.returnValue(Observable.of(list_of_master_functional_unit_response));
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitsOfMasterFunctionalArea').and.returnValue(Observable.throw('error'))
     
        component.fetchFunctionalUnits();
        
        expect(masterFunctionalUnitService.fetchMasterFunctionalUnitList).toHaveBeenCalledTimes(1);
        expect(masterFunctionalUnitService.fetchFunctionalUnitsOfMasterFunctionalArea).toHaveBeenCalledTimes(1);
      });

      it('should  fetchMasterFunctionalUnitList throw error in fetchFunctionalUnits ' ,()=> {

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        spyOn(masterFunctionalUnitService,'fetchMasterFunctionalUnitList').and.returnValue(Observable.throw('error'));
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitsOfMasterFunctionalArea').and.returnValue(Observable.of(list_of_master_functional_unit_response));
     
        component.fetchFunctionalUnits();
        
        expect(masterFunctionalUnitService.fetchMasterFunctionalUnitList).toHaveBeenCalledTimes(1);
        expect(masterFunctionalUnitService.fetchFunctionalUnitsOfMasterFunctionalArea).toHaveBeenCalledTimes(0);
      });


      it('test onProductChange',()=>{

        let functionalUnits = new Array<MasterFunctionalUnit>();
        functionalUnits = [
          {
            "functionalUnitType": "MasterFunctionalUnit",
            "functionalUnitName": "Departments",
            "gridOptionsModel": {
                "animatedRows": false,
                "rowSelection": "multiple",
                "columnDefs": [
                ],
                "rowData":null
              },
            "description": "Departments",
            "version": 0,
            "productCode": "ACCT",
            "propagationStarted": false,
            "createdDate":null,
            "lastUpdatedDate":null,
            "id": "6c44e2da-3bed-4773-87c0-ed257c861943",
            "recordType": "FunctionalUnitInfo"
          }
        ]
        component.functionalUnits = functionalUnits;
        component.onProductChange("ACCT");
        expect(component.selectedFunctionalUnits.length).toEqual(0)
      });

      it('test disableSaveButton',()=>{

    
        component.selectedPlatform ="FLEX";
        let myPlatforms: Platform[] = [
          {
                  id:"01",
                  recordType:"11111",
                  platformName: "FLEX",
                  platformCode: "flex",
                  selected: true,      
          }
      ]
      component.platforms = myPlatforms;
      let filteredFunctionalUnits = new Array<MasterFunctionalUnit>();
      filteredFunctionalUnits = [
          {
            "functionalUnitType": "MasterFunctionalUnit",
            "functionalUnitName": "Departments",
            "gridOptionsModel": {
                "animatedRows": false,
                "rowSelection": "multiple",
                "columnDefs": [
                ],
                "rowData":null
              },
            "description": "Departments",
            "version": 0,   
            "productCode": "ACCT",
            "propagationStarted": false,
            "createdDate":null,
            "lastUpdatedDate":null,
            "id": "6c44e2da-3bed-4773-87c0-ed257c861943",
            "recordType": "FunctionalUnitInfo"
          }
        ]

        component.filteredFunctionalUnits = filteredFunctionalUnits;
        component.functionalArea = functionalArea;
        component.selectedFunctionalUnits.length =2;
        component.disableSaveButton();

      })



      it('test checkDuplicateFunctionalArea if duplicate record is not exist',()=>{

        spyOn(masterFunctionalAreaService,'fetchMasterFAByNameAndPlatformAndProductCode').and.returnValue(Observable.of(genericResponse_null));
        spyOn(component,'submitFunctionalArea').and.returnValue({code:'success'});
        component.checkDuplicateFunctionalArea();

        expect(masterFunctionalAreaService.fetchMasterFAByNameAndPlatformAndProductCode).toHaveBeenCalledTimes(1);
        expect(component.submitFunctionalArea).toHaveBeenCalledTimes(1);

      });


      it('test checkDuplicateFunctionalArea in editMode and existingFAName and DBFAName not same',()=>{
      
        spyOn(masterFunctionalAreaService,'fetchMasterFAByNameAndPlatformAndProductCode').and.returnValue(Observable.of(genericResponse));
        
        component.functionalArea  = functionalArea;
        component.existingFaName = 'TEST'
        component.checkDuplicateFunctionalArea();

        expect(masterFunctionalAreaService.fetchMasterFAByNameAndPlatformAndProductCode).toHaveBeenCalledTimes(1);

      });


      it('test checkDuplicateFunctionalArea  not in editMode',()=>{
        
        component['data'].edit = false;
        spyOn(masterFunctionalAreaService,'fetchMasterFAByNameAndPlatformAndProductCode').and.returnValue(Observable.of(genericResponse));
        component.checkDuplicateFunctionalArea();
        expect(masterFunctionalAreaService.fetchMasterFAByNameAndPlatformAndProductCode).toHaveBeenCalledTimes(1);
        expect(component['data'].edit).toBeFalsy();

      });

      it('test checkDuplicateFunctionalArea in editMode and resultObj is null',()=>{
        
        component.functionalArea  = functionalArea;
        component.existingFaName = 'TEST'
        component['data'].edit = true;
        spyOn(masterFunctionalAreaService,'fetchMasterFAByNameAndPlatformAndProductCode').and.returnValue(Observable.of(genericResponse1));
        spyOn(component,'submitFunctionalArea').and.returnValue({code:'success'});
        component.checkDuplicateFunctionalArea();
        expect(masterFunctionalAreaService.fetchMasterFAByNameAndPlatformAndProductCode).toHaveBeenCalledTimes(1);
        expect(component['data'].edit).toBeTruthy();

      });

      it('test checkDuplicateFunctionalArea fetchMasterFAByNameAndPlatformAndProductCode throw error',()=>{
         
        spyOn(masterFunctionalAreaService,'fetchMasterFAByNameAndPlatformAndProductCode').and.returnValue(Observable.throw('error'));
        component.checkDuplicateFunctionalArea();
        expect(masterFunctionalAreaService.fetchMasterFAByNameAndPlatformAndProductCode).toHaveBeenCalledTimes(1);
        

      });

      it('test checkDuplicateFunctionalArea for propagation underway',()=>{
         
        component.functionalArea  = functionalArea;
        component.existingFaName = 'UI_Test'
        spyOn(masterFunctionalAreaService,'fetchMasterFAByNameAndPlatformAndProductCode').and.returnValue(Observable.of(genericResponse2));
        component.checkDuplicateFunctionalArea();
        expect(masterFunctionalAreaService.fetchMasterFAByNameAndPlatformAndProductCode).toHaveBeenCalledTimes(1);
      });


      it('test checkDuplicateFunctionalArea for propagation not started',()=>{
         
        component.functionalArea  = functionalArea;
        component.existingFaName = 'UI_Test'
        spyOn(masterFunctionalAreaService,'fetchMasterFAByNameAndPlatformAndProductCode').and.returnValue(Observable.of(genericResponse3));
        spyOn(component,'submitFunctionalArea').and.returnValue({code:'success'});
        component.checkDuplicateFunctionalArea();
        expect(masterFunctionalAreaService.fetchMasterFAByNameAndPlatformAndProductCode).toHaveBeenCalledTimes(1);
      });


      
      it('test checkDuplicateFunctionalArea  not in editMode and response is null',()=>{
        
        component['data'].edit = false;
        spyOn(masterFunctionalAreaService,'fetchMasterFAByNameAndPlatformAndProductCode').and.returnValue(Observable.of(genericResponse4));
        spyOn(component,'submitFunctionalArea').and.returnValue({code:'success'});
        component.checkDuplicateFunctionalArea();
        expect(masterFunctionalAreaService.fetchMasterFAByNameAndPlatformAndProductCode).toHaveBeenCalledTimes(1);
        expect(component['data'].edit).toBeFalsy();

      });

      it('test submitFunctionalArea',()=>{
        
       
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj); 
      
        let loaderDialogRef:any={
          close(value = '') {
          }
        }
        const list_of_master_functional_unit_response1: any[] =[
          {
              "functionalUnitType": "MasterFunctionalUnit",
              "functionalUnitName": "-A Configurations",
              "gridOptionsModel": {
                "animatedRows": false,
                "rowSelection": "multiple",
                "columnDefs": [
                ],
                "rowData":null
              },
              "description": "-A Configurations",
              "version": 0,
              "productCode": "SVC",
              "createdDate": null,
              "lastUpdatedDate": null,
              "propagationStarted": false,
              "id":"6eadd998-944b-44d9-a973-7e9159c26db7",
              "recordType": "FunctionalUnitInfo",
              "selected": true,
              "updatedBy": null
            }
      ] 
        component.filteredFunctionalUnits = list_of_master_functional_unit_response1;
        spyOn(masterFunctionalAreaService,'createMasterFunctionalArea')
        .and.returnValue(Observable.of(functionalArea));
        spyOn(masterFunctionalUnitService,'createMultipleFunctionalUnits')
        .and.returnValue(Observable.of(list_of_master_functional_unit_response));
        component.submitFunctionalArea(loaderDialogRef);

        expect(masterFunctionalAreaService.createMasterFunctionalArea).toHaveBeenCalledTimes(1);
        expect(masterFunctionalUnitService.createMultipleFunctionalUnits).toHaveBeenCalledTimes(1);
      });
  

      it('test submitFunctionalArea in editMode',()=>{
        
       
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj); 
      
        let loaderDialogRef:any={
          close(value = '') {
          }
        }
        component.editMode = false;
        const list_of_master_functional_unit_response1: any[] =[
          {
              "functionalUnitType": "MasterFunctionalUnit",
              "functionalUnitName": "-A Configurations",
              "gridOptionsModel": {
                "animatedRows": false,
                "rowSelection": "multiple",
                "columnDefs": [
                ],
                "rowData":null
              },
              "description": "-A Configurations",
              "version": 0,
              "productCode": "SVC",
              "createdDate": null,
              "lastUpdatedDate": null,
              "propagationStarted": false,
              "id":"6eadd998-944b-44d9-a973-7e9159c26db7",
              "recordType": "FunctionalUnitInfo",
              "selected": true,
              "updatedBy": null
            }
      ] 
        component.filteredFunctionalUnits = list_of_master_functional_unit_response1;
        spyOn(masterFunctionalAreaService,'createMasterFunctionalArea')
        .and.returnValue(Observable.of(functionalArea));
        spyOn(masterFunctionalUnitService,'createMultipleFunctionalUnits')
        .and.returnValue(Observable.of(list_of_master_functional_unit_response));
        component.submitFunctionalArea(loaderDialogRef);

        expect(masterFunctionalAreaService.createMasterFunctionalArea).toHaveBeenCalledTimes(1);
        expect(masterFunctionalUnitService.createMultipleFunctionalUnits).toHaveBeenCalledTimes(1);
      });
      it('test submitFunctionalArea throws error',()=>{
        
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj); 
      
        let loaderDialogRef:any={
          close(value = '') {
          }
        }
        component.editMode = false;
        const list_of_master_functional_unit_response1: any[] =[
          {
              "functionalUnitType": "MasterFunctionalUnit",
              "functionalUnitName": "-A Configurations",
              "gridOptionsModel": {
                "animatedRows": false,
                "rowSelection": "multiple",
                "columnDefs": [
                ],
                "rowData":null
              },
              "description": "-A Configurations",
              "version": 0,
              "productCode": "SVC",
              "createdDate": null,
              "lastUpdatedDate": null,
              "propagationStarted": false,
              "id":"6eadd998-944b-44d9-a973-7e9159c26db7",
              "recordType": "FunctionalUnitInfo",
              "selected": true,
              "updatedBy": null
            }
      ] 
        component.filteredFunctionalUnits = list_of_master_functional_unit_response1;
        spyOn(masterFunctionalAreaService,'createMasterFunctionalArea')
        .and.returnValue(Observable.of(functionalArea));
        spyOn(masterFunctionalUnitService,'createMultipleFunctionalUnits')
        .and.returnValue(Observable.throwError('error'));
        component.submitFunctionalArea(loaderDialogRef);

        expect(masterFunctionalAreaService.createMasterFunctionalArea).toHaveBeenCalledTimes(1);
        expect(masterFunctionalUnitService.createMultipleFunctionalUnits).toHaveBeenCalledTimes(1);
      });

      it('test closePopup',()=>{
        component.closePopup();
      });

      it('test onChange',()=>{
        let masterFunctionalUnit:MasterFunctionalUnit={
            "functionalUnitType": "MasterFunctionalUnit",
            "functionalUnitName": "-A Configurations",
            "gridOptionsModel": {
              "animatedRows": false,
              "rowSelection": "multiple",
              "columnDefs": [
              ],
              "rowData":null
            },
            "description": "-A Configurations",
            "version": 0,
            "productCode": "SVC",
            "createdDate": null,
            "lastUpdatedDate": null,
            "propagationStarted": false,
            "id":"6eadd998-944b-44d9-a973-7e9159c26db7",
            "recordType": "FunctionalUnitInfo",
  
        }
        let event:any={checked:false}
        component.selectedFunctionalUnits = list_of_master_functional_unit_response;
        component.onChange(masterFunctionalUnit,event)
      });

      it('test onChange event is not checked',()=>{
        let masterFunctionalUnit:MasterFunctionalUnit={
            "functionalUnitType": "MasterFunctionalUnit",
            "functionalUnitName": "-A Configurations",
            "gridOptionsModel": {
              "animatedRows": false,
              "rowSelection": "multiple",
              "columnDefs": [
              ],
              "rowData":null
            },
            "description": "-A Configurations",
            "version": 0,
            "productCode": "SVC",
            "createdDate": null,
            "lastUpdatedDate": null,
            "propagationStarted": false,
            "id":"6eadd998-944b-44d9-a973-7e9159c26db7",
            "recordType": "FunctionalUnitInfo",
  
        }
        let event:any={checked:true}
        component.selectedFunctionalUnits = list_of_master_functional_unit_response;
        component.onChange(masterFunctionalUnit,event)
      });
}) ;