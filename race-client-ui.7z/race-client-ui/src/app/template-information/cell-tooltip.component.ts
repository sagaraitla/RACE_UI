import { Component, OnInit } from '@angular/core';
import { AgRendererComponent } from 'ag-grid-angular';

@Component({
  selector: 'ag-grid-cell-tooltip',
  templateUrl: './cell-tooltip.component.html',
  styleUrls: ['./template-information.component.css']
})
export class AgGridCellTooltipRenderer implements AgRendererComponent {

    cellValue;
    message : string;
	errorLevelWarning:boolean;
	isDropDown :boolean;
    constructor() {
    }

    agInit(params): void {
			
		if(params.colDef.dataType==='DROPDOWN' || params.colDef.dataType==='GROUPEDMULTIVALUEDROPDOWN' ||params.colDef.dataType==='MULTIVALUEDROPDOWN'||params.colDef.dataType==='MULTIVALUE'){
			this.isDropDown=true;	
		}
    	this.cellValue = params.data[params.column.getId()];
    	if(params.colDef.cellEditor == 'agLargeTextCellEditor') {
    		if(!params.colDef.cellEditorParams.rows) {
    			params.colDef.cellEditorParams.rows = 2;
    		}
    		if(!params.colDef.cellEditorParams.cols) {
    			params.colDef.cellEditorParams.cols = 22;
    		}
    	}
    	if(params.data.error && params.rowIndex == params.data.error.rowIndex) {
			let errors = params.data.error.errors.filter(function(errorObj) {
				return (errorObj && errorObj.errorField == params.colDef.field);
			});
	  		if(errors && errors.length > 0) {
				  this.message = errors[0].errorDescription;
				  this.errorLevelWarning = errors[0].errorLevel=== "Validation_Warning";
	  		}
	    }
   }

    refresh(params: any): boolean {
        return true;
    }
}

export type CellAction = (params) => void;