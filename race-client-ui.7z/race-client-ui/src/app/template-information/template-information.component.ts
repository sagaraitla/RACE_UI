
import {forkJoin as observableForkJoin, interval as observableInterval,  Observable } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as FileSaver from 'file-saver'; 
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FunctionalAreaService } from '../services/functional-area-service';
import { FunctionalUnitService } from '../services/functional-unit-service';
import { DataTransferService } from '../services/data-transfer-service';
import { AuthService } from '../services/auth-service';
import { RowDataService } from '../services/rowdata-service';
import { ProjectObject } from '../model/project-object';
import { StoreObject } from '../model/store-object';
import { StoreService } from '../services/store-service';
import { TemplateObject } from '../model/template-object';
import { PlatformObject } from '../model/platform-object'
import { ScreenObject } from '../model/screen-object';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { AgGridCellTooltipRenderer } from './cell-tooltip.component';

import { Router } from '@angular/router';
import {BootstrapDatePickerComponent} from "../editor-components/date-picker.component";
import * as moment from 'moment';
import { GridOptions } from 'ag-grid/main';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {MultivalueDialogComponent} from '../multivalue-dialog/multivalue-dialog.component';

import {MultivalueDropdownDialogComponent} from '../multivalue-dropdown-dialog/multivalue-dropdown-dialog.component';
import { GroupedMultivalueDialogComponent } from '../multivalue-dropdown-with-grouping/multivalue-dropdown-with-grouping.component';
import { ExcelService } from '../services/excel-service';
import { BestPracticeService } from '../services/bestpractice-service';
import { ProjectService } from '../services/project-service';
import { ValidationService} from '../services/validation-service';
import { FormattingService } from '../services/formatting-service';
import {ConfirmDialogComponent} from '../confirm-dialog/confirm-dialog.component';
import { AlertDialogComponent } from '../alert-dialog/alert-dialog.component';
import { FlexDashService } from '../services/flex-dash.service';
import { DashReport } from '../model/dash-report';
import {FlexApi} from '../model/flex-api-objects';
import { DashReportComponent } from '../dash-report/dash-report.component';
import { ToastrService } from 'ngx-toastr';
import { BestPracticeObject } from '../model/bestpractice-object';
import { SSSObject } from '../model/sss-object';
import { ProcessValidationResultsComponent } from '../process-validation-results/process-validation-results.component';
import { Constants } from '../constant/constants';
import { BPFUPropagateChangesDialogComponent } from '../bp-fu-propagate-changes-dialog-details/bp-fu-propagate-changes-dialog.component';

@Component({
  selector: 'app-template-information',
  templateUrl: './template-information.component.html',
  styleUrls: ['./template-information.component.css']
})
export class TemplateInformationComponent implements OnInit, OnDestroy {

  projectObject: ProjectObject = new ProjectObject();
  templateObject : TemplateObject = new TemplateObject();
  storeObject: StoreObject = new StoreObject();
  dashReport: DashReport=new DashReport();
  flexApi: FlexApi=new FlexApi();
  sssObject: SSSObject = new SSSObject();
  templateContext: any;


  firstFormGroup: FormGroup; 
  projectNumber : string;
  storeName : string;
  storeId : string;
  functionalAreaId:string;
  templateName : string;
  dataSource : any;
  showGrid : boolean =false;
  currentScreen : ScreenObject = null;
  currentScreenContext: any = null;
  deletedRowIds : any = {};

  gridApi : any;
  gridColumnApi : any;
  index:any;
  templateId : string;
  editGridPermissionForVIC = false;    
  createProjectPermission = false;  
  adminPermission = false;
  message : string = "Template data saved successfully!";
  showMessage : boolean=false;
  stepperStatus: string = 'Data Collection';
  status : string = 'Work in Progress';
  currentScreenIndex: number = 0;
  startingIndexOrRecordType: number = 1000;
  functionalUnits: ScreenObject[];
  matchedFunctionalAreas : TemplateObject[];

  errorMessage : string ="Error occurred while saving the Template data! Please try again..";
  showErrorMessage : boolean =false;
  
  statusList : string[] = ['Data Collection', 'Validation', 'Start Setup', 'Complete'];
  fileToUpload:File = null;

  unsavedDataPresent = false;    
  fieldNewVal : string;
  managerHierachy: Array<string> = new Array<string>();
  enterpriseManagerHierachy : Array<string> = new Array<string>();
  currentEmpNoList : Array<string> = new Array<string>();
  managerName : string;
  enterpriseStoreData : StoreObject = new StoreObject();
  isEnterpriseStore : string;
  isBestPractice : boolean = false;
  versionName : string = "";
  
  templateReceived = false;  
  timer = observableInterval(20 * 1000);
  subscription :any;
  
  currentIndex : number = 0;
  emptyRequiredFieldCount : number = 0;
  recentFileToUpload:File = null;  
  
isProjectSourceEnvDash=false;
loggedInUserRoleList: any;
isDealerApproverLogin: boolean=false;
isDealerApproved=false;
dealerApproverName: string;
dealerApprovePermission:boolean=false;
isStateStandard: boolean = false;
isSSSNavigatedFromProject:boolean=false;
isProject: boolean=true;
bp_auditlog_name: any;
bp_auditlog_msg: any;
auditlog_type: any;
sssVersion: any;
sssName: any;
sssStore: any;
sssFaName:any;
importColumnList=[];
verticalStepperInput = {};
bestPracticePlatformCode: string;
processValidationCompleteOrOverridden:boolean=false;
showProcessValidationResultButton:boolean = false; 
  constructor(private _formBuilder: FormBuilder,private functionalAreaService: FunctionalAreaService, private functionalUnitService: FunctionalUnitService,
		  private dataTransferService : DataTransferService, private authService: AuthService, 
		  private route : ActivatedRoute,private router: Router, private dialog: MatDialog,
		  private excelService : ExcelService, private validationService : ValidationService,
          private formattingService: FormattingService, private bestPracticeService : BestPracticeService, 
          private projectService : ProjectService, private storeService : StoreService, private rowDataService : RowDataService,private flexDashService :FlexDashService,private toastrService: ToastrService ) {
            
      this.projectNumber =this.route.snapshot.params.projectNumber;
      this.templateId = this.route.snapshot.params.templateId;
      this.isEnterpriseStore=this.route.snapshot.params.enterpriseStore;
      this.storeId =this.route.snapshot.params.storeId;
      this.functionalAreaId =this.route.snapshot.params.functionalAreaId;      
      
      this.isBestPractice = this.route.snapshot.params.isBestPractice ? true : false;
      this.projectObject.platform = new PlatformObject();
      this.projectObject.storeIds = [];
      this.managerHierachy=[];
      this.currentEmpNoList =[];
      this.isStateStandard = this.route.snapshot.params.isStateStandard?true:false;
      this.bestPracticePlatformCode = this.route.snapshot.params.platformCode;
      this.isSSSNavigatedFromProject = this.route.snapshot.params.isSSSNavigatedFromProject?true:false;
      this.verticalStepperInput['bestPractice']=this.isBestPractice;
      this.verticalStepperInput['sss']= this.isStateStandard;
      this.verticalStepperInput['sssNavigatedFromProject']= this.isSSSNavigatedFromProject;

      if( this.isBestPractice ||  this.isStateStandard || this.isSSSNavigatedFromProject ) {
          this.isProject = false;
      }
      
      if(!this.isBestPractice && !this.isStateStandard && !this.isSSSNavigatedFromProject)
      {          
      this.authService.fetchLoggedInUserAndPermissions().subscribe((data: any) => {
	      this.projectService.getProjectByNumber(this.projectNumber).subscribe((tempProject:any)=>{
                  this.storeService.getStore(tempProject.id,this.storeId).subscribe( (storeObject : StoreObject) =>
                  {
                      this.storeObject = storeObject;
                  });
                  this.projectService.getStoresOfProject(tempProject.id).subscribe((tempStores:any) => {
	              tempStores.filter((tempStore)=>{
	                  if(tempStore.enterpriseStore==true){
	                      this.enterpriseStoreData=tempStore;
	                  }
	              });
	          }) ;
	       });
      });
    }
  }

  ngOnInit() {

    
      this.authService.fetchLoggedInUserAndPermissions().subscribe((data: any) => {
        if(this.isBestPractice || this.isStateStandard)
        {  
            this.getBestPracticeVersionInfo();
        }
          this.getTemplateInfo();
          if(this.isEnterpriseStore=='false' && this.isBestPractice==false && this.isStateStandard == false && this.isSSSNavigatedFromProject == false){
            this.projectNumber =this.route.snapshot.params.projectNumber;
            this.projectService.getProjectByNumber(this.projectNumber).subscribe((tempProject:any)=>{
               this.projectObject = tempProject;
                this.projectService.getStoresOfProject(tempProject.id).subscribe((tempStores:any) => {
                   tempStores.filter((tempStore)=>{
                       if(tempStore.enterpriseStore==true){
                           this.enterpriseStoreData=tempStore;
                           this.populateManagerHierarchy(this.enterpriseStoreData);
                       }
                   });
               }) ;
               this.dealerApproverCriteria();
            });
        } 
          this.showGrid = false;
	      this.adminPermission = this.authService.isAuthorised('DOT_ADMIN');
	      this.editGridPermissionForVIC = this.checkForEditGridPermission(false);    
	      this.createProjectPermission = this.adminPermission || this.authService.isAuthorised('DOT_PROJECT_CREATE');
	      this.dealerApprovePermission = this.authService.isAuthorised('RACE_FUNCTIONAL_AREA_STATUS_UPDATE'); 
      });
      this.unsavedDataPresent = false; 
      this.firstFormGroup = this._formBuilder.group({
          firstCtrl: ['', Validators.required]
        });
      
      this.managerHierachy=[];
      this.subscription = this.timer.subscribe(t=> {
          let refreshableStatuses = ['Validation in Progress', 'Sent to DMS'];
          if(this.templateReceived) {
              if(refreshableStatuses.indexOf(this.templateObject.status) > -1) {
                   this.functionalAreaService.getFunctionalAreaById(this.templateObject.id,this.templateObject.recordType) 
                    .subscribe(functionalArea => {
                        if(functionalArea != null && functionalArea != undefined){
                            this.templateObject = functionalArea;
                            this.showProcessValidationResultButton = functionalArea.showProcessValidationResultsButton;
                            this.processValidationCompleteOrOverridden = functionalArea.showValidateOrTransferButton;
                            this.setStepperStatus(this.templateObject.status);
                        }
                       
                    }, error => {
                    });
              }
          }
      });
  }
  
  ngOnDestroy() {
      this.subscription.unsubscribe();
  }

  dealerApproverCriteria()
  {
     
    if(this.projectObject.projectSourceEnv=="DASH"){
        this.isProjectSourceEnvDash=true;
        if(this.projectObject.dealerApproverRequired){
        this.dealerApproverName=this.projectObject.dealerApproverContact;
        this.statusList=[];
        this.statusList =['Data Collection','Dealer Approval', 'Validation', 'Start Setup', 'Complete'];
        if(this.checkLogInForDealerApprover()==true){
                   this.showDealerApproveButton();
                    this.editGridPermissionForVIC = this.checkForEditGridPermission(false);
                }
            }
       }
  }
  checkLogInForDealerApprover(): boolean
  {
    
    this.loggedInUserRoleList.forEach(roles =>{
        if(roles.roleName==="DOT - Dealer Approver" && this.dealerApprovePermission){
            this.isDealerApproverLogin=true;
                return true;
        }
    });
    return true;
  }
  
  
  populateManagerHierarchy(enterpriseStore:StoreObject){
	        this.functionalAreaService.getFunctionalAreasByStoreId(false, enterpriseStore.recordType).subscribe(tempTemplates=>{  
      tempTemplates.filter(template=>{
	         if(template.functionalAreaName.toUpperCase().match(/EMPLOYEE*/)){
                 this.functionalAreaService.getFullFunctionalAreaByStoreIdAndFunctionalAreaId(template.id,template.recordType).subscribe(templateContext=>{
	        		 templateContext.screenContextList.filter(tempScreenContext=>{
	        			 if(tempScreenContext.screen.screenName.toUpperCase().match(/EMPLOYEE*/)){
	        				 tempScreenContext.rowData.filter(tempRowData=>{
	        					 if(tempRowData.management=='Y' || tempRowData.management=='y' ){
	                                 this.enterpriseManagerHierachy.push(tempRowData.name); 
	                             }
	        				 });
	        			 }
	        		 });
	        	 });
	         }
	     });
      });
  }
  
  getTemplateInfo(){
      let me = this;
      let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
          width: '300px',
          height: '150px',
          data: { message: 'Fetching Template Information.' }
      });
      
      this.storeId =this.route.snapshot.params.storeId;
      this.functionalAreaId =this.route.snapshot.params.functionalAreaId;  
      
      if(this.isSSSNavigatedFromProject){
        this.sssObject=JSON.parse(sessionStorage.getItem("sssObject"));
        this.sssVersion=this.sssObject.sssVersion;
        this.sssName=this.sssObject.sssName;
        this.sssStore=this.sssObject.sssStore;
        this.sssFaName=this.sssObject.sssFaName;
        this.projectNumber =this.sssObject.projectNumber;
        this.storeId=this.sssObject.stateStandardVersionRecordType;
        this.functionalAreaId =this.sssObject.sssFAId;
        }

      this.functionalAreaService.getFunctionalAreaById(this.storeId, this.functionalAreaId)
      .subscribe(
           functionalArea => {
        	   this.templateContext = {
        	        template : functionalArea,
        	        screenContextList: []
        	   }
               this.templateObject = functionalArea;
               if(this.isEnterpriseStore=='false' && this.isBestPractice==false && this.isStateStandard == false && this.isSSSNavigatedFromProject == false){
                this.showProcessValidationResultButton = this.templateObject.showProcessValidationResultsButton;
                this.processValidationCompleteOrOverridden = this.templateObject.showValidateOrTransferButton;
           }
        	   this.functionalUnitService.getFunctionalUnitsOfFunctionalArea(this.functionalAreaId)
        	   .subscribe(
        	       screens => {
        	    	   if(screens != null && screens.length > 0) {
        	    		   let screenContext = null;
        	    		   this.functionalUnits = screens;
	    		    	   for(let screen of screens) {
                               if(screen.gridOptionsModel.columnDefs[0] !== undefined && screen.gridOptionsModel.columnDefs[0] !== null) {
                                    screen.gridOptionsModel.columnDefs[0].rowDrag=true;
                               }
	    		    		   screenContext = {screen : screen, rowData: []};
        	    			   this.templateContext.screenContextList.push(screenContext);
        	    		   }
	    		    	   this.currentScreenContext = this.templateContext.screenContextList[this.currentScreenIndex];
	    	        	   this.currentScreen = this.currentScreenContext.screen;
	    	        	   loaderDialogRef.close();
	    	        	   this.fetchDataForCurrentScreen(true);
        	    	   } else {
        	    		   this.toastrService.warning('No screens configured on the template');
                           loaderDialogRef.close();
                           this.templateReceived = true;
        	    	   }
        	       },
        	       error => {
        	    	   this.toastrService.error('Error occurred while fetching screens ' + error.error.message);
                       loaderDialogRef.close();
                       this.templateReceived = false;
        	       }
        	   );
           },
           error=>{
               console.log(error)
        	   this.toastrService.error('Error occurred while fetching template ' + error.error.message);
               loaderDialogRef.close();
               this.templateReceived = false;
           }
      );
  }
  
  getBestPracticeVersionInfo()
    {
       this.getBestPracticeDetailsByName(this.projectNumber, this.bestPracticePlatformCode,false).subscribe( bpObject =>
            {
                let bpVersionId =this.route.snapshot.params.storeId;
                this.bestPracticeService.getVersionOfBestPractice(bpObject.id,bpVersionId, false).subscribe(bestPracticeVersion =>
                {
                    this.versionName = bestPracticeVersion.versionName;
                });              

            }

        );

    }

  processTemplateGrid(loaderDialogRef: any) {
	  if(this.templateObject.screenIds) {
		  for(let screenId of this.templateObject.screenIds) {
			  this.deletedRowIds[screenId] = [];
		  }
	  }
	  if(this.templateContext.screenContextList != null && this.templateContext.screenContextList.length > 0) {
      	this.templateContext.screenContextList.filter(screenContext => {
               if(!this.isBestPractice)
               {
                // This need to be implemented along with rewriting of pickValuesFromStore() method as per new design
                // this.projectService.getProjectByNumber(this.projectNumber).subscribe( projectObj => {
                //             this.storeService.getStore(projectObj.id, this.storeId).subscribe( stores => {
                //             this.storeObject = stores[0];
                //             this.pickValuesFromStore(this.currentScreen);
                //             });
      
                // });
                }    
        	  
        	  	this.editGridPermissionForVIC = this.checkForEditGridPermission(false);
            	this.setStepperStatus(this.templateObject.status);
          	let tempScreen = screenContext.screen;
          	tempScreen.gridOptionsModel.rowSelection='multiple';
            this.currentIndex = screenContext.rowData.length;
            if(tempScreen.gridOptionsModel.columnDefs[0] !== undefined && tempScreen.gridOptionsModel.columnDefs[0] !== null)
            {
                tempScreen.gridOptionsModel.columnDefs[0].rowDrag=true;
            }
          	tempScreen.gridOptionsModel.columnDefs.filter((tempColDef)=>{
          		tempColDef.filterParams= {
                      clearButton: true
                  };
          		if(tempColDef.headerName.toUpperCase()=="MANAGER" && this.templateObject.functionalAreaName.toUpperCase().match(/EMPLOYEE*/)){
          			tempColDef.cellEditor = 'agTextCellEditor';
                      tempColDef.editable=false;
                  }
          		tempColDef.headerTooltip = tempColDef.headerName;
          		tempColDef.cellClassRules = {
      
                    "alert-danger": function(params) {
                         let errorFieldList = [];
                         let fieldIndex = -1;
                           if(params.data.error) {
                            params.data.error.errors.filter(error =>{
                                
                                if(error && error.errorType !="VR_Type"){
                                    errorFieldList.push(error.errorField);
                                }
                            });
                               params.data.error.errors.filter(error =>{
                                if(error && error.errorLevel === "Validation_Error"){
                                    errorFieldList.push(error.errorField);
                                } 
                            });
                              fieldIndex = errorFieldList.indexOf(params.colDef.field);
                         };
                         return params.data.error && params.data.error.rowIndex == params.rowIndex && fieldIndex > -1;
                      },
                     
                   "alert-warning" : function(params){
                        let errorFieldList = [];
                        let fieldIndex = -1;
                        if(params.data.error){ 
                          params.data.error.errors.filter(error =>{
                              if(error && error.errorType === "VR_Type" && error.errorLevel === "Validation_Warning"){
                                errorFieldList.push(error.errorField);
                              }
                          });
                        fieldIndex = errorFieldList.indexOf(params.colDef.field);    
                     };
                     return params.data.error && params.data.error.rowIndex == params.rowIndex && fieldIndex > -1 ;
                    },      
                  };
 
          		if(tempColDef.dataType && // tempColDef.dataType.toString()!=='MULTIVALUEDROPDOWN' &&
                  		//&& (template[0].templateName.toUpperCase().match(/EMPLOYEE*/) && tempColDef.headerName.toUpperCase()!=="MANAGER") 
                  		tempColDef.dataType.toString()!=='GROUPEDMULTIVALUEDROPDOWN' 
                          && tempColDef.dataType.toString()!=='PICK FROM STORE') {
                      tempColDef.cellRendererFramework = AgGridCellTooltipRenderer;
                  }
          		if(tempColDef.dataType==='DATE' ){    
                      tempColDef.cellEditorFramework=BootstrapDatePickerComponent;    
                  }
                  
                  if(tempColDef.dataType==='DROPDOWN' && tempColDef.cellEditorParams.values[0] != '' ){    
                      tempColDef.cellEditorParams.values.splice(0,0,'');
                  }
                  if(tempColDef.dataType === 'BOOLEAN')
                  {
                      tempColDef.cellEditorParams = {
                          values : ["1","0"],
                          formatValue : function(value:string) {
                                    return (value==="1")?"True":"False";
                          }
                      };
                  }
                  
                  if(!this.isBlank(tempColDef.defaultValue)){
                  	screenContext.rowData.filter((tempRowData)=>{
                          if(this.isBlank(tempRowData[tempColDef.field])){
                              tempRowData[tempColDef.field]=tempColDef.defaultValue;
                          }
                      });
                  }
                  
                  if('begdate' == tempColDef.field && 'COA' == tempScreen.screenName) {  
                  	screenContext.rowData.filter((tempRowData)=> {
                  		if (this.isBlank(tempRowData[tempColDef.field])) {
                  			tempRowData[tempColDef.field] = this.getBeginDateValue();
                  		}
                    });
                  }
                     if(tempColDef.editable === "true" || tempColDef.editable === true) {
                      tempColDef.editable =  this.checkForEditGridPermission(tempColDef.editableByCDKOnly);
                  } else {
                      tempColDef.editable = false;
                  }
                  tempColDef.onCellValueChanged= (params)=> {
                      
                     params.data['isUpdated'] = true;
                    if(params.data[params.colDef.field])
                    {
                        params.data[params.colDef.field] = params.data[params.colDef.field].trim();
                    }
                  	if(params.colDef.dataType.toString()==='MULTIVALUEDROPDOWN') {
                  		params.colDef.editable=true;
                          let dialogRef = this.dialog.open(MultivalueDropdownDialogComponent, {
                          	width: '500px',
                          	data: { fieldId: params.data[params.column.getId()], values :params.colDef.cellEditorParams.values}
                          });
                      
                          dialogRef.afterClosed().subscribe(result => {
                          	this.fieldNewVal = result;            
                              params.data[params.column.getId()]= this.fieldNewVal;
                              params.data[params.column.getId()]= this.fieldNewVal;
                              params.value = this.fieldNewVal;
                              params.api.setRowData(this.currentScreenContext.rowData);
                              this.cellValueChanged(params);
                          	params.api.refreshCells();            
                          });
                      }
                  	
                  	  if(params.colDef.dataType.toString()==='CURRENCY') {
                          this.validateAndFormatCurrency(params);
                      }
                      
                      if(params.colDef.dataType.toString()==='PERCENTAGE') {
                          this.validateAndFormatPercenatage(params);
                      }
                       
                      tempScreen.updated=true;
                      if(params.colDef.dataType.toString()==='DATE'){ 
                     
                      	let selectedDate = moment(params.newValue,"MM/DD/YYYY").toDate();
                          let formattedDate :any; let day : any; let month : any;
                          let today = new Date(); 
                          let dd = today.getDate();let mm = today.getMonth()+1; let yyyy = today.getFullYear();
                          
                          if(dd<10) {
                              day='0'+dd;
                          } else {
                              day=dd;
                          }
                          if(mm<10) {
                              month='0'+mm;
                          } else {  
                              month=mm;
                          }
                          
                          formattedDate = month+'/'+day+'/'+yyyy;        
                          let currentDate = moment(formattedDate,"MM/DD/YYYY").toDate();
                          if(params.colDef.validationRule!==''){
                              const array=params.colDef.validationRule.toString().split(":"); 
                              let condition = new String();  
                              condition = array[0].trim();
                              const validDate= moment(array[1],"MM/DD/YYYY").toDate();
                          
                              if(condition === '>='){
                                  if(validDate > selectedDate){                                       
                                       let validationRuleForUI = "greater than or equal to "+validDate;
                                       let alertDialogRef = this.dialog.open(AlertDialogComponent,
                                        {
                                            width : 'auto',
                                            height : 'auto',
                                            data : { messageListArray : ["Please choose date matching validation rule : "+validationRuleForUI]}
                                        });
                                       params.data[params.colDef.field] = params.oldValue;
                                       return false;
                                  }
                              } else if(condition === '<='){
                                  if(validDate < selectedDate){
                                      let validationRuleForUI = "less than or equal to "+validDate;
                                    //   let alertDialogRef = this.dialog.open(AlertDialogComponent,
                                    //     {
                                    //         width : 'auto',
                                    //         height : 'auto',
                                    //         data : { messageListArray : ["Please choose date matching validation rule : "+validationRuleForUI]}
                                    //     });     
                                    this.toastrService.error("Please choose date matching validation rule : "+validationRuleForUI)                                 
                                      params.data[params.colDef.field] = params.oldValue;
                                      return false;
                                  }
                              } 
                          }
                        
                 
                      }
                      
                      if(params.colDef.dataType.toString()==='INT'){ 
                      	if (isNaN(params.newValue)) {
                      		this.toastrService.error("Must input only numbers");
                              params.data[params.colDef.field] = "";
                              params.api.refreshCells();
                      		  return false;
                          }                         
                      }
                      
                      if(params.colDef.dataType.toString()==='DROPDOWN'){ 
                        if(params.data.error) {
                            for(let j=params.data.error.errors.length-1;j>=0;j--){
                                var errorData=params.data.error.errors[j];
                                if(errorData.errorField===params.colDef.field && errorData.errorLevel==="invalid"){
                                    params.data.error.errors.splice(j,1);
                                }
                            }
                        } 
                        params.api.refreshCells();                                
                    }

                      if(params.colDef.dataType.toString()==='EMAIL'){
                          let EMAIL_REGEXP = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;
                          let emailValue = params.data[params.colDef.field];
                          if(emailValue) {
                          	if(!EMAIL_REGEXP.test(emailValue)) {
                          		this.toastrService.error("Please enter valid email id!!");
                                  params.data[params.colDef.field] = params.oldValue;
                              } else {
                                  params.data[params.colDef.field] = emailValue.toLowerCase();
                              }
                          }
                      }
                      
                      if ( ('Roles' == tempScreen.screenName || 'CDKU Job Titles' == tempScreen.screenName) 
                    		  && 'CurrentEmpNo' == tempColDef.headerName) {   
                      	tempColDef.cellEditorParams.values = this.currentEmpNoList;
                      }
                      let required : boolean = this.getBooleanValue(params.colDef.required);

                      if(params.colDef.dataType.toString()==='CHAR'){
                        if(required){
                          if(params.newValue && params.newValue != params.oldValue ) {
                                if(params.data.error) {
                                  for(let j=params.data.error.errors.length-1;j>=0;j--){
                                      var errorData=params.data.error.errors[j];
                                      if(params.newValue.length <= params.colDef.dataLength){
                                           if(errorData.errorField===params.colDef.field && errorData.errorType == null &&
                                                   (errorData.errorLevel === Constants.ERROR_DATA_REQUIRED || errorData.errorLevel === Constants.ERROR_DATA_MORE_LENGTH)){
                                              params.data.error.errors.splice(j,1);
                                                  }
                                      }
                                  }
                                }
                                 params.api.refreshCells();
                            }                         
                        }else{
                            if(params.colDef.dataLength>0){
                              if(params.newValue.length <= params.colDef.dataLength){
                                  if(params.data.error) {
                                      for(let j=params.data.error.errors.length-1;j>=0;j--){
                                          var errorData=params.data.error.errors[j];
                                          if(errorData.errorField===params.colDef.field && errorData.errorType == null && errorData.errorLevel === Constants.ERROR_DATA_MORE_LENGTH){
                                             params.data.error.errors.splice(j,1);
                                          }
                                      }
                                    }
                                     params.api.refreshCells();
                              }
                            }
                        }
                      }

                      if(required && params.colDef.dataType.toString()!=='CHAR'){
                        if(params.newValue && params.newValue != params.oldValue) {
                    		  if(params.data.error) {
                                for(let j=params.data.error.errors.length-1;j>=0;j--){
                                    var errorData=params.data.error.errors[j];
                                    if(errorData.errorField===params.colDef.field && errorData.errorType == null){
                                       params.data.error.errors.splice(j,1);
                                    }
                                }
                              }
                               params.api.refreshCells();
                    	  }
                      }
                      
                  }
                  
                  tempColDef.onCellDoubleClicked = (cell)=>{
                    cell.data['isUpdated'] = true;
                  	if(this.templateObject.functionalAreaName.toUpperCase().match(/EMPLOYEE*/)){
                  		if(cell.colDef.headerName.toUpperCase()=="MANAGER"){
                  			cell.colDef.cellEditor = 'agTextCellEditor';
                  			cell.colDef.editable=false;
                  			this.managerHierachy=[];
                  			if(this.isEnterpriseStore=='false'){
                  				this.enterpriseManagerHierachy.filter((tempEmployee)=>{
                  					this.managerHierachy.push(tempEmployee);
                  				});
                  			}
                  			screenContext.rowData.filter((tempRowData,index)=> {
                  				if(index<cell.node.childIndex && (tempRowData.management=="Y" || tempRowData.management=='y')){    
                  					this.managerHierachy.push(tempRowData.name);
                  				}
                            });
                            
                  			let dialogRef = this.dialog.open(MultivalueDropdownDialogComponent, {
                  				width: '500px',
                  				data: { fieldId: cell.data[cell.column.getId()], values: this.managerHierachy}
                            });
                          
                            dialogRef.afterClosed().subscribe(result => {
                            	this.fieldNewVal = result;            
                                  cell.data[cell.column.getId()]= this.fieldNewVal;
                              	cell.api.refreshCells();            
                            });
                        }
                    }
                  	
                  	if(cell.colDef.dataType.toString()==='MULTIVALUE') {
                       
                        cell.colDef.editable=true;
                        let dialogRef = this.dialog.open(MultivalueDialogComponent, {
                          	width: '250px',
                          	data: { fieldNewVal: cell.data[cell.colDef.field]}
                          });
                          
                          dialogRef.afterClosed().subscribe(result => {
  	                        this.fieldNewVal = result;            
                              cell.data[cell.colDef.field]= this.fieldNewVal;
                              cell.value = this.fieldNewVal;
                              cell.api.setRowData(this.currentScreenContext.rowData);
                              this.cellValueChanged(cell);
  	                        cell.api.refreshCells();            
                          });
                         
                      }
                  	
                      if(cell.colDef.dataType.toString()==='MULTIVALUEDROPDOWN') {
                          cell.colDef.editable=true;
                          let dialogRef = this.dialog.open(MultivalueDropdownDialogComponent, {
                          	width: '500px',
                          	data: { fieldId: cell.data[cell.column.getId()], values: cell.colDef.cellEditorParams.values}
                          });
                      
                          dialogRef.afterClosed().subscribe(result => {
                          	    this.fieldNewVal = result;            
                                cell.data[cell.column.getId()]= this.fieldNewVal;
                                cell.value = this.fieldNewVal;
                                cell.api.setRowData(this.currentScreenContext.rowData);
                                this.cellValueChanged(cell);
                          	    cell.api.refreshCells();            
                          });
                      }
                      
                      if(cell.colDef.dataType.toString()==='GROUPEDMULTIVALUEDROPDOWN') {
                          this.groupedMultivalueDropdown(cell);
                      }
                  }
          	});
          });
      }
	  loaderDialogRef.close();
      this.templateReceived = true;
  }
  
  
  validateAndFormatCurrency(params: any) {
	  
	  let formattedCurrencyValue = this.formattingService
			  		.formatCurrencyWithCommaAndDecimalPoint(params.data[params.column.getId()]);
	  if(params.newValue != params.oldValue) {
		  if(params.data.error) {
			  delete params.data.error;
		  }
		  let flag = this.validationService.isCurrencyValueValid(formattedCurrencyValue);
		  if(flag) {
			  params.data[params.column.getId()] = formattedCurrencyValue;
		  } else {
			  this.toastrService.error('Invalid currency value!!!');
			  params.data[params.column.getId()] = null;
          }
		  params.api.refreshCells();
	  }
  }
  
  validateAndFormatPercenatage(params: any) {
	  
	  let formattedPercentageValue = this.formattingService
			  		.formatPercentageWithDecimalPoint(params.data[params.column.getId()], true);

      if(formattedPercentageValue === null)
      {
        let rowData = this.currentScreenContext.rowData;        
        let rowNumber = params.node.rowIndex;
        let fieldName = params.colDef.field;
        let error = {
            errorDescription: 'Only Numbers are allowed',
            errorField: fieldName,
            errorLevel: '',
            isUpdated: false
            };
        let row = rowData[rowNumber];
            if(rowData[rowNumber].hasOwnProperty('error')) {
            let rowErrors = row['error']['errors'];
                if(rowErrors) {
                    rowErrors.push(error);
                    } else {
                    row['error']['errors'] = [error];
                    }
            } else {
                row['error'] = {
                rowIndex : 	rowNumber,
                timeStamp : '',
                errors : [error]
                }
            }	
      }
      else {
            if(params.data.error) {
            delete params.data.error;
            }
      }

	  if(params.newValue != params.oldValue){
		  params.data[params.column.getId()] = formattedPercentageValue;
      }
	  params.api.refreshCells();
  } 
  
  groupedMultivalueDropdown(cell: any) {
      let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
          width: '300px',
          height: '150px',
          data: { message: 'Fetching Data.' }
      });
      this.rowDataService.getSecRolesData(false, 'flex')
      .subscribe(data => {
          cell.colDef.editable=false;
          loaderDialogRef.close();
          let dialogRef = this.dialog.open(GroupedMultivalueDialogComponent, {
        	  width: '600px',
        	  height: 'auto',
        	  data: {cell: cell, list: data}
          });
      
          dialogRef.afterClosed().subscribe(result => {
              cell.data[cell.column.getId()] = result.join(',');
        	  cell.api.refreshCells();
        	  this.unsavedDataPresent = true;  
          });
        },
        error => {
        	loaderDialogRef.close();
        	this.toastrService.warning('Sometng went wrong!');
        });
  }
  
  pickValuesFromStore(screen: any) {
      let me = this;
      let fieldList = [];
      let storeFieldList = [];
      for (let column of screen.gridOptionsModel.columnDefs) {
          if(column.dataType === 'PICK FROM STORE') {
              fieldList.push(column.field);
              storeFieldList.push(column.validationRule);
          }
      }
      // Need to re-write below logic as rowData in gridOptionsModel is no more valid with new DB Schema
    //   for(let row of screen.gridOptionsModel.rowData) {
    //       for(let field of fieldList) {
    //           if(!row[field]) {
    //               row[field] = this.storeObject[storeFieldList[fieldList.indexOf(field)]];
    //           }
    //       }
    //   }
  }

  checkForEditGridPermission(checkForEditableByCDKOnly : boolean) {
	  if (  this.adminPermission || this.isBestPractice || this.isStateStandard ||
            ( null != this.templateObject.vic && this.templateObject.vic.loginId == this.authService.getLoggedInUsersLoginId()) || 
            ( null != this.templateObject.secondaryVic && this.templateObject.secondaryVic.loginId == this.authService.getLoggedInUsersLoginId())) {
		  if (checkForEditableByCDKOnly) {
			  return this.checkIfLoggedInUserIsCDKPersonnel();
          }
		  return true;
	  }
	  else {
		  return false;
	  }
  }

  checkIfLoggedInUserIsCDKPersonnel() {
	  let isCDKUserFlag = false;
	  let user = this.authService.getLoggedInUser();
	  if (null != user.enterprise && user.enterprise.id == 'E000000') {
		  isCDKUserFlag = true; 
	  }
	  return isCDKUserFlag;
  } 
  showDealerApprovalButton(){
    
    if(this.editGridPermissionForVIC &&  this.isProjectSourceEnvDash==true &&  this.templateObject.isDealerApproved==false && !this.isDealerApproverLogin &&
        (!this.templateObject.status || this.templateObject.status === 'Work in Progress' 
        || this.templateObject.status === 'Validation Failed' || this.templateObject.status === 'Transfer to DMS failed' || 
        this.templateObject.status === 'Request Cancelled by Dealer')){
         return true;
        }else{
         return false
        }
   }
 
   
   showDealerApproveButton(): boolean{
    if(this.isProjectSourceEnvDash==true && this.templateObject.isDealerApproved==false && this.templateObject.status ==='Request Dealer for Approval' && this.dealerApprovePermission){
          return true;
      }else{
          return false}
    }
    

 importFlexData(){
if(this.storeObject.storeNumber=="" || this.storeObject.storeNumber==null)
        {this.toastrService.error('Vendor store number cannot be empty');}
        else{
        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
            width: '300px',
            height: '150px',
            data: { message: 'Fetching Dash Information' }
        });
        this.flexApi.cmfNumber=this.storeObject.cmfNumber;
        this.flexApi.storeNumber=this.storeObject.storeNumber;
        this.flexApi.functionalAreaId=this.functionalAreaId;
        this.flexApi.projectId=this.projectObject.id;
        this.flexApi.storeId=this.storeId;
        this.flexDashService.importFlexData(this.flexApi)
        .subscribe(data=>{
                        this.flexDashService.bindFlexAPi(this.templateContext,this.currentScreenContext, this.gridApi,data);
                        this.unsavedDataPresent = true
                            loaderDialogRef.close();},
                error=>{
                    this.toastrService.warning('Error occurred while fetching Dash Information');
                    loaderDialogRef.close();
                    })
                }
            }

importCOARowData(){
        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
            width: '300px',
            height: '150px',
            data: { message: 'Preparing COA Raw Data Report  ' }
        });
        let xlsFileName = this.excelService.generateFileNameForExportXls(this.projectNumber, this.storeObject.storeName, this.templateObject.functionalAreaName);
        this.flexDashService.importCOAData(this.storeObject.cmfNumber, this.storeObject.storeNumber)
                            .subscribe(data  => { FileSaver.saveAs(data, xlsFileName);
                                                  loaderDialogRef.close();},
                            error =>{ console.log("Error downloading the file.");
                                    loaderDialogRef.close();
                                    this.toastrService.warning("No COA raw data with given CMF and Vendor Store Number")},
                            ()  => console.log('Completed file download.'));}

showImportCOARawData(): boolean{
      if(this.isProjectSourceEnvDash==true && this.templateObject.functionalAreaName.toLowerCase()==="Accounting".toLowerCase()){
              return true;
          }else{
              return false;}
        }

importGLRowData(){
            let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
                width: '300px',
                height: '150px',
                data: { message: 'Fetching GL Account Raw Data. ' }
            });
            let xlsFileName = this.excelService.generateFileNameForExportXls(this.projectNumber, this.storeObject.storeName, this.templateObject.functionalAreaName);
            this.flexDashService.importGLRawData(this.storeObject.cmfNumber, this.storeObject.storeNumber)
                                .subscribe(data  => {
                                     FileSaver.saveAs(data, xlsFileName);
                                     loaderDialogRef.close();},
                                error =>{ 
                                        console.log("Error downloading the file.");
                                        loaderDialogRef.close();
                                        },
                                ()  => console.log('Completed file download.'));}
    

                                
showGLRowDataButton(): boolean {
            if(this.isProjectSourceEnvDash == true && "Sales".toLowerCase() ===  this.templateObject.functionalAreaName.toLowerCase() ){
                return true;
            }else{
                return false;}
        }

showValidateButton() {
    let stasusList = ['Work in Progress', 'Validation Failed', 'Transfer to DMS failed', '', null,'Request Approved by Dealer'];
    
    if(this.isProjectSourceEnvDash && this.projectObject.dealerApproverRequired){
    if(!this.templateObject.isDealerApproved){
            return false;
        }else{
            return this.editGridPermissionForVIC && this.projectObject.isProject == 1 && 
            this.processValidationCompleteOrOverridden === true &&
            (!this.templateObject.status || this.templateObject.status == null || 
                stasusList.indexOf(this.templateObject.status) > -1);
        }
    }else{
        return this.editGridPermissionForVIC && this.projectObject.isProject == 1 && 
        this.processValidationCompleteOrOverridden === true &&
        (!this.templateObject.status || this.templateObject.status == null || 
            stasusList.indexOf(this.templateObject.status) > -1);
    }
}

showTransferButton() {
    let stasusList = ['Validation Done', 'Transfer to DMS failed'];
    return this.editGridPermissionForVIC && this.projectObject.isProject == 1 
    && this.processValidationCompleteOrOverridden === true
    && stasusList.indexOf(this.templateObject.status) > -1;
}

showProcessValidationResultsButton(){
    return this.editGridPermissionForVIC && this.projectObject.isProject === 1 
    && this.showProcessValidationResultButton == true;
}

setStepperStatus(status: string) {
    if(status === 'Work in Progress') {
        this.stepperStatus = 'Data Collection';
        this.status = status;
    } else if((status ==='Request Dealer for Approval' || status ==='Request Approved by Dealer') && this.isProjectSourceEnvDash){
        this.stepperStatus = 'Dealer Approval';
        this.status = status;
    }else if(status ==='Request Cancelled by Dealer'){
        this.stepperStatus = 'Data Collection';
        this.status = status;
   }else if(status === 'Validation Done' || status === 'Validation in Progress') {
        this.stepperStatus = 'Validation';
        this.status = status;
    }else if(status === 'Validation Failed'){
        this.status = status;
    }
     else if(status === 'Sent to DMS' || status === 'Transfer to DMS failed') {
        this.stepperStatus = 'Start Setup';
        this.status = status;
    } else if(status === 'Transfer to DMS successful') {
        this.stepperStatus = 'Complete';
        this.status = status;
    }
}

iconColor(status: string) {
    status = status != null && status != '' ? status : 'Work in Progress'; 
    let style = {'color':'white'};
    if(status === 'OPEN' || status === 'Open' || status === 'Work in Progress') {
        style = {'color':'yellow'};
    } else if(status === 'Transfer to DMS successful') {
        style = {'color':'green'};
    }  else if(status === 'Validation Done' || status === 'Request Approved by Dealer') {
        style = {'color':'blue'};
    }  else if(status === 'Sent to DMS' || status === 'Request Dealer for Approval' ) {
        style = {'color':'orange'};
    } else if(status === 'Validation in Progress') {
        style = {'color':'gray'};
    } else if(status === 'Validation Failed' || status === 'Transfer to DMS failed' || status === 'Request Cancelled by Dealer' ) {
        style = {'color':'red'};
    }
    return style;
}

changeTemplateStatus_Dealer(status:string){
    let currentStatus : boolean;
    let timer : boolean;
    if(this.projectObject.dealerApproverContact==null || this.projectObject.dealerApproverContact==" ") { 
       this.toastrService.warning('Dealer Approver  Name  is empty');
    }
    
    let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
                        width: '300px',
                        height: '150px',
                        data: { message: 'Updating functional area.' }
                    });
                    this.templateObject.status=status;
                this.flexDashService.statusUpdateFunctionalArea( this.templateObject,this.templateObject.id,this.templateObject.recordType)
                    .subscribe(data => {
                        if(data._body === 'Request Dealer for Approval') {
                            this.templateObject.status = 'Request Dealer for Approval';
                        }
                        if(data._body === 'Request Approved by Dealer') {
                            this.templateObject.status = 'Request Approved by Dealer';
                            //this.isDealerApprove=true;
                        }
                        if(data._body === 'Request Cancelled by Dealer') {
                            this.templateObject.status = 'Request Cancelled by Dealer';
                        }
                       
                      loaderDialogRef.close();
                      this.getTemplateInfo();
                    },
                    error => {
                      loaderDialogRef.close();
                        this.toastrService.error(error.error.message);
                    });
}

checkPtsSvcFaStatus(status: string){
    if(this.templateObject.productCode === "ACCT"){
            this.functionalAreaService.getFunctionalAreasByStoreId(false, this.storeObject.recordType)
           .subscribe(functionalAreas =>{
             this.matchedFunctionalAreas = functionalAreas.filter(template=> (template.productCode === "PTS" || template.productCode ==="SVC") && (template.status === "Transfer to DMS successful"));
                if(this.matchedFunctionalAreas != undefined && this.matchedFunctionalAreas.length>0){
                    this.toastrService.error('Accounting cannot be validated or transferred since Parts or Service for this store has already been transferred.'); 
                }else{
                     this.changeTemplateStatus(status); 
                }
           });    
    } else{
            this.changeTemplateStatus(status); 
        }
}

checkAccFaStatus(status: string){
    if(this.templateObject.productCode === "ACCT")
        this.checkPtsSvcFaStatus(status);
    else if(this.templateObject.productCode === "PTS" || this.templateObject.productCode === "SVC"){
           this.functionalAreaService.getFunctionalAreasByStoreId(false, this.storeObject.recordType)
           .subscribe(functionalAreas =>{
           this.matchedFunctionalAreas =  functionalAreas.filter(template=> template.productCode === "ACCT" && template.status != "Transfer to DMS successful");
                if(this.matchedFunctionalAreas != undefined && this.matchedFunctionalAreas.length>0){
                    this.toastrService.error(' Parts or Service cannot be transferred before transferring Accounting'); 
                }else{
                    this.changeTemplateStatus(status);    
                }                
            });
    } else{
        this.changeTemplateStatus(status);  
    }  
}

changeTemplateStatus(status: string) {
      let currentStatus : string;
	  let timer : boolean;
	  if( this.storeObject.ipAddress) {
          this.functionalAreaService.getFunctionalAreaStatus(this.templateObject.id,this.templateObject.recordType).
				  subscribe(
            functionalAreaStatus=> {
			      currentStatus = functionalAreaStatus;
			      timer=true;
		        
			      if(currentStatus && timer){
			    	  let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
		                  width: '300px',
		                  height: '150px',
		                  data: { message: 'Updating functional area.' }
			    	  });
                      this.functionalAreaService.validateAndTransferProduct(this.projectObject.id, this.templateObject.id, this.templateObject.recordType,status)
			    	  .subscribe(data => {
			    		  if(status === 'validate') {
			    			  this.templateObject.status = 'Validation Done';
			    		  } else if(status === 'transfer') {
			    			  this.templateObject.status = 'Sent for Setup';
			    		  }
			            loaderDialogRef.close();
			            this.getTemplateInfo();
			          },
			          error => {
                          let message  = error.error.message;
                          if(this.templateObject.status === 'Transfer to DMS failed' || this.templateObject.status ==='Validation Done'){
                                message = message + ' Perhaps the FA has got locked due to bad data. Would you like to unlock it ?';
                          }
                            let confirmDialogRef = this.dialog.open(ConfirmDialogComponent, {
                                width: '450px',
                                height: '200px',
                                data: { message: message }
                            });
                            confirmDialogRef.afterClosed().subscribe(result => {
                            if (result) {
                                if(this.templateObject.status === 'Transfer to DMS failed'|| this.templateObject.status === 'Validation Done'){
                                    this.functionalAreaService.unlockFunctionalArea(this.templateObject.id, this.templateObject.recordType)
                                    .subscribe(data =>{
                                            confirmDialogRef.close();
                                            this.getTemplateInfo(); 
                                     })
                                    }
                                } 
                             });
                        loaderDialogRef.close();
			          });
			        }
		        
			        else{
			            this.toastrService.info("Someone else is already performing action on this Functional Area..please try again later");
			        }
	          	}
          );
       // }
        
      } 
      else {
    	  this.toastrService.error('IP address cannont be empty!');
	  }
  }
  
  
    submitTemplate() {
    	let allowSave = true;
    	this.emptyRequiredFieldCount = 0; 
    	for (let screenContext of this.templateContext.screenContextList) {
    		this.requiredFieldsNotFilled(screenContext)
    	}
    	for (let screenContext of this.templateContext.screenContextList) {
	    	if (this.newEmptyRowAlreadyExists(screenContext)) {
	    		this.toastrService.error('Please fill the row (that contains either all blank or default values) in functional unit - ' + screenContext.screen.screenName +' , before saving !"');
	    		allowSave = false;
	    		break;
	    	}
    	}
    	
    	if (allowSave){
    		var displayMessage = 'Saving . . .';
    		if (this.emptyRequiredFieldCount > 0){
    			displayMessage = 'Saving . . . \nSome required fields that have not been filled will be highlighted in Red';
    		}
		     if(this.unsavedDataPresent === true || this.excelService.isUnsavedDataPresent()){
                let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
                    width: '500px',
                    height: '150px',
                    data: { message: displayMessage }
                });
		    	 let requests = this.createRequestsForBatchSaveAndDelete(this.flexDashService.isUnsavedDataPresent());
                 this.executeSaveAndDeleteRowDataRequestsOnFromServer(requests, 0, loaderDialogRef);
                 if(this.projectObject != null && this.projectObject != undefined && this.projectObject.isProject == 1){
                    this.templateObject.showProcessValidationResultsButton = true;
                    this.templateObject.showValidateOrTransferButton = false;
                    this.functionalAreaService.saveSingleFunctionalArea(this.templateObject)
                    .subscribe(functionalArea => {
                    if (functionalArea != null && functionalArea != undefined) {
                        console.log('functionalArea updated with showProcessValidationResultsButton flag');
                    }
                },error => {
                    loaderDialogRef.close();
                    console.log(error);
                });
                 }
		     }
		     else{
		         this.toastrService.warning("No data to Save..");
		         return false;
		     }
    	}
    }
    
    private createRequestsForBatchSaveAndDelete(isFromFlexAPI) : any[] {
    	let requests = [];

    	for (let screenContext of this.templateContext.screenContextList) {
            let tableDataListToDelete = [];
            let models = [];
            let rowDataList = [];
            let rowDataListToBeDeleted = [];
           
        	if(this.deletedRowIds[screenContext.screen.recordType]) {
        		tableDataListToDelete = this.deletedRowIds[screenContext.screen.recordType];
        	}
        	/*let tableDataList: any[] = screenContext.rowData.filter(
				function(row, rowIndex, rowData) {

                    if(isFromFlexAPI){
                      row.isUpdated = true;}
					let flag = !row.rowDataId || row.hasOwnProperty('isUpdated') || row.index == undefined || row.index != rowIndex; 
					//Checking if it has beed modified (1. Added New (!row.rowDataId) 2. Order  Change (row.index != rowIndex) 3. Cell Value Changed (row.hasOwnProperty('isUpdated')))
					if(flag) {
						row.index = rowIndex;
					}
					return flag;
            });*/
        	let tableDataList: any[] = screenContext.rowData.filter(
    				function(row, rowIndex, rowData) {
    					let flag = !row.rowDataId || row.hasOwnProperty('isUpdated') || row.index == undefined; 
    					//Checking if it has beed modified (1. Added New (!row.rowDataId) 2. Cell Value Changed (row.hasOwnProperty('isUpdated')))
    					return flag;
                });
        	tableDataListToDelete.forEach(tableRowInDB => {
        		let rowToDelete = {};
        		rowToDelete['id'] = screenContext.screen.recordType;
        		rowToDelete['recordType'] = tableRowInDB.recordType;
        		if(tableRowInDB.hasOwnProperty('isUpdated') ) {
        			delete tableRowInDB['isUpdated'];
        		}
        		rowToDelete['data'] = tableRowInDB;
                rowDataListToBeDeleted.push(rowToDelete);
            });
        	tableDataList.forEach(tableRow => {
        		let row = {};
                row['id'] = screenContext.screen.recordType;
                row['recordType'] = tableRow.recordType;
                tableRow['id'] = screenContext.screen.recordType;
                tableRow['recordType'] = tableRow.recordType;
                
                if(tableRow.hasOwnProperty('isUpdated') ) {
                    delete tableRow['isUpdated'] ;
                }
                row['data'] = tableRow;
                rowDataList.push(row);
            });
        	let count = rowDataList.length > rowDataListToBeDeleted.length ? rowDataList.length : rowDataListToBeDeleted.length;
        	
            let i = 0, j = 0 ;

            this.settingAuditlogDetails();
        	for (i=0,j=count; i<j; i+=200) {
        		models.push({
                    'functionalAreaId':this.currentScreen.id,
        			'screenId' : screenContext.screen.recordType,
        			'recordsToSave' : rowDataList.slice(i,i+200),
                    'recordsToDelete' : rowDataListToBeDeleted.slice(i,i+200),
                    'auditlogType':  this.auditlog_type,
                    'auditlogName':this.bp_auditlog_name,
                    'auditlogMessage':this.bp_auditlog_msg

        		});
            }
            for(let model of models) {
                requests.push(this.rowDataService.batchSaveAndDeleteRowData(model));
            }
        }
        
        
        return requests;
    }

settingAuditlogDetails(){

    if(! this.isProject){
        this.auditlog_type = Constants.BP_AUDITLOG ;
        this.bp_auditlog_name = this.projectNumber+" - "+this.versionName;
        if(this.isStateStandard){
            this.bp_auditlog_msg="State Standard Version Updated";
        }else{
            this.bp_auditlog_msg="OEM BP Version Updated";
        }
    }
}
    
    private executeSaveAndDeleteRowDataRequestsOnFromServer(serverRequests: any[], startIndex: number, loaderDialogRef: any) {

    	let requests = serverRequests.slice(startIndex, startIndex + 2);
    	startIndex += 2;
    	
    	if(requests.length > 0) {
    		observableForkJoin(requests)
			.subscribe(data => {
				if(startIndex < serverRequests.length) {
		    		this.executeSaveAndDeleteRowDataRequestsOnFromServer(serverRequests, startIndex, loaderDialogRef);
		    	} else {
		    		loaderDialogRef.close();
		    		this.unsavedDataPresent = false;
		    		this.excelService.resetUnsavedDataPresent(); 
		    		this.getTemplateInfo();
		    		this.deletedRowIds = {};
		    	}
			});
        }
    }
    
    addRow(currentScreenContext: any, addRowButtonClick : boolean) {
    	let previousIndex: number = 0;
    	let nextIndex: number = 0;
    	let rowIndexInDBOrRecordType : number = 0;
    	let gridOptions = currentScreenContext.screen.gridOptionsModel;
        if (this.newEmptyRowAlreadyExists(currentScreenContext)) {
            this.toastrService.error("Please fill the existing row (that contains either all blank or default values) before adding a new one !");
        }
        else {
        	if (addRowButtonClick && currentScreenContext.rowData.length != 0 && this.gridApi.getSelectedRows().length > 0){
        		this.currentIndex = this.currentIndex +1;
        	}
        	else{// First Row
                this.currentIndex = currentScreenContext.rowData.length;
        	}
        	
        	if (this.currentIndex !=0 && this.currentScreenContext.rowData[this.currentIndex-1]) {
        		previousIndex  = this.currentScreenContext.rowData[this.currentIndex-1]['recordType'];
        	}
        	if (this.currentIndex !=0 && this.currentIndex <= currentScreenContext.rowData.length && this.currentScreenContext.rowData[this.currentIndex]) {
        		nextIndex  = this.currentScreenContext.rowData[this.currentIndex]['recordType'];
        	}
        	if (previousIndex == 0 && nextIndex ==0) { //If First Row
        		rowIndexInDBOrRecordType = this.startingIndexOrRecordType;
        	}
        	if (previousIndex != 0 && nextIndex ==0) { //If last Row
        		rowIndexInDBOrRecordType = Number.parseInt(previousIndex.toString()) + Number.parseInt(this.startingIndexOrRecordType.toString());
        	}
        	if (previousIndex != 0 && nextIndex !=0) { //Any Other Row
        		rowIndexInDBOrRecordType = (Number.parseInt(previousIndex.toString()) + Number.parseInt(nextIndex.toString()))/2;
        	}
        	
            const newItems = this.createNewRowData(gridOptions);
            gridOptions.columnDefs.filter((tempDefs) => {
                if (tempDefs.defaultValue != null || tempDefs.defaultValue != "" || tempDefs.defaultValue != undefined) {
                    if (newItems.hasOwnProperty(tempDefs.field)) {
                        newItems[tempDefs.field] = tempDefs.defaultValue;
                    }
                }
            });

            if (newItems.hasOwnProperty('begdate') && 'COA' == currentScreenContext.screen.screenName) {
                newItems.begdate = this.getBeginDateValue();
            }
            this.gridApi.updateRowData({ add: [newItems], addIndex:this.currentIndex });
            this.currentScreenContext.rowData.splice(this.currentIndex, 0, newItems); 
            this.currentScreenContext.rowData[this.currentIndex]['recordType'] = Math.floor(rowIndexInDBOrRecordType);
            this.pickValuesFromStore(this.currentScreen);
            this.unsavedDataPresent = true;
            // scrolls to the first column
            var firstCol = this.gridColumnApi.getAllDisplayedColumns()[0]
            this.gridApi.ensureColumnVisible(firstCol);
            // sets focus into the first grid cell
            this.gridApi.setFocusedCell(this.currentIndex, firstCol);
            this.gridApi.startEditingCell({
                rowIndex: this.currentIndex,
                colKey: gridOptions.columnDefs[0].field
            });
        	currentScreenContext.screen.updated = true;
        }
        currentScreenContext.screen.rowDataEmpty = false;
        
    }

      createNewRowData(gridOptions: GridOptions) {
    	let newRow: any = {};
      	newRow.rowDataId = null;
      	newRow.screenId = null;
    	for(let colDef of gridOptions.columnDefs) {
    		newRow[colDef['field']] = null;
    	}
    	return newRow;
      }

      deleteSelectedRows(gridOptions: GridOptions, screen: ScreenObject) {
    	  let rowData = this.currentScreenContext.rowData;
          const selectedRows = this.gridApi.getSelectedRows();
          if (selectedRows.length >= 1) {
              const result = this.gridApi.updateRowData({ remove: selectedRows });
              
              for(let row of selectedRows) {
            	  if(row.rowDataId) {  // if it has been saved in the DB before
            		  if(!this.deletedRowIds[this.currentScreenContext.screen.recordType]) {
            			  this.deletedRowIds[this.currentScreenContext.screen.recordType] = [];
            		  }
            		  this.deletedRowIds[this.currentScreenContext.screen.recordType].push(row);
            	  }
            	  let index1 = rowData.indexOf(row);
                  rowData.splice(index1, 1);
              }
              
              this.unsavedDataPresent = true;
              screen.updated = true;
          }
          if(rowData.length === 0){
            screen.rowDataEmpty = true;
          }
      }

    deleteAllRows(gridOptions: GridOptions, screen: ScreenObject) {
        
        let rowData = this.currentScreenContext.rowData;
        const selectedRows = this.getAllRows();
        if(selectedRows.length >= 1) {
            const result = this.gridApi.updateRowData({ remove: selectedRows }); 
            for(let row of selectedRows) {
                if(row.rowDataId) {  // if it has been saved in the DB before
                    if(!this.deletedRowIds[this.currentScreenContext.screen.recordType]) {
                        this.deletedRowIds[this.currentScreenContext.screen.recordType] = [];
                    }
                    this.deletedRowIds[this.currentScreenContext.screen.recordType].push(row);
                }
                let index1 = rowData.indexOf(row);
                rowData.splice(index1,1);
            }          
            this.unsavedDataPresent = true;
            screen.updated = true;
        }
        if(rowData.length === 0){
          screen.rowDataEmpty = true;
        }
    }
    
    getAllRows() {
        let rowDatas = [];
        this.gridApi.forEachNode(node => rowDatas.push(node.data));
        return rowDatas;
    }

    getBooleanValue(value : any ) : boolean {
    	switch(value){
    	 case "True": case "true": case true : case "TRUE": return true;
    	 default: return false;
        }
    }
      
    requiredFieldsNotFilled(currentScreenContext:  any) {
      	let rowData = currentScreenContext.rowData;
      	let screen =  currentScreenContext.screen;
      	let gridOptions = currentScreenContext.screen.gridOptionsModel;
      	
          for (var r = 0; r < rowData.length; r++) {
              for (var c = 0; c < gridOptions.columnDefs.length; c++) {
                  var fieldName = gridOptions.columnDefs[c].field;
                  let required : boolean = this.getBooleanValue(gridOptions.columnDefs[c].required);
                  if (rowData[r][fieldName] === ""|| rowData[r][fieldName] == null ) {
                      if (required){
                    	this.emptyRequiredFieldCount++;
                      	let error = {
      							errorDescription: 'Mandatory field cannot be empty',
      							errorField: fieldName,
      							errorLevel: Constants.ERROR_DATA_REQUIRED,
                                isUpdated: false
      					};
                      	let row = rowData[r];
  						if(rowData[r].hasOwnProperty('error')) {
  							let rowErrors = row['error']['errors'];
  							if(rowErrors) {
  								rowErrors.push(error);
  							} else {
  								row['error']['errors'] = [error];
  							}
  						} else {
  							row['error'] = {
  								rowIndex : 	r,
  								timeStamp : '',
  								errors : [error]
  							}
  						}	
                      }
                  }
              }
          }
      }
      
      
    newEmptyRowAlreadyExists(currentScreenContext:  any) : boolean {
    	let rowData = currentScreenContext.rowData;
    	let screen =  currentScreenContext.screen;
    	let gridOptions = currentScreenContext.screen.gridOptionsModel;
    	if(screen.screenName === "COA"){
            gridOptions.rowData = rowData;
        }
        for (var r = 0; r < rowData.length; r++) {
            var emptyFieldCount = 0;
            var defaultFieldCount =0;
            for (var c = 0; c < gridOptions.columnDefs.length; c++) {
                var fieldName = gridOptions.columnDefs[c].field;
                if (rowData[r][fieldName] === ""|| rowData[r][fieldName] == null ) {
                    emptyFieldCount++;
                }
                else if (rowData[r][fieldName] === gridOptions.columnDefs[c].defaultValue || 
                        ('COA' == screen.screenName && fieldName === 'begdate' && gridOptions.rowData[r][fieldName] === this.getBeginDateValue())) {
                	defaultFieldCount++;
                }
            }
            if (gridOptions.columnDefs.length === emptyFieldCount + defaultFieldCount && gridOptions.columnDefs.length != defaultFieldCount) {
                return true;
            }
        }
        return false;
    }
    
    getBeginDateValue() {
        let today = new Date();
        let year = today.getFullYear() - 5;
        return '1/1/' + year;
    }

      // This method export the current functional area headers into xlsx file, include row data based on flag param.    
      exporttoXlsWithRowData(includeRowData : boolean)
      {
        let xlsFileName : string;
        if(this.isBestPractice || this.isStateStandard)
        {
            xlsFileName = this.excelService.generateFileNameForExportXls(this.projectNumber, this.versionName, this.templateObject.functionalAreaName);
        }
        else
        {
            xlsFileName = this.excelService.generateFileNameForExportXls(this.projectNumber, this.storeObject.storeName, this.templateObject.functionalAreaName);
        }
        
        if(includeRowData)
        {
            this.excelService.getTemplateXlsWithData(this.templateObject)
            .subscribe(data  => { FileSaver.saveAs(data, xlsFileName)},
                error => console.log("Error downloading the file."),
                ()    => console.log('Completed file download.'));
        }
        else
        {
            this.excelService.getTemplateXls(this.templateObject)
            .subscribe(data  => { FileSaver.saveAs(data, xlsFileName)},
                error => console.log("Error downloading the file."),
                ()    => console.log('Completed file download.'));
            
        }
      }

    // This method will export the current screen or functional unit as csv file.          
      exportCSV() {
        let csvFullFileName:string;

        if(this.isBestPractice || this.isStateStandard)
        {
            csvFullFileName = this.excelService.generateFileNameForExportCSV(this.projectNumber,this.versionName,this.templateObject.functionalAreaName,this.currentScreen.screenName);
        }else{
            csvFullFileName = this.excelService.generateFileNameForExportCSV(this.projectNumber,this.storeObject.storeName,this.templateObject.functionalAreaName,this.currentScreen.screenName);
        }

        
        this.excelService.getScreenCsv(this.currentScreen.id,this.currentScreen.recordType)
        .subscribe(data  => { FileSaver.saveAs(data, csvFullFileName)},
          error => console.log("Error downloading the file."),
        ()    => console.log('Completed file download.'));
      }

      exporPDFtReport(){
        this.dashReport.projectNumber=this.projectNumber;
        this.dashReport.storeId=this.storeObject.id;
        this.dashReport.storeName=this.storeObject.storeName;
        this.dashReport.functionalUnitId=this.currentScreen.recordType;
        this.dashReport.templateName=this.templateObject.functionalAreaName;
        this.dashReport.functionalAreaId=this.currentScreen.id;
        this.dashReport.screenName=this.currentScreen.screenName;


        
        let columnNames = [];

       
        this.currentScreen.gridOptionsModel.columnDefs.forEach((order: any) => {
            columnNames.push(order.headerName);
      });

        let dialogRef = this.dialog.open(DashReportComponent, {
            width : '30%',
            height : 'auto',                
            data: { sheetList : columnNames}
          });

          dialogRef.afterClosed().subscribe(result => {
            let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
                width: '300px',
                height: '150px',
                data: { message: 'Fetching Report Information.' }
            });
          
            this.importColumnList = result;
            if(result!=undefined && result!=""){
            this.dashReport.columnList=this.importColumnList;
            let pdfFileName = this.flexDashService.generateFileNameForExportPDF(this.projectNumber, this.storeObject.storeName, this.templateObject.functionalAreaName,this.currentScreen.screenName);
            this.flexDashService.exporPDFtReport(this.dashReport).subscribe(data  => { 
                        FileSaver.saveAs(data, pdfFileName);
                  
                        loaderDialogRef.close();},
             error => console.log("Error downloading the file."),
             () => console.log('Completed file download.'));
            }else{
                loaderDialogRef.close();
            }

           });
        
      }
      getProject(projectNumber: string) {
        this.removeSSSSessionObject();
          if (this.unsavedDataPresent) {
              if (confirm("You may have unsaved data on this page. Click 'OK' to continue , or  'Cancel' to stay on this page")) {
                if (this.isStateStandard) {
                    this.router.navigate(['bestPractice/stateStandard/' + projectNumber + '/true']);
                } else {
                this.isBestPractice ? this.router.navigate(['bestpractice/getOne/' + projectNumber + '/' + this.bestPracticePlatformCode]) : this.router.navigate(['projects/' + projectNumber]);                
                }
            }
          }
          else {
                if (this.isBestPractice)
                {
                    this.router.navigate(['bestpractice/getOne/' + projectNumber + '/' + this.bestPracticePlatformCode]);
                }else if (this.isStateStandard) {
                    this.router.navigate(['bestPractice/stateStandard/' + projectNumber + '/true']);
                }
                else
                {
                    this.router.navigate(['projects/' + projectNumber]);                
                }
          }
      }
      removeSSSSessionObject(){
        if(sessionStorage.getItem("sssObject")!==undefined){
              sessionStorage.removeItem("sssObject");
        }
    }
    populateCurrentEmpNoListForCDKUJobTitlesOrRoles(template:TemplateObject){
    	  this.currentEmpNoList =[];
    	  this.templateContext.screenContextList.filter(tempScreenContext => {
    		  if(tempScreenContext.screen.screenName.toUpperCase().match(/EMPLOYEES*/)){
  				 tempScreenContext.rowData.filter(tempRowData=>{
  					this.currentEmpNoList.push(tempRowData.currentempno); 
  				 });
  			 }
    	  })
      }
      
      selectFunctionalUnit(event: any) {
    	  this.currentScreenIndex = event.selectedIndex;
    	  this.currentScreenContext = this.templateContext.screenContextList[event.selectedIndex]
    	  this.currentScreen = this.currentScreenContext.screen;
    	  if(this.currentScreenContext.rowData.length <= 0) {
        	  this.fetchDataForCurrentScreen(false);
          } else {
        	  this.handleSettingRowData(screen);
          }
      }
      
      private fetchDataForCurrentScreen(isGridProcessRequired: boolean) {
        if(this.templateObject.copyRowData) {
            this.currentScreen.gridOptionsModel.columnDefs.filter((columnDef) => {
                columnDef.editable = false;
            });
	 		let alertDialogRef = this.dialog.open(AlertDialogComponent,
				{
					width : 'auto',
					height : 'auto',
					data : { messageListArray : ["This project has been configured using a Best Practice the data for which is being copied in the background. Meanwhile, you would not be able to modify any data. Kindly wait !!!"]}
				});
	 		
	 		alertDialogRef.afterClosed().subscribe(result => {
	 			this.fetchScreenData(isGridProcessRequired, this.currentScreen, this.currentScreenContext);
             });

    	} else {
              this.fetchScreenData(isGridProcessRequired, this.currentScreen, this.currentScreenContext);
    	  }
      }
      
      private fetchScreenData(isGridProcessRequired: boolean, screen: any, screenContext: any) {
    	  let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
    		  width: '500px',
              height: '150px',
              data: { message: 'Fetching data for functional Unit ' +  screen.screenName}
          });
          
    	  this.rowDataService.getRowDataOfScreen(false, screenContext.screen.recordType)
    	  	.subscribe(rowData => {
                var rowDataList = rowData.map(function (row) {
                    return row.data;
                  });
    	  		screenContext.rowData = rowDataList;
    	  		if(isGridProcessRequired) {
    	  			this.processTemplateGrid(loaderDialogRef);
    	  			this.handleSettingRowData(screen);
    	  		} else {
    	  			loaderDialogRef.close();
    	  		}
    	  }, error => {
    	  		this.toastrService.error('error while fetching the data ' + error.error.message);
    	  		loaderDialogRef.close();
    	  });
      }
      
      private handleSettingRowData(screen: any) {
    	  this.pickValuesFromStore(this.currentScreen);
          this.index=screen.selectedIndex;
          this.showGrid =true;
          if(this.gridApi !== undefined)
          {
            this.gridApi.setColumnDefs(this.currentScreen.gridOptionsModel.columnDefs);
            this.gridApi.setRowData(this.currentScreenContext.rowData);
          }
          
          if (this.currentScreen.screenName == "CDKU Job Titles" || this.currentScreen.screenName == "Roles"){
        	  this.populateCurrentEmpNoListForCDKUJobTitlesOrRoles(this.templateObject);
          }
      }
      
      autoSizeAll() {
	    var allColumnIds = [];
	    this.gridColumnApi.getAllColumns().forEach(function(column) {
	      allColumnIds.push(column.colId);
	    });
	    this.gridColumnApi.autoSizeColumns(allColumnIds);
	  }
	  
      onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.sizeColumnsToFit(params);
        this.gridApi.setColumnDefs(this.currentScreen.gridOptionsModel.columnDefs);
        this.gridApi.setRowData(this.currentScreenContext.rowData);
		this.autoSizeAll();
      }
      
      rowDataChanged(params: any) {
          this.sizeColumnsToFit(params);
      }
      
      onRowClicked(params: any){
          this.currentIndex = params.rowIndex;
      }
     
      sizeColumnsToFit(params: any) {
          if(this.currentScreen.gridOptionsModel.columnDefs.length <= 5) {
              params.api.sizeColumnsToFit();
          }
      }
      

     // This method checks whether same file is getting imported again for second time.
     handleFileInputforBestPractice(files: FileList)        
     {
        this.fileToUpload = files.item(0);      
        if(this.fileToUpload && this.recentFileToUpload)
            {
            if(this.fileToUpload.name === this.recentFileToUpload.name)
                {
                    let confirmDialogRef = this.dialog.open(ConfirmDialogComponent, {
                        width: '300px',
                        height: '160px',
                        data: { message: 'Are you sure you want to reload the same file ?' }
                    });
              	  confirmDialogRef.afterClosed().subscribe(result => {
                    if (result) 
                        {
                        this.excelService.importXLSXFile(files, this.templateContext,this.currentScreenContext, this.gridApi);
                        this.unsavedDataPresent = this.excelService.isUnsavedDataPresent();
                        }
                    });                     
                }
            else
                {
                    this.recentFileToUpload = this.fileToUpload;
                    this.excelService.importXLSXFile(files,this.templateContext,this.currentScreenContext, this.gridApi);                    
                    this.unsavedDataPresent = this.excelService.isUnsavedDataPresent();
                }
            }
        else 
            {
                this.recentFileToUpload = this.fileToUpload;
                this.excelService.importXLSXFile(files,this.templateContext,this.currentScreenContext, this.gridApi);        
                this.unsavedDataPresent = this.excelService.isUnsavedDataPresent();        
            }    
    }
   
     // This method is to set the value of file to null, to allow import of same xlsx file again and again.
     resetImportFileValue()
     {
        let input : any = document.getElementById('file');
        if(input)
        {
            input.value = null;         
        }
     }
   
    cellValueChanged(params){
        this.unsavedDataPresent = true;  
    }
    
    navigateToNextCell (evt) {
      var KEY_DOWN = 40;  
      evt = (evt) ? evt : ((window.event) ? event : null);
        if (evt) {
            if (evt.event.keyCode == KEY_DOWN && evt.event.shiftKey ) {
                this.addRow(this.currentScreenContext, false);
            }
        }
    }
    
    tabToNextCell(params) {
    	if (!params.nextCellDef)
    	{
    		this.addRow(this.currentScreenContext, false);
    	}
    	else {
	      const result = {
	        rowIndex: params.nextCellDef.rowIndex,
	        column: params.nextCellDef.column,
	        floating: params.nextCellDef.floating
	      };
	      return result;
    	}
      }
    
    newOnboardingProject() {
        if (this.unsavedDataPresent) {
            if (confirm("You may have unsaved data on this page. Click 'OK' to continue , or  'Cancel' to stay on this page")) {
                this.router.navigateByUrl('projects/create');
            }
        }
        else {
            this.router.navigateByUrl('projects/create');
        }
    }
    
    gotoDashboard() {
        if (this.unsavedDataPresent) {
            if (confirm("You may have unsaved data on this page. Click 'OK' to continue , or  'Cancel' to stay on this page")) {
                this.router.navigateByUrl('dashboard');
            }
        }
        else {
            this.router.navigateByUrl('dashboard');
        }
    }
    
     isBlank(str) {
        return (!str || /^\s*$/.test(str));
    }

     isDisplaySaveButton() {
         return this.editGridPermissionForVIC && 
                 (!this.templateObject.status || this.templateObject.status === 'Work in Progress' 
                     || this.templateObject.status === 'Validation Failed' || this.templateObject.status === 'Transfer to DMS failed' || this.templateObject.status === 'Request Approved by Dealer'|| this.templateObject.status === 'Request Cancelled by Dealer');
     }
     
     showImportFlexDataButton(){
        return this.editGridPermissionForVIC && 
        (!this.templateObject.status || this.templateObject.status === 'Work in Progress' 
            || this.templateObject.status === 'Validation Failed' || this.templateObject.status === 'Transfer to DMS failed' || this.templateObject.status === 'Request Cancelled by Dealer');

     }
     onRowDragEnd(event:any) {
    	 let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
             width: '500px',
             height: '150px',
             data: { message: 'Updating the row sequence. Remember to  hit \'Save\' if you wish to persist it.'}
         });
    	 let previousIndex: number = 0;
     	 let nextIndex: number = 0;
     	 let rowIndexInDBOrRecordType : number = 0;
    	 let recordToMove = event.node.data;
    	 let recordNewIndex = event.overIndex;
    	 let recordCurrentIndex = this.currentScreenContext.rowData.indexOf(recordToMove);
      	 
    	 if (recordNewIndex != recordCurrentIndex) {
	    	 //Before moving (changing the rowIndexInDBOrRecordType), mark the record for deletion
	    	 if(recordToMove['rowDataId']) {  // If it has been saved in the DB before
	    		  if(!this.deletedRowIds[this.currentScreenContext.screen.recordType]) {
	    			  this.deletedRowIds[this.currentScreenContext.screen.recordType] = [];
	    		  }
	    		  let recordToDelete = Object.assign({}, recordToMove);
	    		  recordToDelete['isUpdated'] = true;
	    		  this.deletedRowIds[this.currentScreenContext.screen.recordType].push(recordToDelete);
	    		  this.unsavedDataPresent = true;
	       	 }
	    	
	    	 //Calculate the new rowIndexInDBOrRecordType
	      	if (recordNewIndex !=0 && this.currentScreenContext.rowData[recordNewIndex-1]) {
	     		previousIndex  = this.currentScreenContext.rowData[recordNewIndex-1]['recordType'];
	     	}
	     	if (recordNewIndex < this.currentScreenContext.rowData.length -1 && this.currentScreenContext.rowData[recordNewIndex]) {
	     		nextIndex  = this.currentScreenContext.rowData[recordNewIndex]['recordType'];
	     	} 
	      	if (previousIndex == 0 && nextIndex !=0) { //If First Row
	      		rowIndexInDBOrRecordType = nextIndex/2;
	     	}
	     	if (previousIndex != 0 && nextIndex ==0) { //If last Row
	     		rowIndexInDBOrRecordType = Number.parseInt(previousIndex.toString()) + Number.parseInt(this.startingIndexOrRecordType.toString());
	     	}
	     	if (previousIndex != 0 && nextIndex !=0) { //Any Other Row
	     		rowIndexInDBOrRecordType = (Number.parseInt(previousIndex.toString()) + Number.parseInt(nextIndex.toString()))/2;
	     	}
	     	//Modify the rowIndexInDBOrRecordType of recordToMove
	     	recordToMove['recordType'] = Math.floor(rowIndexInDBOrRecordType);
	     	if(recordToMove['rowDataId']) { // If it has been saved in the DB before
	     		recordToMove['isUpdated'] = true;
	     	}
    	 }
    	loaderDialogRef.close();
     }

     getBestPracticeDetailsByName(bestPracticeName: string, platformCode : string, permissionCheckNeeded: boolean): Observable<BestPracticeObject> {
        let bestPracticeObject: Observable<BestPracticeObject>;
        if (this.isStateStandard) {
            bestPracticeObject = this.bestPracticeService
            .getSSSBPByBestPracticeName(bestPracticeName, permissionCheckNeeded);
        } else {
            bestPracticeObject = this.bestPracticeService
            .getByBestPracticeNameAndPlatform(bestPracticeName, platformCode, permissionCheckNeeded);
        }
        return bestPracticeObject;
      }

      viewOrIncorporateBPChanges(){
        let dialogRef=this.dialog.open(BPFUPropagateChangesDialogComponent,{
            width :'80%',
            height :'80%',
            data : {
                faId:this.templateObject.recordType,
                storeId:this.templateObject.id,
                projectId:this.storeObject.id,
                faName:this.templateObject.functionalAreaName

            }
        });
        dialogRef.afterClosed().subscribe(result => {
                this.ngOnInit();
        });
      }

     showViewOrIncorporateBPChangesButton(){
        let stasusList = ['Work in Progress', 'Validation Failed', 'Transfer to DMS failed','Validation Done'];

        if(this.editGridPermissionForVIC && this.projectObject.isProject == 1 && this.templateObject.incorporateBpChanges
            && (!this.templateObject.status || this.templateObject.status == null || 
                stasusList.indexOf(this.templateObject.status) > -1)){
            return true;
        }
        return false;
      }

      openDialogToProcessValidationResults(){
        let dialogRef=this.dialog.open(ProcessValidationResultsComponent,{
            width :'80%',
            height :'80%',
            data : {
                projectName:this.projectObject.projectNumber,
                storeName:this.storeObject.storeName,
                functionalAreaName:this.templateObject.functionalAreaName,
                platformName:this.projectObject.platform.platformName,
                sourceProductCode:this.templateObject.productCode,
                faId:this.templateObject.recordType,
                storeId:this.templateObject.id,
                projectId:this.storeObject.id

            }
        });
        dialogRef.afterClosed().subscribe(result=>{
            if(result.processValidationCompleteOrOverridden){
                let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
                    width: '300px',
                    height: '150px',
                    data: { message: 'Updating functional area.' }
                });
                this.templateObject.showValidateOrTransferButton = result.processValidationCompleteOrOverridden;
                this.templateObject.showProcessValidationResultsButton = false;
                this.functionalAreaService.saveSingleFunctionalArea(this.templateObject).
                subscribe(functionalArea => {
                    if (functionalArea != null && functionalArea != undefined) {
                        console.log('functionalArea updated with processValidationCompleteOrOverridden flag');
                    loaderDialogRef.close();
                    this.ngOnInit();
                    }
                },error => {
                    loaderDialogRef.close();
                    console.log(error);
                });
            }else{
                this.ngOnInit();
            }
            
         });
    }

}

	