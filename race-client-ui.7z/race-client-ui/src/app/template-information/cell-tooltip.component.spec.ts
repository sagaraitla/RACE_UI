import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialogModule, MatDialogRef, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatListModule, MatMenuModule, MatPaginatorModule, MatProgressBarModule, MatProgressSpinnerModule, MatSelectModule, MatSidenavModule, MatSnackBarModule, MatSortModule, MatStepperModule, MatTooltipModule, MAT_DIALOG_DATA } from "@angular/material";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { ActivatedRoute, Router, RouterModule } from "@angular/router";
import { GridApi } from "ag-grid";
import { AgGridModule } from "ag-grid-angular";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule } from "ngx-toastr";
import { AgGridCellTooltipRenderer } from "./cell-tooltip.component";
import FileSaver = require("file-saver");

describe('AgGridCellTooltipRenderer',() => {

    
    let component : AgGridCellTooltipRenderer;
    let fixture : ComponentFixture<AgGridCellTooltipRenderer>;
    beforeEach(async(() =>{
        let data= {
        }
        const gridApiSpy = jasmine.createSpyObj('GridApi',['sizeColumnsToFit','setColumnDefs','setRowData']);
        TestBed.configureTestingModule({
           imports: [
                MatCardModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatPaginatorModule,
                MatDialogModule,
                ToastrModule.forRoot(),
                AgGridModule.withComponents([]),
                RouterModule.forRoot([]),
                CommonModule,
                MatSelectModule,
                MatSortModule,
                MatIconModule,
                FormsModule,
                MatMenuModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                SortableModule,
                MatSortModule,
                MatStepperModule,
                ReactiveFormsModule,
                MatSnackBarModule,
                MatSidenavModule,
                MatProgressBarModule,
                MatListModule,
                MatCheckboxModule,
                MatTooltipModule,
            ],
            declarations : [AgGridCellTooltipRenderer],
            providers : [
    
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: ''},
                {provide:GridApi,useValue:gridApiSpy},
                {provide: ActivatedRoute, useValue: {snapshot: {params: {storeId:"S123",functionalAreaId:"456",projectNumber:"P111"}}}}

            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: []}});
          
            fixture = TestBed.createComponent(AgGridCellTooltipRenderer);
            component = fixture.componentInstance;

    }));

    it('test agInit if Datatype is DROPDOWN',()=>{
        let params:any={
            colDef:{
                dataType:'DROPDOWN'
            },
            column:{
                getId
              },
              data:{},
        }
        function getId(){
            return '10011'
          }
        component.agInit(params)
        expect(component.isDropDown).toBeTruthy();
    })  


    it('test agInit if cell editor is agLargeTextCellEditor and cols are defined ',()=>{
        let params:any={
            colDef:{
                dataType:'CHAR',
                cellEditor:'agLargeTextCellEditor',
                cellEditorParams:{
                    rows:{}
                }
            },
            column:{
                getId
              },
              data:{},
        }
        function getId(){
            return '10011'
          }
        component.agInit(params)
        expect(component.isDropDown).toBeFalsy();
    })  

    it('test agInit if cell editor is agLargeTextCellEditor and rows are defined ',()=>{

        let params:any={
            colDef:{
                dataType:'CHAR',
                cellEditor:'agLargeTextCellEditor',
                cellEditorParams:{
                    cols:{}
                }
            },
            column:{
                getId
              },
              data:{},
        }
        function getId(){
            return '10011'
          }
        component.agInit(params)
        expect(component.isDropDown).toBeFalsy();
    })  

    it('test agInit if params has errors',()=>{
        let errors:any[]=[
            {
             errorLevel:'high'
            },
            {
                errorLevel:'medium'   
            },
            {
                errorLevel:'medium'
            }
        ]

        let errorObj:any[]=[{
            errorFiled:"SNO"
        }]
        let params:any={
            colDef:{
                dataType:'CHAR',
                cellEditor:'agLargeTextCellEditors',
                cellEditorParams:{
                    cols:{}
                }
            },
            column:{
                getId
              },
              data:{
                error:{
                    errors:{
                        filter
                    },
                    rowIndex:11
                }
              },
              rowIndex:11
        }

        function filter(){
          return  errors
        }
        function getId(){
            return '10011'
          }
        component.agInit(params)
        expect(component.isDropDown).toBeFalsy();
    }) 

   it('test refresh',()=>{
       let params:any={}
      expect(component.refresh(params)).toBeTruthy();
   });


});