import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatDialogRef, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatListModule, MatMenuModule, MatPaginatorModule, MatProgressBarModule, MatProgressSpinnerModule, MatSelectModule, MatSidenavModule, MatSnackBarModule, MatSortModule, MatStepperModule, MatTooltipModule, MAT_DIALOG_DATA } from "@angular/material";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { ActivatedRoute, Router, RouterModule } from "@angular/router";
import { GridApi } from "ag-grid";
import { AgGridModule } from "ag-grid-angular";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { Observable, of } from "rxjs";
import { AlertDialogComponent } from "../alert-dialog/alert-dialog.component";
import { BPFUPropagateChangesDialogComponent } from "../bp-fu-propagate-changes-dialog-details/bp-fu-propagate-changes-dialog.component";
import { ConfirmDialogComponent } from "../confirm-dialog/confirm-dialog.component";
import { DashReportComponent } from "../dash-report/dash-report.component";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { BestPracticeObject } from "../model/bestpractice-object";
import { Platform } from "../model/master-platform";
import { ProjectObject } from "../model/project-object";
import { ScreenObject } from "../model/screen-object";
import { SSSObject } from "../model/sss-object";
import { StoreObject } from "../model/store-object";
import { TemplateObject } from "../model/template-object";
import { ProcessValidationResultsComponent } from "../process-validation-results/process-validation-results.component";
import { AuditLogService } from "../services/audit-log-service";
import { AuthService } from "../services/auth-service";
import { BestPracticeService } from "../services/bestpractice-service";
import { DataTransferService } from "../services/data-transfer-service";
import { ExcelService } from "../services/excel-service";
import { FlexDashService } from "../services/flex-dash.service";
import { FlexValidationService } from "../services/flex-validation.service";
import { FormattingService } from "../services/formatting-service";
import { FunctionalAreaService } from "../services/functional-area-service";
import { FunctionalUnitService } from "../services/functional-unit-service";
import { ProjectService } from "../services/project-service";
import { RowDataService } from "../services/rowdata-service";
import { ServerCommunicationService } from "../services/server-communication-service";
import { StoreService } from "../services/store-service";
import { ValidationRuleService } from "../services/validation-rule-service";
import { ValidationService } from "../services/validation-service";
import { SteppedProgressbarComponent } from "../stepped-progressbar/stepped-progressbar.component";
import { FunctionalUnitVerticalStepper } from "../vertical-stepper-fu/vertical-stepper-fu.component";
import { TemplateInformationComponent } from "./template-information.component";
import FileSaver = require("file-saver");

describe('TemplateInformationComponent',() => {

    let component : TemplateInformationComponent;
    let fixture : ComponentFixture<TemplateInformationComponent>;
    let auditLogService:AuditLogService;
    let functionalAreaService: FunctionalAreaService;
    let functionalUnitService: FunctionalUnitService;
    let dataTransferService : DataTransferService;
    let authService: AuthService;
    let validationService : ValidationService;
    let excelService : ExcelService;
    let formattingService: FormattingService;
    let bestPracticeService : BestPracticeService;
    let projectService : ProjectService;
    let storeService : StoreService;
    let rowDataService : RowDataService;
    let flexDashService :FlexDashService;
    let routerStub: Router;
    let gridApi:any;
    let serverCommunicationService :ServerCommunicationService;
    let dialog: jasmine.SpyObj<MatDialog>;


    const fakeActivatedRoute = {
        snapshot: {
             params: {

         } }
      } as ActivatedRoute;
    
      const testUrl = 'projects/create';

    beforeEach(async(() =>{

        let data= {
        }
        const gridApiSpy = jasmine.createSpyObj('GridApi',['sizeColumnsToFit','setColumnDefs','setRowData']);
        TestBed.configureTestingModule({
           imports: [
                MatCardModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatPaginatorModule,
                MatDialogModule,
                ToastrModule.forRoot(),
                AgGridModule.withComponents([]),
                RouterModule.forRoot([]),
                CommonModule,
                MatSelectModule,
                MatSortModule,
                MatIconModule,
                FormsModule,
                MatMenuModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                SortableModule,
                MatSortModule,
                MatStepperModule,
                ReactiveFormsModule,
                MatSnackBarModule,
                MatSidenavModule,
                MatProgressBarModule,
                MatListModule,
                MatCheckboxModule,
                MatTooltipModule,
            ],
            declarations : [TemplateInformationComponent,
                LoaderDialogueComponent,SteppedProgressbarComponent,
                FunctionalUnitVerticalStepper,ConfirmDialogComponent,
                ProcessValidationResultsComponent,BPFUPropagateChangesDialogComponent,
                AlertDialogComponent,DashReportComponent],
            providers : [
                FunctionalAreaService,
                FunctionalUnitService,
                DataTransferService,
                ValidationService,
                ExcelService,
                FormattingService,
                BestPracticeService,
                ProjectService,
                StoreService,
                RowDataService,
                FlexDashService,
                FlexValidationService,
                ServerCommunicationService,
                AuditLogService,
                AuthService,
                ToastrService,
                ServerCommunicationService,
                ValidationRuleService,
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: ''},
                {provide:GridApi,useValue:gridApiSpy},
                {provide: ActivatedRoute, useValue: {snapshot: {params: {storeId:"S123",functionalAreaId:"456",projectNumber:"P111"}}}}

            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent,
              ConfirmDialogComponent,ProcessValidationResultsComponent,
              BPFUPropagateChangesDialogComponent,AlertDialogComponent,DashReportComponent]}});
            routerStub  = TestBed.get(Router);
            auditLogService = TestBed.get(AuditLogService);
            functionalUnitService = TestBed.get(FunctionalUnitService);
            functionalAreaService = TestBed.get(FunctionalAreaService);
            dataTransferService = TestBed.get(DataTransferService);
            authService = TestBed.get(AuthService);
            validationService = TestBed.get(ValidationService);
            excelService = TestBed.get(ExcelService);
            formattingService = TestBed.get(FormattingService);
            bestPracticeService = TestBed.get(BestPracticeService);
            projectService = TestBed.get(ProjectService);
            storeService = TestBed.get(StoreService);
            rowDataService = TestBed.get(RowDataService);
            flexDashService = TestBed.get(FlexDashService);
            serverCommunicationService = TestBed.get(ServerCommunicationService);
        }));

      beforeEach(() => {

        let tempProject:any={
          id:"P150"
        }
        let tempStores:any[]=[
          {
            enterpriseStore:true
          }
        ]
        fixture = TestBed.createComponent(TemplateInformationComponent);
        component = fixture.componentInstance;

        spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of({}));
        component.isBestPractice = false;
        component.isEnterpriseStore = 'false';
        component.isStateStandard = false;
        component.isSSSNavigatedFromProject = false;
        spyOn(projectService,'getProjectByNumber').and.returnValue(Observable.of(tempProject));
        spyOn(projectService,'getStoresOfProject').and.returnValue(Observable.of(tempStores));
        spyOn(authService,'isAuthorised').and.returnValue(true);
        fixture.detectChanges();
        expect(component).toBeTruthy();
    });

    const currentProject: ProjectObject = {
        "isProject": 1,
        "enterpriseId": "172935",
        "projectNumber": "PM525916",
        "dealerName": "CDK Automation",
        "location": null,
        "storeIds":null,
        "platform": {
          "platformName": "DRIVE",
          "platformCode": "drive",
          "selected": false
        },
        "status": "OPEN",
        "clientManager": null,
        "vic": null,
        "css": null,
        "projectManager": null,
        "language": null,
        "country": "Other",
        "timezone": null,
        "cdku": false,
        "cdku_coordinator": null,
        "cdku_domain": null,
        "cdku_division": null,
        "cdku_login": null,
        "cdku_password": null,
        "clientProjectAdvocate": null,
        "version": 0,
        "failed": false,
        "projectSourceEnv": "DASH",
        "dealerApproverContact": "Ford",
        "dealerApproverRequired": true,
        "createdDate": null,
        "lastUpdatedDate": null,
        "createdBy": "dotdemouser3@cdk.com",
        "updatedBy": "dotdemouser3@cdk.com",
        "id": "9d3508f7-c0d9-408f-b575-5dd0bf83629b",
        "recordType": "ProjectInfo"
  
    };
  
    const functionalArea: TemplateObject={
        "functionalAreaName": "Sales",
        "functionalAreaType": null,
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Transfer to DMS failed",
        "platforms": [
          {
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true
          }
        ],
        "vic": null,
        "secondaryVic": null,
        "clientFunctionalAreaUser": null,
        "version": 43,
        "isFailed": null,
        "inProcess": false,
        "productCode": "PTS",
        "productVersion": null,
        "bpId": "63f38af3-92e3-4509-81b5-c59365cc7df1",
        "bpVersionId": "70766cde-1b7b-46b1-9c73-a8adf96ceac8",
        "bpTemplateId": "46675d78-a8d5-41ca-8801-c679ef00cff4",
        "isDealerApproved": false,
        "stateStandardId": null,
        "stateStandardName": null,
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": true,
        "showValidateOrTransferButton": false,
        "showProcessValidationResultsButton": true,
        "createdDate": null,
        "lastUpdatedDate": null,
        "screenIds":null,
        "createdBy": null,
        "updatedBy": "Harika.Gajabimkar@cdk.com",
        "incorporateBpChanges": true,
        "isLocked":false,
        "storeId":null,
        "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
        "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
    };

    const storeObject: StoreObject={
        "storeId" : "S000000000",		
        "storeName": "SWANSON FAHRNEY FORD",
        "streetAddress": "3105 HIGHLAND AVE",
        "city": "SELMA",
        "province": "California",
        "zipcode": "93662",
        "templateIds":null,
        "projectId":'123',
        "glCompanyNumber": "5",
        "logonName": "FF-FI",
        "sharedLogonName": null,
        "clientStoreAdvocate": null,
        "language": "en_US",
        "country": "United States",
        "timezone": "UTC-6: Central Standard Time (CST)",
        "cdku_coordinator": null,
        "oem": null,
        "businessPhone": null,
        "enterpriseStore": false,
        "ipAddress": "207.187.74.84",
        "dmsCNumber": "C208605",
        "cmfNumber": "05236540",
        "url": null,
        "storeNumber": "S123",
        "createdDate": null,
        "lastUpdatedDate": null,
        "createdBy": "Ravi.Musinada@cdk.com",
        "updatedBy": "Ravi.Musinada@cdk.com",
        "locked": false,
        "id": "d6111967-f46e-4bf1-99f7-d877f8655872",
        "recordType": "26573770-757a-42c3-8e11-307f6e8051ac"

    }

    const screenObject : ScreenObject = {
      "screenName": "Account Definition",
      "gridOptionsModel": {
        "animatedRows": false,
        "rowSelection": "multiple",
        "columnDefs": [
          {
            "headerName": "Starting RO Number",
            "field": "starting_ro_number",
            "dataType": "INT",
            "required": "false",
            "editable": "false",
            "editableByCDKOnly": "false",
            "defaultValue": "",
            "validationRule": "",
            "dataLength": 9,
            "cellEditor": "agLargeTextCellEditor",
            "cellEditorParams": {
              "maxLength": 9
            }
          }
        ],
        "rowData":null
      },
      "description": "Account Definition",
      "updated": false,
      "version": 0,
      "productCode": "SVC",
      "index": 0,
      "bpScreenId": "6e260b12-03d5-4a9e-854c-ea29eba80dbd",
       "selected": false,
       "templateId": null,
      "copyRowData": true,
      "rowDataEmpty": false,
      "bpPropagationCompleted": false,
      "id": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
      "recordType": "ff991af6-3c55-4642-a500-bed944b7f574" 
    }

    let platForm :Platform={
      "platformName": "FLEX",
      "platformCode": "flex",
      "selected": false,
      "id":"1",
      "recordType":"platform"
    }
    
    const bestPractice: BestPracticeObject={
      isBestPractice : 1,
      bestPracticeName : "Test BP",
      platform : platForm,	
      version : 123,
      failed : false,
      isSSS : 0,
      id:"1",
      recordType:null
    }

    const sssObject:SSSObject={
      "isStateStandardDialog":true,
      "sssVersion":"2020",
      "sssFaName":"Sales",
      "sssStore":"S1_SBV - Clone",
      "sssName":"testbp123",
      "projectNumber":"SBV100",
      "stateStandardVersionRecordType":"5993191b-b392-482e-ad9e-89f40f678fcb",
      "sssFAId":"b3488379-4b8f-4571-8ced-358863e10d31"
    }
    it('test dealerApproverCriteria',()=>{

        component.projectObject = currentProject;
        spyOn(component,'checkLogInForDealerApprover').and.returnValue(true);
        spyOn(component,'checkForEditGridPermission').and.returnValue(false);
        component.dealerApproverCriteria();
    });

    it('test checkLogInForDealerApprover',()=>{

        let loggedInUserRoleList:any[]=[
            {
              roleName:"DOT - Dealer Approver"
            },
            {
                roleName:"ADMIN"
            }
        ]
        let dealerApprovePermission:boolean= true;
        component.loggedInUserRoleList = loggedInUserRoleList;
        component.dealerApprovePermission = dealerApprovePermission;
        let result = component.checkLogInForDealerApprover();
        expect(result).toBeTruthy();
        expect(component.isDealerApproverLogin).toBeTruthy();
        
    });

    
    it('test checkLogInForDealerApprover for no having Dealer Approver Role',()=>{

        let loggedInUserRoleList:any[]=[
            {
                roleName:"ADMIN"
            }
        ]
        let dealerApprovePermission:boolean= true;
        component.loggedInUserRoleList = loggedInUserRoleList;
        component.dealerApprovePermission = dealerApprovePermission;
        let result = component.checkLogInForDealerApprover();
        expect(result).toBeTruthy();
        expect(component.isDealerApproverLogin).toBeFalsy();
        
    });

    it('test checkForEditGridPermission',()=>{
        let checkForEditableByCDKOnly= true;
        component.adminPermission = true;
        spyOn(component,'checkIfLoggedInUserIsCDKPersonnel').and.returnValue(true);
       let result = component.checkForEditGridPermission(checkForEditableByCDKOnly);
       expect(result).toBeTruthy();
    });
    
    it('test checkForEditGridPermission in case adminPermission false',()=>{
        let checkForEditableByCDKOnly= true;
        component.adminPermission = false;
       let result = component.checkForEditGridPermission(checkForEditableByCDKOnly);
       expect(result).toBeFalsy();
    });

    it('test checkForEditGridPermission in case checkForEditableByCDKOnly false',()=>{
        let checkForEditableByCDKOnly= false;
        component.adminPermission = true;
       let result = component.checkForEditGridPermission(checkForEditableByCDKOnly);
       expect(result).toBeTruthy();
       
    });

    it('test checkIfLoggedInUserIsCDKPersonnel',()=>{
        let user:any={
            enterprise:{
                id:'E000000'
                
            }
        }
       spyOn(authService,'getLoggedInUser').and.returnValue(user);
       let result = component.checkIfLoggedInUserIsCDKPersonnel();
       expect(result).toBeTruthy(); 
    });

    it('test setStepperStatus',()=>{
        component.setStepperStatus("Work in Progress");
        expect(component.stepperStatus).toBe('Data Collection')
        expect(component.status).toBe('Work in Progress')

        component.isProjectSourceEnvDash= true;
        component.setStepperStatus('Request Dealer for Approval');
        expect(component.stepperStatus).toBe('Dealer Approval')
        expect(component.status).toBe('Request Dealer for Approval')

        component.setStepperStatus('Request Cancelled by Dealer');
        expect(component.stepperStatus).toBe('Data Collection')
        expect(component.status).toBe('Request Cancelled by Dealer')

        component.setStepperStatus('Validation Done');
        expect(component.stepperStatus).toBe('Validation')
        expect(component.status).toBe('Validation Done')

        component.setStepperStatus('Validation Failed');
        expect(component.status).toBe('Validation Failed')

        component.setStepperStatus('Sent to DMS');
        expect(component.stepperStatus).toBe('Start Setup')
        expect(component.status).toBe('Sent to DMS')

        component.setStepperStatus('Transfer to DMS successful');
        expect(component.stepperStatus).toBe('Complete')
        expect(component.status).toBe('Transfer to DMS successful')
    });


    it('test iconColor',()=>{

        let result =component.iconColor('OPEN')
        expect(result.color).toBe('yellow')

        let result1 =component.iconColor('Transfer to DMS successful')
        expect(result1.color).toBe('green')

        let result12 =component.iconColor('Validation Done')
        expect(result12.color).toBe('blue')

        let result3 =component.iconColor('Sent to DMS')
        expect(result3.color).toBe('orange')

        let result4 =component.iconColor('Validation in Progress')
        expect(result4.color).toBe('gray')

        let result5 =component.iconColor('Validation Failed')
        expect(result5.color).toBe('red')
    });

    it('test settingAuditlogDetails',()=>{

        component.isProject = false;
        component.projectNumber = "P1122"
        component.versionName = "2021"
        component.isStateStandard = false;
        component.settingAuditlogDetails();
        expect(component.bp_auditlog_name).toBe("P1122 - 2021")
        expect(component.bp_auditlog_msg).toBe('OEM BP Version Updated')
    });

    
    it('test settingAuditlogDetails  BP type is SSS',()=>{

        component.isProject = false;
        component.projectNumber = "P1122"
        component.versionName = "2021"
        component.isStateStandard = true;
        component.settingAuditlogDetails();
        expect(component.bp_auditlog_name).toBe("P1122 - 2021")
        expect(component.bp_auditlog_msg).toBe('State Standard Version Updated')
    }); 

    it('test showDealerApprovalButton',()=>{

      component.editGridPermissionForVIC = true;
      component.isProjectSourceEnvDash = true;
      component.templateObject = functionalArea;
      component.isDealerApproverLogin  = false;
      let result =component.showDealerApprovalButton();
      expect(result).toBeTruthy();
    });

    it('test showDealerApprovalButton false for editGridPermissionForVIC ',()=>{

        component.editGridPermissionForVIC = false;
        component.isProjectSourceEnvDash = true;
        component.templateObject = functionalArea;
        component.isDealerApproverLogin  = false;
        let result =component.showDealerApprovalButton();
        expect(result).toBeFalsy();
      });

      it('test showGLRowDataButton',()=>{
        component.isProjectSourceEnvDash = true;
        component.templateObject = functionalArea;
        let result = component.showGLRowDataButton();
        expect(result).toBeTruthy();
      });

      it('test showGLRowDataButton if isProjectSourceEnvDash is false',()=>{
        component.isProjectSourceEnvDash = false;
        component.templateObject = functionalArea;
        let result = component.showGLRowDataButton();
        expect(result).toBeFalsy();
      });

      it('test showValidateButton',()=>{
        component.isProjectSourceEnvDash = true;
        component.projectObject = currentProject;
        let result = component.showValidateButton();
        expect(result).toBeFalsy();
      });

     it('test showValidateButton in case isProjectSourceEnvDash false',()=>{
        component.isProjectSourceEnvDash = false;
        component.editGridPermissionForVIC = true;
        component.projectObject = currentProject;
        component.processValidationCompleteOrOverridden = true;
        component.templateObject = functionalArea
        let result = component.showValidateButton();
        expect(result).toBeTruthy();
      });

      it('test showTransferButton',()=>{
        component.editGridPermissionForVIC = true;
        component.projectObject = currentProject;
        component.processValidationCompleteOrOverridden  = true;
        component.templateObject = functionalArea
        let result =component.showTransferButton();
        expect(result).toBeTruthy();
      });

      it('test showProcessValidationResultsButton',()=>{
        component.editGridPermissionForVIC = true;
        component.projectObject = currentProject;
        component.showProcessValidationResultButton  = true;
        let result =component.showProcessValidationResultsButton();
      
        expect(result).toBeTruthy();
      });

      it('test showImportCOARawData',()=>{

        component.isProjectSourceEnvDash = true;
        let templateObj = functionalArea;
        templateObj.functionalAreaName = "Accounting";
        component.templateObject = templateObj;
        let result = component.showImportCOARawData();
        expect(result).toBeTruthy();

      });

      it('test showImportCOARawData if isProjectSourceEnvDash false ',()=>{

        component.isProjectSourceEnvDash = false;
        let result = component.showImportCOARawData();
        expect(result).toBeFalsy();
        
      });
  
      it('test changeTemplateStatus_Dealer',()=>{

        let data:any={}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close:  {}});
        dialogRefSpyObj.componentInstance = { body: '' };
        spyOn(component,'getTemplateInfo');

        let data1:any={
            _body:'Request Dealer for Approval'
        }
        spyOn(flexDashService,'statusUpdateFunctionalArea').and.returnValue(Observable.of(data1))
        component.changeTemplateStatus_Dealer('Transfer to DMS failed');
        expect(component.templateObject.status).toBe('Request Dealer for Approval')
      });

      
      it('test changeTemplateStatus_Dealer for Request Approved by Dealer status ',()=>{

        let data:any={}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close:  {}});
        dialogRefSpyObj.componentInstance = { body: '' };
        spyOn(component,'getTemplateInfo');

        let data1:any={
            _body:'Request Approved by Dealer'
        }
        spyOn(flexDashService,'statusUpdateFunctionalArea').and.returnValue(Observable.of(data1))
        component.changeTemplateStatus_Dealer('Transfer to DMS failed');
        expect(component.templateObject.status).toBe('Request Approved by Dealer')
      });

      it('test changeTemplateStatus_Dealer for Request Cancelled by Dealer',()=>{

        let data:any={}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close:  {}});
        dialogRefSpyObj.componentInstance = { body: '' };
        spyOn(component,'getTemplateInfo');

        let data1:any={
            _body:'Request Cancelled by Dealer'
        }
        spyOn(flexDashService,'statusUpdateFunctionalArea').and.returnValue(Observable.of(data1))
        component.changeTemplateStatus_Dealer('Transfer to DMS failed');
        expect(component.templateObject.status).toBe('Request Cancelled by Dealer')
      });

      it('test changeTemplateStatus_Dealer throws error',()=>{

        let data:any={}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close:  {}});
        dialogRefSpyObj.componentInstance = { body: '' };
        spyOn(component,'getTemplateInfo');

        let data1:any={
            _body:'Request Cancelled by Dealer'
        }
        let error:any={
            error:{
                message:"server throw error"
            }
        }
        spyOn(flexDashService,'statusUpdateFunctionalArea').and.returnValue(Observable.throwError(error))
        component.changeTemplateStatus_Dealer('Transfer to DMS failed');
      });
      
      it('test checkPtsSvcFaStatus',()=>{

        let templateObj = functionalArea;
        templateObj.functionalAreaName = "Accounting";
        templateObj.productCode = 'ACCT';
        component.templateObject = templateObj;

        let functionalAreas : any[]=[
            {
             productCode:'PTS',
             status:'Transfer to DMS successful'   
            },
            {
             productCode:'SVC' 
            }
        ]
        spyOn(functionalAreaService,'getFunctionalAreasByStoreId').and.returnValue(Observable.of(functionalAreas))
        spyOn(component,'changeTemplateStatus');
        component.checkPtsSvcFaStatus('validate')
        expect(functionalAreaService.getFunctionalAreasByStoreId).toHaveBeenCalledTimes(1);
        expect(component.matchedFunctionalAreas.length).toEqual(1)
      });

      it('test checkPtsSvcFaStatus if matching functional areas are 0',()=>{

        let templateObj = functionalArea;
        templateObj.functionalAreaName = "Accounting";
        templateObj.productCode = 'ACCT';
        component.templateObject = templateObj;

        let functionalAreas : any[]=[
            {
             productCode:'ACT',
             status:'Transfer to DMS successful'   
            },
            {
             productCode:'SLS' 
            }
        ]
        spyOn(functionalAreaService,'getFunctionalAreasByStoreId').and.returnValue(Observable.of(functionalAreas))
        spyOn(component,'changeTemplateStatus');
        component.checkPtsSvcFaStatus('validate')
        expect(functionalAreaService.getFunctionalAreasByStoreId).toHaveBeenCalledTimes(1);
        expect(component.matchedFunctionalAreas.length).toEqual(0)
      });

      it('test checkPtsSvcFaStatus if matching functional areas are 0',()=>{

        let templateObj = functionalArea;
        templateObj.functionalAreaName = "Service";
        templateObj.productCode = 'SVC';
        component.templateObject = templateObj;
        spyOn(component,'changeTemplateStatus');
        component.checkPtsSvcFaStatus('validate')
        expect(component.changeTemplateStatus).toHaveBeenCalledTimes(1);
      });

      it('test checkAccFaStatus',()=>{
        let templateObj = functionalArea;
        templateObj.functionalAreaName = "Parts";
        templateObj.productCode = 'PTS';
        component.templateObject = templateObj;
        let functionalAreas : any[]=[
            {
             productCode:'ACCT',
             status:'Validation Done'   
            },
            {
             productCode:'SLS' 
            }
        ]
        spyOn(functionalAreaService,'getFunctionalAreasByStoreId').and.returnValue(Observable.of(functionalAreas))
        component.checkAccFaStatus('validate');
        expect(functionalAreaService.getFunctionalAreasByStoreId).toHaveBeenCalledTimes(1);
        expect(component.matchedFunctionalAreas.length).toEqual(1)
    });

    it('test checkAccFaStatus if matching functional area length zero',()=>{
        let templateObj = functionalArea;
        templateObj.functionalAreaName = "Parts";
        templateObj.productCode = 'PTS';
        component.templateObject = templateObj;
        let functionalAreas : any[]=[
            {
             productCode:'SLS',
             status:'Validation Done'   
            },
            {
             productCode:'SLS' 
            }
        ]
        spyOn(component,'changeTemplateStatus');
        spyOn(functionalAreaService,'getFunctionalAreasByStoreId').and.returnValue(Observable.of(functionalAreas))
        component.checkAccFaStatus('validate');
        expect(functionalAreaService.getFunctionalAreasByStoreId).toHaveBeenCalledTimes(1);
        expect(component.matchedFunctionalAreas.length).toEqual(0)
        expect(component.changeTemplateStatus).toHaveBeenCalledTimes(1);
    });

    it('test checkAccFaStatus if Product code is other than PTS or SVC',()=>{
        let templateObj = functionalArea;
        templateObj.functionalAreaName = "Sales";
        templateObj.productCode = 'SLS';
        component.templateObject = templateObj;
        spyOn(component,'changeTemplateStatus');
        component.checkAccFaStatus('validate');
        expect(component.changeTemplateStatus).toHaveBeenCalledTimes(1);
    });

    it('test checkAccFaStatus if Product code is ACCT',()=>{
        let templateObj = functionalArea;
        templateObj.functionalAreaName = "Accounting";
        templateObj.productCode = 'ACCT';
        component.templateObject = templateObj;
        spyOn(component,'checkPtsSvcFaStatus');
        component.checkAccFaStatus('validate');
        expect(component.checkPtsSvcFaStatus).toHaveBeenCalledTimes(1);
    });

    it('test changeTemplateStatus for validate status',()=>{
       
        let data1:any={}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close:  {}});
        dialogRefSpyObj.componentInstance = { body: '' };
        let data:any;{
            faStatus:'Validation in Progress'
        }
        component.storeObject = storeObject;
        spyOn(functionalAreaService,'getFunctionalAreaStatus').and.returnValue(Observable.of('Validation In Progress'));
        spyOn(functionalAreaService,'validateAndTransferProduct').and.returnValue(Observable.of({}));
        spyOn(component,'getTemplateInfo');
        component.changeTemplateStatus('validate')
        expect(functionalAreaService.getFunctionalAreaStatus).toHaveBeenCalledTimes(1);
        expect(functionalAreaService.validateAndTransferProduct).toHaveBeenCalledTimes(1);
        expect(component.templateObject.status).toBe('Validation Done');
        
    });

    
    it('test changeTemplateStatus for transfer status',()=>{
       
        let data1:any={}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close:  {}});
        dialogRefSpyObj.componentInstance = { body: '' };
        component.storeObject = storeObject;
        spyOn(functionalAreaService,'getFunctionalAreaStatus').and.returnValue(Observable.of('Validation In Progress'));
        spyOn(functionalAreaService,'validateAndTransferProduct').and.returnValue(Observable.of({}));
        spyOn(component,'getTemplateInfo');
        component.changeTemplateStatus('transfer')
        expect(functionalAreaService.getFunctionalAreaStatus).toHaveBeenCalledTimes(1);
        expect(functionalAreaService.validateAndTransferProduct).toHaveBeenCalledTimes(1);
        expect(component.templateObject.status).toBe('Sent for Setup');
        
    });

    it('test changeTemplateStatus for Invalid CurrentStatus or FunctionalAreaStatus',()=>{
       
      let data1:any={}
      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close:  {}});
      dialogRefSpyObj.componentInstance = { body: '' };
      component.storeObject = storeObject;
      spyOn(functionalAreaService,'getFunctionalAreaStatus').and.returnValue(Observable.of(undefined));
      component.changeTemplateStatus('transfer');
      expect(component['toastrService'].previousToastMessage).toBe('Someone else is already performing action on this Functional Area..please try again later');
    });


   it('test changeTemplateStatus for empty ipAddress',()=>{
    let storeObj = storeObject;
    storeObj.ipAddress= null;
    component.storeObject = storeObj;
    component.changeTemplateStatus('transfer')
    expect(component['toastrService'].previousToastMessage).toBe('IP address cannont be empty!');
    });



    it('test changeTemplateStatus api throwError',()=>{

      let error:any={
        error:{
          message:'API Error'
        }
      }

      let value:any={
        result:true
      }
      let data1:any={}
      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(value), close:  {}});
      dialogRefSpyObj.componentInstance = { body: '' };

  
      let data:any;{
          faStatus:'Validation in Progress'
      }
      component.storeObject = storeObject;
      spyOn(functionalAreaService,'getFunctionalAreaStatus').and.returnValue(Observable.of('Validation In Progress'));
      spyOn(functionalAreaService,'validateAndTransferProduct').and.returnValue(Observable.throwError(error));
      spyOn(component,'getTemplateInfo');
      component.changeTemplateStatus('validate')
    });

    it('test importFlexData',()=>{

      let data1:any={}
      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed:of(true), close:  {}});
      dialogRefSpyObj.componentInstance = { body: '' };
   
      component.storeObject = storeObject;
      component.functionalAreaId = "FA1122";
      component.projectObject = currentProject;
      spyOn(flexDashService,'importFlexData').and.returnValue(Observable.of({}));
      spyOn(flexDashService,'bindFlexAPi').and.returnValue(Observable.of({}));
      component.importFlexData();
      expect(component.flexApi.storeNumber).toBe("S123")
      expect(component.flexApi.projectId).toBe("9d3508f7-c0d9-408f-b575-5dd0bf83629b")
      expect(flexDashService.importFlexData).toHaveBeenCalledTimes(1);
      expect(flexDashService.bindFlexAPi).toHaveBeenCalledTimes(1);
    });

    it('test importFlexData throws error',()=>{

      let data1:any={}
      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed:of(true), close:  {}});
      dialogRefSpyObj.componentInstance = { body: '' };
   
      component.storeObject = storeObject;
      component.functionalAreaId = "FA1122";
      component.projectObject = currentProject;
      spyOn(flexDashService,'importFlexData').and.returnValue(Observable.throwError('error'));
      component.importFlexData();
      expect(component.flexApi.storeNumber).toBe("S123")
      expect(component.flexApi.projectId).toBe("9d3508f7-c0d9-408f-b575-5dd0bf83629b")
      expect(flexDashService.importFlexData).toHaveBeenCalledTimes(1);
    });

    it('test importFlexData in case of store number is empty',()=>{

      let storeObj = storeObject;
        storeObj.storeNumber= "";
        component.storeObject = storeObj;
      component.importFlexData();
      expect(component['toastrService'].previousToastMessage).toBe('Vendor store number cannot be empty')
    });

    it('test fetchScreenData',()=>{

      let screen:any={
        "bpPropagationCompleted": false,
        "bpScreenId": "e7037681-29f3-48a1-9b31-a52235fb5ce7",
        "copyRowData": false,
        "deleted": false,
        "description": "Account Definition",
        "id": "98048de0-066c-4bfa-8de5-2c397198cd44",
        "index": 0,
        "productCode": "PTS",
        "recordType": "7f6c5165-1159-4f18-91ec-b4cb82ce0974",
        "rowDataEmpty": true,
        "screenName": "Account_Definition",
        "updated": false,
        "version": 0
      }

      let rowData:any[]=[
        {
          "rowDataId": "7ff415a2-f62c-4a77-a276-c06d77188844",
          "data": {
            "rowDataId": "7ff415a2-f62c-4a77-a276-c06d77188844",
            "screenId": null,
            "cdk_source_3_digits": "102",
            "description": "adding new source",
            "manufacturer_code": "GZ",
            "order_pad_number": "111",
            "sort_source_number": "101",
            "auto-create_reverse_memos_(y_n)": "YES",
            "keep_prices_on_memo_(y_n)": "YES",
            "transfer_prices_to_new#_on_pnc_(y_n)": "NO",
            "require_delay_pnc_s_(y_n)": "YES",
            "transfer_orders_to_new#_on_delay_pnc_(y_n)": "YES",
            "update_delay_pnc_(y_n)": "YES",
            "source_prefix": "check",
            "ss_default": "NS",
            "use_source_escalators_(y_n)": "NO",
            "recordType": 1000,
            "id": "02200ce4-c178-43e0-a434-2c13ce4f47b5",
            "index": "1000"
          },
          "id": "02200ce4-c178-43e0-a434-2c13ce4f47b5",
          "recordType": "1000"
        }
      ]
      let screenContext: any={
        "rowData": [],
        "screen":{
        "bpPropagationCompleted": false,
        "bpScreenId": "a7627cf7-2ead-4f43-9fe2-f5af0eceefed",
        "copyRowData": false,
        "deleted": false,
        "description": "Source Criteria",
        "id": "9eb8c050-8dda-4817-9877-8bebca0d3c60",
        "index": 0,
        "masterScreenId": null,
        "productCode": "PTS",
        "recordType": "02200ce4-c178-43e0-a434-2c13ce4f47b5",
        "rowDataEmpty": false,
        "screenName": "Source Criteria",
        "updated": false,
        "version": 0
        }
      }
      spyOn(rowDataService,'getRowDataOfScreen').and.returnValue(Observable.of(rowData))
      spyOn(component,'processTemplateGrid');
      const privateSpy = spyOn<any>(component, 'handleSettingRowData');
      component['fetchScreenData'](true,screen,screenContext)
      expect(component['handleSettingRowData']).toHaveBeenCalledTimes(1);
      expect(component.processTemplateGrid).toHaveBeenCalledTimes(1);
      expect(rowDataService.getRowDataOfScreen).toHaveBeenCalledTimes(1);

    });

    
    it('test fetchScreenData throw error',()=>{

      let data1:any={}
      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed:of(true), close:  {}});
      dialogRefSpyObj.componentInstance = { body: '' };
   
      let screen:any={
        "screenName": "Account_Definition",
      }
      let rowData:any[]=[
        {
          "rowDataId": "7ff415a2-f62c-4a77-a276-c06d77188844",
          "data": {
          },
          "id": "02200ce4-c178-43e0-a434-2c13ce4f47b5",
          "recordType": "1000"
        }
      ]
      let screenContext: any={
        "rowData": [],
        "screen":{
          "recordType": "02200ce4-c178-43e0-a434-2c13ce4f47b5",
          "screenName": "Source Criteria",
          }
      }
      let error:any={
        error:{
            message:"server throw error"
        }
      }
      spyOn(rowDataService,'getRowDataOfScreen').and.returnValue(Observable.throwError(error))
      component['fetchScreenData'](true,screen,screenContext)
      expect(rowDataService.getRowDataOfScreen).toHaveBeenCalledTimes(1);
      expect(component['toastrService'].previousToastMessage).toBe('error while fetching the data server throw error')
      
    });



    it('test fetchScreenData if isGridProcessRequired is false ',()=>{

      let data1:any={}
      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed:of(true), close:  {}});
      dialogRefSpyObj.componentInstance = { body: '' };
      let screen:any={
        "screenName": "Account_Definition",
      }
      let rowData:any[]=[
        {
          "rowDataId": "7ff415a2-f62c-4a77-a276-c06d77188844",
          "data": {
            "rowDataId": "7ff415a2-f62c-4a77-a276-c06d77188844",
            "id": "02200ce4-c178-43e0-a434-2c13ce4f47b5",
            "index": "1000"
          },
          "id": "02200ce4-c178-43e0-a434-2c13ce4f47b5",
          "recordType": "1000"
        }
      ]
      let screenContext: any={
        "rowData": [],
        "screen":{
        "recordType": "02200ce4-c178-43e0-a434-2c13ce4f47b5",
        "screenName": "Source Criteria",
        }
      }
      spyOn(rowDataService,'getRowDataOfScreen').and.returnValue(Observable.of(rowData))
      spyOn(component,'processTemplateGrid');
      const privateSpy = spyOn<any>(component, 'handleSettingRowData');
      component['fetchScreenData'](false,screen,screenContext)
      expect(component['handleSettingRowData']).toHaveBeenCalledTimes(0);
      expect(component.processTemplateGrid).toHaveBeenCalledTimes(0);
      expect(rowDataService.getRowDataOfScreen).toHaveBeenCalledTimes(1);

    });


    it('test exportCSV',()=>{

      component.isBestPractice = true;
      component.isStateStandard = true;
      let csvFileName = "Test.csv"
      component.currentScreen = screenObject;
      spyOn(FileSaver, 'saveAs').and.stub();
      spyOn(serverCommunicationService,'getHeaders').and.returnValue(Observable.of({}));
      spyOn(excelService,'generateFileNameForExportCSV').and.returnValue(Observable.of(csvFileName));
      spyOn(excelService,'getScreenCsv').and.returnValue(Observable.of({}));
      component.exportCSV();
    });

    it('test exportCSV throws error',()=>{

      component.isBestPractice = true;
      component.isStateStandard = true;
      let csvFileName = "Test.csv"
      component.currentScreen = screenObject;
      spyOn(FileSaver, 'saveAs').and.stub();
      spyOn(serverCommunicationService,'getHeaders').and.returnValue(Observable.of({}));
      spyOn(excelService,'generateFileNameForExportCSV').and.returnValue(Observable.of(csvFileName));
      spyOn(excelService,'getScreenCsv').and.returnValue(Observable.throwError('error'));
      component.exportCSV();
    });


    
    it('test exportCSV if isBestPractice  false',()=>{

      component.isBestPractice = false;
      component.isStateStandard = false;
      let csvFileName = "Test.csv"
      component.currentScreen = screenObject;
      spyOn(serverCommunicationService,'getHeaders').and.returnValue(Observable.of({}));
      spyOn(excelService,'generateFileNameForExportCSV').and.returnValue(Observable.of(csvFileName));
      component.exportCSV();
    });

  it('test isDisplaySaveButton',()=>{
    component.editGridPermissionForVIC  = true;
    component.templateObject = functionalArea;
    let result = component.isDisplaySaveButton();
    expect(result).toBeTruthy();

  });

  it('test showViewOrIncorporateBPChangesButton',()=>{
    component.editGridPermissionForVIC  = true;
    component.projectObject = currentProject;
    component.templateObject = functionalArea;
    let result = component.showViewOrIncorporateBPChangesButton();
    expect(result).toBeTruthy();
  });

   it('test getBestPracticeDetailsByName',()=>{
    component.isStateStandard = false;
    spyOn(bestPracticeService,'getByBestPracticeNameAndPlatform').and.returnValue(Observable.of(bestPractice));
    component.getBestPracticeDetailsByName("Test BP",'SVC',true);  
  }); 

  
  it('test getBestPracticeDetailsByName for SSS',()=>{
    component.isStateStandard = true;
    spyOn(bestPracticeService,'getByBestPracticeNameAndPlatform').and.returnValue(Observable.of(bestPractice));
    component.getBestPracticeDetailsByName("Test BP",'SVC',true);  
  }); 

  it('test showImportFlexDataButton for SSS',()=>{
    component.editGridPermissionForVIC  = true;
    component.templateObject = functionalArea;
    let result = component.showImportFlexDataButton();  
    expect(result).toBeTruthy();
  }); 


  it('test openDialogToProcessValidationResults',()=>{


    let result:any={
      processValidationCompleteOrOverridden:true
    }
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(result), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };

    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
 
    component.projectObject = currentProject;
    component.storeObject = storeObject;
    component.templateObject = functionalArea;
  
    let responseFunctionalArea:any={}
    spyOn(functionalAreaService,'saveSingleFunctionalArea').and.returnValue(Observable.of(responseFunctionalArea));
    spyOn(component,'ngOnInit');
    component.openDialogToProcessValidationResults();
    expect(functionalAreaService.saveSingleFunctionalArea).toHaveBeenCalledTimes(1);
    expect(dialogRefSpyObj.afterClosed).toHaveBeenCalled();
  });

  
  it('test openDialogToProcessValidationResults throw error afterClosed',()=>{


    let result:any={
      processValidationCompleteOrOverridden:true
    }
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(result), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };

    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
 
    component.projectObject = currentProject;
    component.storeObject = storeObject;
    component.templateObject = functionalArea;
  
    spyOn(functionalAreaService,'saveSingleFunctionalArea').and.returnValue(Observable.throwError('error'));
    spyOn(component,'ngOnInit');
    component.openDialogToProcessValidationResults();
    expect(functionalAreaService.saveSingleFunctionalArea).toHaveBeenCalledTimes(1);
    expect(dialogRefSpyObj.afterClosed).toHaveBeenCalled();
  });

  it('test openDialogToProcessValidationResults afterClosed result false',()=>{


    let result:any={
      processValidationCompleteOrOverridden:false
    }
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(result), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };

    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
 
    component.projectObject = currentProject;
    component.storeObject = storeObject;
    component.templateObject = functionalArea;
  
    spyOn(component,'ngOnInit');
    component.openDialogToProcessValidationResults();
    expect(dialogRefSpyObj.afterClosed).toHaveBeenCalled();
  });

  it('test viewOrIncorporateBPChanges',()=>{

  
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };

    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    spyOn(component,'ngOnInit');
    component.viewOrIncorporateBPChanges();
    expect(dialogRefSpyObj.afterClosed).toHaveBeenCalled();

  });

  it('test fetchDataForCurrentScreen',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    const myPrivateSpy = spyOn<any>(component, 'fetchScreenData')
    component.currentScreen = screenObject;
    component.templateObject = functionalArea;
    component['fetchDataForCurrentScreen'](false);
    expect(dialogRefSpyObj.afterClosed).toHaveBeenCalled();
  });


  it('test fetchDataForCurrentScreen if copyRowData is false',()=>{
    const myPrivateSpy = spyOn<any>(component, 'fetchScreenData')
    component.currentScreen = screenObject;
    let fa = functionalArea;
    fa.copyRowData = false;
    component.templateObject = fa;
    component['fetchDataForCurrentScreen'](false);
    expect(component['fetchScreenData']).toHaveBeenCalledTimes(1);
  });
  
  it('test selectFunctionalUnit',()=>{

    let event:any={selectedIndex:0}
    let screen1:any={
      rowData:[],
      screen:{
        screenName:"Accounts Payable",
        index: 0
      }
    }
    let templateContext :any={
      screenContextList:[screen1]
    }
    const myPrivateSpy = spyOn<any>(component, 'fetchDataForCurrentScreen');
    component.templateContext = templateContext;
    component.selectFunctionalUnit(event);
    expect(component['fetchDataForCurrentScreen']).toHaveBeenCalledTimes(1);
  });

   
  it('test selectFunctionalUnit in rowData length <=1',()=>{

    let event:any={selectedIndex:0}
    let screen1:any={
      rowData:[{
        name:"test"
      }],
      screen:{
        screenName:"Accounts Payable",
        index: 0
      }
    }
    let templateContext :any={
      screenContextList:[screen1]
    }
    const myPrivateSpy1 = spyOn<any>(component, 'handleSettingRowData');
    component.templateContext = templateContext;
    component.selectFunctionalUnit(event);
    expect(component['handleSettingRowData']).toHaveBeenCalledTimes(1);
  });

  it('test onRowDragEnd',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    let event:any={
      overIndex: 1,
      node: {
        data:{
          "accounting_posting": "Yes",
           "car-inv": "Yes",
           "cash_conversion_(canada_only)": "No",
           "dms_external_ip_address_for_dc": "",
           "error": {
              "rowIndex": 0, 
             "timeStamp": "",
              "errors": Array(2)
             },
           "f&i_leasing": "Yes",
           "forms_builder": "Yes",
           "id": "31361346-e7dd-49ac-b605-bd432ef6dd18",
           "index": "1000",
           "name-file": "No",
           "recordType": 1000,
           "rowDataId": "8250ba32-4419-4bf3-8ac4-5cccb74a8e23",
           "screenId": null,
           "service": "Yes",
           "service_account_name": "",
           "use_digital_contracting_on_this_logon": "No",
           "vms": "Yes",
           "vms_account_name": "",
           "we_owe_activation": "Yes"
       }
      }
    }
    let currentScreenContext:any={
      rowData:[
        {
          "accounting_posting": "Yes",
          "car-inv": "Yes",
          "cash_conversion_(canada_only)": "No",
          "dms_external_ip_address_for_dc": "",
          "error": {
             "rowIndex": 0, 
            "timeStamp": "",
             "errors": Array(2)
            },
          "f&i_leasing": "Yes",
          "forms_builder": "Yes",
          "id": "31361346-e7dd-49ac-b605-bd432ef6dd18",
          "index": "1000",
          "name-file": "No",
          "recordType": 1000,
          "rowDataId": "8250ba32-4419-4bf3-8ac4-5cccb74a8e23",
          "screenId": null,
          "service": "Yes",
          "service_account_name": "",
          "use_digital_contracting_on_this_logon": "No",
          "vms": "Yes",
          "vms_account_name": "",
          "we_owe_activation": "Yes"
        },
        {
        "f&i_leasing": "Yes",
        "forms_builder": "No",
        "id": "31361346-e7dd-49ac-b605-bd432ef6dd18",
        "index": "2000",
        "isUpdated": true,
        "name-file": "Yes",
        "recordType": 500,
        "rowDataId": "a4116205-b5f2-4b37-8636-0934e5fe6010",
        "screenId": null,
        "service": "Yes",
        "service_account_name": "",
        "use_digital_contracting_on_this_logon": "No",
        "vms": "Yes",
        "vms_account_name": "",
        "we_owe_activation": "Yes"
        }
       ],
      screen:{
        recordType: "413b4ec1-392e-4428-8c88-c63ed141c5a9"
      }
    }
    component.currentScreenContext = currentScreenContext;
    component.onRowDragEnd(event);
  });

  it('test onRowDragEnd if previous  index !=0',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    let event:any={
      overIndex: 0,
      node: {
        data:{
          "accounting_posting": "Yes",
           "car-inv": "Yes",
           "cash_conversion_(canada_only)": "No",
           "dms_external_ip_address_for_dc": "",
           "error": {
              "rowIndex": 0, 
             "timeStamp": "",
              "errors": Array(2)
             },
           "f&i_leasing": "Yes",
           "forms_builder": "Yes",
           "id": "31361346-e7dd-49ac-b605-bd432ef6dd18",
           "index": "1000",
           "name-file": "No",
           "recordType": 1000,
           "rowDataId": "8250ba32-4419-4bf3-8ac4-5cccb74a8e23",
           "screenId": null,
           "service": "Yes",
           "service_account_name": "",
           "use_digital_contracting_on_this_logon": "No",
           "vms": "Yes",
           "vms_account_name": "",
           "we_owe_activation": "Yes"
       }
      }
    }
      let currentScreenContext:any={
      rowData:[
        {
          "accounting_posting": "Yes",
          "car-inv": "Yes",
          "cash_conversion_(canada_only)": "No",
          "dms_external_ip_address_for_dc": "",
          "error": {
             "rowIndex": 0, 
            "timeStamp": "",
             "errors": Array(2)
            },
          "f&i_leasing": "Yes",
          "forms_builder": "Yes",
          "id": "31361346-e7dd-49ac-b605-bd432ef6dd18",
          "index": "1000",
          "name-file": "No",
          "recordType": 1000,
          "rowDataId": "8250ba32-4419-4bf3-8ac4-5cccb74a8e23",
          "screenId": null,
          "service": "Yes",
          "service_account_name": "",
          "use_digital_contracting_on_this_logon": "No",
          "vms": "Yes",
          "vms_account_name": "",
          "we_owe_activation": "Yes"
        },
        {
        "f&i_leasing": "Yes",
        "forms_builder": "No",
        "id": "31361346-e7dd-49ac-b605-bd432ef6dd18",
        "index": "2000",
        "isUpdated": true,
        "name-file": "Yes",
        "recordType": 500,
        "rowDataId": "a4116205-b5f2-4b37-8636-0934e5fe6010",
        "screenId": null,
        "service": "Yes",
        "service_account_name": "",
        "use_digital_contracting_on_this_logon": "No",
        "vms": "Yes",
        "vms_account_name": "",
        "we_owe_activation": "Yes"
        }
       ],
      screen:{
        recordType: "413b4ec1-392e-4428-8c88-c63ed141c5a9"
      }
    }
    component.currentScreenContext = currentScreenContext;
    component.onRowDragEnd(event);
  });

  it('test isBlank',()=>{
    let result = component.isBlank('test')
    expect(result).toBeFalsy();
    
  });

  it('test requiredFieldsNotFilled',()=>{

    let currentScreenContext:any={
      rowData:[
        {
          "accounting_posting": "Yes",
          "car-inv": "Yes",
          "cash_conversion_(canada_only)": "No",
          "dms_external_ip_address_for_dc": "",
          "f&i_leasing": "Yes",
          "forms_builder": "Yes",
          "name-file": "Yes",
          "recordType": 1000,
          "rowDataId": null,
          "screenId": null,
          "service": "Yes",
          "service_account_name": "",
          "use_digital_contracting_on_this_logon": "No",
          "vms": "Yes",
          "vms_account_name": "",
          "we_owe_activation": "Yes"
        }
       ],
      screen:{
        "bpPropagationCompleted": false,
        "bpScreenId": "c1504596-80fa-40bc-ab02-27b04cc40c29",
        "copyRowData": false,
        "deleted": false,
        "description": "CSR Setup",
        "gridOptionsModel": {
              "animatedRows": false, 
              "rowSelection": "multiple",
              "columnDefs":[
                {
                  "cellEditor": "agSelectCellEditor",
                  "cellEditorParams": {"values": Array(3)},
                  "dataLength": 0,
                  "dataType": "DROPDOWN",
                  "defaultValue": "Yes",
                  "editable": true,
                  "editableByCDKOnly": "true",
                  "field": "forms_builder",
                  "headerTooltip": "Forms Builder",
                  "required": "true",
                  "rowDrag": true,
                  "validationRule": "Yes,No"
                },
                {
                  "cellEditor": "agLargeTextCellEditor",
                  "clientScreen": "",
                  "dataLength": 24,
                  "dataType": "CHAR",
                  "defaultValue": "",
                  "editable": true,
                  "editableByCDKOnly": "true",
                  "field": "service_account_name",
                  "headerName": "Service Account Name",
                  "headerTooltip": "Service Account Name",
                  "required": "true",
                  "validationRule": "",
                }
              
              ],
              "rowData": Array(1)
        },
        "id": "dee8ab06-be22-4df8-8c78-ca1c60c9f81b",
        "index": 0,
        "masterScreenId": null,
        "productCode": "SLS",
        "recordType": "413b4ec1-392e-4428-8c88-c63ed141c5a9",
        "rowDataEmpty": false,
        "screenName": "CSR Setup",
        "updated": true,
        "version": 0
      }
    }

    component.currentScreenContext = currentScreenContext;
    component.requiredFieldsNotFilled(currentScreenContext);
  });


  
  it('test requiredFieldsNotFilled row has error',()=>{

    let currentScreenContext:any={
      rowData:[
        {
          "accounting_posting": "Yes",
          "car-inv": "Yes",
          "cash_conversion_(canada_only)": "No",
          "dms_external_ip_address_for_dc": "",
          "f&i_leasing": "Yes",
          "forms_builder": "Yes",
          "name-file": "Yes",
          "recordType": 1000,
          "rowDataId": null,
          "screenId": null,
          "service": "Yes",
          "service_account_name": "",
          "use_digital_contracting_on_this_logon": "No",
          "vms": "Yes",
          "vms_account_name": "",
          "we_owe_activation": "Yes",
          "error":[
            {
                "rowIndex": 0,
                "timeStamp": "",
                "errors": [
                  {
                    "errorDescription": "Mandatory field cannot be empty",
                    "errorField": "Service Account Name",
                    "errorLevel": "",
                    "isUpdated": false
                  }
                ]
            }
            ]
        }
       ],
      screen:{
        "bpPropagationCompleted": false,
        "bpScreenId": "c1504596-80fa-40bc-ab02-27b04cc40c29",
        "copyRowData": false,
        "deleted": false,
        "description": "CSR Setup",
        "gridOptionsModel": {
              "animatedRows": false, 
              "rowSelection": "multiple",
              "columnDefs":[
                {
                  "dataLength": 0,
                  "dataType": "DROPDOWN",
                  "defaultValue": "Yes",
                  "editable": true,
                  "headerTooltip": "Forms Builder",
                  "required": "true",
                },
                {
                  "dataLength": 24,
                  "dataType": "CHAR",
                  "defaultValue": "",
                  "editable": true,
                  "editableByCDKOnly": "true",
                  "field": "service_account_name",
                  "headerName": "Service Account Name",
                  "required": "true",
                }
              
              ],
              "rowData": Array(1)
        },
        "id": "dee8ab06-be22-4df8-8c78-ca1c60c9f81b",
        "index": 0,
        "masterScreenId": null,
        "productCode": "SLS",
        "recordType": "413b4ec1-392e-4428-8c88-c63ed141c5a9",
        "rowDataEmpty": false,
        "screenName": "CSR Setup",
        "updated": true,
        "version": 0
      }
    }
    component.currentScreenContext = currentScreenContext;
    component.requiredFieldsNotFilled(currentScreenContext);
  });

  it('test getBooleanValue true case',()=>{
    let result = component.getBooleanValue("TRUE")
    expect(result).toBeTruthy();
  });

  it('test getBooleanValue false case',()=>{
    let result = component.getBooleanValue("test")
    expect(result).toBeFalsy();
  });

  it('test submitTemplate',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    let templateContext:any={
      screenContextList:[
        {
          screen:{
            "bpPropagationCompleted": false,
            "bpScreenId": "c1504596-80fa-40bc-ab02-27b04cc40c29",
            "copyRowData": false,
            "deleted": false,
            "description": "CSR Setup",
            "gridOptionsModel": {"animatedRows": false, "rowSelection": "multiple", "columnDefs": Array(13), "rowData": Array(1)},
            "id": "dee8ab06-be22-4df8-8c78-ca1c60c9f81b",
            "index": 0,
            "masterScreenId": null,
            "productCode": "SLS",
            "recordType": "413b4ec1-392e-4428-8c88-c63ed141c5a9",
            "rowDataEmpty": false,
            "screenName": "CSR Setup",
            "updated": true,
            "version": 0,
          },
          rowData:[{
            "accounting_posting": "Yes",
            "car-inv": "Yes",
            "cash_conversion_(canada_only)": "No",
            "dms_external_ip_address_for_dc": "",
            "error": {"rowIndex": 0, "timeStamp": "", "errors": Array(1)},
            "f&i_leasing": "Yes",
            "forms_builder": "Yes",
            "isUpdated": true,
            "name-file": "Yes",
            "recordType": 1000,
            "rowDataId": null,
            "screenId": null,
            "service": "Yes",
            "service_account_name": "Durable"
          }]
        }
      ]
    }
    let functionalArea:any={
      functionalAreaName:"Service"
    }
   
    spyOn(component,'requiredFieldsNotFilled');
    spyOn(component,'newEmptyRowAlreadyExists').and.returnValue(false);
    component.templateContext = templateContext;

    component.emptyRequiredFieldCount  = 1;
    component.unsavedDataPresent = true;
    spyOn(excelService,'isUnsavedDataPresent').and.returnValue(true);
    const myPrivateSpy1 = spyOn<any>(component, 'createRequestsForBatchSaveAndDelete');
    const myPrivateSpy2 = spyOn<any>(component, 'executeSaveAndDeleteRowDataRequestsOnFromServer');
    component.projectObject = currentProject;
    spyOn(functionalAreaService,'saveSingleFunctionalArea').and.returnValue(Observable.of(functionalArea));
    component.submitTemplate();
    expect(functionalAreaService.saveSingleFunctionalArea).toHaveBeenCalledTimes(1);
    expect(component['createRequestsForBatchSaveAndDelete']).toHaveBeenCalledTimes(1);
  });

  it('test submitTemplate save throws error from server',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    let templateContext:any={
      screenContextList:[
        {
          screen:{
            "bpPropagationCompleted": false,
            "bpScreenId": "c1504596-80fa-40bc-ab02-27b04cc40c29",
            "copyRowData": false,
            "deleted": false,
            "description": "CSR Setup",
            "gridOptionsModel": {"animatedRows": false, "rowSelection": "multiple", "columnDefs": Array(13), "rowData": Array(1)},
            "id": "dee8ab06-be22-4df8-8c78-ca1c60c9f81b",
            "index": 0,
            "masterScreenId": null,
            "productCode": "SLS",
            "recordType": "413b4ec1-392e-4428-8c88-c63ed141c5a9",
            "rowDataEmpty": false,
            "screenName": "CSR Setup",
            "updated": true,
            "version": 0,
          },
          rowData:[{
            "accounting_posting": "Yes",
            "car-inv": "Yes",
            "cash_conversion_(canada_only)": "No",
            "dms_external_ip_address_for_dc": "",
            "error": {"rowIndex": 0, "timeStamp": "", "errors": Array(1)},
            "f&i_leasing": "Yes",
            "forms_builder": "Yes",
            "isUpdated": true,
            "name-file": "Yes",
            "recordType": 1000,
            "rowDataId": null,
            "screenId": null,
            "service": "Yes",
            "service_account_name": "Durable"
          }]
        }
      ]
    }
    let functionalArea:any={
      functionalAreaName:"Service"
    }

    spyOn(component,'requiredFieldsNotFilled');
    spyOn(component,'newEmptyRowAlreadyExists').and.returnValue(false);
    component.templateContext = templateContext;

    component.emptyRequiredFieldCount  = 1;
    component.unsavedDataPresent = true;
    spyOn(excelService,'isUnsavedDataPresent').and.returnValue(true);
    const myPrivateSpy1 = spyOn<any>(component, 'createRequestsForBatchSaveAndDelete');
    const myPrivateSpy2 = spyOn<any>(component, 'executeSaveAndDeleteRowDataRequestsOnFromServer');
    component.projectObject = currentProject;
    spyOn(functionalAreaService,'saveSingleFunctionalArea').and.returnValue(Observable.throwError('error'));
    component.submitTemplate();
    expect(functionalAreaService.saveSingleFunctionalArea).toHaveBeenCalledTimes(1);
    expect(component['createRequestsForBatchSaveAndDelete']).toHaveBeenCalledTimes(1);
  });
  
  it('test submitTemplate if no data there to save',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    let templateContext:any={
      screenContextList:[
        {
          screen:{
            "bpPropagationCompleted": false,
            "bpScreenId": "c1504596-80fa-40bc-ab02-27b04cc40c29",
            "copyRowData": false,
            "deleted": false,
            "description": "CSR Setup",
            "gridOptionsModel": {"animatedRows": false, "rowSelection": "multiple", "columnDefs": Array(13), "rowData": Array(1)},
            "id": "dee8ab06-be22-4df8-8c78-ca1c60c9f81b",
            "index": 0,
            "masterScreenId": null,
            "productCode": "SLS",
            "recordType": "413b4ec1-392e-4428-8c88-c63ed141c5a9",
            "rowDataEmpty": false,
            "screenName": "CSR Setup",
            "updated": true,
            "version": 0,
          },
          rowData:[{
            "accounting_posting": "Yes",
            "car-inv": "Yes",
            "cash_conversion_(canada_only)": "No",
            "dms_external_ip_address_for_dc": "",
            "error": {"rowIndex": 0, "timeStamp": "", "errors": Array(1)},
            "f&i_leasing": "Yes",
            "forms_builder": "Yes",
            "isUpdated": true,
            "name-file": "Yes",
            "recordType": 1000,
            "rowDataId": null,
            "screenId": null,
            "service": "Yes",
            "service_account_name": "Durable"
          }]
        }
      ]
    }
    let functionalArea:any={
      functionalAreaName:"Service"
    }
  
    spyOn(component,'requiredFieldsNotFilled');
    spyOn(component,'newEmptyRowAlreadyExists').and.returnValue(false);
    component.templateContext = templateContext;

    component.emptyRequiredFieldCount  = 1;
    component.unsavedDataPresent = false;
    spyOn(excelService,'isUnsavedDataPresent').and.returnValue(false);
    const myPrivateSpy1 = spyOn<any>(component, 'createRequestsForBatchSaveAndDelete');
    const myPrivateSpy2 = spyOn<any>(component, 'executeSaveAndDeleteRowDataRequestsOnFromServer');
    component.projectObject = currentProject;
    spyOn(functionalAreaService,'saveSingleFunctionalArea').and.returnValue(Observable.throwError('error'));
    component.submitTemplate();
    expect(functionalAreaService.saveSingleFunctionalArea).toHaveBeenCalledTimes(0);
    expect(component['createRequestsForBatchSaveAndDelete']).toHaveBeenCalledTimes(0);
  });

    
  it('test submitTemplate if row data is not filled  before saving',()=>{

   
    let templateContext:any={
      screenContextList:[
        {
          screen:{
            "bpPropagationCompleted": false,
            "bpScreenId": "c1504596-80fa-40bc-ab02-27b04cc40c29",
            "copyRowData": false,
            "deleted": false,
            "description": "CSR Setup",
            "gridOptionsModel": {"animatedRows": false, "rowSelection": "multiple", "columnDefs": Array(13), "rowData": Array(1)},
            "id": "dee8ab06-be22-4df8-8c78-ca1c60c9f81b",
            "index": 0,
            "masterScreenId": null,
            "productCode": "SLS",
            "recordType": "413b4ec1-392e-4428-8c88-c63ed141c5a9",
            "rowDataEmpty": false,
            "screenName": "CSR Setup",
            "updated": true,
            "version": 0,
          },
          rowData:[{
            "accounting_posting": "Yes",
            "car-inv": "Yes",
            "cash_conversion_(canada_only)": "No",
            "dms_external_ip_address_for_dc": "",
            "error": {"rowIndex": 0, "timeStamp": "", "errors": Array(1)},
            "f&i_leasing": "Yes",
            "forms_builder": "Yes",
            "isUpdated": true,
            "name-file": "Yes",
            "recordType": 1000,
            "rowDataId": null,
            "screenId": null,
            "service": "Yes",
            "service_account_name": "Durable"
          }]
        }
      ]
    }
    spyOn(component,'requiredFieldsNotFilled');
    spyOn(component,'newEmptyRowAlreadyExists').and.returnValue(true);
    component.templateContext = templateContext;
    component.submitTemplate();
    expect(component['toastrService'].previousToastMessage).toBe('Please fill the row (that contains either all blank or default values) in functional unit - CSR Setup , before saving !"');
  });

  it('test populateManagerHierarchy',()=>{

    let templates:any=[
      {
        functionalAreaName:'EMPLOYEE'
      },
      {
        functionalAreaName:'Service'
      }
    ]
    let templateContext:any={
      screenContextList:[
        {
          screen:{
            "bpPropagationCompleted": false,
            "bpScreenId": "c1504596-80fa-40bc-ab02-27b04cc40c29",
            "copyRowData": false,
            "deleted": false,
            "description": "CSR Setup",
            "gridOptionsModel": {"animatedRows": false, "rowSelection": "multiple", "columnDefs": Array(13), "rowData": Array(1)},
            "id": "dee8ab06-be22-4df8-8c78-ca1c60c9f81b",
            "index": 0,
            "masterScreenId": null,
            "productCode": "SLS",
            "recordType": "413b4ec1-392e-4428-8c88-c63ed141c5a9",
            "rowDataEmpty": false,
            "screenName": "EMPLOYEE",
            "updated": true,
            "version": 0,
          },
          rowData:[{
            "management":"Y",
            "accounting_posting": "Yes",
            "car-inv": "Yes",
            "cash_conversion_(canada_only)": "No",
            "dms_external_ip_address_for_dc": "",
            "error": {"rowIndex": 0, "timeStamp": "", "errors": Array(1)},
            "f&i_leasing": "Yes",
            "forms_builder": "Yes",
            "isUpdated": true,
            "name-file": "Yes",
            "recordType": 1000,
            "rowDataId": null,
            "screenId": null,
            "service": "Yes",
            "service_account_name": "Durable"
          }]
        }
      ]
    }
    spyOn(functionalAreaService,'getFunctionalAreasByStoreId').and.returnValue(Observable.of(templates));
    spyOn(functionalAreaService,'getFullFunctionalAreaByStoreIdAndFunctionalAreaId').and.returnValue(Observable.of(templateContext));
    component.populateManagerHierarchy(storeObject);
    expect(component.enterpriseManagerHierachy.length).toBe(1);
  });
  
  it('test getTemplateInfo if SSS Navigation false ',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    let screens:any[]=[
      {
        "screenName": "Account Definition",
        "gridOptionsModel": {
          "animatedRows": false,
          "rowSelection": "multiple",
          "columnDefs": [
            {
              "headerName": "Starting RO Number",
              "field": "starting_ro_number",
              "dataType": "INT",
              "required": "false",
              "editable": "false",
              "editableByCDKOnly": "false",
              "rowDrag":true,
              "cellEditorParams": {
                "maxLength": 9
              }
            }
          ],
          "rowData":null
        },
        "description": "Account Definition",
        "id": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
        "recordType": "ff991af6-3c55-4642-a500-bed944b7f574" 
      }
    ]

    component.isSSSNavigatedFromProject = false;
    spyOn(functionalAreaService,'getFunctionalAreaById').and.returnValue(Observable.of(functionalArea));
    component.isEnterpriseStore = 'false';
    component.isBestPractice = false;
    component.isStateStandard = false;
    component.isSSSNavigatedFromProject = false;
    spyOn(functionalUnitService,'getFunctionalUnitsOfFunctionalArea').and.returnValue(Observable.of(screens));
    const myPrivateSpy1 = spyOn<any>(component, 'fetchDataForCurrentScreen');
    component.getTemplateInfo();
    expect(component['showProcessValidationResultButton']).toBeFalsy();
    expect(component['processValidationCompleteOrOverridden']).toBeTruthy();
    expect(component['currentScreen'].screenName).toBe('Account Definition');
  });

  it('test getTemplateInfo if SSS Navigation true ',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    let screens:any[]=[
      {
        "screenName": "Account Definition",
        "gridOptionsModel": {
          "animatedRows": false,
          "rowSelection": "multiple",
          "columnDefs": [
            {
              "headerName": "Starting RO Number",
              "field": "starting_ro_number",
              "dataType": "INT",
              "required": "false",
              "editable": "false",
              "editableByCDKOnly": "false",
              "rowDrag":true,
              "cellEditorParams": {
                "maxLength": 9
              }
            }
          ],
          "rowData":null
        },
        "description": "Account Definition",
        "id": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
        "recordType": "ff991af6-3c55-4642-a500-bed944b7f574" 
      }
    ]

    component.isSSSNavigatedFromProject = true;
    
    let sssObject1:any={
      sssVersion:'2019',
      sssName:'test-sss',
      sssStore:'test-sss-store',
      sssFaName:'test-sss-fa-name',
      projectNumber:'test-sss-projectNumber',
      stateStandardVersionRecordType:'test-sss-recordtype',
      sssFAId:'test-sssFAId'
    }
    spyOn(JSON,'parse').and.returnValue(sssObject1);
    spyOn(functionalAreaService,'getFunctionalAreaById').and.returnValue(Observable.of(functionalArea));
    component.isEnterpriseStore = 'false';
    component.isBestPractice = false;
    component.isStateStandard = false;
    spyOn(functionalUnitService,'getFunctionalUnitsOfFunctionalArea').and.returnValue(Observable.of(screens));
    const myPrivateSpy1 = spyOn<any>(component, 'fetchDataForCurrentScreen');
    component.getTemplateInfo();
    expect(component.sssName).toBe('test-sss');
    expect(component.sssStore).toBe('test-sss-store');
    expect(component.sssFaName).toBe('test-sss-fa-name');
  });


  it('test getTemplateInfo if SSS Navigation false and there are not screens ',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    let screens:any[]=[]

    component.isSSSNavigatedFromProject = false;
    spyOn(functionalAreaService,'getFunctionalAreaById').and.returnValue(Observable.of(functionalArea));
    component.isEnterpriseStore = 'false';
    component.isBestPractice = false;
    component.isStateStandard = false;
    component.isSSSNavigatedFromProject = false;
    const myPrivateSpy1 = spyOn<any>(component, 'fetchDataForCurrentScreen');
    spyOn(functionalUnitService,'getFunctionalUnitsOfFunctionalArea').and.returnValue(Observable.of(screens));
    component.getTemplateInfo();
    expect(component['toastrService'].previousToastMessage).toBe('No screens configured on the template');
  });

  it('test getTemplateInfo if SSS Navigation false and Functional unit service throws error',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    let screens:any[]=[]
    let error:any={
      error:{
          message:"Functional Unit error"
      }
  }
    component.isSSSNavigatedFromProject = false;
    spyOn(functionalAreaService,'getFunctionalAreaById').and.returnValue(Observable.of(functionalArea));
    component.isEnterpriseStore = 'false';
    component.isBestPractice = false;
    component.isStateStandard = false;
    component.isSSSNavigatedFromProject = false;
    const myPrivateSpy1 = spyOn<any>(component, 'fetchDataForCurrentScreen');
    spyOn(functionalUnitService,'getFunctionalUnitsOfFunctionalArea').and.returnValue(Observable.throwError(error));
    component.getTemplateInfo();
    expect(component['toastrService'].previousToastMessage).toBe('Error occurred while fetching screens Functional Unit error');
    expect(component['templateReceived']).toBeFalsy();
  });

  it('test getTemplateInfo if SSS Navigation false and Functional Area service throws error',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    let error:any={
      error:{
          message:"Functional Area error"
      }
  }
    component.isSSSNavigatedFromProject = false;
    spyOn(functionalAreaService,'getFunctionalAreaById').and.returnValue(Observable.throwError(error));
    component.getTemplateInfo();
    expect(component['toastrService'].previousToastMessage).toBe('Error occurred while fetching template Functional Area error');
    expect(component['templateReceived']).toBeFalsy();
  });


  it('test getBestPracticeVersionInfo',()=>{

    let bpVersion :any={
      bestPracticeVersion:{
        versionName:'Test'
      }
    }
    spyOn(component,'getBestPracticeDetailsByName').and.returnValue(Observable.of({}));
    spyOn(bestPracticeService,'getVersionOfBestPractice').and.returnValue(Observable.of(bpVersion));
    component.getBestPracticeVersionInfo();
  });


  it('test populateCurrentEmpNoListForCDKUJobTitlesOrRoles',()=>{

    let templateContext:any={
      screenContextList:[
        {
          screen:{
            "screenName": "EMPLOYEE",
          },
          rowData:[{
            "currentempno":"123"
          }]
        }
      ]
    }
    component.templateContext = templateContext;
    component.populateCurrentEmpNoListForCDKUJobTitlesOrRoles(functionalArea);
    
  })
  it('test tabToNextCell',()=>{

    let params:any={
      nextCellDef:{
        column:{
          colId: "ending_ro_number"
        },
        rowIndex: 68,
        floating: null
      }
    }
   let result = component.tabToNextCell(params);
   expect(result.rowIndex).toBe(68);
  });

  it('test tabToNextCell if nextCellDef is null',()=>{

    let params:any={
      nextCellDef:false
    }
   const privateSpy = spyOn<any>(component, 'addRow');
   let result = component.tabToNextCell(params);
   expect(component['addRow']).toHaveBeenCalledTimes(1);
   
  });
    

  it('test navigateToNextCell',()=>{
    let evt:any={
      event:{
        keyCode: 40,
        shiftKey: true
      }
    }
    const privateSpy = spyOn<any>(component, 'addRow');
    component.navigateToNextCell(evt);
    expect(component['addRow']).toHaveBeenCalledTimes(1);
  });

  it('test cellValueChanged',()=>{
    component.cellValueChanged({})
    expect(component.unsavedDataPresent).toBeTruthy();
  });

  it('test resetImportFileValue',()=>{

    var dummyElement = document.createElement('div');
    document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);   
    component.resetImportFileValue();
  });

  it('test rowDataChanged',()=>{
    const privateSpy = spyOn<any>(component, 'sizeColumnsToFit');
    component.rowDataChanged({});
  });

  it('test onRowClicked',()=>{
    let params:any={rowIndex:10 }
    component.onRowClicked(params);
    expect(component['currentIndex']).toBe(10);
  });

  it('test pickValuesFromStore',()=>{
    
    const screenObject : any = {
      "screenName": "Account Definition",
      "gridOptionsModel": {
        "columnDefs": [
          {
            "headerName": "Starting RO Number",
            "field": "starting_ro_number",
            "dataType": "PICK FROM STORE",
            "required": "false",
            "editable": "false",
            "editableByCDKOnly": "false",
            "defaultValue": "",
            "validationRule": ""
          }
        ],
        "rowData":null
      },
      "id": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
      "recordType": "ff991af6-3c55-4642-a500-bed944b7f574" 
    }
    component.pickValuesFromStore(screenObject);
  });

  it('test handleFileInputforBestPractice',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    
    const getFileList = () => {
      const blob = new Blob([""], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      blob["lastModifiedDate"] = "";
      blob["name"] = "jobstacksetup-job5-parts-5_14_2021-4_08_59 PM.xlsx";
      const file = <File>blob;
      const fileList: FileList = {
        0: file,
        length: 1,
        item: (index: number) => file
      };
      return fileList;
    };
    let myFileList = getFileList();

    const blob1 = new Blob([""], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    blob1["lastModifiedDate"] = "";
    blob1["name"] = "jobstacksetup-job5-parts-5_14_2021-4_08_59 PM.xlsx";
    const file1 = <File>blob1;
    component.recentFileToUpload = file1;
    spyOn(excelService,'importXLSXFile');
    spyOn(excelService,'isUnsavedDataPresent').and.returnValue(true);
    component.handleFileInputforBestPractice(myFileList);
    expect(excelService.importXLSXFile).toHaveBeenCalledTimes(1);
    expect(component['unsavedDataPresent']).toBeTruthy();
  });

  
  it('test handleFileInputforBestPractice imported files are different',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    
    const getFileList = () => {
      const blob = new Blob([""], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      blob["lastModifiedDate"] = "";
      blob["name"] = "jobstacksetup1-job5-parts-5_14_2021-4_08_59 PM.xlsx";
      const file = <File>blob;
      const fileList: FileList = {
        0: file,
        length: 1,
        item: (index: number) => file
      };
      return fileList;
    };
    let myFileList = getFileList();

    const blob1 = new Blob([""], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    blob1["lastModifiedDate"] = "";
    blob1["name"] = "jobstacksetup-job5-parts-5_14_2021-4_08_59 PM.xlsx";
    const file1 = <File>blob1;
    component.recentFileToUpload = null;
    spyOn(excelService,'importXLSXFile');
    spyOn(excelService,'isUnsavedDataPresent').and.returnValue(false);
    component.handleFileInputforBestPractice(myFileList);
    expect(excelService.importXLSXFile).toHaveBeenCalledTimes(1);
    expect(component['unsavedDataPresent']).toBeFalsy();
  });

  it('test handleFileInputforBestPractice imported files are different name',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    
    const getFileList = () => {
      const blob = new Blob([""], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      blob["lastModifiedDate"] = "";
      blob["name"] = "test.xlsx";
      const file = <File>blob;
      const fileList: FileList = {
        0: file,
        length: 1,
        item: (index: number) => file
      };
      return fileList;
    };
    let myFileList = getFileList();

    const blob1 = new Blob([""], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    blob1["lastModifiedDate"] = "";
    blob1["name"] = "jobstacksetup-job5-parts-5_14_2021-4_08_59 PM.xlsx";
    const file1 = <File>blob1;
    component.recentFileToUpload = file1;
    spyOn(excelService,'importXLSXFile');
    spyOn(excelService,'isUnsavedDataPresent').and.returnValue(false);
    component.handleFileInputforBestPractice(myFileList);
    expect(excelService.importXLSXFile).toHaveBeenCalledTimes(1);
    expect(component['unsavedDataPresent']).toBeFalsy();
  });

  it('test getBeginDateValue',()=>{
   component.getBeginDateValue(); 
  });

  it('test newOnboardingProject',()=>{
    spyOn(window, 'confirm').and.returnValue(true);
    const navigateSpy = spyOn(routerStub, 'navigateByUrl');
    component.unsavedDataPresent = true;
    component.newOnboardingProject();
    expect(navigateSpy).toHaveBeenCalledWith('projects/create');
  });

  it('test newOnboardingProject if unsavedDataPresent false',()=>{
    const navigateSpy = spyOn(routerStub, 'navigateByUrl');
    component.unsavedDataPresent = false;
    component.newOnboardingProject();
    expect(navigateSpy).toHaveBeenCalledWith('projects/create');

  });

  it('test gotoDashboard',()=>{
    component.unsavedDataPresent = true;
    spyOn(window, 'confirm').and.returnValue(true);
    const navigateSpy = spyOn(routerStub, 'navigateByUrl');
    component.gotoDashboard();
    expect(navigateSpy).toHaveBeenCalledWith('dashboard');
  });

  it('test gotoDashboard if unsavedDataPresent false',()=>{
    component.unsavedDataPresent = false;
    const navigateSpy = spyOn(routerStub, 'navigateByUrl');
    component.gotoDashboard();
    expect(navigateSpy).toHaveBeenCalledWith('dashboard');
  });

  it('test getProject',()=>{

    component.unsavedDataPresent = true;
    component.isStateStandard = true;
    const navigateSpy = spyOn(routerStub, 'navigate');
    spyOn(component,'removeSSSSessionObject');
    spyOn(window, 'confirm').and.returnValue(true);
    component.getProject("P1122");
    expect(navigateSpy).toHaveBeenCalledWith(['bestPractice/stateStandard/P1122/true']);
  });

  it('test getProject BP is not SSS',()=>{
    component.unsavedDataPresent = true;
    component.isStateStandard = false;
    const navigateSpy = spyOn(routerStub, 'navigate');
    spyOn(component,'removeSSSSessionObject');
    spyOn(window, 'confirm').and.returnValue(true);
    component.isBestPractice = true;
    component.bestPracticePlatformCode = 'FLEX';
    component.getProject("P1122");
    expect(navigateSpy).toHaveBeenCalledWith(['bestpractice/getOne/P1122/FLEX']);
  });

  it('test getProject if un saved data not present',()=>{
    component.unsavedDataPresent = false;
    const navigateSpy = spyOn(routerStub, 'navigate');
    spyOn(component,'removeSSSSessionObject');
    component.isBestPractice = true;
    component.bestPracticePlatformCode = 'DRIVE';
    component.getProject("P1122");
    expect(navigateSpy).toHaveBeenCalledWith(['bestpractice/getOne/P1122/DRIVE']);
  });

  it('test getProject if un saved data not present and BP is SSS',()=>{
    component.unsavedDataPresent = false;
    const navigateSpy = spyOn(routerStub, 'navigate');
    spyOn(component,'removeSSSSessionObject');
    component.isBestPractice = false;
    component.isStateStandard = true;
    component.getProject("P1122");
    expect(navigateSpy).toHaveBeenCalledWith(['bestPractice/stateStandard/P1122/true']);
  });

  it('test getProject if un saved data not present and not SSS and BP',()=>{
    component.unsavedDataPresent = false;
    const navigateSpy = spyOn(routerStub, 'navigate');
    spyOn(component,'removeSSSSessionObject');
    component.isBestPractice = false;
    component.isStateStandard = false;
    component.getProject("P1122");
    expect(navigateSpy).toHaveBeenCalledWith(['projects/P1122']);
  });

  it('test exporPDFtReport',()=>{
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    component.projectNumber = "P2233";
    component.storeObject = storeObject;
    component.templateObject = functionalArea;
    component.currentScreen = screenObject;

    let columnList :any[]=['COA','ACCOUNTING']
    component.importColumnList = columnList;
    spyOn(flexDashService,'generateFileNameForExportPDF').and.returnValue('TestPDF');
    spyOn(FileSaver, 'saveAs').and.stub();
    let testData:any={}
    spyOn(flexDashService,'exporPDFtReport').and.returnValue(Observable.of(testData));
    component.exporPDFtReport();
  });
 
  it('test exporPDFtReport throw error',()=>{
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    component.projectNumber = "P2233";
    component.storeObject = storeObject;
    component.templateObject = functionalArea;
    component.currentScreen = screenObject;

    let columnList :any[]=['COA','ACCOUNTING']
    component.importColumnList = columnList;
    spyOn(flexDashService,'generateFileNameForExportPDF').and.returnValue('TestPDF');
    spyOn(FileSaver, 'saveAs').and.stub();
    let testData:any={}
    spyOn(flexDashService,'exporPDFtReport').and.returnValue(Observable.throwError('error'));
    component.exporPDFtReport();
  });

  
  it('test exporPDFtReport if result of LoaderDialogue component is undefined',()=>{
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(undefined), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    component.projectNumber = "P2233";
    component.storeObject = storeObject;
    component.templateObject = functionalArea;
    component.currentScreen = screenObject;

    let columnList :any[]=['COA','ACCOUNTING']
    component.importColumnList = columnList;
    spyOn(FileSaver, 'saveAs').and.stub();
    let testData:any={}
    component.exporPDFtReport();
  });

  it('test exporttoXlsWithRowData',()=>{
    let fileName:string = "p05mar-store2-sales-5_4_2021-4_22_11 PM";
    let testData:any={}
    component.isBestPractice = true;
    component.isStateStandard = true;
    spyOn(excelService,'generateFileNameForExportXls').and.returnValue(fileName);
    spyOn(FileSaver, 'saveAs').and.stub();
    spyOn(excelService,'getTemplateXlsWithData').and.returnValue(Observable.of(testData));
    component.exporttoXlsWithRowData(true);
    expect(excelService.getTemplateXlsWithData).toHaveBeenCalledTimes(1);
  });

  it('test exporttoXlsWithRowData throws error',()=>{
    let fileName:string = "p05mar-store2-sales-5_4_2021-4_22_11 PM";
    let testData:any={}
    component.isBestPractice = true;
    component.isStateStandard = true;
    spyOn(excelService,'generateFileNameForExportXls').and.returnValue(fileName);
    spyOn(FileSaver, 'saveAs').and.stub();
    spyOn(excelService,'getTemplateXlsWithData').and.returnValue(Observable.throwError('error'));
    component.exporttoXlsWithRowData(true);
    expect(excelService.getTemplateXlsWithData).toHaveBeenCalledTimes(1);
  });

  it('test exporttoXlsWithRowData without includes row data',()=>{
    let fileName:string = "p05mar-store2-sales-5_4_2021-4_22_11 PM";
    let testData:any={}
    component.isBestPractice = true;
    component.isStateStandard = true;
    spyOn(excelService,'generateFileNameForExportXls').and.returnValue(fileName);
    spyOn(FileSaver, 'saveAs').and.stub();
    spyOn(excelService,'getTemplateXls').and.returnValue(Observable.of(testData));
    component.exporttoXlsWithRowData(false);
    expect(excelService.getTemplateXls).toHaveBeenCalledTimes(1);
  });

  
  it('test exporttoXlsWithRowData without includes row data and throw error',()=>{
    let fileName:string = "p05mar-store2-sales-5_4_2021-4_22_11 PM";
    component.isBestPractice = true;
    component.isStateStandard = true;
    spyOn(excelService,'generateFileNameForExportXls').and.returnValue(fileName);
    spyOn(FileSaver, 'saveAs').and.stub();
    spyOn(excelService,'getTemplateXls').and.returnValue(Observable.throwError('error'));
    component.exporttoXlsWithRowData(false);
    expect(excelService.getTemplateXls).toHaveBeenCalledTimes(1);
  });

  it('test exporttoXlsWithRowData if isBestPractice and SSS false',()=>{
    let fileName:string = "p05mar-store2-sales-5_4_2021-4_22_11 PM";
    let testData:any={}
    component.isBestPractice = false;
    component.isStateStandard = false;
    spyOn(excelService,'generateFileNameForExportXls').and.returnValue(fileName);
    spyOn(FileSaver, 'saveAs').and.stub();
    spyOn(excelService,'getTemplateXls').and.returnValue(Observable.of(testData));
    component.exporttoXlsWithRowData(false);
    expect(excelService.getTemplateXls).toHaveBeenCalledTimes(1);
  });

  it('test importCOARowData',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    let testData:any={}
    let fileName:string = "p05mar-store2-sales-5_4_2021-4_22_11 PM";
    spyOn(excelService,'generateFileNameForExportXls').and.returnValue(Observable.of(fileName))
    spyOn(flexDashService,'importCOAData').and.returnValue(Observable.of(testData));
    spyOn(FileSaver, 'saveAs').and.stub();
    component['importCOARowData']();
  });
 
  it('test importCOARowData throws error',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    let testData:any={}
    let fileName:string = "p05mar-store2-sales-5_4_2021-4_22_11 PM";
    spyOn(excelService,'generateFileNameForExportXls').and.returnValue(Observable.of(fileName))
    spyOn(flexDashService,'importCOAData').and.returnValue(Observable.throwError('error'));
    spyOn(FileSaver, 'saveAs').and.stub();
    component['importCOARowData']();
   expect(component['toastrService'].previousToastMessage).toBe('No COA raw data with given CMF and Vendor Store Number')
  });

  it('test importGLRowData',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    let testData:any={}
    let fileName:string = "p05mar-store2-sales-5_4_2021-4_22_11 PM";
    spyOn(excelService,'generateFileNameForExportXls').and.returnValue(Observable.of(fileName))
    spyOn(flexDashService,'importGLRawData').and.returnValue(Observable.of(testData));
    spyOn(FileSaver, 'saveAs').and.stub();
    component.importGLRowData();
    expect(excelService.generateFileNameForExportXls).toHaveBeenCalledTimes(1);
  });

  
  it('test importGLRowData throws error',()=>{

    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

    let fileName:string = "p05mar-store2-sales-5_4_2021-4_22_11 PM";
    spyOn(excelService,'generateFileNameForExportXls').and.returnValue(Observable.of(fileName))
    spyOn(flexDashService,'importGLRawData').and.returnValue(Observable.throwError('error'));
    spyOn(FileSaver, 'saveAs').and.stub();
    component.importGLRowData();
    expect(excelService.generateFileNameForExportXls).toHaveBeenCalledTimes(1);
  });


  it('test newEmptyRowAlreadyExists',()=>{

    let currentScreenContext :any={
      rowData:[
        {
          "apply_shop_charges": "Yes",
          "begin_date": "",
          "calculate_tax": "Yes",
          "cost_amount_percentage": "0.0000%",
          "cost_percentage_of": "",
          "cost_pricing_method": "Fixed",
          "description": "Parts Discount",
          "end_date": "4/19/2021",
          "exclude_from_discounts": "Yes",
          "fee_code": "PD",
          "fixed_cost_amount": "$0.00",
          "fixed_sale_amount": "$5.00",
          "gl_account": "54300",
          "gl_account_prompt_flag": "Yes",
          "gl_company": "#CO#",
          "id": "b5ac63c2-1854-497a-806f-62176029129b",
          "index": "1000",
          "labor_fee_type": "Miscellaneous",
          "maximum_amount_$": "",
          "minimum_amount_$": "",
          "recordType": "1000",
          "rowDataId": "ab70f432-26bd-4d92-af13-945701cc0660",
          "sale_amount_percentage": "0.0000%",
          "sale_percentage_of": "",
          "sale_pricing_method": "Fixed"
        },
        {
          "apply_shop_charges": "Yes",
          "begin_date": "",
          "calculate_tax": "No",
          "cost_amount_percentage": "0.0000%",
          "cost_percentage_of": "",
          "cost_pricing_method": "Fixed",
          "description": "Service Discount",
          "end_date": "4/19/2021",
          "exclude_from_discounts": "Yes",
          "fee_code": "SD",
          "fixed_cost_amount": "$0.00",
          "fixed_sale_amount": "$0.00",
          "gl_account": "57000",
          "gl_account_prompt_flag": "Yes",
          "gl_company": "#CO#",
          "id": "b5ac63c2-1854-497a-806f-62176029129b",
          "index": "2000",
          "labor_fee_type": "Miscellaneous",
          "maximum_amount_$": "",
          "minimum_amount_$": "",
          "recordType": "2000",
          "rowDataId": "b0c2306f-def3-469e-8987-c75d71e741b8",
          "sale_amount_percentage": "0.0000%",
          "sale_percentage_of": "",
          "sale_pricing_method": "Fixed"
        }
       ],
      screen:{
        "bpPropagationCompleted": false,
        "bpScreenId": "3f9a8551-80a4-42d9-a0bb-a0ff3df980f8",
        "copyRowData": true,
        "deleted": false,
        "description": "Fee Codes",
        "gridOptionsModel": {
         "animatedRows":false, 
          "rowSelection":"multiple",
           "columnDefs":[
             {
              "dataType": "CHAR",
              "defaultValue": "",
              "editable": true,
              "editableByCDKOnly": false,
              "field": "fee_code",
              "headerName": "Fee Code",
               "required": true
             },
             {
              "dataType": "CHAR",
              "defaultValue": "",
              "editable": true,
              "editableByCDKOnly": false,
              "field": "description",
              "headerName": "Description",
               "required": true
             }
           ], 
           "rowData": Array(2)
          },
        "id": "3f2df3b6-3330-4825-82e0-0052d331c128",
        "index": 0,
        "masterScreenId": null,
        "productCode": "SVC",
        "recordType": "b5ac63c2-1854-497a-806f-62176029129b",
        "rowDataEmpty": false,
        "screenName": "Fee Codes",
        "updated": false,
        "version": 0
      }
    }
    component.newEmptyRowAlreadyExists(currentScreenContext);
  });

    it('test createRequestsForBatchSaveAndDelete',()=>{


      let deleteRowIds:any=    {
        "413b4ec1-392e-4428-8c88-c63ed141c5a9":[
          {
            "id": "413b4ec1-392e-4428-8c88-c63ed141c5a9",
            "index": "10000",
            "labor_fee_type": "Miscellaneous",
            "maximum_amount_$": "",
            "minimum_amount_$": "",
            "recordType": "413b4ec1-392e-4428-8c88-c63ed141c5a9"
          }
        ],
      }

      component.currentScreen = screenObject;
      spyOn(rowDataService,'batchSaveAndDeleteRowData').and.returnValue(Observable.of({}));
      let templateContext:any={
        screenContextList:[
          {
            screen:{
              "bpPropagationCompleted": false,
              "bpScreenId": "c1504596-80fa-40bc-ab02-27b04cc40c29",
              "copyRowData": false,
              "deleted": false,
              "description": "CSR Setup",
              "gridOptionsModel": {"animatedRows": false, "rowSelection": "multiple", "columnDefs": Array(13), "rowData": Array(1)},
              "id": "dee8ab06-be22-4df8-8c78-ca1c60c9f81b",
              "index": 0,
              "masterScreenId": null,
              "productCode": "SLS",
              "recordType": "413b4ec1-392e-4428-8c88-c63ed141c5a9",
              "rowDataEmpty": false,
              "screenName": "CSR Setup",
              "updated": true,
              "version": 0,
            },
            rowData:[{
              "accounting_posting": "Yes",
              "car-inv": "Yes",
              "cash_conversion_(canada_only)": "No",
              "dms_external_ip_address_for_dc": "",
              "error": {"rowIndex": 0, "timeStamp": "", "errors": Array(1)},
              "f&i_leasing": "Yes",
              "forms_builder": "Yes",
              "isUpdated": true,
              "name-file": "Yes",
              "recordType": 1000,
              "rowDataId": null,
              "screenId": null,
              "service": "Yes",
              "service_account_name": "Durable"
            }]
          }
        ]
      }
      component.deletedRowIds = deleteRowIds;
      component.templateContext = templateContext;
      component['tableDataListToDelete '] =[];
      component['createRequestsForBatchSaveAndDelete'](true);
      expect(rowDataService.batchSaveAndDeleteRowData).toHaveBeenCalledTimes(1);

    });


    it('test Delete All Rows',()=>{
      let gridOptions:{};
      let screen = screenObject;
      let currentScreenContext:any={
        rowData:[
          {
            "accounting_posting": "Yes",
            "car-inv": "Yes",
            "cash_conversion_(canada_only)": "No",
            "dms_external_ip_address_for_dc": "",
            "error": {
               "rowIndex": 0, 
              "timeStamp": "",
               "errors": Array(2)
              },
            "f&i_leasing": "Yes",
            "forms_builder": "Yes",
            "id": "31361346-e7dd-49ac-b605-bd432ef6dd18",
            "index": "1000",
            "name-file": "No",
            "recordType": 1000,
            "rowDataId": "8250ba32-4419-4bf3-8ac4-5cccb74a8e23",
            "screenId": null,
            "service": "Yes",
            "service_account_name": "",
            "use_digital_contracting_on_this_logon": "No",
            "vms": "Yes",
            "vms_account_name": "",
            "we_owe_activation": "Yes"
          },
          {
          "f&i_leasing": "Yes",
          "forms_builder": "No",
          "id": "31361346-e7dd-49ac-b605-bd432ef6dd18",
          "index": "2000",
          "isUpdated": true,
          "name-file": "Yes",
          "recordType": 500,
          "rowDataId": "a4116205-b5f2-4b37-8636-0934e5fe6010",
          "screenId": null,
          "service": "Yes",
          "service_account_name": "",
          "use_digital_contracting_on_this_logon": "No",
          "vms": "Yes",
          "vms_account_name": "",
          "we_owe_activation": "Yes"
          }
         ],
        screen:{
          recordType: "413b4ec1-392e-4428-8c88-c63ed141c5a9"
        }
      }
      let selectedRows:any= [
        {
          "error": {
              "rowIndex": 0,
              "timeStamp": "",
              "errors": [
                  {
                      "errorDescription": "Dropdown value is Invalid. Please check the value",
                      "errorField": "number_months_of_history",
                      "errorLevel": "invalid",
                      "isUpdated": false
                  }
              ]
          },
          "starting_invoice_number": "15000",
          "ending_invoice_number": "999999999",
          "dealer_code": "",
          "use_negative_o_h__s": "YES",
          "turn_parts_cashiering_on": "YES",
          "force_print_of_final_invoice": "",
          "allow_overrides_to_account_and_control_numbers": "YES",
          "days_to_display_orders_on_arrived_status": "",
          "days_to_keep_customer_orders_and_backorders_after_receipted": "",
          "delete_pnc_references_to_parts_not_on_file": "",
          "order_seasonal_part_numbers_up_to_per_job_only_in_season": "",
          "use_lifo_accounting": "",
          "lifo_method": "",
          "lifo_calendar_(indicate_the_month)": "",
          "number_months_of_history": "1",
          "permit_orders_outside_of_pac_multiple_quantity": "NO",
          "default_price_code_for_parts_customers": "100",
          "default_sale_type_for_parts_customers": "CASH",
          "prompt_for_lost_sale": "YES",
          "enable_real-time_posting_for_parts_invoices": "NO",
          "enable_real-time_posting_for_service_ro_invoices": "NO",
          "id": "1df74487-2095-4b8c-9f7c-d442d1d586c0",
          "recordType": "1000",
          "index": "1000",
          "rowDataId": "f3ed49be-cc26-466a-8151-2e2421b0a2be"
      }
      ]
      
       let gridApi1:any={
         updateRowData
      } 
      let val:any={
        'test':'1'
      }

      function updateRowData(){
        return "test";
      }
      component.currentScreenContext = currentScreenContext;
      component.gridApi = gridApi1;
      spyOn(component,'getAllRows').and.returnValue(selectedRows);
      component.deleteAllRows(gridOptions,screen);
      expect(component.unsavedDataPresent).toBeTruthy();
      

    });

    it('test Delete All Rows if row data length is 0',()=>{
      let gridOptions:{};
      let screen = screenObject;
      let currentScreenContext:any={
        rowData:[
         ],
        screen:{
          recordType: "413b4ec1-392e-4428-8c88-c63ed141c5a9"
        }
      }
      let selectedRows:any= [
      ]

      let gridApi:any={
         updateRowData
      } 
      function updateRowData(){
        return selectedRows;
      }
      component.currentScreenContext = currentScreenContext;
      component.gridApi = gridApi;
      spyOn(component,'getAllRows').and.returnValue(selectedRows);
      component.deleteAllRows(gridOptions,screen);
      expect(component.unsavedDataPresent).toBeFalsy();
      expect(screen.rowDataEmpty).toBeTruthy();
      

    });

    it('test getAllRows ',()=>{

      let rowDatas:any[]=[
      ]
      let nodes:any[]=[
        {
          "fee_code": "PD",
          "description": "Parts Discount",
          "index": "1000",
          "rowDataId": "ab70f432-26bd-4d92-af13-945701cc0660"
        },
        {
          "fee_code": "SD",
          "description": "Service Discount",
          "index": "2000",
          "rowDataId": "b0c2306f-def3-469e-8987-c75d71e741b8"
        }
      ]
      let gridApi:any={
        forEachNode
     } 
     function forEachNode(){

     return  nodes.forEach(node=>{
        rowDatas.push(node)
      })
     }
     component.gridApi = gridApi;
     let result = component.getAllRows();
    });

     it('test handleSettingRowData',()=>{

      let currentScreen = screenObject;
      currentScreen.screenName = 'CDKU Job Titles';
      component.currentScreen = currentScreen;

      spyOn(component,'pickValuesFromStore');
      spyOn(component,'populateCurrentEmpNoListForCDKUJobTitlesOrRoles');
      component['handleSettingRowData'](screenObject);
      expect(component.pickValuesFromStore).toHaveBeenCalledTimes(1);
    });


    it('test handleSettingRowData gridApi is defined',()=>{

      
      let currentScreenContext:any={
        rowData:[
          {
          "f&i_leasing": "Yes",
          "forms_builder": "No",
          "id": "31361346-e7dd-49ac-b605-bd432ef6dd18",
          "index": "2000",
          "isUpdated": true,
          "name-file": "Yes",
          "recordType": 500,
          "rowDataId": "a4116205-b5f2-4b37-8636-0934e5fe6010",
          "screenId": null,
          "service": "Yes",
          "service_account_name": "",
          "use_digital_contracting_on_this_logon": "No",
          "vms": "Yes",
          "vms_account_name": "",
          "we_owe_activation": "Yes"
          }
         ],
        screen:{
          recordType: "413b4ec1-392e-4428-8c88-c63ed141c5a9"
        }
      }
      component.currentScreen = screenObject;
      component.currentScreen.screenName = "test";

      spyOn(component,'pickValuesFromStore');
      spyOn(component,'populateCurrentEmpNoListForCDKUJobTitlesOrRoles');

      let gridApi:any={
        setColumnDefs(){},
        setRowData(){}
      } 
      component.currentScreenContext = currentScreenContext;
      component.gridApi = gridApi;
      component['handleSettingRowData'](screenObject);
      expect(component.pickValuesFromStore).toHaveBeenCalledTimes(1);
      expect(component.populateCurrentEmpNoListForCDKUJobTitlesOrRoles).toHaveBeenCalledTimes(0);
    });


    it('test showDealerApproveButton',()=>{
 
      component.isProjectSourceEnvDash = true;
      component.dealerApprovePermission = true;
      component.templateObject = functionalArea;
      component.templateObject.status = 'Request Dealer for Approval';
      expect(component.showDealerApproveButton()).toBeTruthy();
    });

    it('test createNewRowData',()=>{

      const gridOptions :any = {
        columnDefs:[
            {
                dataType: "BOOLEAN",
                headerName: "Auto order",
                required: "true",
                field:'Auto order'            }
        ]
      }
      let newRow = component.createNewRowData(gridOptions);
      expect(newRow.rowDataId).toBeNull();
      expect(newRow.screenId).toBeNull();
    });

    it('test deleteSelectedRows',()=>{
      
      let gridOptions:{};
      let screen = screenObject;
      let currentScreenContext:any={
        rowData:[
          {
            "accounting_posting": "Yes",
            "car-inv": "Yes",
            "cash_conversion_(canada_only)": "No",
            "dms_external_ip_address_for_dc": "",
            "error": {
               "rowIndex": 0, 
              "timeStamp": "",
               "errors": Array(2)
              },
            "f&i_leasing": "Yes",
            "forms_builder": "Yes",
            "id": "31361346-e7dd-49ac-b605-bd432ef6dd18",
            "index": "1000",
            "name-file": "No",
            "recordType": 1000,
            "rowDataId": "8250ba32-4419-4bf3-8ac4-5cccb74a8e23",
            "screenId": null,
            "service": "Yes",
            "service_account_name": "",
            "use_digital_contracting_on_this_logon": "No",
            "vms": "Yes",
            "vms_account_name": "",
            "we_owe_activation": "Yes"
          },
          {
          "f&i_leasing": "Yes",
          "forms_builder": "No",
          "id": "31361346-e7dd-49ac-b605-bd432ef6dd18",
          "index": "2000",
          "isUpdated": true,
          "name-file": "Yes",
          "recordType": 500,
          "rowDataId": "a4116205-b5f2-4b37-8636-0934e5fe6010",
          "screenId": null,
          "service": "Yes",
          "service_account_name": "",
          "use_digital_contracting_on_this_logon": "No",
          "vms": "Yes",
          "vms_account_name": "",
          "we_owe_activation": "Yes"
          }
         ],
        screen:{
          recordType: "413b4ec1-392e-4428-8c88-c63ed141c5a9"
        }
      }
      let selectedRows:any= [
        {
          "error": {
              "rowIndex": 0,
              "timeStamp": "",
              "errors": [
                  {
                      "errorDescription": "Dropdown value is Invalid. Please check the value",
                      "errorField": "number_months_of_history",
                      "errorLevel": "invalid",
                      "isUpdated": false
                  }
              ]
          },
          "starting_invoice_number": "15000",
          "ending_invoice_number": "999999999",
          "dealer_code": "",
          "use_negative_o_h__s": "YES",
          "turn_parts_cashiering_on": "YES",
          "force_print_of_final_invoice": "",
          "allow_overrides_to_account_and_control_numbers": "YES",
          "days_to_display_orders_on_arrived_status": "",
          "days_to_keep_customer_orders_and_backorders_after_receipted": "",
          "delete_pnc_references_to_parts_not_on_file": "",
          "order_seasonal_part_numbers_up_to_per_job_only_in_season": "",
          "use_lifo_accounting": "",
          "lifo_method": "",
          "lifo_calendar_(indicate_the_month)": "",
          "number_months_of_history": "1",
          "permit_orders_outside_of_pac_multiple_quantity": "NO",
          "default_price_code_for_parts_customers": "100",
          "default_sale_type_for_parts_customers": "CASH",
          "prompt_for_lost_sale": "YES",
          "enable_real-time_posting_for_parts_invoices": "NO",
          "enable_real-time_posting_for_service_ro_invoices": "NO",
          "id": "1df74487-2095-4b8c-9f7c-d442d1d586c0",
          "recordType": "1000",
          "index": "1000",
          "rowDataId": "f3ed49be-cc26-466a-8151-2e2421b0a2be"
      }
      ]
      
       let gridApi1:any={
         updateRowData,
         getSelectedRows
      } 
    
      function updateRowData(){
        return "test";
      }
      function getSelectedRows(){
        return selectedRows
      }
      component.currentScreenContext = currentScreenContext;
       component.gridApi = gridApi1;
      component.deleteSelectedRows(gridOptions,screen);
      expect(component.unsavedDataPresent).toBeTruthy();
      expect(screenObject.updated).toBeTruthy();
    });

    it('test deleteSelectedRows if RowData length is 0',()=>{
      
      let gridOptions:{};
      let screen = screenObject;
      let currentScreenContext:any={
        rowData:[],
        screen:{
          recordType: "413b4ec1-392e-4428-8c88-c63ed141c5a9"
        }
      }
      let selectedRows:any= []
      
       let gridApi:any={
         updateRowData,
         getSelectedRows
      } 
    
      function updateRowData(){
        return "test";
      }
      function getSelectedRows(){
        return selectedRows
      } 
      component.currentScreenContext = currentScreenContext;
      component.gridApi = gridApi;
      component.deleteSelectedRows(gridOptions,screen);
      expect(component.unsavedDataPresent).toBeFalsy();
      expect(screen.rowDataEmpty).toBeTruthy();
    });

    it('test removeSSSSessionObject',()=>{
      component.removeSSSSessionObject();
    });

    it('test Add Row new Row Already Exists',()=>{
      let addRowButtonClick:boolean = true;
      let currentScreenContext:any={
        screen:{
          gridOptionsModel: {
            "animatedRows": false,
            "rowSelection": "multiple",
            "columnDefs": [
              {
                "headerName": "Starting RO Number",
                "field": "starting_ro_number",
                "dataType": "INT",
                "required": "false",
                "editable": "false",
                "editableByCDKOnly": "false",
                "defaultValue": "",
                "validationRule": "",
                "dataLength": 9,
                "cellEditor": "agLargeTextCellEditor",
                "cellEditorParams": {
                  "maxLength": 9
                }
              }
            ],
            "rowData":null
          },
          rowDataEmpty:false,
          recordType: "413b4ec1-392e-4428-8c88-c63ed141c5a9"
        }
      }
      spyOn(component,'newEmptyRowAlreadyExists').and.returnValue(true);
      component.addRow(currentScreenContext,addRowButtonClick);
      expect(component['toastrService'].previousToastMessage).toBe("Please fill the existing row (that contains either all blank or default values) before adding a new one !")
    });

    it('test Add Row new Row Already did not Exist',()=>{

      let currentIndex : number = 0;
      let addRowButtonClick:boolean = true;
      let currentScreenContext:any={
        rowData:[
          {
            "accounting_posting": "Yes",
            "car-inv": "Yes",
            "cash_conversion_(canada_only)": "No",
            "dms_external_ip_address_for_dc": "",
            "f&i_leasing": "Yes",
            "forms_builder": "Yes",
            "id": "31361346-e7dd-49ac-b605-bd432ef6dd18",
            "index": "1000",
            "name-file": "No",
            "recordType": 1000,
            "rowDataId": "8250ba32-4419-4bf3-8ac4-5cccb74a8e23",
            "screenId": null,
            "service": "Yes",
            "service_account_name": "",
            "use_digital_contracting_on_this_logon": "No",
            "vms": "Yes",
            "vms_account_name": "",
            "we_owe_activation": "Yes"
          },
          {
            "accounting_posting": "Yes",
            "car-inv": "Yes",
            "recordType": 2000,
            "rowDataId": "8250ba32-4419-4bf3-8ac4-5cccb74a8e23",
            "screenId": null
          }
         ],
        screen:{
          gridOptionsModel: {
            "animatedRows": false,
            "rowSelection": "multiple",
            "columnDefs": [
              {
                "headerName": "Starting RO Number",
                "field": "starting_ro_number",
                "dataType": "INT",
                "required": "false",
                "editable": "false",
                "editableByCDKOnly": "false",
                "defaultValue": "",
                "validationRule": "",
                "dataLength": 9,
                "cellEditor": "agLargeTextCellEditor",
                "cellEditorParams": {
                  "maxLength": 9
                }
              }
            ],
            "rowData":null
          },
          rowDataEmpty:false,
          recordType: "413b4ec1-392e-4428-8c88-c63ed141c5a9"
        }
      }
      let selectedRows:any= [
        {
          "starting_invoice_number": "15000",
          "ending_invoice_number": "999999999",
          "index": "1000",
          "rowDataId": "f3ed49be-cc26-466a-8151-2e2421b0a2be"
      }
      ]

      let gridColumnApi :any={
        getAllDisplayedColumns
      }
      function getAllDisplayedColumns(){
        return 1
      }

      let gridApi:any={
        updateRowData,
        getSelectedRows,
        ensureColumnVisible,
        setFocusedCell,
        startEditingCell

      } 
      function startEditingCell(){
        return ;
       }
      function setFocusedCell(){
        return true;
       }
      function ensureColumnVisible(){
        return true;
       }
      function updateRowData(){
       return "test";
      }
      function getSelectedRows(){
       return selectedRows
      }
      currentIndex = 1;
      component.currentIndex = currentIndex;
      component.gridApi = gridApi
      component.gridColumnApi = gridColumnApi;
      spyOn(component,'pickValuesFromStore');
      spyOn(component,'newEmptyRowAlreadyExists').and.returnValue(false);
      component.currentScreenContext = currentScreenContext;
      component.addRow(currentScreenContext,addRowButtonClick);
      expect(component.pickValuesFromStore).toHaveBeenCalledTimes(1);
    });

    it('test Add Row new Row if it is 2nd or 5th row',()=>{

      let currentIndex : number = 0;
      let addRowButtonClick:boolean = true;
      let currentScreenContext:any={
        rowData:[
          {
            "accounting_posting": "Yes",
            "recordType": 1000,
          },
          {
            "accounting_posting": "Yes",
            "recordType": 2000,
          },
          {
            "accounting_posting": "No",
            "recordType": 3000,
          },
          {
            "accounting_posting": "Yes",
            "recordType": 4000,
          }
         ],
        screen:{
          screenName:'COA',
          gridOptionsModel: {
            "animatedRows": false,
            "rowSelection": "multiple",
            "columnDefs": [
              {
                "headerName": "Starting RO Number",
                "field": "starting_ro_number",
                "dataType": "INT",
                "required": "false",
                "editable": "false",
                "editableByCDKOnly": "false",
                "defaultValue": "",
                "validationRule": "",
                "dataLength": 9,
                "cellEditor": "agLargeTextCellEditor",
                "cellEditorParams": {
                  "maxLength": 9
                }
              }
            ],
            "rowData":null
          },
          rowDataEmpty:false,
          recordType: "413b4ec1-392e-4428-8c88-c63ed141c5a9"
        }
      }
      let selectedRows:any= [
        {
          "starting_invoice_number": "15000",
          "ending_invoice_number": "999999999",
          "index": "1000",
          "rowDataId": "f3ed49be-cc26-466a-8151-2e2421b0a2be"
      }
      ]

      let gridColumnApi :any={
        getAllDisplayedColumns
      }
      function getAllDisplayedColumns(){
        return 1
      }

      let gridApi:any={
        updateRowData,
        getSelectedRows,
        ensureColumnVisible,
        setFocusedCell,
        startEditingCell
      } 
      function startEditingCell(){
        return ;
       }
      function setFocusedCell(){
        return true;
       }
      function ensureColumnVisible(){
        return true;
       }
      function updateRowData(){
       return "test";
      }
      function getSelectedRows(){
       return selectedRows
      }
      currentIndex = 1;
      component.currentIndex = currentIndex;
      component.gridApi = gridApi
      component.gridColumnApi = gridColumnApi;
      spyOn(component,'pickValuesFromStore');
      spyOn(component,'newEmptyRowAlreadyExists').and.returnValue(false);
      component.currentScreenContext = currentScreenContext;
      let newItems:any={begdate:'08-02-2018'}
      spyOn(component,'createNewRowData').and.returnValue(newItems);
      component.addRow(currentScreenContext,addRowButtonClick);
      expect(component.pickValuesFromStore).toHaveBeenCalledTimes(1);
    });

    it('test addRow if Add Row button is not clicked',()=>{

      let currentIndex : number = 0;
      let addRowButtonClick:boolean = false;
      let currentScreenContext:any={
        rowData:[],
        screen:{
          screenName:'COA',
          gridOptionsModel: {
            "animatedRows": false,
            "rowSelection": "multiple",
            "columnDefs": [
              {
                "headerName": "Starting RO Number",
                "field": "starting_ro_number",
                "dataType": "INT",
                "required": "false",
                "editable": "false",
                "editableByCDKOnly": "false",
                "defaultValue": "",
                "validationRule": "",
                "dataLength": 9,
                "cellEditor": "agLargeTextCellEditor",
                "cellEditorParams": {
                  "maxLength": 9
                }
              }
            ],
            "rowData":null
          },
          rowDataEmpty:false,
          recordType: "413b4ec1-392e-4428-8c88-c63ed141c5a9"
        }
      }
      let selectedRows:any= [
        {
          "starting_invoice_number": "15000",
          "ending_invoice_number": "999999999",
          "index": "1000",
          "rowDataId": "f3ed49be-cc26-466a-8151-2e2421b0a2be"
      }
      ]

      let gridColumnApi :any={
        getAllDisplayedColumns
      }
      function getAllDisplayedColumns(){
        return 1
      }

      let gridApi:any={
        updateRowData,
        getSelectedRows,
        ensureColumnVisible,
        setFocusedCell,
        startEditingCell
      } 
      function startEditingCell(){
        return ;
       }
      function setFocusedCell(){
        return true;
       }
      function ensureColumnVisible(){
        return true;
       }
      function updateRowData(){
       return "test";
      }
      function getSelectedRows(){
       return selectedRows
      }
      currentIndex = 4;
      component.currentIndex = currentIndex;
      component.gridApi = gridApi
      component.gridColumnApi = gridColumnApi;
      spyOn(component,'pickValuesFromStore');
      spyOn(component,'newEmptyRowAlreadyExists').and.returnValue(false);
      component.currentScreenContext = currentScreenContext;
      let newItems:any={begdate:'08-02-2018'}
      spyOn(component,'createNewRowData').and.returnValue(newItems);
      component.addRow(currentScreenContext,addRowButtonClick);
      expect(component.pickValuesFromStore).toHaveBeenCalledTimes(1);
      expect(component.currentIndex).toBe(0);
    });

    it('test validateAndFormatCurrency if currency is Invalid',()=>{
        let params:any={
          newValue:'12$',
          oldValue:undefined,
          data:{
            error:undefined
          },
          column:{
            getId
          },
          api:{
            refreshCells
          }
        }
        function refreshCells(){
          return 
        }
        function getId(){
          return 'finance_charge_up_to'
        }
       let formattedCurrencyValue = '$12$.00';
       spyOn(formattingService,'formatCurrencyWithCommaAndDecimalPoint').and.returnValue(formattedCurrencyValue);
       spyOn(validationService,'isCurrencyValueValid').and.returnValue(false);
       component.validateAndFormatCurrency(params);
       expect(component['toastrService'].previousToastMessage).toBe('Invalid currency value!!!')
       expect(formattingService.formatCurrencyWithCommaAndDecimalPoint).toHaveBeenCalledTimes(1);
       expect(validationService.isCurrencyValueValid).toHaveBeenCalledTimes(1);
    });

    it('test validateAndFormatCurrency if currency is valid',()=>{
      let params:any={
        newValue:'12',
        oldValue:undefined,
        data:{
          error:{

          }
        },
        column:{
          getId
        },
        api:{
          refreshCells
        }
      }
      function refreshCells(){
        return
      }
      function getId(){
        return 'finance_charge_up_to'
      }
     let formattedCurrencyValue = '$12.00';
     spyOn(formattingService,'formatCurrencyWithCommaAndDecimalPoint').and.returnValue(formattedCurrencyValue);
     spyOn(validationService,'isCurrencyValueValid').and.returnValue(true);
     component.validateAndFormatCurrency(params);
     expect(formattingService.formatCurrencyWithCommaAndDecimalPoint).toHaveBeenCalledTimes(1);
     expect(validationService.isCurrencyValueValid).toHaveBeenCalledTimes(1);
  });

  it('test validateAndFormatPercentage if percentage value is empty ',()=>{

    let params:any={
      newValue:'43',
      oldValue:undefined,
      data:{
        error:{
          errors:[
            {
              errorDescription: "Mandatory field cannot be empty",
              errorField: "account#",
              errorLevel: "required",
              isUpdated: false  
            }
          ]

        }
      },
      column:{
        getId
      },
      api:{
        refreshCells
      }
    }
      function refreshCells(){
        return
      }
      function getId(){
        return 'finance_charge_rate'
      }
    spyOn(formattingService,'formatPercentageWithDecimalPoint').and.returnValue("");
    component.validateAndFormatPercenatage(params);
    expect(formattingService.formatPercentageWithDecimalPoint).toHaveBeenCalledTimes(1);
  });

  it('test validateAndFormatPercentage if percentage value is neither NULL nor empty ',()=>{

    let params:any={
      newValue:'67',
      oldValue:undefined,
      data:{
        error:{
          errors:[
            {
              errorDescription: "Mandatory field cannot be empty",
              errorField: "account#",
              errorLevel: "required",
              isUpdated: false  
            }
          ]

        }
      },
      column:{
        getId
      },
      api:{
        refreshCells
      }
    }
      function refreshCells(){
        return
      }
      function getId(){
        return 'finance_charge_rate'
      }
    spyOn(formattingService,'formatPercentageWithDecimalPoint').and.returnValue("67.0000%");
    component.validateAndFormatPercenatage(params);
    expect(params.data['finance_charge_rate']).toBe('67.0000%');
    expect(formattingService.formatPercentageWithDecimalPoint).toHaveBeenCalledTimes(1);
  });

  it('test validateAndFormatPercentage if percentage value is null',()=>{

    let params:any={
      newValue:null,
      oldValue:undefined,
      data:{
        error:{
          errors:[
            {
              errorDescription: "Mandatory field cannot be empty",
              errorField: "account#",
              errorLevel: "required",
              isUpdated: false  
            }
          ]

        }
      },
      node:{
        rowIndex:0
      },
      colDef:{
        field:'finance_charge_rate'
      },
      column:{
        getId
      },
      api:{
        refreshCells
      }
    }
      function refreshCells(){
        return
      }
      function getId(){
        return 'finance_charge_rate'
      }

      let currentScreenContext:any={
      "rowData": [
          {
              "rowDataId": "0e28fe9e-5008-4d36-8916-acfc881d8f0a",
              "screenId": null,
              "co_": "tes",
              "sched_code": "",
              "finance_charge_up_to": "$12.00",
              "finance_charge_jrnl": "",
              "recordType": 1000,
              "id": "ca13903d-0f85-41a2-9c6f-c8e51583c7db",
              "index": "1000",
              "finance_charge_rate": "nul",
              "isUpdated": true,
              "error": {
                  "rowIndex": 0,
                  "timeStamp": "",
                  "errors": [
                      {
                          "errorDescription": "Only Numbers are allowed",
                          "errorField": "finance_charge_rate",
                          "errorLevel": "",
                          "isUpdated": false
                      }
                  ]
              }
          }
      ]
      }  
    component.currentScreenContext = currentScreenContext; 
    spyOn(formattingService,'formatPercentageWithDecimalPoint').and.returnValue(null);
    component.validateAndFormatPercenatage(params);
    expect(formattingService.formatPercentageWithDecimalPoint).toHaveBeenCalledTimes(1);
  });

  it('test validateAndFormatPercentage if percentage value is null and row does not have error and errors',()=>{

    let params:any={
      newValue:null,
      oldValue:undefined,
      data:{
        error:{
          errors:[
            {
              errorDescription: "Mandatory field cannot be empty",
              errorField: "account#",
              errorLevel: "required",
              isUpdated: false  
            }
          ]

        }
      },
      node:{
        rowIndex:0
      },
      colDef:{
        field:'finance_charge_rate'
      },
      column:{
        getId
      },
      api:{
        refreshCells
      }
    }
      function refreshCells(){
        return
      }
      function getId(){
        return 'finance_charge_rate'
      }

      let currentScreenContext:any={
      "rowData": [
          {
              "rowDataId": "0e28fe9e-5008-4d36-8916-acfc881d8f0a",
              "screenId": null,
              "co_": "tes",
              "sched_code": "",
              "finance_charge_up_to": "$12.00",
              "finance_charge_jrnl": "",
              "recordType": 1000,
              "id": "ca13903d-0f85-41a2-9c6f-c8e51583c7db",
              "index": "1000",
              "finance_charge_rate": "nul",
              "isUpdated": true
          }
      ]
      }  
    component.currentScreenContext = currentScreenContext; 
    spyOn(formattingService,'formatPercentageWithDecimalPoint').and.returnValue(null);
    component.validateAndFormatPercenatage(params);
    expect(formattingService.formatPercentageWithDecimalPoint).toHaveBeenCalledTimes(1);
  });

  it('test validateAndFormatPercentage if percentage value is null and row does not have error',()=>{

    let params:any={
      newValue:null,
      oldValue:undefined,
      data:{
        error:{
          errors:[
            {
              errorDescription: "Mandatory field cannot be empty",
              errorField: "account#",
              errorLevel: "required",
              isUpdated: false  
            }
          ]

        }
      },
      node:{
        rowIndex:0
      },
      colDef:{
        field:'finance_charge_rate'
      },
      column:{
        getId
      },
      api:{
        refreshCells
      }
    }
      function refreshCells(){
        return
      }
      function getId(){
        return 'finance_charge_rate'
      }

      let currentScreenContext:any={
      "rowData": [
          {
              "rowDataId": "0e28fe9e-5008-4d36-8916-acfc881d8f0a",
              "screenId": null,
              "co_": "tes",
              "sched_code": "",
              "finance_charge_up_to": "$12.00",
              "finance_charge_jrnl": "",
              "recordType": 1000,
              "id": "ca13903d-0f85-41a2-9c6f-c8e51583c7db",
              "index": "1000",
              "finance_charge_rate": "nul",
              "isUpdated": true,
               "error": {
                  "rowIndex": 0,
                  "timeStamp": ""
              } 
          }
      ]
      }  
    component.currentScreenContext = currentScreenContext; 
    spyOn(formattingService,'formatPercentageWithDecimalPoint').and.returnValue(null);
    component.validateAndFormatPercenatage(params);
    expect(formattingService.formatPercentageWithDecimalPoint).toHaveBeenCalledTimes(1);
  });

  it('test processTemplateGrid for dropdown data type', ()=>{
    
    let params1:any={
      data:{
        error:{}
      }
    }
    let screen1:any={
      rowData:[],
      screen:{
        screenName:"Accounts Payable",
        gridOptionsModel: {
            columnDefs:[]=[
              {
                cellEditorParams:{
                  values:[]=[
                    {
                      value1:'test'
                    }
                  ]
                },
                dataType: "DROPDOWN",
                headerName: "MANAGER",
                cellEditor :'agTextCellEditor',
                editable:true,
                cellClassRules:{
                  
                  "alert-danger": function(params) {

                  }
                  
                }
              }
            ]
          },
        index: 0
      }
    }
    let templateContext :any={
      screenContextList:[screen1]
    }
    component.templateContext = templateContext;
    let funArea = functionalArea;
    funArea.functionalAreaName = 'EMPLOYEE';
    component.templateObject = funArea;
    spyOn(component,'checkForEditGridPermission').and.returnValue(true);
    spyOn(component,'setStepperStatus');
    let loaderDialogRef1:any={
      close(value = '') {
      }
    }
    component.processTemplateGrid(loaderDialogRef1);
  });


  it('testa sizeColumnsToFit',()=>{

    let params:any={
      api:{
        sizeColumnsToFit
      }
    }
    function sizeColumnsToFit(){
      return true;
    }
    component.currentScreen = screenObject;
    component.sizeColumnsToFit(params);

  });

  it('test onGridReady',()=>{

    let currentScreenContext:any={
      rowData:[
        {
          "accounting_posting": "Yes",
          "car-inv": "Yes",
          "we_owe_activation": "Yes"
        },
       
       ],
      screen:{
        recordType: "413b4ec1-392e-4428-8c88-c63ed141c5a9"
      }
    }
    let params:any={
      api:{
        setColumnDefs(){},
        setRowData(){}
      }
    }
    component.gridApi = gridApi;
    component.currentScreen = screenObject;
    component.currentScreenContext = currentScreenContext;
    spyOn(component,'sizeColumnsToFit');
    spyOn(component,'autoSizeAll');
    component.onGridReady(params);
  });


it('test executeSaveAndDeleteRowDataRequestsOnFromServer',()=>{
  let loaderDialogRef:any={
   close
  }
  function close(){}

  let serverRequests: any[]=[
    Observable.of("test")
  ]
  
  spyOn(excelService,'resetUnsavedDataPresent').and.returnValue(Observable.of({}));
  spyOn(component,'getTemplateInfo');
  component['executeSaveAndDeleteRowDataRequestsOnFromServer'](serverRequests,0,loaderDialogRef);
});


it('test executeSaveAndDeleteRowDataRequestsOnFromServer',()=>{
  let loaderDialogRef:any={
   close
  }
  function close(){}

  let serverRequests: any[]=[
    Observable.of("test"),
    Observable.of("test1"),
    Observable.of("test2"),
    Observable.of("test3"),
    Observable.of("test4")
  ]
  
  spyOn(excelService,'resetUnsavedDataPresent').and.returnValue(Observable.of({}));
  spyOn(component,'getTemplateInfo');
  component['executeSaveAndDeleteRowDataRequestsOnFromServer'](serverRequests,0,loaderDialogRef);
});


});


