import { Component, OnInit, ViewChild } from '@angular/core';

import { ProjectService } from '../services/project-service';
import { DataTransferService } from '../services/data-transfer-service';
import { AuthService } from '../services/auth-service';
import { Router } from '@angular/router';
import { DataSource } from '@angular/cdk/collections';
import { BehaviorSubject, Observable } from 'rxjs';
import { ProjectObject } from '../model/project-object';
import { PlatformObject } from '../model/platform-object';
import { ScreenObject } from '../model/screen-object';
import { StoreObject } from '../model/store-object';
import { MatPaginator, MatTableDataSource, MatSort, Sort } from '@angular/material';
import { MatDialog, MatDialogRef } from '@angular/material';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { FlexDashService } from '../services/flex-dash.service';
import { ToastrService } from 'ngx-toastr';
import { Constants } from '../constant/constants';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
    
    @ViewChild(MatPaginator,{static: false}) paginator: MatPaginator;
    
    @ViewChild(MatSort,{static: false}) sort: MatSort;
    
    dataSource : any;
    dotUsersList = {};
    openProjects=0;
    closedProjects=0;
    cancelledProjects=0;
    postopnedProjects=0;
    createProjectPermission = false;

    loggedInUser: string;
    hasPMRole = false;
    hasVICRole = false;
    showProjectsAsPM = false;
    showProjectsAsVIC = false;
    emptyStoreIdsList: string[] = [];
    nothingTOShow : boolean = false;
    message : string = "No projects assigned to you yet";
    showOpenProject: boolean = true;
    loggedInUserRoleList=[];
    dealerApprovePermission:boolean=false;
    constructor(private projectService: ProjectService, private toastrService : ToastrService,
           private authService: AuthService, private router: Router, private dialog: MatDialog) {
    }

    displayedColumns = ['projectNumber', 'dealerName', 'platform.platformName', 'projectManager','createdDate','lastUpdatedDate', 'status'];
  
    ngOnInit() {
        this.authService.fetchLoggedInUserAndPermissions().subscribe((data: any) => {
            let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
                width: '300px',
                height: '150px',
                data: { message: 'Fetching Dashboard details ..' }
            });
            
            this.loggedInUser = this.authService.getLoggedInUsersLoginId();
	  	    this.createProjectPermission = this.authService.isAuthorised('DOT_PROJECT_CREATE');
	  	    this.hasPMRole = this.authService.checkIfLoggedInUserHasRole('DOT - PROJECT MANAGER');
	  	    this.hasVICRole = this.authService.checkIfLoggedInUserHasRole('DOT - VIC');
            this.authService.fetchCommonServicesUsersWithManagerRole().subscribe(data =>{
            	data.forEach(user => {
            		this.dotUsersList[user.user.loginId] = user.user.firstName + ' ' + user.user.lastName;
                    const sortState: Sort = {active: 'lastUpdatedDate', direction: 'desc'};
                    this.sort.active = sortState.active;
                    this.sort.direction = sortState.direction;
                    this.sort.sortChange.emit(sortState);
                });
               
                this.fetchAllProjects();
      
            	loaderDialogRef.close();
            });
        });
        
    }
    
    fetchAllProjects() {
        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
          width: '300px',
          height: '150px',
          data: { message: 'Fetching Dashboard details ..' }
        });
        this.openProjects=0;
        this.closedProjects=0;
        this.cancelledProjects=0;
        this.postopnedProjects=0;
 
        this.projectService.getAllProjects(this.showProjectsAsVIC).subscribe(
          genericResponse => {
            if(genericResponse != null && genericResponse.resultCode===Constants.CDK_200){
               var data = genericResponse.resultObj;
               if (this.hasPMRole && this.showProjectsAsPM)
               {
                    data = data.filter( project => project.projectManager === this.loggedInUser);
               }
               data.forEach(project => {
                        
                      if(!project.storeIds) {
                         project.storeIds = this.emptyStoreIdsList;
                      }
                      
                      if(!project.platform) {
                         project.platform = new PlatformObject();
                      }
                   
                      if(project.status === 'OPEN')
                          this.openProjects+=1;
                      else if(project.status === 'FINISHED')
                          this.closedProjects+=1;
                      else if(project.status === 'POSTPONED')
                          this.postopnedProjects+=1;
                      else if(project.status === 'CANCELLED')
                          this.cancelledProjects+=1;                           
                 });
                 
               this.dataSource =  new MatTableDataSource<ProjectObject>(data);
               this.dataSource.data.forEach(element => {
                for (const key in element) {
                  if (!element[key] || element[key] === null || element[key] === undefined) {
                    element[key] = '';
                  }
                }
              });
              this.dataSource.filterPredicate = function(data, filter: string): boolean {
                return (data.projectNumber && data.projectNumber.toLowerCase().includes(filter))
                ||(data.dealerName && data.dealerName.toLowerCase().includes(filter))
                ||(data.platform.platformName && data.platform.platformName.toLowerCase().includes(filter))
                ||(data.projectManager && data.projectManager.toLowerCase().includes(filter))
                ||(data.createdDate && data.createdDate.toString().includes(filter))
                ||(data.lastUpdatedDate && data.lastUpdatedDate.toString().toLowerCase().includes(filter))
                ||(data.status && data.status.toLowerCase().toLowerCase().includes(filter));
            };
               this.showOpenProjectsOnly(null);
               this.nothingTOShow = data.length == 0;
               
               this.dataSource.sortingDataAccessor = (item, property) => {
                switch(property) {
                  case 'projectNumber': return item.projectNumber;  
                  case 'platform.platformName': return item.platform.platformName;
                  default: return item[property];
                }
              };
               this.dataSource.paginator = this.paginator;
               this.dataSource.sort = this.sort;
               loaderDialogRef.close();
            }
            else{
              this.toastrService.warning("Something went wrong...");
              loaderDialogRef.close();
            }
        });
    }
   
    newOnboardingProject() {
      this.router.navigateByUrl('projects/create');
    }
    
    applyFilter(filterValue: string) {
            filterValue = filterValue.trim(); // Remove whitespace
            filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
            this.dataSource.filter = filterValue;
               
    }
    
    showSelectedProjectsOption(event: any, PMorVIC : any) {
        if (event.checked) {
        	if ('PM' === PMorVIC){
        		this.showProjectsAsPM = true;
        		this.showProjectsAsVIC = false;
        	}
        	else if ('VIC' === PMorVIC){
	        	 this.showProjectsAsVIC = true;
        		this.showProjectsAsPM = false;
        	}
        } else {
        	if ('PM' === PMorVIC){
            	this.showProjectsAsPM = false;
            }
            else if ('VIC' === PMorVIC){
            	this.showProjectsAsVIC = false;
            }
            
        }
        this.fetchAllProjects();
    }
    
    showOpenProjectsOnly(event: any) {
    	if(event) {
    		this.showOpenProject = event.checked;
    	}
    	if (this.showOpenProject) {
    		this.dataSource.filter = 'open';
        } else {
        	this.dataSource.filter = '';
        }
    }
    
    getProject(projectNumber : string) {
            this.router.navigate(['projects/' +  projectNumber]);
    }
    
    iconColor(status: string) {
      status = status != null && status != '' ? status : 'OPEN'; 
      let style = {'color':'white'};
      if(status === 'OPEN' || status === 'Open') {
          style = {'color':'blue'};
      } else if(status === 'FINISHED' || status === 'Finished') {
          style = {'color':'green'};
      }  else if(status === 'CANCELLED' || status === 'Cancelled') {
          style = {'color':'grey'};
      }  else if(status === 'POSTPONED' || status === 'Postponed') {
          style = {'color':'orange'};
      } else if(status === 'INACTIVE' || status === 'Inactive') {
        style = {'color':'yellow'};
    }
      return style;
  }
}