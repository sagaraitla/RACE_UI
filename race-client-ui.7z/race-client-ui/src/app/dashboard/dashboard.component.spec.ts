import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { AuthService } from "../services/auth-service";
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatFormFieldModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatSort, MatTableDataSource, MatTableModule } from "@angular/material";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CdkTableModule } from "@angular/cdk/table";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { CommonModule } from "@angular/common";
import { Router } from "@angular/router";
import { of } from "rxjs";
import { DashboardComponent } from "./dashboard.component";
import { ProjectService } from "../services/project-service";
import { DataTransferService } from "../services/data-transfer-service";
import { FlexDashService } from "../services/flex-dash.service";
import { ProjectObject } from "../model/project-object";
import { Observable } from "rxjs";
import { HasPermissionDirective } from '../directive/has-permission.directive';


describe('DashboardComponent', () => {

    let component : DashboardComponent;
    let fixture: ComponentFixture<DashboardComponent>;
    let authService: AuthService;
    let projectService: ProjectService;
    let dataTransferService: DataTransferService;
    let flexDashService :FlexDashService;
    let router : Router;
    let dataSource :any;
    let filter:any;
    
    beforeEach(() => {
        let mockRouter = {
            navigate: jasmine.createSpy('navigateByUrl')
        } 
        TestBed.configureTestingModule({
            imports: [
                MatCardModule,
                FormsModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatInputModule,
                MatTableModule,
                MatPaginatorModule,
                MatDialogModule,
                HttpClientTestingModule,
                ToastrModule.forRoot(),
                NoopAnimationsModule,
                MatProgressSpinnerModule ,
                ReactiveFormsModule,
                CommonModule,
                MatSelectModule,
                MatRadioModule,
                MatCheckboxModule,
                MatMenuModule
            ],
            declarations: [DashboardComponent, HasPermissionDirective, LoaderDialogueComponent],
            providers:[
                 ProjectService,
                 AuthService,
                 ToastrService,
                 { provide: Router, useValue: mockRouter }
               ]
        }).overrideModule(BrowserDynamicTestingModule,{ set: { entryComponents: [LoaderDialogueComponent]}});

        authService = TestBed.get(AuthService);
        projectService = TestBed.get(ProjectService);
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(DashboardComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });


    const user_data1:any[]=[
      {
        "user": {
            "userGuid": "95B987AA7657728BE053440B6364CA78",
            "loginId": "Abraham.Joseph@cdk.com",
            "firstName": "Abraham",
            "middleInitial": null,
            "lastName": "Joseph",
            "dmsUserIdentifier": [],
            "locked": false,
            "adminNotes": null,
            "creationDate": "2019-11-01T13:14:41+0000",
            "lastLoginDate": null,
            "locale": "en_US",
            "state": 2,
            "prefix": null,
            "suffix": null,
            "nickName": null,
            "employeeId": null,
            "jobTitle": null,
            "selfServiceEnabled": 0,
            "accountStatus": "Active",
            "communicationEdgeId": "abrahamjosephcdkcom@dit.cdkcollaborate.com",
            "uniquePrincipalName": "Abraham.Joseph@cdk.com",
            "externallyFederated": true
        }
    }
    ]
    const users_data:any={
        
        "totalMatches": 1,
        "users": [
          {
             "user":{
               'loginId':"Sindhuja.gandrakota@cdk.com",
               "firstName": "Sindhuja",
               "lastName": "gandrakota",
             },
              
            "contacts": [],
            "enterprise": {
              "idpName": "CDK Self Enterprise",
              "id": "E000000",
              "name": "CDK Global"
            },
            "stores": [
              {
                "id": "S000000000",
                "name": "CDK Global",
                "defaultStore": true
              }
            ],
            "roles": [
              {
                "roleGuid": "541CDF9969F03905E053440B63646E2A",
                "roleName": "EIS_DATA_CORRECTION"
              },
            ]
          }
        ]
    }

    const generic_response_allProjects: any = {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [
          {
            "isProject": 1,
            "enterpriseId": "E000000",
            "projectNumber": "P000001",
            "dealerName": "Honda1",

            "platform": {
              "id": null,
              "platformName": "FLEX",
              "platformCode": "flex",
              "selected": false
            },
            "status": "OPEN",
            "clientManager": null,
            "vic": null,
            "css": null,
            "projectManager": "Dawn.Jordan@cdk.com",
            "id": "8e728963-124c-4552-8a73-f580cf4784ca",
            "recordType": "ProjectInfo"
          }
        ]
    }

    const generic_response_allProjects_finished: any = {
      "resultCode": "CDK_200",
      "resultDescription": "OK",
      "resultObj": [
        {
          "isProject": 1,
          "enterpriseId": "E000000",
          "projectNumber": "P000001",
          "dealerName": "Honda1",
          "status": "FINISHED",
          "projectManager": "Dawn.Jordan@cdk.com",
          "id": "8e728963-124c-4552-8a73-f580cf4784ca",
          "recordType": "ProjectInfo"
        }
      ]
    }

    const generic_response_allProjects_postponed: any = {
      "resultCode": "CDK_200",
      "resultDescription": "OK",
      "resultObj": [
        {
          "isProject": 1,
          "enterpriseId": "E000000",
          "projectNumber": "P000001",
          "dealerName": "Honda1",
          "status": "POSTPONED",
          "projectManager": "Dawn.Jordan@cdk.com",
          "id": "8e728963-124c-4552-8a73-f580cf4784ca",
          "recordType": "ProjectInfo"
        }
      ]
    }

    const generic_response_allProjects_cancelled: any = {

      "resultCode": "CDK_200",
      "resultDescription": "OK",
      "resultObj": [
        {
          "isProject": 1,
          "enterpriseId": "E000000",
          "projectNumber": "P000001",
          "dealerName": "Honda1",
          "status": "CANCELLED",
          "projectManager": "Dawn.Jordan@cdk.com",
          "id": "8e728963-124c-4552-8a73-f580cf4784ca",
          "recordType": "ProjectInfo"
        }
      ]
    }
    const genericResponse:any=null;

    it('test ngONInit',()=>{
   
      spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of({}));
      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
      dialogRefSpyObj.componentInstance = { body: '' };
      dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj); 

      spyOn(component,'fetchAllProjects');
      spyOn(authService,'getLoggedInUsersLoginId').and.returnValue("Sagar.Aitla@cdk.com");
      spyOn(authService,'isAuthorised').and.returnValue(true);
      spyOn(authService,'checkIfLoggedInUserHasRole').and.returnValue(true);
      spyOn(authService,'fetchCommonServicesUsersWithManagerRole').and.returnValue(Observable.of(user_data1));
      component.sort = new MatSort();
      component.ngOnInit();
    });


    it('test showSelectedProjectsOption',()=>{

        spyOn(component,'fetchAllProjects');

        let event:any={
           checked:false
        };
       event.checked = true;

       let PMorVIC :string ="PM";
       component.showSelectedProjectsOption(event,PMorVIC);
       expect(component.showProjectsAsPM).toEqual(true);
       expect(component.showProjectsAsVIC).toEqual(false);
    

       let PMorVIC1 :string ="VIC";
       component.showSelectedProjectsOption(event,PMorVIC1);
       expect(component.showProjectsAsPM).toEqual(false);
       expect(component.showProjectsAsVIC).toEqual(true);


       event.checked = false;
       let PMorVIC3 :string ="PM";
       component.showSelectedProjectsOption(event,PMorVIC3);
       expect(component.showProjectsAsPM).toEqual(false);

       let PMorVIC4 :string ="VIC";
       component.showSelectedProjectsOption(event,PMorVIC4);
       expect(component.showProjectsAsVIC).toEqual(false);

    });

    it('test iconColor',()=>{

        let status:string = "OPEN";
        let resultValue = component.iconColor(status);
        expect(resultValue.color).toEqual('blue')

        let status1:string = "FINISHED";
        let resultValue1 = component.iconColor(status1);
        expect(resultValue1.color).toEqual('green')

        let status2:string = "CANCELLED";
        let resultValue2 = component.iconColor(status2);
        expect(resultValue2.color).toEqual('grey')

        let status3:string = "POSTPONED";
        let resultValue3 = component.iconColor(status3);
        expect(resultValue3.color).toEqual('orange')

        let status4:string = "INACTIVE";
        let resultValue4 = component.iconColor(status4);
        expect(resultValue4.color).toEqual('yellow')

    }); 


    it('test applyFilter',()=>{
      component.dataSource= new MatTableDataSource<ProjectObject>(generic_response_allProjects[0]); 
      component.applyFilter("Test");
      expect(component.dataSource.filter).toEqual('test');
    });

    it('test fetchAllProjects for open projects',()=>{

      component.dataSource= new MatTableDataSource<ProjectObject>(generic_response_allProjects);
      spyOn(projectService,'getAllProjects').and.returnValue(Observable.of(generic_response_allProjects));
      component.fetchAllProjects();
      expect(projectService.getAllProjects).toHaveBeenCalledTimes(1);
      expect(component.openProjects).toEqual(1);
    });

    it('test fetchAllProjects for finished projects',()=>{

      component.dataSource= new MatTableDataSource<ProjectObject>(generic_response_allProjects_finished);
      spyOn(projectService,'getAllProjects').and.returnValue(Observable.of(generic_response_allProjects_finished));
      component.fetchAllProjects();
      expect(projectService.getAllProjects).toHaveBeenCalledTimes(1);
      expect(component.closedProjects).toEqual(1);
    });
    
    it('test fetchAllProjects for Postponed projects',()=>{

      component.dataSource= new MatTableDataSource<ProjectObject>(generic_response_allProjects_postponed);
      spyOn(projectService,'getAllProjects').and.returnValue(Observable.of(generic_response_allProjects_postponed));
      component.fetchAllProjects();
      expect(projectService.getAllProjects).toHaveBeenCalledTimes(1);
      expect(component.postopnedProjects).toEqual(1);
    });

    it('test fetchAllProjects for cancelled projects',()=>{
      component.dataSource= new MatTableDataSource<ProjectObject>(generic_response_allProjects_postponed);
      spyOn(projectService,'getAllProjects').and.returnValue(Observable.of(generic_response_allProjects_cancelled));
      component.fetchAllProjects();
      expect(projectService.getAllProjects).toHaveBeenCalledTimes(1);
      expect(component.cancelledProjects).toEqual(1);
    });
    

    it('test fetchAllProjects for generic response  null',()=>{
      spyOn(projectService,'getAllProjects').and.returnValue(Observable.of(genericResponse));
      component.fetchAllProjects();
      expect(projectService.getAllProjects).toHaveBeenCalledTimes(1);

    });


    it('test showOpenProjectsOnly',()=>{
      let event:any={
        checked:true
      }
      let dataSource:any={
        filter:'close'
      }
      component.dataSource = dataSource;
      component.showOpenProjectsOnly(event);
      expect(component.dataSource.filter).toBe('open')
    });

    
    it('test showOpenProjectsOnly if event is false',()=>{
      let event:any={
        checked:false
      }
      let dataSource:any={
        filter:'close'
      }
      component.dataSource = dataSource;
      component.showOpenProjectsOnly(event);
      expect(component.dataSource.filter).toBe('')
    });
    
});