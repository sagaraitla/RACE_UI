import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { FormBuilder, FormControl, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { DashReportComponent } from "./dash-report.component";
import { MatCardModule, MatCheckboxModule,MatOptionModule, MatDialogModule,MatDialogRef,MAT_DIALOG_DATA, MatDividerModule, MatFormFieldModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatSidenavModule, MatTableModule, MatOption } from '@angular/material';
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
describe('DashReportComponent', () => {

    let component : DashReportComponent;
    let fixture: ComponentFixture<DashReportComponent>;
    let _formBuilder : FormBuilder;

    beforeEach(async(() => {

      const dialogMock = {
        close: () => { }
    };

    let data= ["Comp Lines","Sources","Dealer Code","Dealer Name"];
   
    let useTestData ={
      sheetList:data
    }

        TestBed.configureTestingModule({
          imports: [
            FormsModule,
            MatDialogModule,
            
            HttpClientTestingModule,
            MatProgressSpinnerModule,
            ReactiveFormsModule,
            MatOptionModule,
            MatSelectModule,
            MatRadioModule,
            MatCheckboxModule,
            MatSidenavModule],
          declarations: [ DashReportComponent,LoaderDialogueComponent],
          providers:[
            { provide: MAT_DIALOG_DATA, useValue: useTestData },
             {provide: MatDialogRef, useValue: dialogMock}
          ]
        }).overrideModule(BrowserDynamicTestingModule,
           { set: { entryComponents: [LoaderDialogueComponent]}});

           
            
            fixture = TestBed.createComponent(DashReportComponent);
            component = fixture.componentInstance;
            _formBuilder = TestBed.get(FormBuilder); 
            component.selectedSheets = _formBuilder.control
          ({ 
          recipientTypes: new FormControl(
          {
              value: ["mock"]
              
          }
          )
          });
      }));

      const selectedMock = {
        selected:()=>{ return true}
      }
    const platforms:any=[
        {
            platformName:"FLEX"
        }
    ]
    const screenList:any =['scl','sos','order pad',];
    const emptyList:any =[];

    const finalListSelected:any=['scl','sos'];


   


    it('should create Create Dash Report Component',()=>{
      expect(component).toBeTruthy();
    });

    it('On OK Click',()=>{
        component.onOkClick(screenList);
        expect(screenList.length).toEqual(3);
     })
    it('On OK Click',()=>{
      component.onOkClick(emptyList);
      expect(emptyList.length).toEqual(0);
   })

   it('On Close Click',()=>{
    component.onClose(screenList);
    expect(screenList.length).toEqual(3);
    })

  it('On toggleAllSelection Click',()=>{
    const selected = true;
    Object.defineProperty(component,'allSelected',{get:() => selected})
    component.toggleAllSelection();
    expect(screenList.length).toEqual(3);
  })

  it('On toggleAllSelection Click else part',()=>{
    const selected = false;
    Object.defineProperty(component,'allSelected',{get:() => selected})
    component.toggleAllSelection();
    expect(screenList.length).toEqual(3);
  })

  it('On toggleAllSelection Click',()=>{
    const length = 2;
    Object.defineProperty(component,'value',{get:() => length})
    const selected = false;
    Object.defineProperty(component,'allSelected',{get:() => selected});
    
    component.tosslePerOne();
    expect(screenList.length).toEqual(3);
  })
   

   
}); 