import { Component, OnInit, ViewChild, Inject } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { Tree, TreeModel, NodeEvent, Ng2TreeSettings, TreeController } from 'ng2-tree';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatOption} from '@angular/material';
import { MatPaginator, MatSort } from '@angular/material';
import { DataSource } from '@angular/cdk/table';
import { BehaviorSubject, Observable } from 'rxjs';
import { FlexDashService } from '../services/flex-dash.service';
import { GridOptions } from 'ag-grid';
import { GridOptionsModel } from '../model/grid-options-object';
import { FormControl } from '@angular/forms';
import { ImportDialog } from '../import-dialog/import-dialog.component';

@Component({
  selector: 'app-dash-report',
  templateUrl: './dash-report.component.html',
  styleUrls: ['./dash-report.component.css']
})
export class DashReportComponent implements OnInit {

  ngOnInit() {}
  
  selectedSheets = new FormControl();
    public finalListSelected : string[];
    private sheetList : string[];
    @ViewChild('allSelected',{static: false}) private allSelected: MatOption;
    constructor(
      public dialogRef: MatDialogRef<DashReportComponent>,
      @Inject(MAT_DIALOG_DATA) public data: any) {
        this.sheetList = data.sheetList;        
        this.finalListSelected = [];
        }

        onOkClick(sheetsSelected : string): void {
          if(sheetsSelected)
          {

            this.finalListSelected = sheetsSelected.toString().split(',');
          }
          this.dialogRef.close(this.finalListSelected);    
        }
        onClose(finalListSelected : string[]) : any[] {          
            return finalListSelected;              
          }
        
          toggleAllSelection() {
          
            if (this.allSelected.selected) {
              
              this.selectedSheets
                .patchValue([...this.sheetList.map(item => item), 0]);
             


            } else {
              this.selectedSheets.patchValue([]);
            }
          }

          
          tosslePerOne() {
          
            if(this.allSelected.selected)
            {
              this.allSelected.deselect();
              return false;              
            }
            if(this.selectedSheets.value.length == this.sheetList.length)
            {
              this.allSelected.select();
            }

          }
}
