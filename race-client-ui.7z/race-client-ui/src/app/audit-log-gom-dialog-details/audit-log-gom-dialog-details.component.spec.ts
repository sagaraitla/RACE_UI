import { CdkTableModule } from "@angular/cdk/table";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatDialogModule, MatIconModule, MatDividerModule, MatProgressSpinnerModule, MatSnackBarModule, MatSortModule, MatCardModule, MatPaginatorModule, MatFormFieldModule, MatInputModule, MatCheckboxModule, MatDialogRef, MAT_DIALOG_DATA, MatDialog, MatTableDataSource, MatSort } from "@angular/material";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { AgGridModule } from "ag-grid-angular";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule } from "ngx-toastr";
import { observable, Observable, of } from "rxjs";
import { AuditLogDialogComponent } from "../audit-log-dialog/audit-log-dialog.component";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { GOMAuditLogsResponse } from "../model/audit-logsGOMResponse-object";
import { GenericResponse } from "../model/generic-response";
import { MasterFunctionalUnit } from "../model/master-functional-unit";
import { ScreenObject } from "../model/screen-object";
import { AuditLogService } from "../services/audit-log-service";
import { AuthService } from "../services/auth-service";
import { FunctionalUnitService } from "../services/functional-unit-service";
import { MasterFunctionalUnitService } from "../services/master-functional-unit-service";
import { ServerCommunicationService } from "../services/server-communication-service";
import { AuditLogGomDialogComponent } from "./audit-log-gom-dialog.component";

describe('AuditLogGomDialogComponent', () => {

 describe('AuditLogGomDialogComponent with PropagateFUGOM',()=>{

  let component : AuditLogGomDialogComponent;
  let fixture : ComponentFixture<AuditLogGomDialogComponent>;
  let auditLogService : AuditLogService;
  let masterfunctionalUnitService:MasterFunctionalUnitService;
  let functionalUnitService: FunctionalUnitService;
 
  const dialogMock = {
      close: () => { }
  };

  class MockRouter {
      navigateByUrl(url: string) { return url; }
  }

  beforeEach(async() =>{
      let data  = {
          displayName : "PropagateFUGOM",
          masterFunctionalUnit:"testFU",
          fuName : "screenFU"
      }
      TestBed.configureTestingModule({
          imports:[
              MatDialogModule,
              MatIconModule,
              CdkTableModule,
              MatDividerModule,
              MatProgressSpinnerModule,
              HttpClientTestingModule,
              NoopAnimationsModule,
              FormsModule,
              ReactiveFormsModule,
              BrowserModule,
              ToastrModule.forRoot(),
              MatSnackBarModule,
              MatSortModule,
              SortableModule,
              MatCardModule,
              MatPaginatorModule,
              MatFormFieldModule,
              MatInputModule,
              AgGridModule.withComponents([]),
              MatCheckboxModule
          ],

          declarations : [
              LoaderDialogueComponent,AuditLogDialogComponent, AuditLogGomDialogComponent
          ],

          providers :[
              AuditLogService, AuthService, MasterFunctionalUnitService, FunctionalUnitService, ServerCommunicationService,
              {provide : MatDialogRef , useValue : dialogMock},
              {provide : MAT_DIALOG_DATA, useValue : data},
              {provide : Router, useClass : MockRouter}

          ]
  }).overrideModule(BrowserDynamicTestingModule,
      { set: { entryComponents: [LoaderDialogueComponent, AuditLogDialogComponent]}});
        auditLogService = TestBed.get(AuditLogService);
        fixture = TestBed.createComponent(AuditLogGomDialogComponent);
        masterfunctionalUnitService = TestBed.get(MasterFunctionalUnitService);
        functionalUnitService = TestBed.get(FunctionalUnitService);
        component = fixture.componentInstance;    
})

const generic_response : GenericResponse = {
  "resultCode": "CDK_200",
  "resultDescription": "OK",
  "resultObj": [
    {
      "objectType": "Propagation",
      "date": "2020-10-29T09:56:13.635+0000",
      "objectIdentifier": "ProjOct21 : store1 : Propagate_Fu_To_BP_Drive",
      "user": "Suresh.Vanga@cdk.com",
      "event": undefined,
      "id": "65768c40-62ff-4d0c-ade9-0ebffc74b69a",
      "recordType": "PropagationInfo"
    }
    ],
    "executionTime" : null
}

it('test ng on init method', () =>{
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

  spyOn(masterfunctionalUnitService,'fetchFUGomDifferences').and.returnValue(Observable.of({}));
  spyOn(auditLogService, 'getGOMAuditlogFieldsInfoById').and.returnValue(Observable.of(generic_response));
  component.dataSource = new MatTableDataSource<GOMAuditLogsResponse>(generic_response.resultObj);
  component.sort = new MatSort();
  component.dataSource.sort = component.sort;
  fixture.detectChanges();
});

 })

 describe('AuditLogGomDialogComponent with IncorporateBPChanges',()=>{

  let component : AuditLogGomDialogComponent;
  let fixture : ComponentFixture<AuditLogGomDialogComponent>;
  let auditLogService : AuditLogService;
  let masterfunctionalUnitService:MasterFunctionalUnitService;
  let functionalUnitService: FunctionalUnitService;
 
  const dialogMock = {
      close: () => { }
  };

  class MockRouter {
      navigateByUrl(url: string) { return url; }
  }

  beforeEach(async() =>{
      let data  = {
          displayName : "IncorporateBPChanges",
          storeId:'',
          screenObject:{
            screenName:'COA'
          },
          faName : "Account"
      }
      TestBed.configureTestingModule({
          imports:[
              MatDialogModule,
              MatIconModule,
              CdkTableModule,
              MatDividerModule,
              MatProgressSpinnerModule,
              HttpClientTestingModule,
              NoopAnimationsModule,
              FormsModule,
              ReactiveFormsModule,
              BrowserModule,
              ToastrModule.forRoot(),
              MatSnackBarModule,
              MatSortModule,
              SortableModule,
              MatCardModule,
              MatPaginatorModule,
              MatFormFieldModule,
              MatInputModule,
              AgGridModule.withComponents([]),
              MatCheckboxModule
          ],

          declarations : [
              LoaderDialogueComponent,AuditLogDialogComponent, AuditLogGomDialogComponent
          ],

          providers :[
              AuditLogService, AuthService, MasterFunctionalUnitService, FunctionalUnitService, ServerCommunicationService,
              {provide : MatDialogRef , useValue : dialogMock},
              {provide : MAT_DIALOG_DATA, useValue : data},
              {provide : Router, useClass : MockRouter}

          ]
  }).overrideModule(BrowserDynamicTestingModule,
      { set: { entryComponents: [LoaderDialogueComponent, AuditLogDialogComponent]}});
        auditLogService = TestBed.get(AuditLogService);
        fixture = TestBed.createComponent(AuditLogGomDialogComponent);
        masterfunctionalUnitService = TestBed.get(MasterFunctionalUnitService);
        functionalUnitService = TestBed.get(FunctionalUnitService);
        component = fixture.componentInstance;    
})

const generic_response : GenericResponse = {
  "resultCode": "CDK_200",
  "resultDescription": "OK",
  "resultObj": [
    {
      "objectType": "Propagation",
      "date": "2020-10-29T09:56:13.635+0000",
      "objectIdentifier": "ProjOct21 : store1 : Propagate_Fu_To_BP_Drive",
      "user": "Suresh.Vanga@cdk.com",
      "event": undefined,
      "id": "65768c40-62ff-4d0c-ade9-0ebffc74b69a",
      "recordType": "PropagationInfo"
    }
    ],
    "executionTime" : null
}

it('test ng on init method', () =>{
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

  spyOn(functionalUnitService,'getFunctionalUnitGOMDiffs').and.returnValue(Observable.of({}));
  component.dataSource = new MatTableDataSource<GOMAuditLogsResponse>(generic_response.resultObj);
  component.sort = new MatSort();
  component.dataSource.sort = component.sort;
  fixture.detectChanges();
});

 })

  describe('AuditLogGomDialogComponent with GridOptionModel', () =>{
    let component : AuditLogGomDialogComponent;
    let fixture : ComponentFixture<AuditLogGomDialogComponent>;
    let auditLogService : AuditLogService;
    let masterfunctionalUnitService:MasterFunctionalUnitService;
    let functionalUnitService: FunctionalUnitService;
   
    const dialogMock = {
        close: () => { }
    };

    class MockRouter {
        navigateByUrl(url: string) { return url; }
    }

    beforeEach(async() =>{
        let data  = {
            displayName : "GridOptionModel",
            auditLog : {
                id : "auId"
            },
            fuName : "screenFU"
        }
        TestBed.configureTestingModule({
            imports:[
                MatDialogModule,
                MatIconModule,
                CdkTableModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                ToastrModule.forRoot(),
                MatSnackBarModule,
                MatSortModule,
                SortableModule,
                MatCardModule,
                MatPaginatorModule,
                MatFormFieldModule,
                MatInputModule,
                AgGridModule.withComponents([]),
                MatCheckboxModule
            ],

            declarations : [
                LoaderDialogueComponent,AuditLogDialogComponent, AuditLogGomDialogComponent
            ],

            providers :[
                AuditLogService, AuthService, MasterFunctionalUnitService, FunctionalUnitService, ServerCommunicationService,
                {provide : MatDialogRef , useValue : dialogMock},
                {provide : MAT_DIALOG_DATA, useValue : data},
                {provide : Router, useClass : MockRouter}

            ]
    }).overrideModule(BrowserDynamicTestingModule,
        { set: { entryComponents: [LoaderDialogueComponent, AuditLogDialogComponent]}});
          auditLogService = TestBed.get(AuditLogService);
          fixture = TestBed.createComponent(AuditLogGomDialogComponent);
          masterfunctionalUnitService = TestBed.get(MasterFunctionalUnitService);
          functionalUnitService = TestBed.get(FunctionalUnitService);
          component = fixture.componentInstance;    
})

const generic_response : GenericResponse = {
    "resultCode": "CDK_200",
    "resultDescription": "OK",
    "resultObj": [
      {
        "objectType": "Propagation",
        "date": "2020-10-29T09:56:13.635+0000",
        "objectIdentifier": "ProjOct21 : store1 : Propagate_Fu_To_BP_Drive",
        "user": "Suresh.Vanga@cdk.com",
        "event": undefined,
        "id": "65768c40-62ff-4d0c-ade9-0ebffc74b69a",
        "recordType": "PropagationInfo"
      }
      ],
      "executionTime" : null
  }

  const generic_empResObj_response : GenericResponse = {
    "resultCode": "CDK_200",
    "resultDescription": null,
    "resultObj": [
      ],
      "executionTime" : null
  }

  const screenObject : ScreenObject = {
    "screenName": "Account Definition",
    "gridOptionsModel": {
      "animatedRows": false,
      "rowSelection": "multiple",
      "columnDefs": [
        {
          "headerName": "Starting RO Number",
          "field": "starting_ro_number",
          "dataType": "INT",
          "required": "false",
          "editable": "true",
          "editableByCDKOnly": "false",
          "defaultValue": "",
          "validationRule": "",
          "dataLength": 9,
          "cellEditor": "agLargeTextCellEditor",
          "cellEditorParams": {
            "maxLength": 9
          }
        }
      ],
      "rowData":null
    },
    "description": "Account Definition",
    "updated": false,
    "version": 0,
    "productCode": "SVC",
    "index": 0,
    "bpScreenId": "6e260b12-03d5-4a9e-854c-ea29eba80dbd",
     "selected": false,
     "templateId": null,
    "copyRowData": true,
    "rowDataEmpty": false,
    "bpPropagationCompleted": false,
    "id": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
    "recordType": "ff991af6-3c55-4642-a500-bed944b7f574" 
}


  const gomDetails : GOMAuditLogsResponse = {
      headerName : "header",
      status : "status",
      gridOptionModelDiff : []
  }

  const master_funtional_unit: MasterFunctionalUnit={
    "functionalUnitType": "MasterFunctionalUnit",
    "functionalUnitName": "BP_Tree_Check_PropagationTQAIG",
    "gridOptionsModel": {
      "animatedRows": false,
      "rowSelection": "multiple",
      "columnDefs": [
      ],
      "rowData":null
    },
    "description": "BP_Tree_Check_Propagation",
    "version": 0,
    "productCode": "PTS",
    "createdDate": null,
    "lastUpdatedDate": null,
    "propagationStarted": false,
    "id": "ad5b9464-5839-4c84-aac3-c66f2398f6ad",
    "recordType": "FunctionalUnitInfo"
  }

  
  it('test close dialog method', () =>{
    component.closePopup();
});

it('test iconColor method', () =>{
  component.iconColor("Modified");
  component.iconColor("Added");
  component.iconColor("Deleted");
});

it('test open audit log method',() =>{
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  component.openAuditLogDialogue(gomDetails);
})

   it('test ng on init method', () =>{
      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
      dialogRefSpyObj.componentInstance = { body: '' };
      dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
      spyOn(auditLogService, 'getGOMAuditlogFieldsInfoById').and.returnValue(Observable.of(generic_response));
      component.dataSource = new MatTableDataSource<GenericResponse>(generic_response.resultObj);
      component.sort = new MatSort();
      component.dataSource.sort = component.sort;
      fixture.detectChanges();
      expect(auditLogService.getGOMAuditlogFieldsInfoById).toHaveBeenCalledTimes(1);
   });

   it('test ng on init method throw api error', () =>{
    
    let error:any={
      error:{
        message:'API Error'
      }
    }
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    spyOn(auditLogService, 'getGOMAuditlogFieldsInfoById').and.returnValue(Observable.throwError(error));
    component.dataSource = new MatTableDataSource<GenericResponse>(generic_response.resultObj);
    component.sort = new MatSort();
    component.dataSource.sort = component.sort;
    fixture.detectChanges();
    expect(auditLogService.getGOMAuditlogFieldsInfoById).toHaveBeenCalledTimes(1);
    expect(component['toastrService'].previousToastMessage).toBe('Error while fetching the data API Error');
 });

    it('test ng on init method PropagateFUGOM', () =>{
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    spyOn(masterfunctionalUnitService, 'fetchFUGomDifferences').and.returnValue(Observable.of(generic_response));
    component.masterFunctionalUnit = master_funtional_unit;
    component['displayName'] = 'PropagateFUGOM';
    component.dataSource = new MatTableDataSource<GenericResponse>(generic_response.resultObj);
    component.sort = new MatSort();
    component.dataSource.sort = component.sort;
    fixture.detectChanges();
    expect(masterfunctionalUnitService.fetchFUGomDifferences).toHaveBeenCalledTimes(1);
 });

 it('test ng on init method PropagateFUGOM In case of API Error', () =>{
  let error:any={
    error:{
      message:'API Error'
    }
  }
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  spyOn(masterfunctionalUnitService, 'fetchFUGomDifferences').and.returnValue(Observable.throwError(error));
  component.masterFunctionalUnit = master_funtional_unit;
  component['displayName'] = 'PropagateFUGOM';
  fixture.detectChanges();
  expect(masterfunctionalUnitService.fetchFUGomDifferences).toHaveBeenCalledTimes(1);
  expect(component['toastrService'].previousToastMessage).toBe('Error while fetching the data API Error');
});


it('test ng on init method PropagateFUGOM In case of  API gives undefined results', () =>{
 
  let response = undefined;
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  spyOn(masterfunctionalUnitService, 'fetchFUGomDifferences').and.returnValue(Observable.of(response));
  component.masterFunctionalUnit = master_funtional_unit;
  component['displayName'] = 'PropagateFUGOM';
  fixture.detectChanges();
  expect(masterfunctionalUnitService.fetchFUGomDifferences).toHaveBeenCalledTimes(1);
});

it('test ng on init method PropagateFUGOM In case of  API gives result Object empty', () =>{
 
  const generic_response : GenericResponse = {
    "resultCode": "CDK_200",
    "resultDescription": "OK",
    "resultObj": [
      ],
      "executionTime" : null
  }
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  spyOn(masterfunctionalUnitService, 'fetchFUGomDifferences').and.returnValue(Observable.of(generic_response));
  component.masterFunctionalUnit = master_funtional_unit;
  component['displayName'] = 'PropagateFUGOM';
  fixture.detectChanges();
  expect(masterfunctionalUnitService.fetchFUGomDifferences).toHaveBeenCalledTimes(1);
  expect(component.message).toBe('This Functional Unit has been added newly to one or more Functional Areas.')
  expect(component.isDiffPresent).toBeTruthy();
});

 it('test ng on init method IncorporateBPChanges', () =>{
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  spyOn(functionalUnitService, 'getFunctionalUnitGOMDiffs').and.returnValue(Observable.of(generic_response));
  component.masterFunctionalUnit = master_funtional_unit;
  component.screenObject = screenObject;
  component['displayName'] = 'IncorporateBPChanges';
  component.dataSource = new MatTableDataSource<GenericResponse>(generic_response.resultObj);
  component.sort = new MatSort();
  component.dataSource.sort = component.sort;
  fixture.detectChanges();
  expect(functionalUnitService.getFunctionalUnitGOMDiffs).toHaveBeenCalledTimes(1);
});

it('test ng on init method IncorporateBPChanges API throws error', () =>{
  let error:any={
    error:{
      message:'API Error'
    }
  }
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  spyOn(functionalUnitService, 'getFunctionalUnitGOMDiffs').and.returnValue(Observable.throwError(error));
  component.masterFunctionalUnit = master_funtional_unit;
  component.screenObject = screenObject;
  component['displayName'] = 'IncorporateBPChanges';
  fixture.detectChanges();
  expect(functionalUnitService.getFunctionalUnitGOMDiffs).toHaveBeenCalledTimes(1);
  expect(component['toastrService'].previousToastMessage).toBe('Error while fetching the data API Error');
});

it('test ng on init method IncorporateBPChanges API gives undefined results', () =>{
 
  let response = undefined;
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  spyOn(functionalUnitService, 'getFunctionalUnitGOMDiffs').and.returnValue(Observable.of(response));
  component.masterFunctionalUnit = master_funtional_unit;
  component.screenObject = screenObject;
  component['displayName'] = 'IncorporateBPChanges';
  fixture.detectChanges();
  expect(functionalUnitService.getFunctionalUnitGOMDiffs).toHaveBeenCalledTimes(1);
});


it('test ng on init method IncorporateBPChanges In case of  API gives result Object empty', () =>{
 
  const generic_response : GenericResponse = {
    "resultCode": "CDK_200",
    "resultDescription": "OK",
    "resultObj": [
      ],
      "executionTime" : null
  }
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  spyOn(functionalUnitService, 'getFunctionalUnitGOMDiffs').and.returnValue(Observable.of(generic_response));
  component.masterFunctionalUnit = master_funtional_unit;
  component.screenObject = screenObject;
  component['displayName'] = 'IncorporateBPChanges';
  component.faName = 'Service'
  fixture.detectChanges();
  expect(functionalUnitService.getFunctionalUnitGOMDiffs).toHaveBeenCalledTimes(1);
  expect(component.message).toBe("This Functional Unit has been added newly to the FunctionalArea - Service.")
  expect(component.isDiffPresent).toBeTruthy();
});



  it('test ngOn init else case', () =>{
    spyOn(auditLogService, 'getGOMAuditlogFieldsInfoById').and.returnValue(Observable.of(generic_empResObj_response));
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    component.ngOnInit();
    expect(auditLogService.getGOMAuditlogFieldsInfoById).toHaveBeenCalledTimes(1);
  });


})

});