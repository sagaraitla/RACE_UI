import { Component, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar, MatTableDataSource , MatSort, Sort} from '@angular/material';
import { Router } from '@angular/router';

import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { AuditLogService } from '../services/audit-log-service';
import { AuthService } from '../services/auth-service';
import { AuditLogsObject } from '../model/audit-logs-object';
import { ToastrService } from 'ngx-toastr';
import { AuditLogDialogComponent } from  '../audit-log-dialog/audit-log-dialog.component';
import { GOMAuditLogsResponse } from '../model/audit-logsGOMResponse-object';
import { MasterFunctionalUnit } from '../model/master-functional-unit';
import { MasterFunctionalUnitService } from '../services/master-functional-unit-service';
import { FunctionalUnitService } from '../services/functional-unit-service';
import { ScreenObject } from '../model/screen-object';

@Component({
      selector: 'app-audit-log-gom-dialog',
      templateUrl: './audit-log-gom-dialog.component.html',
      styleUrls: ['./audit-log-gom-dialog.component.css']
})

export class AuditLogGomDialogComponent {
    
      @ViewChild(MatSort,{static: false}) sort: MatSort;
        
      auditLog : AuditLogsObject;
      dataSource : any;
      displayName:string;
      fuName:string;
      masterFunctionalUnit:MasterFunctionalUnit;
      storeId: string;
      screenName: string;
      screenObject :ScreenObject;
      message:string;
      isDiffPresent:boolean;
      faName:string;
      displayedColumns = ['headerName','status','more'];

      constructor(private auditLogService: AuditLogService, private dialogRef: MatDialogRef<AuditLogGomDialogComponent>, private authService: AuthService,
              private _formBuilder: FormBuilder, @Inject(MAT_DIALOG_DATA) private data: any,  private dialog: MatDialog, private toastrService:ToastrService,
              private snackBar: MatSnackBar, private router: Router,private masterfunctionalUnitService:MasterFunctionalUnitService,
               private functionalUnitService: FunctionalUnitService) {
          dialogRef.disableClose = true;
          this.displayName = this.data.displayName;
          if(this.displayName === 'GridOptionModel'){
            this.auditLog = JSON.parse(JSON.stringify(this.data.auditLog));
          }

          if(this.displayName === 'PropagateFUGOM'){
            this.masterFunctionalUnit = JSON.parse(JSON.stringify(this.data.masterFunctionalUnit));
          }

          this.fuName = this.data.fuName;
          
          if(this.displayName === 'IncorporateBPChanges'){
            this.storeId = this.data.storeId;
            this.screenName = this.data.screenObject.screenName;
            this.fuName = this.screenName;
            this.screenObject= this.data.screenObject;
            this.faName = this.data.faName;
          }
         

      }
  
      ngOnInit() {

        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
            width: '300px',
            height: '150px',
            data: { message: 'Fetching GridOptionModel details..' }
          });
          if(this.displayName === 'GridOptionModel'){
            this.auditLogService.getGOMAuditlogFieldsInfoById(this.auditLog.id).subscribe(genericResponse => {
              if(genericResponse != null && genericResponse != undefined && genericResponse.resultDescription != null && genericResponse.resultDescription == "OK"){
               
                  this.dataSource =  new MatTableDataSource<GOMAuditLogsResponse>(genericResponse.resultObj);   
                  this.dataSource.sort = this.sort;
                  const sortState: Sort = {active: 'status', direction: 'asc'};
                         this.sort.active = sortState.active;
                         this.sort.direction = sortState.direction;
                         this.sort.sortChange.emit(sortState);
                  loaderDialogRef.close();
              }else{
                loaderDialogRef.close();
              }
              },error => {
                  this.toastrService.error('Error while fetching the data ' + error.error.message);
                  loaderDialogRef.close();
                  }
              );
          }

          if(this.displayName === 'PropagateFUGOM'){
            this.masterfunctionalUnitService.fetchFUGomDifferences(this.masterFunctionalUnit.id).subscribe(genericResponse => {
              if(genericResponse != null && genericResponse != undefined && genericResponse.resultDescription != null && genericResponse.resultDescription == "OK"){
                  if(genericResponse.resultObj != null && genericResponse.resultObj.length == 0){
                    this.message = "This Functional Unit has been added newly to one or more Functional Areas.";
                    this.isDiffPresent = true;
                  }
                    this.dataSource =  new MatTableDataSource<GOMAuditLogsResponse>(genericResponse.resultObj);   
                    this.dataSource.sort = this.sort;
                    const sortState: Sort = {active: 'status', direction: 'asc'};
                           this.sort.active = sortState.active;
                           this.sort.direction = sortState.direction;
                           this.sort.sortChange.emit(sortState);
                    loaderDialogRef.close();
                  
                  
              }else{
              loaderDialogRef.close();
              }
              },error => {
                  this.toastrService.error('Error while fetching the data ' + error.error.message);
                  loaderDialogRef.close();
                  }
              );
          }

          if(this.displayName === 'IncorporateBPChanges'){
            this.functionalUnitService.getFunctionalUnitGOMDiffs(this.storeId,this.screenObject.id,this.screenObject.recordType).subscribe(genericResponse => {
               if(genericResponse != null && genericResponse != undefined && genericResponse.resultDescription != null && genericResponse.resultDescription == "OK"){
                if(genericResponse.resultObj != null && genericResponse.resultObj.length == 0){
                  this.message = "This Functional Unit has been added newly to the FunctionalArea - "+this.faName+ ".";
                  this.isDiffPresent = true;
                }     
                this.dataSource =  new MatTableDataSource<GOMAuditLogsResponse>(genericResponse.resultObj);   
                     this.dataSource.sort = this.sort;
                     const sortState: Sort = {active: 'status', direction: 'asc'};
                      this.sort.active = sortState.active;
                      this.sort.direction = sortState.direction;
                      this.sort.sortChange.emit(sortState);
                      loaderDialogRef.close();
                }else{
                      loaderDialogRef.close();
                }
              },error => {
                  this.toastrService.error('Error while fetching the data ' + error.error.message);
                  loaderDialogRef.close();
                  }
              );

          }
          
      }
  
      closePopup() {
          this.dialogRef.close();
      };
      
      iconColor(status: string) {
          status = status != null && status != '' ? status : 'Not Modified'; 
          let style = {'color':'grey'};
          if(status === 'Modified' || status === 'modified') {
              style = {'color':'blue'};
          }else if(status === 'Added'){
            style = {'color':'green'};
          }else if(status === 'Deleted'){
            style = {'color':'red'};
          }
          return style;
      }

      openAuditLogDialogue(gomDetails : GOMAuditLogsResponse){
       
        let dialogRef = this.dialog.open(AuditLogDialogComponent, {
          width: '60%',
          height: '80%',
          data: {
            gomDetails: gomDetails,
            displayName:'GridOptionModel',
            fuName:this.fuName

          }
      }); 
    }

}
