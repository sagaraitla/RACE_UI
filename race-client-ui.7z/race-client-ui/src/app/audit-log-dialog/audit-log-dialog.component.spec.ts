import { CdkTableModule } from "@angular/cdk/table";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatDialog, MatDialogModule, MatDialogRef, MatDividerModule, MatIconModule, MatProgressSpinnerModule, MatSnackBarModule, MatSort, MatSortModule, MatTableDataSource, MAT_DIALOG_DATA } from "@angular/material";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { Observable, of } from "rxjs";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { AuditLogsObject } from "../model/audit-logs-object";
import { GOMAuditLogsResponse } from "../model/audit-logsGOMResponse-object";
import { FieldInfoObject } from "../model/fields-info-object";
import { GenericResponse } from "../model/generic-response";
import { AuditLogService } from "../services/audit-log-service";
import { AuthService } from "../services/auth-service";
import { ServerCommunicationService } from "../services/server-communication-service";
import { AuditLogDialogComponent } from "./audit-log-dialog.component"

describe('AuditLogDialogComponent',() =>{
    let component : AuditLogDialogComponent;
    let fixture : ComponentFixture<AuditLogDialogComponent>;
    let auditLogService : AuditLogService;
    let authService : AuthService;
    let gomAuditLogResponse : GOMAuditLogsResponse;
    let serverCommunicationService : ServerCommunicationService;

    class MatDialogMock {
        open() {
          return {
            afterClosed: () => Observable.of(true)
          };
        }
      };

      const dialogMock = {
        close: () => { }
        };
      

      const testurl = 'dashboard';
      
      beforeEach(()=>{

        let mockRouter = {
            navigate: jasmine.createSpy('navigateByUrl')
        } 
        const AuditLogdialogServiceSpy = jasmine.createSpyObj('AuditLogService', ['getAuditlogFieldsInfoById']);
        let data ={
            displayName : "Project - Store",
            auditLog:'test'

        }
        TestBed.configureTestingModule({
            imports:[
                MatDialogModule,
                MatIconModule,
                CdkTableModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                ToastrModule.forRoot(),
                MatSnackBarModule,
                MatSortModule,
                SortableModule
            ],
            declarations:[
                AuditLogDialogComponent, LoaderDialogueComponent
            ],
            providers:[
                AuditLogService,
                AuthService,
                ToastrService,{ provide: Router, useValue: {url:testurl} },
                { provide: MAT_DIALOG_DATA, useValue: data },
                { provide: MatDialogRef, useValue: dialogMock },
                ServerCommunicationService
            ]
        }).overrideModule(BrowserDynamicTestingModule,
          { set: { entryComponents: [LoaderDialogueComponent]}});

            authService = TestBed.get(AuthService);
            auditLogService = TestBed.get(AuditLogService);
      });

      beforeEach(() =>{
          fixture = TestBed.createComponent(AuditLogDialogComponent)
          component = fixture.componentInstance;
          fixture.detectChanges();
      })
      

      const audit_log_mock_response : GenericResponse = {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [
          {
            "objectType": "Propagation",
            "date": "2020-10-29T09:56:13.635+0000",
            "objectIdentifier": "ProjOct21 : store1 : Propagate_Fu_To_BP_Drive",
            "user": "Suresh.Vanga@cdk.com",
            "event": "Functional units propagation has been completed",
            "id": "65768c40-62ff-4d0c-ade9-0ebffc74b69a",
            "recordType": "PropagationInfo"
          }
          ],
          "executionTime" : null
      }

      const gom_audit_mock_response : GOMAuditLogsResponse = {
          "headerName" : "header",
           "status" : "status",
           "gridOptionModelDiff" :[
               {
                   "id" : "fieldId",
                   "fieldName" : "fName",
                   "previousValue" : "prev",
                   "currentValue" : "cur",
                   "status" : "Open"
                }
           ]
      }


      it('test ngOnInit throws API Error',()=>{
        let error:any={
          error:{
            message:'API Error'
          }
        }
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close:()=>{} });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(auditLogService, 'getAuditlogFieldsInfoById').and.returnValue(Observable.throwError(error));
        component.ngOnInit();
        expect(component['toastrService'].previousToastMessage).toBe('Error while fetching the data API Error')

      });

      

      it('test ngOnInit where display Name is not equal to GridOptionModel ',()=>{
       
        let fieldInfoObject:FieldInfoObject[]=[{
          'id' : 'F11122',
          'fieldName' : 'Header',
          'previousValue': 'SNO',
          'currentValue' : 'SerialNumber',
          'status': 'true'
        }
      ]
        let gomAuditLogDetails:GOMAuditLogsResponse={
          headerName : 'Header',
          status : 'true',
          gridOptionModelDiff:fieldInfoObject
        }
        component.gomAuditLogDetails = gomAuditLogDetails;
        component.dataSource= new MatTableDataSource<FieldInfoObject>(gomAuditLogDetails.gridOptionModelDiff);
        component.dataSource.sort= new MatSort;
        component['displayName']= 'GridOptionModel';
        component.ngOnInit();
      });
     
      it('test close pop up',()=>{
        component.closePopup()
      });

      it("test ngOnInit",()=>{

        spyOn(auditLogService, 'getAuditlogFieldsInfoById').and.returnValue(Observable.of(audit_log_mock_response));
        component.ngOnInit();
      });

      it('test init with error', () =>{
          audit_log_mock_response.resultDescription = "test";
        spyOn(auditLogService, 'getAuditlogFieldsInfoById').and.returnValue(Observable.of(audit_log_mock_response));
        component.ngOnInit();        
      });

      it('test iconColor method', () =>{
          component.iconColor("Modified");
          component.iconColor("Added");
          component.iconColor("Deleted");
      });
     
})