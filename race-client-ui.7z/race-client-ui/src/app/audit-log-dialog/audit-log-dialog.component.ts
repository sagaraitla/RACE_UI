import { Component, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar, MatTableDataSource , MatSort, Sort} from '@angular/material';
import { Router } from '@angular/router';

import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { AuditLogService } from '../services/audit-log-service';
import { UserObject } from '../model/user-object';
import { AuthService } from '../services/auth-service';
import { AuditLogsObject } from '../model/audit-logs-object';
import { FieldInfoObject } from '../model/fields-info-object';
import { Constants } from '../constant/constants';
import { ToastrService } from 'ngx-toastr';
import { GOMAuditLogsResponse } from '../model/audit-logsGOMResponse-object';

@Component({
      selector: 'app-audit-log-dialog',
      templateUrl: './audit-log-dialog.component.html',
      styleUrls: ['./audit-log-dialog.component.css']
})

export class AuditLogDialogComponent {
    
      @ViewChild(MatSort,{static: false}) sort: MatSort;
        
      auditLog : AuditLogsObject;
      dataSource : any;
      displayName:string;
      gomAuditLogDetails:GOMAuditLogsResponse;
      fuName:string;

      displayedColumns = ['fieldName','previousValue','currentValue','status'];
      constructor(private auditLogService: AuditLogService, private dialogRef: MatDialogRef<AuditLogDialogComponent>, private authService: AuthService,
              private _formBuilder: FormBuilder, @Inject(MAT_DIALOG_DATA) private data: any,  private dialog: MatDialog, private toastrService:ToastrService,
              private snackBar: MatSnackBar, private router: Router) {
          dialogRef.disableClose = true;
          
          this.displayName = this.data.displayName;
          if(this.displayName !== 'GridOptionModel'){
            this.auditLog = JSON.parse(JSON.stringify(this.data.auditLog));
          }else{
            this.fuName = this.data.fuName;
            this.gomAuditLogDetails = JSON.parse(JSON.stringify(this.data.gomDetails));
          }

      }
  
      ngOnInit() {

        if(this.displayName !== 'GridOptionModel'){
          let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
            width: '300px',
            height: '150px',
            data: { message: 'Fetching project/store details...' }
          });

        this.auditLogService.getAuditlogFieldsInfoById(this.auditLog.id).subscribe(genericResponse => {
            if(genericResponse != null && genericResponse != undefined && genericResponse.resultDescription == "OK" && genericResponse.resultDescription != null){
              if(this.displayName === 'Project - Store'){
                const sortState: Sort = {active: 'date', direction: 'asc'};
                this.sort.active = sortState.active;
                this.sort.direction = sortState.direction;
                this.sort.sortChange.emit(sortState);
              }
                this.dataSource =  new MatTableDataSource<FieldInfoObject>(genericResponse.resultObj);   
                this.dataSource.sort = this.sort;
                loaderDialogRef.close();
            }else{
            loaderDialogRef.close();
            }
            },error => {
                this.toastrService.error('Error while fetching the data ' + error.error.message);
                loaderDialogRef.close();
                }
            );
        }else{
          this.dataSource =  new MatTableDataSource<FieldInfoObject>(this.gomAuditLogDetails.gridOptionModelDiff);   
          this.dataSource.sort = this.sort;
          
        }

        
          
      }
  
      closePopup() {
          this.dialogRef.close();
      };
      
      iconColor(status: string) {
          status = status != null && status != '' ? status : 'Not Modified'; 
          let style = {'color':'grey'};
          if(status === 'Modified' || status === 'modified') {
              style = {'color':'blue'};
          }else if(status === 'Added'){
            style = {'color':'green'};
          }else if(status === 'Deleted'){
            style = {'color':'red'};
          }
          return style;
      }
}
