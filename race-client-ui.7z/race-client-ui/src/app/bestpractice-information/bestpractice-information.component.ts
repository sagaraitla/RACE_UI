import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material';
import { BestPracticeService } from '../services/bestpractice-service';
import { AuthService } from '../services/auth-service';
import { PlatformObject } from '../model/platform-object'
import { AddBPVersionComponent } from '../add-bp-version/add-bp-version-dialog.component';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { BestPracticeObject } from '../model/bestpractice-object';
import { BestPracticeVersionObject } from '../model/bestpractice-version-object';
import { AddBPSSSVersionComponent } from '../add-bp-sss-version/add-bp-sss-version-dialog.component';
import { Constants } from '../constant/constants';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-bestpractice-information',
  templateUrl: './bestpractice-information.component.html',
  styleUrls: ['./bestpractice-information.component.css']
})
export class BestPracticeInformationComponent implements OnInit, OnDestroy {

  bestPracticeObject: BestPracticeObject = new BestPracticeObject();
  bestPracticeObjectCopy: BestPracticeObject = new BestPracticeObject();
  addStorePermission = false;
  editProjectPermission = false;
  createBPPermission = false;
  hasEnterpriseStore: boolean;
  storesReceived = false;
  currentStatus: string;
  bpVersions: BestPracticeVersionObject[] = [];
  bpVersionsCopy: BestPracticeVersionObject[] = [];
  templateList = [];

  subscription: any;
  isStateStandard: boolean = false;
  dialogRef: any;
  constructor(private bestPracticeService: BestPracticeService, private authService: AuthService, private route: ActivatedRoute, private dialog: MatDialog, private router: Router, private toastrService: ToastrService) {
    this.bestPracticeObject.platform = new PlatformObject();
    this.isStateStandard = this.route.snapshot.params.isStateStandard ? true : false;
  }

  ngOnInit() {
	  	this.authService.fetchLoggedInUserAndPermissions().subscribe(() => {
	        this.getBestPracticeInformation('Fetching Best Practice Information.');
	        this.createBPPermission = this.authService.isAuthorised('DOT_ADMIN');
	        this.addStorePermission = this.authService.isAuthorised('DOT_ADMIN');
	        this.editProjectPermission = this.authService.isAuthorised('DOT_ADMIN');
    });

  }

  ngOnDestroy() {
  }

  getBestPracticeInformation(loaderMessage: string) {
    let loaderDialogRef;
    if (loaderMessage) {
      loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
        width: '300px',
        height: '150px',
        data: { message: loaderMessage }
      });
    }
    this.getBestPracticeDetailsByName(this.route.snapshot.params.name,this.route.snapshot.params.platformCode, true)
      .subscribe(
        bestPractice => {
          this.bestPracticeObject = bestPractice;
          this.bestPracticeObjectCopy = Object.assign({}, this.bestPracticeObject);
          this.bestPracticeService.getVersionsByBestPracticeId(bestPractice.id, true).subscribe(
            bpVersionList => {
              this.storesReceived = true;
              this.bpVersions = bpVersionList;
              this.bpVersionsCopy = JSON.parse(JSON.stringify(this.bpVersions))

              if( this.bpVersions.length !== 0){
                let loaderDialogRefFA = this.dialog.open(LoaderDialogueComponent, {
                width: '300px',
                height: '150px',
                data: { message: "Fetching functionalArea details" }
              });

              this.bpVersions.forEach(bpVersionObj => {
                this.bestPracticeService.getFunctionalAreasOfBpVersion(bpVersionObj.recordType, true).subscribe(templates => {
                    bpVersionObj.functionalAreaList = [];
                    templates.forEach(template => {
                    bpVersionObj.functionalAreaList.push(template);
                      });
                    loaderDialogRefFA.close();
                });
             
               });
              } 
            },
            error => {
              this.toastrService.error('got error' + error.error.message);
              loaderDialogRef.close();
            });
          if (loaderMessage) {
            loaderDialogRef.close();
          }
        }, error => {
          this.toastrService.error('got error' + error.error.message);
          loaderDialogRef.close();
        }
      );
    //}
  }

  openDialogToAddVersion(versionName: string) {
    let dialogRef: any;
    if (this.isStateStandard) {
      dialogRef = this.dialog.open(AddBPSSSVersionComponent, {
        width: '65%',
        height: '85%',
        data: {
          project: this.bestPracticeObject,
          bpVersionName: versionName,
        }
      });
    } else {
      dialogRef = this.dialog.open(AddBPVersionComponent, {
        width: '65%',
        height: '85%',
        data: {
          project: this.bestPracticeObject,
          bpVersionName: versionName,
        }
      });

    }

    dialogRef.afterClosed().subscribe(result => {
      if(result!=Constants.POPUP_CANCEL)
      this.getBestPracticeInformation('Updating Best Practice Information.');
    });
  }

  editVersion(versionName: string) {
    this.openDialogToAddVersion(versionName);
  }

  cloneVersion(bestPracticeVersion: BestPracticeVersionObject) {
    let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
      width: '300px',
      height: '150px',
      data: { message: 'Cloning Version...' }
    });
    this.bestPracticeService.cloneBestPracticeVersion(bestPracticeVersion)
      .subscribe(() => {
        loaderDialogRef.close();
        this.getBestPracticeInformation('Fetching updated Best Practice Information.');
      });

  }

  getTemplate(versionId: string, functionalAreaId: string) {
    if (this.isStateStandard) {
      this.router.navigate(['bestpractice/' + this.bestPracticeObject.bestPracticeName + '/statestandard/version/' + versionId + '/functionalAreas/' + functionalAreaId + '/false' + '/true']);
    } else {
      this.router.navigate(['bestpractice/' + this.bestPracticeObject.bestPracticeName + '/' + this.bestPracticeObject.platform.platformCode + '/version/' + versionId + '/functionalAreas/' + functionalAreaId + '/false' + '/true']);
    }

  }

  newBestPractice() {
    if (!this.jsonEqual(this.bestPracticeObjectCopy, this.bestPracticeObject)) {
      if (confirm("You have unsaved data on this page. Click 'OK' to continue , or  'Cancel' to stay on this page")) {
        this.router.navigateByUrl('bestpractice/create');
      }
    }
    else {
      this.router.navigateByUrl('bestpractice/create');
    }
  }

  gotoBPMaintenance() {
    if (!this.jsonEqual(this.bestPracticeObjectCopy, this.bestPracticeObject)) {
      if (confirm("You have unsaved data on this page. Click 'OK' to continue , or  'Cancel' to stay on this page")) {
        this.router.navigateByUrl('bestpractice');
      }
    }
    else {
      this.router.navigateByUrl('bestpractice');
    }
  }

  jsonEqual(a, b) {
    return JSON.stringify(a) === JSON.stringify(b);
  }

  templateContentClass(isFirst: any, isLast: any) {
    let templateContentClass = 'pt-2 pb-2';
    if (isFirst && !isLast) {
      templateContentClass = 'pb-2';
    } else if (!isFirst && isLast) {
      templateContentClass = 'pt-2';
    } else if (isFirst && isLast) {
      templateContentClass = '';
    }
    return templateContentClass;
  }

  getBestPracticeDetailsByName(bestPracticeName: string, platformCode: string, permissionCheckNeeded: boolean): Observable<BestPracticeObject> {
    let bestPracticeObject: Observable<BestPracticeObject>;
    if (this.isStateStandard) {
      bestPracticeObject = this.bestPracticeService
        .getSSSBPByBestPracticeName(bestPracticeName, permissionCheckNeeded);
    } else {
      bestPracticeObject = this.bestPracticeService
        .getByBestPracticeNameAndPlatform(bestPracticeName, platformCode, permissionCheckNeeded);
    }
    return bestPracticeObject;
  }

  save(bestPracticeObject: BestPracticeObject){
    if (!this.jsonEqual(this.bestPracticeObjectCopy, this.bestPracticeObject)) {
    this.dialogRef=this.dialog.open(LoaderDialogueComponent, {
      width: '300px',
      height: '150px',
      data: { message: 'Updating Best Practice Name...' }
    });
    this.bestPracticeService.checkAndUpdateBPName(bestPracticeObject)
      .subscribe(genericResponse => {
        this.dialogRef.close();
        if(genericResponse != null && genericResponse.resultCode!=Constants.CDK_200){
          
          this.toastrService.info(genericResponse.resultDescription);
        }else{
          this.bestPracticeObjectCopy = Object.assign({}, this.bestPracticeObject);
          if(bestPracticeObject.isSSS===1){
            this.router.navigate(['bestPractice/stateStandard/' +  bestPracticeObject.bestPracticeName+'/true'])
          } else {
            this.router.navigate(['bestpractice/getOne/' +   bestPracticeObject.bestPracticeName + '/' +  bestPracticeObject.platform.platformCode]);
          }
        } 
      },
        () => {
          
          this.dialogRef.close();
          this.toastrService.error('Error while creating Best Practice');

        });
  }
  }

}