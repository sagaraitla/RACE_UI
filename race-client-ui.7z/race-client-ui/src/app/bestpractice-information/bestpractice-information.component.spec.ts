import { CdkTableModule } from '@angular/cdk/table';
import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatDividerModule, MatFormFieldModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatSidenavModule, MatStepperModule, MatTableModule } from '@angular/material';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router, RouterModule } from '@angular/router';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { Observable, of } from 'rxjs';
import { AddBPSSSVersionComponent } from '../add-bp-sss-version/add-bp-sss-version-dialog.component';
import { AddBPVersionComponent } from '../add-bp-version/add-bp-version-dialog.component';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { BestPracticeObject } from '../model/bestpractice-object';
import { BestPracticeVersionObject } from '../model/bestpractice-version-object';
import { GenericResponse } from '../model/generic-response';
import { AuthService } from '../services/auth-service';
import { BestPracticeService } from '../services/bestpractice-service';
import { LaunchDarklyService } from '../services/launchdarkly-service';
import { BestPracticeInformationComponent } from './bestpractice-information.component';

describe('BestPracticeInformationComponent', () => {

    let component : BestPracticeInformationComponent;
    let fixture: ComponentFixture<BestPracticeInformationComponent>;
    let bestPracticeService: BestPracticeService;
    let launchDarklyService : LaunchDarklyService;
    let authService: AuthService;
    let routerStub: Router;
    let toastrService : ToastrService;

    beforeEach(async(() => {

        TestBed.configureTestingModule({
          imports: [
            MatProgressSpinnerModule,
            MatMenuModule,
            MatDividerModule,
            FormsModule,
            MatCardModule,
            FormsModule,
            MatFormFieldModule,
            MatInputModule,
            CdkTableModule,
            MatMenuModule,
            MatTableModule,
            MatPaginatorModule,
            MatDialogModule,
            HttpClientTestingModule,
            ToastrModule.forRoot(),
            RouterModule.forRoot([]),
            NoopAnimationsModule,
            ReactiveFormsModule,
            CommonModule,
            MatSelectModule,
            MatRadioModule,
            ReactiveFormsModule,
            MatCheckboxModule,
            MatStepperModule,
            MatSidenavModule],
          declarations: [BestPracticeInformationComponent,LoaderDialogueComponent,AddBPSSSVersionComponent,AddBPVersionComponent],
          providers:[
            BestPracticeService,
            LaunchDarklyService,
            AuthService,
           ToastrService
          ]
        }).overrideModule(BrowserDynamicTestingModule,
           { set: { entryComponents: [LoaderDialogueComponent,AddBPSSSVersionComponent,AddBPVersionComponent]}});

            authService = TestBed.get(AuthService);
            bestPracticeService = TestBed.get(BestPracticeService);
            launchDarklyService = TestBed.get(LaunchDarklyService);
            routerStub  = TestBed.get(Router);
            toastrService  = TestBed.get(ToastrService);

            fixture = TestBed.createComponent(BestPracticeInformationComponent);
            component = fixture.componentInstance;
      }));

      const generic_response : GenericResponse = {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [
        ],
          "executionTime" : null
      }
      
      const bpVersionList: BestPracticeVersionObject[]=[
        {
            id : '123',
            recordType : 'Best Practice version',
            versionName : '1.1',
            active : true,
            objectType : 'test',
            functionalAreaList : [],
            propagationStarted:false
        } 
      ]
    const bestPracticeVersion: BestPracticeVersionObject={
        id : '123',
        recordType : 'Best Practice version',
        versionName : '1.1',
        active : true,
        objectType : 'test',
        functionalAreaList : [],
        propagationStarted:false
    }  

    const platforms:any=[
        {
            platformName: "FLEX",
            platformCode :"FLEX"
        }
    ]
    const bestPracticeObject : BestPracticeObject={
        isBestPractice : 1,
        bestPracticeName : 'testBP',
        platform : platforms,
        version : 1.1,
        failed : false,
        isSSS : 1,
        id:'123',
        recordType:'BestPractice'
    }

    const functionalAreaOfBPVersion:any[]=[
        {
            "functionalAreaName": "FA_color",
            "functionalAreaType": "BestPracticeFunctionalArea",
            "oemName": null,
            "clientSignoffDate": null,
            "selected": false,
            "status": "Work in Progress",
            "platforms": [
              {
                "id": null,
                "platformName": "FLEX",
                "platformCode": "flex",
                "selected": true
              }
            ],
            "vic": null,
            "secondaryVic": null,
            "clientFunctionalAreaUser": null,
            "version": 0,
            "isFailed": null,
            "inProcess": false,
            "productCode": "PTS",
            "productVersion": "check",
            "masterFAId": "acd18aa6-8eed-456e-b266-c7e3e095c467",
            "bpId": "266a92e4-6e58-421b-a93c-fdbb389090c5",
            "bpVersionId": null,
            "bpTemplateId": null,
            "isDealerApproved": false,
            "stateStandardId": null,
            "stateStandardName": null,
            "stateStandardVersionRecordType": null,
            "stateStandardVersionName": null,
            "copyRowData": false,
            "showValidateOrTransferButton": false,
            "showProcessValidationResultsButton": true,
            "createdDate": null,
            "lastUpdatedDate": null,
            "createdBy": null,
            "updatedBy": null,
            "incorporateBpChanges": false,
            "locked": false,
            "id": "3812951d-983c-4894-b26a-c84b00bb5bec",
            "recordType": "edda3022-7bc5-4844-9cf7-ea772d6533ca"
          }
    ]
    
      
    it('should create Create Best Practice Component',()=>{
        expect(component).toBeTruthy();
      });

    it('test ngOnInit',()=>{
        let data:{}
       spyOn(authService, 'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data))
       spyOn(authService, 'isAuthorised').and.returnValue(false)
       fixture.detectChanges;
       component.ngOnInit();
       expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(1);
    });


    it('test save best practice',()=>{
        spyOn(bestPracticeService,'checkAndUpdateBPName').and.returnValue(Observable.of(generic_response));
        spyOn(routerStub, 'navigate');
        component.save(bestPracticeObject);
        expect(bestPracticeService.checkAndUpdateBPName).toHaveBeenCalledTimes(1);
        expect(routerStub.navigate).toHaveBeenCalledWith(['bestPractice/stateStandard/testBP/true']);
    });

    it('test save',()=>{
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
         dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(bestPracticeService,'checkAndUpdateBPName').and.returnValue(Observable.throwError('error'));
       
        const bestPracticeObject : BestPracticeObject={
            isBestPractice : 1,
            bestPracticeName : 'testBP',
            platform : platforms,
            version : 1.1,
            failed : false,
            isSSS : 1,
            id:'123',
            recordType:'BestPractice'
        }
        component.bestPracticeObject = bestPracticeObject

        const bestPracticeObject1 : BestPracticeObject={
            isBestPractice : 1,
            bestPracticeName : 'testBP1',
            platform : platforms,
            version : 1.1,
            failed : false,
            isSSS : 1,
            id:'123',
            recordType:'BestPractice'
        }
        component.bestPracticeObjectCopy = bestPracticeObject1
        component.save(bestPracticeObject);
        expect(component['toastrService'].previousToastMessage).toBe('Error while creating Best Practice');
    });


    it('test save if generic response code is not 200',()=>{

        const generic_response1 : GenericResponse = {
            "resultCode": "CDK_201",
            "resultDescription": "OK",
            "resultObj": [
            ],
              "executionTime" : null
          }
          
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
         dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(bestPracticeService,'checkAndUpdateBPName').and.returnValue(Observable.of(generic_response1));
       
        const bestPracticeObject : BestPracticeObject={
            isBestPractice : 1,
            bestPracticeName : 'testBP',
            platform : platforms,
            version : 1.1,
            failed : false,
            isSSS : 1,
            id:'123',
            recordType:'BestPractice'
        }
        component.bestPracticeObject = bestPracticeObject

        const bestPracticeObject1 : BestPracticeObject={
            isBestPractice : 1,
            bestPracticeName : 'testBP1',
            platform : platforms,
            version : 1.1,
            failed : false,
            isSSS : 1,
            id:'123',
            recordType:'BestPractice'
        }
        component.bestPracticeObjectCopy = bestPracticeObject1
        component.save(bestPracticeObject);
        expect(component['toastrService'].previousToastMessage).toBe('OK');
    });

    it('test save if isSSS is not 1',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
         dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(bestPracticeService,'checkAndUpdateBPName').and.returnValue(Observable.of(generic_response));
       
        const platforms1:any={
                platformName: "DRIVE",
                platformCode :"DRIVE"
        }
        
        const bestPracticeObject : BestPracticeObject={
            isBestPractice : 1,
            bestPracticeName : 'testBP',
            platform : platforms1,
            version : 1.1,
            failed : false,
            isSSS : 1,
            id:'123',
            recordType:'BestPractice'
        }
        component.bestPracticeObject = bestPracticeObject

        const bestPracticeObject1 : BestPracticeObject={
            isBestPractice : 1,
            bestPracticeName : 'testBP1',
            platform : platforms1,
            version : 1.1,
            failed : false,
            isSSS : 1,
            id:'123',
            recordType:'BestPractice'
        }
        
        component.bestPracticeObjectCopy = bestPracticeObject1
         
       
        const saveBestPracticeObject : BestPracticeObject={
            isBestPractice : 1,
            bestPracticeName : 'testBP',
            platform : platforms1,
            version : 1.1,
            failed : false,
            isSSS : 0,
            id:'123',
            recordType:'BestPractice'
        }
        component.bestPracticeObject = bestPracticeObject
        spyOn(routerStub, 'navigate');
        component.save(saveBestPracticeObject);
        expect(routerStub.navigate).toHaveBeenCalledWith(['bestpractice/getOne/testBP/DRIVE']);
    });

    it('test clone version',()=>{
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
         dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(component,'getBestPracticeInformation');
        spyOn(bestPracticeService,'cloneBestPracticeVersion').and.returnValue(Observable.of({}));
        component.cloneVersion(bestPracticeVersion);
    });
    
    it('test getBestPracticeInformation',()=>{

        spyOn(component,'getBestPracticeDetailsByName').and.returnValue(Observable.of(bestPracticeObject))
        spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.of(bpVersionList))
        spyOn(bestPracticeService,'getFunctionalAreasOfBpVersion').and.returnValue(Observable.of(functionalAreaOfBPVersion));
        component.getBestPracticeInformation('test');
        expect(bestPracticeService.getVersionsByBestPracticeId).toHaveBeenCalledTimes(1);
       expect(bestPracticeService.getFunctionalAreasOfBpVersion).toHaveBeenCalledTimes(1);

    });
    

   it('test getBestPracticeInformation versions by BP Id throw error',()=>{

        let error:any={
            error:{
             message:'API Error'
            }
        }
         let dialogSpy: jasmine.Spy;
         let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
         dialogRefSpyObj.componentInstance = { body: '' };
         dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(component,'getBestPracticeDetailsByName').and.returnValue(Observable.of(bestPracticeObject))
        spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.throwError(error))
        spyOn(bestPracticeService,'getFunctionalAreasOfBpVersion').and.returnValue(Observable.of(functionalAreaOfBPVersion));
        component.getBestPracticeInformation('test');
        expect(bestPracticeService.getVersionsByBestPracticeId).toHaveBeenCalledTimes(1);
    });


    
   it('test getBestPracticeDetailsByName versions by BP Id throw error',()=>{

    let error:any={
        error:{
          message:'API Error'
        }
      }
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    spyOn(component,'getBestPracticeDetailsByName').and.returnValue(Observable.throwError(error))
    component.getBestPracticeInformation('test');
    });

   it('test getBestPracticeDetailsByName',()=>{

    component.isStateStandard = true;
    spyOn(bestPracticeService,'getSSSBPByBestPracticeName').and.returnValue(Observable.of({}))
    component.getBestPracticeDetailsByName('testBP','DRVE',false);
   });


    it('test openDialogToAddVersion',()=>{
        component.bestPracticeObject = bestPracticeObject;
        component.isStateStandard = true;
        component.openDialogToAddVersion("v1");
    });

    it('test openDialogToAddVersion for OEM BP',()=>{
        component.bestPracticeObject = bestPracticeObject;
        component.isStateStandard = false;
        component.openDialogToAddVersion("v1");
    });

    it('test openDialogToAddVersion after closed',()=>{

        let result:string = 'POPUP_CANCEL1';
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(result), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        spyOn(component,'getBestPracticeInformation')
        component.bestPracticeObject = bestPracticeObject;
        component.isStateStandard = false;
        component.openDialogToAddVersion("v1");
    });

    it('test templateContentClass',()=>{
        let result = component.templateContentClass(true,true);
        expect(result).toEqual('');
        let result1 = component.templateContentClass(false,true);
        expect(result1).toEqual('pt-2');
        let result2 = component.templateContentClass(true,false);
        expect(result2).toEqual('pb-2');
    });

    it('test getTemplate for SSS',()=>{
        component.isStateStandard = true;
        component.bestPracticeObject.bestPracticeName = "newBP";
        spyOn(routerStub, 'navigate');
        component.getTemplate("123","6eadd998-944b-44d9-a973-7e9159c26db7");
        expect(routerStub.navigate).
        toHaveBeenCalledWith(['bestpractice/newBP/statestandard/version/123/functionalAreas/6eadd998-944b-44d9-a973-7e9159c26db7/false/true']);
    });

    it('test getTemplate',()=>{
        component.isStateStandard = false;
        component.bestPracticeObject.bestPracticeName = "newBP";
        component.bestPracticeObject.platform = platforms;
        spyOn(routerStub, 'navigate');
        component.getTemplate("123","6eadd998-944b-44d9-a973-7e9159c26db7");
        expect(routerStub.navigate).
        toHaveBeenCalledWith(['bestpractice/newBP/'+ component.bestPracticeObject.platform.platformCode+'/version/123/functionalAreas/6eadd998-944b-44d9-a973-7e9159c26db7/false/true']);
    });

    it('test jsonEqual',()=>{
        let result = component.jsonEqual("testBP","test");
        expect(result).toBeFalsy();
    })

   it('test gotoBPMaintenance',()=>{
        const platforms1:any={
            platformName: "DRIVE",
            platformCode :"DRIVE"
    }
        const bestPracticeObject : BestPracticeObject={
            isBestPractice : 1,
            bestPracticeName : 'testBP',
            platform : platforms1,
            version : 1.1,
            failed : false,
            isSSS : 1,
            id:'123',
            recordType:'BestPractice'
        }
        component.bestPracticeObject = bestPracticeObject

        const bestPracticeObject1 : BestPracticeObject={
            isBestPractice : 1,
            bestPracticeName : 'testBP1',
            platform : platforms1,
            version : 1.1,
            failed : false,
            isSSS : 1,
            id:'123',
            recordType:'BestPractice'
        }
        
       component.bestPracticeObjectCopy = bestPracticeObject1
       spyOn(window, 'confirm').and.returnValue(true);
       component.gotoBPMaintenance();
    })

    it('test gotoBPMaintenance if two BP obj are equal',()=>{
        const platforms1:any={
            platformName: "DRIVE",
            platformCode :"DRIVE"
    }
        
        const bestPracticeObject : BestPracticeObject={
            isBestPractice : 1,
            bestPracticeName : 'testBP1',
            platform : platforms1,
            version : 1.1,
            failed : false,
            isSSS : 1,
            id:'123',
            recordType:'BestPractice'
        }
        component.bestPracticeObject = bestPracticeObject

        const bestPracticeObject1 : BestPracticeObject={
            isBestPractice : 1,
            bestPracticeName : 'testBP1',
            platform : platforms1,
            version : 1.1,
            failed : false,
            isSSS : 1,
            id:'123',
            recordType:'BestPractice'
        }
        
       component.bestPracticeObjectCopy = bestPracticeObject1
       spyOn(window, 'confirm').and.returnValue(true);
       component.gotoBPMaintenance();
    })

    it('test newBestPractice',()=>{
        const platforms1:any={
            platformName: "DRIVE",
            platformCode :"DRIVE"
    }
        const bestPracticeObject : BestPracticeObject={
            isBestPractice : 1,
            bestPracticeName : 'testBP',
            platform : platforms1,
            version : 1.1,
            failed : false,
            isSSS : 1,
            id:'123',
            recordType:'BestPractice'
        }
        component.bestPracticeObject = bestPracticeObject

        const bestPracticeObject1 : BestPracticeObject={
            isBestPractice : 1,
            bestPracticeName : 'testBP1',
            platform : platforms1,
            version : 1.1,
            failed : false,
            isSSS : 1,
            id:'123',
            recordType:'BestPractice'
        }
        
       component.bestPracticeObjectCopy = bestPracticeObject1
       spyOn(window, 'confirm').and.returnValue(true);
       component.newBestPractice();
    });

    it('test newBestPractice if two BP obj are equal ',()=>{
        const platforms1:any={
            platformName: "DRIVE",
            platformCode :"DRIVE"
    }
        const bestPracticeObject : BestPracticeObject={
            isBestPractice : 1,
            bestPracticeName : 'testBP1',
            platform : platforms1,
            version : 1.1,
            failed : false,
            isSSS : 1,
            id:'123',
            recordType:'BestPractice'
        }
        component.bestPracticeObject = bestPracticeObject

        const bestPracticeObject1 : BestPracticeObject={
            isBestPractice : 1,
            bestPracticeName : 'testBP1',
            platform : platforms1,
            version : 1.1,
            failed : false,
            isSSS : 1,
            id:'123',
            recordType:'BestPractice'
        }
        
       component.bestPracticeObjectCopy = bestPracticeObject1
       spyOn(window, 'confirm').and.returnValue(true);
       component.newBestPractice();
    });

    it('test editVersion',()=>{
        spyOn(component,'openDialogToAddVersion')
        component.editVersion('2021');
    });
});