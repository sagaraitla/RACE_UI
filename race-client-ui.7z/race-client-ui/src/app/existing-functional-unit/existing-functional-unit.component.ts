import { Component, OnInit, ViewChild } from '@angular/core';
import { Router} from '@angular/router';
import {MatDialog,MatDialogRef} from '@angular/material';
import {NewFunctionalUnitComponent} from '../new-functional-unit/new-functional-unit.component';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { MasterFunctionalUnit } from '../model/master-functional-unit';
import { AuthService } from '../services/auth-service';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { MasterFunctionalUnitService } from '../services/master-functional-unit-service';
import { Constants } from '../constant/constants';
import { ToastrService } from 'ngx-toastr';



@Component({
  selector: 'app-existing-functional-unit',
  templateUrl: './existing-functional-unit.component.html',
  styleUrls: ['./existing-functional-unit.component.css']
})
export class ExistingFunctionalUnitComponent implements OnInit {
	createFunctionalUnitPermission : boolean = false;
    deleteFunctionalUnitPermission : boolean = false;
	dataSource : any;
    filter : any;
	displayedColumns = ['functionalUnitName','functionalUnitDescription', 'productCode','createdDate','lastUpdatedDate','actions'];
	functionalUnit : MasterFunctionalUnit;
	@ViewChild(MatPaginator,{static: false}) paginator: MatPaginator;
    @ViewChild(MatSort,{static: false}) sort: MatSort;
    
    constructor(private router:Router, private dialog:MatDialog, private authService: AuthService,
    		private functionalUnitService: MasterFunctionalUnitService,private toastrService : ToastrService){
    }

	ngOnInit() {
		let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
             width: '300px',
             height: '150px',
             data: { message: 'Fetching Functional Units ..' }
        });
    this.authService.fetchLoggedInUserAndPermissions().subscribe((data: any) => {
        this.createFunctionalUnitPermission = this.authService.isAuthorised('DOT_SCREEN_CREATE');
        this.deleteFunctionalUnitPermission = this.authService.isAuthorised('DOT_SCREEN_DELETE');
        
        this.functionalUnitService.fetchMasterFunctionalUnitList()
        .subscribe(functionalUnits => {
            this.dataSource=new MatTableDataSource<MasterFunctionalUnit>(functionalUnits);
            this.dataSource.data.forEach(element => {
                for (const key in element) {
                  if (!element[key] || element[key] === null || element[key] === undefined) {
                    element[key] = '';
                  }
                }
              });
            this.dataSource.filterPredicate = function(data, filter: string): boolean {
                return (data.functionalUnitName && data.functionalUnitName.toLowerCase().includes(filter))
                || (data.description && data.description.toLowerCase().includes(filter))
                || (data.productCode && data.productCode.toLowerCase().includes(filter))
                || (data.createdDate && data.createdDate.toString().includes(filter))
                || (data.lastUpdatedDate && data.lastUpdatedDate.toString().includes(filter));
            };
        	this.dataSource.sortingDataAccessor = (item, property) => {
                switch(property) {
                  case 'functionalUnitName': return item.functionalUnitName ? item.functionalUnitName.toLowerCase(): item;
                  case 'functionalUnitDescription': return item.description ? item.description.toLowerCase() : item;
                  case 'productCode': return item.productCode ? item.productCode.toLowerCase() : item;
                  default: return item[property];
                }
            }; 
    		this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
            if (this.filter) {
                this.applyFilter(this.filter);
            }
            loaderDialogRef.close();
        }, error => {
        	loaderDialogRef.close();
        });
    });
	}
	
	openDialogToCreateOrEditFunctionalUnit(functionalUnit:MasterFunctionalUnit){
		let isEdit = functionalUnit != null;
		let data = {edit : isEdit};
		if(isEdit) {
            data['functionalUnit'] = functionalUnit;
            if(functionalUnit.gridOptionsModel.rowData === undefined || functionalUnit.gridOptionsModel.rowData === null ){
                functionalUnit.gridOptionsModel.rowData = functionalUnit.gridOptionsModel.columnDefs;
            }
        }
		let dialogRef=this.dialog.open(NewFunctionalUnitComponent,{
			width :'80%',
			height :'90%',
			data : data
		});
		  
		dialogRef.afterClosed().subscribe(result=>{
			this.ngOnInit();
		});
    }
    	applyFilter(filterValue: string) {
        filterValue = filterValue.trim(); 
        filterValue = filterValue.toLowerCase(); 
        this.dataSource.filter = filterValue;
    }
	
	gotoDashboard() {
       this.router.navigateByUrl('dashboard');
    }
	
    deleteFunctionalUnit(functionalUnit: MasterFunctionalUnit) {

        this.functionalUnitService.getMasterFunctionalUnitById(functionalUnit.id).subscribe(functionalUnit =>{
            if(functionalUnit != null && functionalUnit != undefined && !functionalUnit.propagationStarted){
                let confirmDialogRef = this.dialog.open(ConfirmDialogComponent, {
                    width: '300px',
                    height: '160px',
                    data: { message: 'Are you sure you want to delete this Functional Unit ?' }
                });
                confirmDialogRef.afterClosed().subscribe(result => {
                    if (result) {
                        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
                            width: '300px',
                            height: '150px',
                            data: { message: 'Deleting Functional Unit..' }
                        });
                        this.functionalUnitService.deleteMasterFunctionalUnit(functionalUnit).subscribe((data: any) => {
                            loaderDialogRef.close();
                            this.ngOnInit();
                        });
                    }
                });
            }else{
               this.toastrService.error('Functional Unit '+this.functionalUnit.functionalUnitName+' Change Propagation is underway. No modifications can take place at this time. Please try later');
            }
        }); 
    }
   
}
