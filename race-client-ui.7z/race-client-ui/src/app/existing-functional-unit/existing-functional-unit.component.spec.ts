import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { AuthService } from "../services/auth-service";
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatFormFieldModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatTableDataSource, MatTableModule } from "@angular/material";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CdkTableModule } from "@angular/cdk/table";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { CommonModule } from "@angular/common";
import { Router } from "@angular/router";
import { Observable } from "rxjs/Rx";
import { of } from "rxjs";
import { ExistingFunctionalUnitComponent } from "./existing-functional-unit.component";
import { MasterFunctionalUnitService } from "../services/master-functional-unit-service";
import { ConfirmDialogComponent } from "../confirm-dialog/confirm-dialog.component";
import { MasterFunctionalUnit } from "../model/master-functional-unit";

describe('ExistingFunctionalUnitComponent', () => {

    let component : ExistingFunctionalUnitComponent;
    let fixture: ComponentFixture<ExistingFunctionalUnitComponent>;
    let authService: AuthService;
    let masterFunctionalUnitService :MasterFunctionalUnitService;
    let router : Router;
    let dataSource :any;
    let filter:any;

    beforeEach(async(() => {
        let mockRouter = {
            navigate: jasmine.createSpy('navigateByUrl')
        } 
        TestBed.configureTestingModule({
            imports: [
                MatCardModule,
                FormsModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatInputModule,
                MatTableModule,
                MatPaginatorModule,
                MatDialogModule,
                HttpClientTestingModule,
                ToastrModule.forRoot(),
                NoopAnimationsModule,
                MatProgressSpinnerModule ,
                ReactiveFormsModule,
                CommonModule,
                MatSelectModule,
                MatRadioModule,
                MatCheckboxModule,
                MatMenuModule,
                ReactiveFormsModule
            ],
            declarations: [ExistingFunctionalUnitComponent,LoaderDialogueComponent,ConfirmDialogComponent],
            providers:[
                MasterFunctionalUnitService,
                 AuthService,
                 ToastrService,
                 { provide: Router, useValue: mockRouter }
               ]
        }).overrideModule(BrowserDynamicTestingModule,{ set: { entryComponents: [LoaderDialogueComponent,ConfirmDialogComponent]}});

        authService = TestBed.get(AuthService);
        masterFunctionalUnitService = TestBed.get(MasterFunctionalUnitService)
        
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ExistingFunctionalUnitComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    const master_functional_unit:any = {
        "functionalUnitType": "MasterFunctionalUnit",
        "functionalUnitName": "Departments",
        "gridOptionsModel": {
            "animatedRows": false,
            "rowSelection": "multiple",
            "columnDefs": [
            ],
            "rowData":null
          },
        "description": "Departments",
        "version": 0,
        "productCode": "ACCT",
        "gomModified": false,
        "propagationStarted": false,
        "propagationStatus": 0,
        "id": "6c44e2da-3bed-4773-87c0-ed257c861943",
        "recordType": "FunctionalUnitInfo"
    }

    const list_of_master_functional_unit_response: MasterFunctionalUnit[] =[
        {
            "functionalUnitType": "MasterFunctionalUnit",
            "functionalUnitName": "BP_Tree_Check_PropagationTQAIG",
            "gridOptionsModel": {
              "animatedRows": false,
              "rowSelection": "multiple",
              "columnDefs": [
              ],
              "rowData":null
            },
            "description": "BP_Tree_Check_Propagation",
            "version": 0,
            "productCode": "PTS",
            "createdDate": null,
            "lastUpdatedDate": null,
            "propagationStarted": false,
            "id": "ad5b9464-5839-4c84-aac3-c66f2398f6ad",
            "recordType": "FunctionalUnitInfo"
          }
    ]  
  

    it('should create ExistingFunctionalUnitComponent ', async(() => {

        let filter:string = 'FUTestToday';
        let data:{
  
        }
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  
          spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data))
          spyOn(authService,'isAuthorised').and.returnValue(Observable.of(false));
          spyOn(masterFunctionalUnitService,'fetchMasterFunctionalUnitList').and.returnValue(Observable.of(list_of_master_functional_unit_response));
          component.ngOnInit();
          expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(1);
          expect(authService.isAuthorised).toHaveBeenCalledTimes(2);
          expect(component).toBeTruthy();
        }));  


    it('test deleteFunctionalArea',()=>{

        spyOn(masterFunctionalUnitService,'getMasterFunctionalUnitById').and.returnValue(Observable.of(master_functional_unit));
        spyOn(masterFunctionalUnitService,'deleteMasterFunctionalUnit').and.returnValue(Observable.of({}));

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        component.deleteFunctionalUnit(master_functional_unit);
      });

  
      it('test openDialogToCreateOrEditFunctionalUnit',()=>{
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        component.openDialogToCreateOrEditFunctionalUnit(master_functional_unit);
      });

      it('test applyFilter',()=>{
        component.dataSource= new MatTableDataSource<MasterFunctionalUnit>(list_of_master_functional_unit_response); 
        component.applyFilter("Test");
        expect(component.dataSource.filter).toEqual('test');
 
       });


});