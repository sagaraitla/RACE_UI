import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatSort, MatDialogRef, MAT_DIALOG_DATA, MatDialog, MatSnackBar, MatTableDataSource } from '@angular/material';
import { AuditLogsObject } from '../model/audit-logs-object';
import { AuditLogService } from '../services/audit-log-service';
import { AuditLogDialogComponent } from '../audit-log-dialog/audit-log-dialog.component';
import { AuthService } from '../services/auth-service';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { FieldInfoObject } from '../model/fields-info-object';
import { Constants } from '../constant/constants';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';

@Component({
  selector: 'app-audit-log-dialog-details',
  templateUrl: './audit-log-dialog-details.component.html',
  styleUrls: ['./audit-log-dialog-details.component.css']
})
export class AuditLogDialogDetailsComponent implements OnInit {

  @ViewChild(MatSort,{static: false}) sort: MatSort;
        
  auditLog : AuditLogsObject;
  dataSource : any;

  displayedColumns = ['fieldName','previousValue','currentValue','status'];
  displayName:string;
  constructor(private auditLogService: AuditLogService, private dialogRef: MatDialogRef<AuditLogDialogComponent>, private authService: AuthService,
          private _formBuilder: FormBuilder, @Inject(MAT_DIALOG_DATA) private data: any,  private dialog: MatDialog,
          private snackBar: MatSnackBar, private router: Router) {
      dialogRef.disableClose = true;
      this.auditLog = JSON.parse(JSON.stringify(this.data.auditLog));
      this.displayName = this.data.displayName;

  }

  ngOnInit() {
    let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
      width: '300px',
      height: '150px',
      data: { message:  this.auditLog.event +' Results Info...' }
      });
      this.auditLogService.getAuditlogFieldsInfoById(this.auditLog.id).subscribe(genericResponse => {
        if(genericResponse != null && genericResponse.resultCode===Constants.CDK_200){
          this.dataSource =  new MatTableDataSource<FieldInfoObject>(genericResponse.resultObj);   
          this.dataSource.sort = this.sort;
          loaderDialogRef.close();
        } else {
          loaderDialogRef.close();
        }
      },error => {
        loaderDialogRef.close();
      }); 
  }

  closePopup() {
      this.dialogRef.close();
  };
  
  iconColor(status: string) {
    status = status != null && status != '' ? status : 'Not Modified';
    let style = { 'color': 'grey' };
    if (status === 'Modified' || status === 'modified' || status === 'Added/Modified') {
      style = { 'color': 'blue' };
    }
    if (status === 'Deleted' || status === 'deleted') {
      style = { 'color': 'red' };
    }
    if (status === 'Added' || status === 'added') {
      style = { 'color': 'green' };
    }
    return style;
  }

}
