import { HttpClientTestingModule } from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { ReactiveFormsModule } from "@angular/forms";
import { MatDialog, MatDialogModule, MatDialogRef, MatFormFieldModule, MatInputModule, MatProgressSpinnerModule, MatSelectModule, MatStepperModule, MAT_DIALOG_DATA } from "@angular/material";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { GridApi, GridOptions } from "ag-grid";
import { AgGridModule } from "ag-grid-angular";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { Observable, of } from "rxjs";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { MasterFunctionalUnit } from "../model/master-functional-unit";
import { AuthService } from "../services/auth-service";
import { FunctionalUnitService } from "../services/functional-unit-service";
import { MasterFunctionalUnitService } from "../services/master-functional-unit-service";
import { ServerCommunicationService } from "../services/server-communication-service";
import { NewFunctionalUnitComponent } from "./new-functional-unit.component";

describe('NewFunctionalUnitComponent',()=>{

    let component : NewFunctionalUnitComponent;
    let fixture : ComponentFixture<NewFunctionalUnitComponent>;
    let masterFunctionalUnitService: MasterFunctionalUnitService;
    let serverCommService: jasmine.SpyObj<ServerCommunicationService>;
    let gridApi:any;
    let gridColumnApi:any;
    let gridOptions:any;

      const testUrl  = 'dashboard';
      beforeEach(async() =>{

        const dialogMock = {
          close: () => { }
      };
      let data= {
        edit:true,
        auditLogVT:{
          event:"Transfer DMS Failed"
          },
        displayName:"Audit_VT_Log",
        functionalUnit:{
          "functionalUnitName": "check_Dropdown",
          "productCode": "PTS",
          "gridOptionsModel": {
            "rowData": [
              {
                  "headerName": "fuel",
                  "field": "fuel",
                  "dataType": "DROPDOWN",
                  "required": "true",
                  "editable": "true",
                  "editableByCDKOnly": false,
                  "defaultValue": "",
                  "clientScreen": "",
                  "validationRule": "Petrol,Disel,Oil",
                  "dataLength": 0,
                  "cellEditor": "agSelectCellEditor",
                  "cellEditorParams": {
                      "values": [
                          "Petrol",
                          "Disel",
                          "Oil"
                      ]
                  }
              }
          ]
          },

        }
      }

        let mockRouter = {
            navigate: jasmine.createSpy('navigateByUrl')
        } 
        const serverCommunicationServiceSpy = jasmine.createSpyObj('ServerCommunicationService', ['get_fileDownload','flex_post','post_fileDownload','put','post']);
        const gridApiSpy = jasmine.createSpyObj('GridApi',['sizeColumnsToFit','getSelectedRows']);
        const gridColumnApiSpy = jasmine.createSpyObj('gridColumnApi',['getAllColumns']);
        TestBed.configureTestingModule({
            imports:[
                MatFormFieldModule,
                MatInputModule,
                MatSelectModule,
                MatStepperModule,
                AgGridModule.withComponents([]),
                ToastrModule.forRoot(),
                ReactiveFormsModule,
                MatProgressSpinnerModule,
                MatDialogModule,
                HttpClientTestingModule,
                BrowserAnimationsModule
            ],
            declarations:[NewFunctionalUnitComponent, LoaderDialogueComponent],
            providers:[
                MasterFunctionalUnitService,
                ToastrService, 
                AuthService,
                {provide:ServerCommunicationService,useValue:serverCommunicationServiceSpy},
                { provide: Router, useValue: {url:testUrl} },
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: dialogMock},
                {provide:GridApi,useValue:gridApiSpy},
                {provide:gridColumnApi,useValue:gridColumnApiSpy}
            ]
      }).overrideModule(BrowserDynamicTestingModule,
        { set: { entryComponents: [LoaderDialogueComponent]}});
        serverCommService = TestBed.get(ServerCommunicationService) as jasmine.SpyObj<ServerCommunicationService>;
          gridApi = TestBed.get(GridApi) as jasmine.SpyObj<GridApi>;  
          gridColumnApi = TestBed.get(gridColumnApi);
      });

      beforeEach(() => {

        gridOptions = {
	        columnDefs: [
	            {headerName: 'Header Name', field: 'headerName', editable: true,rowDrag:true,filterParams : {
                        clearButton: true
                }},
	            {headerName: 'Field', field: 'field', editable: false, hide : true, filterParams : {
                        clearButton: true
                }},
	            {headerName: 'Data Type', field: 'dataType', cellEditor: 'agSelectCellEditor', cellEditorParams: {
	              values: {}}, editable: true, filterParams : {
                      clearButton: true
	                }},
	            {headerName: 'Required', field: 'required', cellEditor: 'agSelectCellEditor', cellEditorParams: {
	              values: [true, false]}, editable: true, filterParams : {
                      clearButton: true
	                }},
	            {headerName: 'Editable', field: 'editable', cellEditor: 'agSelectCellEditor', cellEditorParams: {
	              values: [true, false]}, editable: true, filterParams : {
                      clearButton: true
	                }},
	            {headerName: 'Editable CDK Only', field: 'editableByCDKOnly', cellEditor: 'agSelectCellEditor', cellEditorParams: {
	              values: [true, false]}, editable: true, filterParams : {
                      clearButton: true
	                }},
				{headerName: 'Default Value', field: 'defaultValue', editable: true, filterParams : {
                        clearButton: true
                }}, 
				{headerName: 'Client Screen', field: 'clientScreen', cellEditor: 'agSelectCellEditor', cellEditorParams: {
					values : ['Yes', 'No'] }, editable: true, hide : true, filterParams : {
                        clearButton: true
	                }},  
	            {headerName: 'Validation Rule', field: 'validationRule', editable: true, filterParams : {
                        clearButton: true
				}},
				{headerName: 'Data Length', field: 'dataLength', editable: params => (params.node.data.dataType === 'BOOLEAN' ?  false : true),
					filterParams : {clearButton: true}
				}
	        ],
	        rowData : [],
	        rowDragManaged: true,
	        enableSorting: true,
	        enableFilter: true,
	        animateRows: true,
	        rowSelection : 'multiple',
	        onGridReady: function(params) {
	            params.api.sizeColumnsToFit();
	            var allColumnIds = [];
	            this.columnApi.getAllColumns().forEach(function(column) {
	              allColumnIds.push(column.colId);
	            });
	            this.columnApi.autoSizeColumns(allColumnIds);
	        },
	        onCellValueChanged: function(params) {
	            var colId = params.column.getId();
	            if (colId==='headerName') {
	                const tmp = params.data.headerName.toLowerCase();
	                const search = tmp.replace(/([\s]+|'|\.|\/)/g, '_');
	                params.data.field = search;
			 }
			if (params.node.data.dataType === 'BOOLEAN'){
				params.node.data.dataLength = "1" ;
				params.api.refreshCells(); 
			} 
	    }
	 };

        masterFunctionalUnitService = TestBed.get(MasterFunctionalUnitService);
        fixture = TestBed.createComponent(NewFunctionalUnitComponent);
        component = fixture.componentInstance;
        component.gridOptions = gridOptions1;
        fixture.detectChanges();
        expect(component).toBeTruthy();
      }); 

      const gridOptions1={
        "columnDefs": [
          {
              "headerName": "Header Name",
              "field": "headerName",
              "editable": true,
              "rowDrag": true,
              "filterParams": {
                  "clearButton": true
              }
          },
          {
              "headerName": "Field",
              "field": "field",
              "editable": false,
              "hide": true,
              "filterParams": {
                  "clearButton": true
              }
          },
          {
              "headerName": "Data Type",
              "field": "dataType",
              "cellEditor": "agSelectCellEditor",
              "cellEditorParams": {
                  "values": [
                      "CHAR",
                      "INT",
                      "DATE",
                      "BOOLEAN",
                      "PERCENTAGE",
                      "CURRENCY",
                      "DROPDOWN",
                      "MULTIVALUE",
                      "MULTIVALUEDROPDOWN",
                      "PICK FROM STORE"
                  ]
              },
              "editable": true,
              "filterParams": {
                  "clearButton": true
              }
          },
          {
              "headerName": "Required",
              "field": "required",
              "cellEditor": "agSelectCellEditor",
              "cellEditorParams": {
                  "values": [
                      true,
                      false
                  ]
              },
              "editable": true,
              "filterParams": {
                  "clearButton": true
              }
          },
          {
              "headerName": "Editable",
              "field": "editable",
              "cellEditor": "agSelectCellEditor",
              "cellEditorParams": {
                  "values": [
                      true,
                      false
                  ]
              },
              "editable": true,
              "filterParams": {
                  "clearButton": true
              }
          },
          {
              "headerName": "Editable CDK Only",
              "field": "editableByCDKOnly",
              "cellEditor": "agSelectCellEditor",
              "cellEditorParams": {
                  "values": [
                      true,
                      false
                  ]
              },
              "editable": true,
              "filterParams": {
                  "clearButton": true
              }
          },
          {
              "headerName": "Default Value",
              "field": "defaultValue",
              "editable": true,
              "filterParams": {
                  "clearButton": true
              }
          },
          {
              "headerName": "Client Screen",
              "field": "clientScreen",
              "cellEditor": "agSelectCellEditor",
              "cellEditorParams": {
                  "values": [
                      "Yes",
                      "No"
                  ]
              },
              "editable": true,
              "hide": true,
              "filterParams": {
                  "clearButton": true
              }
          },
          {
              "headerName": "Validation Rule",
              "field": "validationRule",
              "editable": true,
              "filterParams": {
                  "clearButton": true
              }
          },
          {
              "headerName": "Data Length",
              "field": "dataLength",
              "filterParams": {
                  "clearButton": true
              }
          }
      ],
      "rowData": [
          {
              "headerName": "fuel",
              "field": "fuel",
              "dataType": "DROPDOWN",
              "required": "true",
              "editable": "true",
              "editableByCDKOnly": false,
              "defaultValue": "",
              "clientScreen": "",
              "validationRule": "Petrol,Disel,Oil",
              "dataLength": 0,
              "cellEditor": "agSelectCellEditor",
              "cellEditorParams": {
                  "values": [
                      "Petrol",
                      "Disel",
                      "Oil"
                  ]
              }
          }
      ],
      "rowDragManaged": true,
      "enableSorting": true,
      "enableFilter": true,
      "animateRows": true,
      "rowSelection": "multiple"
      }
      const params:any={
          rowIndex:0
      }
      
    const genericResponse :any ={
      "resultCode": "CDK_200",
      "resultDescription": "OK",
      "resultObj": {
        "propagationStarted": false
      },
      "executionTime": 9
    }

    const masterFunctionalUnit:MasterFunctionalUnit={
     
      "functionalUnitType": "MasterFunctionalUnit",
      "functionalUnitName": "LW_FU",
      "gridOptionsModel": {
        "animatedRows": false,
        "rowSelection": "multiple",
        "columnDefs": [
          {
            "headerName": "Sno",
            "field": "sno",
            "dataType": "INT",
            "required": "true",
            "editable": "true",
            "editableByCDKOnly": false,
            "defaultValue": "",
            "clientScreen": "",
            "validationRule": "",
            "dataLength": 0,
            "cellEditor": "agTextCellEditor"
          }
        ],
        "rowData": ""
      },
      "description": "LW_FU desc",
      "version": 0,
      "productCode": "ACCT",
       "createdDate":new Date(),
       "lastUpdatedDate":new Date(),
      "propagationStarted": false,
      "recordType": "FunctionalUnitInfo",
      "id": "51379971-2fe8-4170-8c93-fea26a959596"
    }

      it('test onRowClicked',()=>{
            component.onRowClicked(params);
            console.log(component.currentIndex);
      });

      it('test createNewRowData',()=>{
        let gridOptions:GridOptions={}
        component.createNewRowData(gridOptions);
      });

      it('test loadData',()=>{
        let event:any={
          selectedIndex: 1
        }
        spyOn(component,'checkDuplicateFUFromDB');
        component.loadData(event);
      });
      
      it('test checkDuplicateFUFromDB',()=>{

        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitByNameAndProductCode').and.returnValue(Observable.of(genericResponse));
        component.checkDuplicateFUFromDB();
        expect(component.isDuplicateFU).toBeFalsy();
      });

      it('test checkDuplicateFUFromDB generic response is null',()=>{

        const genericResponse :any ={
          "resultCode": "CDK_200",
          "resultDescription": "OK",
          "resultObj":null,
          "executionTime": 9
        }
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitByNameAndProductCode').and.returnValue(Observable.of(genericResponse));
        component.checkDuplicateFUFromDB();
        expect(component.isDuplicateFU).toBeFalsy();
      });

      
      it('test checkDuplicateFUFromDB return error',()=>{
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitByNameAndProductCode').and.returnValue(Observable.throwError('error'));
        component.checkDuplicateFUFromDB();
        expect(component['toastrService'].previousToastMessage).toBe('Error occurred while checking the duplicate functional unit.')
      });

      it('test checkDuplicateFUFromDB Edit is true',()=>{   
        component['data.edit'] = true;
        component.existingFUName = "test1";
        component.functionalUnit.functionalUnitName ="test1";
        component.existingProductCode = "SVC";
        component.functionalUnit.productCode = "SVC";
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitByNameAndProductCode').and.returnValue(Observable.of(genericResponse));
        component.checkDuplicateFUFromDB();
      });
 
      it('test checkDuplicateFUFromDB Edit is true and ExistFU name ,ExistProductCode is different',()=>{
        
        let data:any={
          edit:true
        }
        component.functionalUnit = masterFunctionalUnit
        component['data'] = data;
        component.existingFUName = "test1";
        component.existingProductCode = "SVC";
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitByNameAndProductCode').and.returnValue(Observable.of(genericResponse));
        component.checkDuplicateFUFromDB();
        expect(component['toastrService'].previousToastMessage).toBe('Functional Unit  with Name and Product Code combination already exists.')
        expect(component.isDuplicateFU).toBeTruthy();
      });

      it('test checkDuplicateFUFromDB Edit is true and ExistFU name ,ExistProductCode are same and Propagated changes is false',()=>{
        
        let data:any={edit:true}
        component.functionalUnit = masterFunctionalUnit
        component['data'] = data;
        component.existingFUName = "LW_FU";
        component.existingProductCode = "ACCT";
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitByNameAndProductCode').and.returnValue(Observable.of(genericResponse));
        component.checkDuplicateFUFromDB();
        expect(component.isDuplicateFU).toBeFalsy();
      });

      
      it('test checkDuplicateFUFromDB Edit is true and ExistFU name ,ExistProductCode are same and Propagated changes is true',()=>{
        
        const genericResponse1 :any ={
          "resultCode": "CDK_200",
          "resultDescription": "OK",
          "resultObj": {
            "propagationStarted": true
          },
          "executionTime": 9
        }
        let data:any={edit:true}
        component.functionalUnit = masterFunctionalUnit
        component['data'] = data;
        component.existingFUName = "LW_FU";
        component.existingProductCode = "ACCT";
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitByNameAndProductCode').and.returnValue(Observable.of(genericResponse1));
        component.checkDuplicateFUFromDB();
        expect(component['toastrService'].previousToastMessage).toBe('Functional Unit LW_FU Change Propagation is underway. No modifications can take place at this time. Please try later')
        expect(component.isDuplicateFU).toBeTruthy()
      });

      it('test productCodeChange',()=>{
        let productCode:string="EMP";
        component.productCodeChange(productCode);
      });

      it('test productCodeChange for other product code',()=>{
        let productCode:string="SVC";
        component.productCodeChange(productCode);
      });

      it('test closePopup',()=>{
        component.closePopup();
      });

      it('test saveFunctionalUnit',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        let rowDatas:any[]=[
        ]
        let nodes:any[]=[
          {
            "fee_code": "PD",
            "description": "Parts Discount",
            "index": "1000",
            "rowDataId": "ab70f432-26bd-4d92-af13-945701cc0660"
          },
          {
            "fee_code": "SD",
            "description": "Service Discount",
            "index": "2000",
            "rowDataId": "b0c2306f-def3-469e-8987-c75d71e741b8"
          }
        ]
        let api:any={

        }

        let gridApi:any={
          forEachNode
       } 
       function forEachNode(){
  
       return  nodes.forEach(node=>{
          rowDatas.push(node)
        })
       }
        let test = gridOptions;
        test.api = gridApi;
        component.gridOptions = test;
        spyOn(masterFunctionalUnitService,'createMasterFunctionalUnit').and.returnValue(Observable.of({}));
        component.saveFunctionalUnit({});
      }); 
    });