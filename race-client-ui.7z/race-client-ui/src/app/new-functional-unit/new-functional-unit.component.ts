import { Component, OnInit,Inject} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GridOptions, GridApi } from 'ag-grid/main';
import { GridOptionsModel } from '../model/grid-options-object';
import { MatDialog,MatDialogRef,MAT_DIALOG_DATA } from '@angular/material';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { MasterFunctionalUnit } from '../model/master-functional-unit';
import { MasterFunctionalUnitService } from '../services/master-functional-unit-service';
import { Constants } from '../constant/constants';
import { ToastrService } from 'ngx-toastr';
import { MatStepper } from '@angular/material/stepper';

@Component({
  selector: 'app-new-functional-unit',
  templateUrl: './new-functional-unit.component.html',
  styleUrls: ['./new-functional-unit.component.css']
})
export class NewFunctionalUnitComponent implements OnInit {
	createScreenPermission : boolean=true;
	firstFormGroup: FormGroup;
	secondFormGroup: FormGroup;
	functionalUnit : MasterFunctionalUnit =new MasterFunctionalUnit();
    label : string;
	productCodes = [];
	selectedStepIndex: number = 0;
    
    currentIndex: number =0;

    dataTypesList = ['CHAR', 'INT','DATE','BOOLEAN', 'PERCENTAGE','CURRENCY', 'DROPDOWN','MULTIVALUE','MULTIVALUEDROPDOWN', "PICK FROM STORE"];
    
	gridOptions : any = {
	        columnDefs: [
	            {headerName: 'Header Name', field: 'headerName', editable: true,rowDrag:true,filterParams : {
                        clearButton: true
                }},
	            {headerName: 'Field', field: 'field', editable: false, hide : true, filterParams : {
                        clearButton: true
                }},
	            {headerName: 'Data Type', field: 'dataType', cellEditor: 'agSelectCellEditor', cellEditorParams: {
	              values: this.dataTypesList}, editable: true, filterParams : {
                      clearButton: true
	                }},
	            {headerName: 'Required', field: 'required', cellEditor: 'agSelectCellEditor', cellEditorParams: {
	              values: [true, false]}, editable: true, filterParams : {
                      clearButton: true
	                }},
	            {headerName: 'Editable', field: 'editable', cellEditor: 'agSelectCellEditor', cellEditorParams: {
	              values: [true, false]}, editable: true, filterParams : {
                      clearButton: true
	                }},
	            {headerName: 'Editable CDK Only', field: 'editableByCDKOnly', cellEditor: 'agSelectCellEditor', cellEditorParams: {
	              values: [true, false]}, editable: true, filterParams : {
                      clearButton: true
	                }},
				{headerName: 'Default Value', field: 'defaultValue', editable: true, filterParams : {
                        clearButton: true
                }}, 
				{headerName: 'Client Screen', field: 'clientScreen', cellEditor: 'agSelectCellEditor', cellEditorParams: {
					values : ['Yes', 'No'] }, editable: true, hide : true, filterParams : {
                        clearButton: true
	                }},  
	            {headerName: 'Validation Rule', field: 'validationRule', editable: true, filterParams : {
                        clearButton: true
				}},
				{headerName: 'Data Length', field: 'dataLength', editable: params => (params.node.data.dataType === 'BOOLEAN' ?  false : true),
					filterParams : {clearButton: true}
				}
	        ],
	        rowData : [],
	        rowDragManaged: true,
	        enableSorting: true,
	        enableFilter: true,
	        animateRows: true,
	        rowSelection : 'multiple',
	        onGridReady: function(params) {
	            params.api.sizeColumnsToFit();
	            var allColumnIds = [];
	            this.columnApi.getAllColumns().forEach(function(column) {
	              allColumnIds.push(column.colId);
	            });
	            this.columnApi.autoSizeColumns(allColumnIds);
	        },
	        onCellValueChanged: function(params) {
	            var colId = params.column.getId();
	            if (colId==='headerName') {
	                const tmp = params.data.headerName.toLowerCase();
	                const search = tmp.replace(/([\s]+|'|\.|\/)/g, '_');
	                params.data.field = search;
			 }
			if (params.node.data.dataType === 'BOOLEAN'){
				params.node.data.dataLength = "1" ;
				params.api.refreshCells(); 
			} 
	    }
	 };
	 isDuplicateFU:boolean = true;
	 existingFUName:string;
	 existingProductCode:string;
    constructor(private functionalUnitService: MasterFunctionalUnitService,private _formBuilder: FormBuilder, @Inject(MAT_DIALOG_DATA) private data: any,
    		private dialog : MatDialog,private dialogRef: MatDialogRef<NewFunctionalUnitComponent>,private toastrService : ToastrService){
		dialogRef.disableClose = true;
 	   if(this.data.edit){
		   this.existingFUName =   this.data.functionalUnit.functionalUnitName;
		   this.existingProductCode = this.data.functionalUnit.productCode;
           this.functionalUnit = this.data.functionalUnit;
           this.gridOptions.rowData =this.functionalUnit.gridOptionsModel.rowData;
           this.functionalUnit.gridOptionsModel = this.gridOptions;
           this.label=' Edit Functional Unit';
           this.productCodeChange(this.functionalUnit.productCode);
            if(this.functionalUnit.productCode == 'EMP') {					
 				this.gridOptions.columnDefs[7].hide = false;
 			}
 	   } 
	   else{
		   this.gridOptions.rowData = []; 
		   this.functionalUnit.gridOptionsModel = this.gridOptions;
		   this.label=' Add Functional Unit';
	   }  
		this.currentIndex = this.gridOptions.rowData.length;
		this.productCodes=Constants.PRODUCT_CODES;
    }
	
    ngOnInit() {
		this.firstFormGroup = this._formBuilder.group({
			functionalUnitNameCtrl: ['', Validators.required],
			descriptionCtrl: ['', Validators.required],
			productCodeCtrl : ['', Validators.required]
		});
	    this.secondFormGroup = this._formBuilder.group({
	    	secondCtrl: ''
	    });
	}
	
	onRowClicked(params : any){
        this.currentIndex = params.rowIndex + 1;
    }
	addRow(gridOptions: GridOptions) {
	    const newItems = this.createNewRowData(gridOptions);
	    gridOptions.api.updateRowData({add: [newItems], addIndex : this.currentIndex});
	}

	createNewRowData(gridOptions: GridOptions) {
	    return {
	    	headerName:'',
	    	field:'',
	    	dataType:'',
	    	required:'',
	    	editable:'',
	    	editableByCDKOnly:'',
	    	defaultValue:'',
	    	clientScreen:'',
	    	validationRule:'',
	    	dataLength:''};
	}

	deleteRow(gridOptions: GridOptions) {
		const selecteRows = gridOptions.api.getSelectedRows();
		const result = gridOptions.api.updateRowData({remove: selecteRows});
	}
	  
	closePopup() {
		this.dialogRef.close(Constants.POPUP_CANCEL);
	};
	
	saveFunctionalUnit(gridOptions : GridOptions){
		var dataValid = true;
		const reqFunctionalUnit: MasterFunctionalUnit = new MasterFunctionalUnit();
		reqFunctionalUnit.functionalUnitName = this.functionalUnit.functionalUnitName;
		reqFunctionalUnit.description = this.functionalUnit.description;
		reqFunctionalUnit.productCode = this.functionalUnit.productCode;
		reqFunctionalUnit.id = this.functionalUnit.id;
		reqFunctionalUnit.recordType = this.functionalUnit.recordType;
		reqFunctionalUnit.version = this.functionalUnit.version;
		reqFunctionalUnit.functionalUnitType = this.functionalUnit.functionalUnitType;
		reqFunctionalUnit.gridOptionsModel = {
			animatedRows: this.gridOptions.animatedRows,
			rowSelection: this.gridOptions.rowSelection,
			columnDefs: [],
			rowData:[]
		};
		
	
	    this.gridOptions.api.forEachNode(function(node) {
	    	if (node.data.headerName && node.data.dataType) {
	    		node.data.editable= (node.data.editable || 'true' == node.data.editable);
	    		node.data.required= (node.data.required || 'true' == node.data.required);
	    		node.data.editableByCDKOnly= (node.data.editableByCDKOnly || 'true' == node.data.editableByCDKOnly);
	    		var toArray = node.data.validationRule.split(",");
	    		if (node.data.dataType === 'BOOLEAN') {
	    			node.data.cellEditor = 'agRichSelectCellEditor';
	    		}
	   
	    		if (node.data.dataType === 'DROPDOWN') {
	    			node.data.cellEditor = 'agSelectCellEditor';
	    			node.data.cellEditorParams = { values: toArray };
	    		}
	
	    		if (node.data.dataType === 'MULTIVALUEDROPDOWN') {
	    			node.data.cellEditor = 'agSelectCellEditor';
	    			node.data.cellEditorParams = { values: toArray };
	    		}
	
	    		if (node.data.dataType === 'DATE') {
	    			node.data.cellEditorFramework = 'BootstrapDatePickerComponent';
	    		}
	
	    		if (node.data.dataLength != undefined) {
	    			node.data.dataLength = +node.data.dataLength
	    		}
	
	    		if (node.data.dataType === 'CHAR' || node.data.dataType === 'INT') {
	    			if (node.data.dataLength === '' || node.data.dataLength === 0) {
	    				node.data.cellEditor = 'agTextCellEditor';
	    			} else if (node.data.dataLength !== '' || node.data.dataLength !== 0) {
	    				node.data.cellEditor = 'agLargeTextCellEditor';
	    				node.data.cellEditorParams = { maxLength: node.data.dataLength };
	    			}
	    		}
	    		reqFunctionalUnit.gridOptionsModel.columnDefs.push(node.data);
	    	} else {
	          dataValid = false;
	    	}
	    });
	    if (dataValid) {
	    	let dialogRef = this.dialog.open(LoaderDialogueComponent, {
	    		width: '300px',
	    		height: '150px',
				data: { message: 'Saving Functional Unit' }
			});
			this.functionalUnitService.createMasterFunctionalUnit(reqFunctionalUnit).subscribe((data: any) => {
				dialogRef.close();
				this.dialogRef.close();
			});
	    }
	    else {
	    	this.toastrService.error('Header Name and Data Type cannot be blank');
	    }
	}
	   
	checkClientScreen(gridOptions : GridOptions, stepper: MatStepper) {
		if(this.functionalUnit.productCode == 'EMP') {
			gridOptions.columnApi.setColumnVisible("clientScreen", true);		 
		} else {
			gridOptions.columnApi.setColumnVisible("clientScreen", false);		 
		}
		stepper.next();
	}
	  
	productCodeChange(productCode: string) {
		if(productCode && productCode === 'EMP') {
			this.dataTypesList = ['CHAR', 'INT','DATE','BOOLEAN', 'PERCENTAGE','CURRENCY', 'EMAIL', 'DROPDOWN','MULTIVALUE','MULTIVALUEDROPDOWN',"GROUPEDMULTIVALUEDROPDOWN", "PICK FROM STORE"];
		} else {
			this.dataTypesList = ['CHAR', 'INT','DATE','BOOLEAN','PERCENTAGE','CURRENCY', 'DROPDOWN','MULTIVALUE','MULTIVALUEDROPDOWN', "PICK FROM STORE"];
		}
		this.gridOptions.columnDefs[2].cellEditorParams.values = this.dataTypesList;
	}

	checkDuplicateFUFromDB() {
			this.functionalUnitService.fetchFunctionalUnitByNameAndProductCode(this.functionalUnit.functionalUnitName,this.functionalUnit.productCode)
			.subscribe(genericResponse => {
				if(genericResponse != null && genericResponse != undefined && genericResponse.resultDescription == "OK" && genericResponse.resultDescription != null){
					if(genericResponse.resultObj != null){
						if(this.data.edit){  
							if(this.existingFUName === this.functionalUnit.functionalUnitName && this.existingProductCode === this.functionalUnit.productCode){
								if(genericResponse.resultObj.propagationStarted){
									this.functionalUnit.propagationStarted = true;
									this.toastrService.error('Functional Unit '+this.functionalUnit.functionalUnitName+' Change Propagation is underway. No modifications can take place at this time. Please try later');
									this.isDuplicateFU = true;
								}else{
									this.isDuplicateFU = false;
								}
							}else{
								this.toastrService.error('Functional Unit  with Name and Product Code combination already exists.');
								this.isDuplicateFU = true;
							}
						 }else{
							this.isDuplicateFU = true; 
							this.toastrService.error('Functional Unit  with Name and Product Code combination already exists.');
						 }
					}else{
						this.isDuplicateFU = false;
					}
				}	
			},
			error => {
				this.toastrService.warning('Error occurred while checking the duplicate functional unit.');
			});

    	
	}

	tabToNextCell(params) {
    	if (!params.nextCellDef)
    	{
    		this.addRow(this.gridOptions);
    	}
    	else {
	      const result = {
	        rowIndex: params.nextCellDef.rowIndex,
	        column: params.nextCellDef.column,
	        floating: params.nextCellDef.floating
	      };
	      return result;
    	}
      }

	disableSaveButton():boolean{
		return this.isDuplicateFU;
	}

	loadData(event){
		if (event.selectedIndex === 1) {
			this.checkDuplicateFUFromDB();
			this.selectedStepIndex = 1;
		}
		if (event.selectedIndex === 0) {
			this.selectedStepIndex = 0;
		}
	}
	    
}
