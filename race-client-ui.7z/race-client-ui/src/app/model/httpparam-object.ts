
export class ParamObject {
    loginId: string;
    enterpriseId: string;
    permissionCode: string;
}
