import { UserObject } from './user-object';
import { ProjectHierarchy } from './project-hierarchy';

export class StoreObject extends ProjectHierarchy {
	storeId: string;
    storeName: string;
    streetAddress: string;
    city: string;
    province: string;
    zipcode: string;
    glCompanyNumber : string;
    logonName : string;
    sharedLogonName : string;
    templateIds: any[];
    clientStoreAdvocate: UserObject[];
    projectId : string;
    language : string;
    country : string;
    timezone : string;
    cdku_coordinator : string;
    oem : string;
    enterpriseStore : boolean;
	businessPhone: string;
	ipAddress: string;
    dmsCNumber: string;
    storeNumber: string="";
    createdDate:Date;    
    lastUpdatedDate:Date;
    createdBy:string;
    updatedBy:string;
	cmfNumber: string;
	url: string;
	locked : boolean;
}