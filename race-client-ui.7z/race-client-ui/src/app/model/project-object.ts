import { PlatformObject } from './platform-object';
import { StoreObject } from './store-object';
import { UserObject } from './user-object';
import { ProjectHierarchy } from './project-hierarchy';

export class ProjectObject extends ProjectHierarchy{
    isProject: number;
    projectNumber: string;
    enterpriseId : string;
    dealerName: string;
    location: string;
    status : string;
    platform : PlatformObject;
    storeIds: string [];
    clientManager: UserObject[];
    vic: UserObject[];
    css: UserObject[];
    clientProjectAdvocate: UserObject[];
    projectManager: string;
    cdku:boolean;
    language : string;
    country : string;
    timezone : string;
    cdku_coordinator : string;
    cdku_domain : string;
    cdku_division : string;
    cdku_login : string;
    cdku_password : string;
    version : number;
    failed : boolean;
    //bestPractice : boolean;
    projectSourceEnv : string;
    dealerApproverContact:string;
    dealerApproverRequired:boolean ;
    createdDate:Date;    
    lastUpdatedDate:Date;
    createdBy:string;
    updatedBy:string;
}
