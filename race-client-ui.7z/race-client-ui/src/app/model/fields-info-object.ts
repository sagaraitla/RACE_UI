export class FieldInfoObject{
    id : string;
    fieldName : string;
    previousValue: string;
    currentValue : string;
    status : string;
}