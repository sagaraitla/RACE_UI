export class TableColumnObject {
    constructor(
        headerName?: string,
        type?: string,
        defaultValue?: string,
        required?: boolean
    ) {}
}
