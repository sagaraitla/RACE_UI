import {RaceArtifact} from './race-artifact';

export class ValidationRuleObject extends RaceArtifact {
	isVR: number;
	platformName: string;
    sourceProductCode : string;
	sourceFunctionalAreaName: string;
	sourceFunctionalUnitName: string;
	sourceFieldHeaderName: string;
	condition : string;
	conditionType : string;
	validationMessage : string;
	targetProductCode : string;
	targetFunctionalAreaName: string;
	targetFunctionalUnitName: string;
	targetFieldHeaderName: string;
	active: boolean;
	status: string;
}