export class ProcessValidationResults{
    status: string;
    description:string;
    validationRuleId:string;
}