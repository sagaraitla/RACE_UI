export class PlatformObject {
    platformName: string;
    platformCode: string;
    selected: boolean;
}
