export class DashReport {
    functionalAreaId : string;
    templateName : string;
    projectNumber: string;
    functionalUnitId : string;
    screenName : string;
    storeId : string;
    storeName : string;
    columnList: any[];
}
