import { RaceArtifact } from './race-artifact';

export class Platform extends RaceArtifact {
	id: string;
	platformName : string;
	platformCode : string;
	selected : boolean;
}
