export class UserObject {
    firstName: string;
    lastName: string;
    loginId: string;
    employeeId: string;
}
