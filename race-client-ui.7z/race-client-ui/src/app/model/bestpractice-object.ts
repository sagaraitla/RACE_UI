import { PlatformObject } from './platform-object';
import {ProjectHierarchy} from './project-hierarchy';
export class BestPracticeObject extends ProjectHierarchy {
    isBestPractice : number;
	bestPracticeName : string;
    platform : PlatformObject;	
    version : number;
    failed : boolean;
    isSSS : number;
}
