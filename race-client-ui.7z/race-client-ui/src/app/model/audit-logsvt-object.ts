
export class AuditLogsVTObject{
    id : string;
    recordType : string;
    objectType : string;
    date : Date;
    objectIdentifier: string;
    user : string;
    event : string;
    s3Source : string;
    pvrresultsPresent : boolean;
    s3LogsPath : string;
}