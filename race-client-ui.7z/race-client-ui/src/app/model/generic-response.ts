

export class GenericResponse {
	resultCode: string;
	resultDescription: string;
	resultObj: any;
	executionTime: number;

}