import { RaceArtifact } from './race-artifact';
import { Platform } from './master-platform';

export class MasterFunctionalArea extends RaceArtifact {

	functionalAreaType: string;
	functionalAreaName: string;
	oemName: string;
	platforms: Platform[];
	version: string;
	productCode: string;
	productVersion: string;
	noOfFunctionalUnits: number;
	propagationStarted:boolean;
}