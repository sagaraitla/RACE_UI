export class BestPracticeVersionObject
{
id : string;
recordType : string;
versionName : string;
active : boolean;
objectType : string;
functionalAreaList : any[];
propagationStarted:boolean;
}
