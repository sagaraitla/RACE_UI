 import {GridOptionsModel} from './grid-options-object';
 import {ProjectHierarchy} from './project-hierarchy';

 export class ScreenObject extends ProjectHierarchy {
        screenName: string;
        gridOptionsModel: GridOptionsModel;
        description: string;
        updated: boolean;
        version: number;
        productCode: string;
        selected: boolean;
        templateId: string;
        index: number;
        bpScreenId: string;
        copyRowData: boolean;
        rowDataEmpty: boolean;
        bpPropagationCompleted:boolean;
}
