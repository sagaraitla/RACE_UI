export class RaceArtifact {
	id: string;
	recordType: string;
}