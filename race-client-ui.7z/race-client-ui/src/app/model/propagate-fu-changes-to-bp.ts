export class PropagateFuChangesToBp {
    item : string;
    itemType : string;
    platform : string;
}