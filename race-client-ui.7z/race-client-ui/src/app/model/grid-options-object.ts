export class GridOptionsModel {
    columnDefs: any[];    
    animatedRows: boolean;
    rowSelection: string;
    rowData: any;
}
