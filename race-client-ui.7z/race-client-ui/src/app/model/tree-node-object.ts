import { TreeModel, TreeModelSettings, ChildrenLoadingFunction } from 'ng2-tree';

export class TreeNodeObject implements TreeModel {
    value: string;
    id: string;
    children?: Array<TreeModel>;
    loadChildren?: ChildrenLoadingFunction;
    settings?: TreeModelSettings;
}
