export class TableObject {
    constructor(
        tableName?: string,
        numberOfColumns?: string,
        description?: string,
    ) {}
}
