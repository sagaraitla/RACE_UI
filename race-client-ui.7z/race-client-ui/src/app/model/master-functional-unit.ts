import {RaceArtifact} from './race-artifact';
import {GridOptionsModel} from './grid-options-object';

export class MasterFunctionalUnit extends RaceArtifact {
	functionalUnitType: string;
	functionalUnitName: string;
	gridOptionsModel: GridOptionsModel;
	description : string;
	version : number;
	productCode : string;
	createdDate:Date;
	lastUpdatedDate:Date;
	propagationStarted:boolean;
}