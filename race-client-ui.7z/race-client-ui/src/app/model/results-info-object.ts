export class ResultsInfoObject
{
    id : string;
    recordType : string;
    level : string;
    functionalUnit : string;
    rowIndex : string;
    key : string;
    value : string;
    procedure : string;
    message : string;
    timestamp : string;
    log : string;
}