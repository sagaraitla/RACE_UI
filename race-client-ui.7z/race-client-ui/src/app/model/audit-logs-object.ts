
export class AuditLogsObject{
    id : string;
    date : Date;
    projectNumber: string;
    user : string;
    event : string;
    enterpriseId : string;
    fieldsInfo : string[];
    validationRuleDesc:string;
    bestPracticeName:string;
    updated : boolean;
    recordType : string;
}