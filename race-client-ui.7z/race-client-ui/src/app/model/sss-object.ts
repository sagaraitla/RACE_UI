export class SSSObject  {

    isStateStandardDialog: boolean;
    sssVersion: string;
    sssStore: string;
    sssFaName: string;
    sssName: string;
    projectNumber: string;
    stateStandardVersionRecordType: string;
    sssFAId:string;
}
