import { UserObject } from './user-object';
import { FieldInfoObject } from './fields-info-object';

export class AuditLogs3Response{
    
logFileName : string;       /** The key under which this object is stored */
size : string;              /** The size of this object, in bytes */
lastModified : Date;        /** The date, according to Amazon S3, when this object was last modified */
storageClass : string;      /** The class of storage used by Amazon S3 to store this object */

}