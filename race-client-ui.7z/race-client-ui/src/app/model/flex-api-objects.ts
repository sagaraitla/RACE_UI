export class FlexApi {
    functionalAreaId : string;
    storeId : string;
    projectId: string;
    cmfNumber: string;
    storeNumber: string;
    
}