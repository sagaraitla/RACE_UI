import { FieldInfoObject } from "./fields-info-object";

export class GOMAuditLogsResponse{
    headerName : string;
    status : string;
    gridOptionModelDiff:FieldInfoObject[];
}