export class ProjectHierarchy {
	id: string;
	recordType: string;
}