import { UserObject } from './user-object';
import { FieldInfoObject } from './fields-info-object';

export class AuditLogsFAObject{
    id : string;
    date : Date;
    objectIdentifier: string;
    user : string;
    event : string;
    fieldsInfo : string[];
}