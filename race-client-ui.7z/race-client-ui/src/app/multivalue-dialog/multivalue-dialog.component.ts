import { Component, OnInit, Inject } from '@angular/core';
import { GridOptionsModel } from '../model/grid-options-object';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {parseString} from 'xml2js';
import { GridOptions } from 'ag-grid/main';

@Component({
  selector: 'app-multivalue-dialog',
  templateUrl: './multivalue-dialog.component.html',
  styleUrls: ['./multivalue-dialog.component.css']
})
export class MultivalueDialogComponent implements OnInit {
  private gridOptionsMultiValue : GridOptions;
  public finalValue : string = "";
  public initalValue : string = "";
  
  constructor(
    public dialogRef: MatDialogRef<MultivalueDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      dialogRef.disableClose = true;
      // to populate preexisting data in cell to the popup grid
      var rowDataFromCell : {headerName:string}[] = [];
      let initalValue = data.fieldNewVal;
      if(initalValue!= undefined && initalValue != ""){
        let splitArray = initalValue.split(",");
        for(let i=0;i<splitArray.length;i++){
          rowDataFromCell.push({headerName:splitArray[i]});
        }
      }

      this.gridOptionsMultiValue = {
        columnDefs : [{headerName: "Header Name", field: "headerName", editable: true , rowDrag: true}],
        rowData : rowDataFromCell,
        enableSorting: true,
        enableFilter: true,
        enableColResize : true,
        rowDragManaged :true,
        
        rowSelection : 'single',
        onGridReady: function(params) {
                      params.api.sizeColumnsToFit();
                      this.gridOptionsMultiValue.api.ensureColumnVisible(this.gridOptionsMultiValue.columnApi.getAllDisplayedColumns()[0]);
                 }
      };
      
    }

  onOkClick(): void {
    var arr = new Array(); 
    this.gridOptionsMultiValue.api.forEachNode(function(node) {         
            if(node.data.headerName){
             arr.push(node.data.headerName.trim());
          }  
        });
      this.finalValue = arr.join(",");;
      this.dialogRef.close(this.finalValue);
  }

    onClose(initalValue : string) : any {
     return initalValue;      
    }
    
  addRow() {      
      const newItems = this.createNewRowData(); 
      this.gridOptionsMultiValue.api.updateRowData({add: [newItems]}); 
  }

  createNewRowData() {
    const row = {headerName:''};
    return row;
  }

  deleteRow() {
      const selecteRows = this.gridOptionsMultiValue.api.getSelectedRows();
      const result = this.gridOptionsMultiValue.api.updateRowData({remove: selecteRows});   
  }  

  ngOnInit() {
  }

}
