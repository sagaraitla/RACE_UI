import { AddStoreComponent } from "./add-store-dialog.component";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AuthService } from "../services/auth-service";
import { Router, RouterModule } from "@angular/router";
import { BestPracticeService } from "../services/bestpractice-service";
import { StoreService } from "../services/store-service";
import {forkJoin as observableForkJoin,  iif } from 'rxjs';
import { ProjectService } from "../services/project-service";
import { FunctionalAreaService } from "../services/functional-area-service";
import { FunctionalUnitService } from "../services/functional-unit-service";
import { Observable, of } from 'rxjs';
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatDialogRef, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatListModule, MatMenuModule, MatOptionModule, MatPaginatorModule, MatProgressSpinnerModule, MatSelectModule, MatSortModule, MatStepper, MatStepperModule, MAT_DIALOG_DATA } from "@angular/material";
import { CdkTableModule } from "@angular/cdk/table";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { CommonModule } from "@angular/common";
import { FormBuilder, FormControl, FormsModule, ReactiveFormsModule, Validators } from "@angular/forms";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { LaunchDarklyService } from "../services/launchdarkly-service";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { BestPracticeObject } from "../model/bestpractice-object";
import { MasterFunctionalArea } from "../model/master-functional-area";
import { ComponentType } from "ag-grid/dist/lib/components/framework/componentResolver";
import { BestPracticeTree } from "../bestpractice-tree/bestpractice-tree.component";
import { TreeModule } from "ng2-tree";
import { ProjectObject } from "../model/project-object";
import { PlatformObject } from "../model/platform-object";
import { TemplateObject } from "../model/template-object";
import { UserObject } from "../model/user-object";
import { template } from "lodash";
import { StoreObject } from "../model/store-object";


describe('Test Add Store',()=>{

  describe('AddStoreComponent', () =>{
    let component : AddStoreComponent;
    let fixture : ComponentFixture<AddStoreComponent>;
    let storeService : StoreService;
    let authService : AuthService;
    let bestPracticeService : BestPracticeService;
    let projectService : ProjectService;
    let functionalAreaService : FunctionalAreaService;
    let functionalUnitService : FunctionalUnitService;
    let launchDarklyService : LaunchDarklyService;
    let _formBuilder : FormBuilder;
    let bestPracticeTree : BestPracticeTree;
    let routerStub : Router;

    class MatDialogMock {
        open() {
          return {
            afterClosed: () => Observable.of(true)
          };
        }
      };

    const dialogMock = {
      close: () => { }
      };
    
    class MockRouter {
      navigateByUrl(url: string) { return url; }
    }
    const testUrl  = 'projects/PM525916';
    beforeEach(async(() =>{
      let mockRouter = {
          navigate: jasmine.createSpy('navigateByUrl')
      }
      let data = {
        project : {
          "isProject": 1,
          "enterpriseId": "172935",
          "projectNumber": "PM525916",
          "dealerName": "CDK Automation",
          "location": null,
          "storeIds":null,
          "platform": {
            "platformName": "DRIVE",
            "platformCode": "drive",
            "selected": false
          },
          "status": "OPEN",
          "clientManager": null,
          "vic": null,
          "css": null,
          "projectManager": null,
          "language": null,
          "country": null,
          "timezone": null,
          "cdku": false,
          "cdku_coordinator": null,
          "cdku_domain": null,
          "cdku_division": null,
          "cdku_login": null,
          "cdku_password": null,
          "clientProjectAdvocate": null,
          "version": 0,
          "failed": false,
          "projectSourceEnv": null,
          "dealerApproverContact": null,
          "dealerApproverRequired": false,
          "createdDate": null,
          "lastUpdatedDate": null,
          "createdBy": "dotdemouser3@cdk.com",
          "updatedBy": "dotdemouser3@cdk.com",
          "id": "9d3508f7-c0d9-408f-b575-5dd0bf83629b",
          "recordType": "ProjectInfo"
        },
        storeRecordType : "9faa4afb-d7c5-479b-aa8a-3a3d8faaab86",
        addStore : false
      }
    const storeServiceSpy = jasmine.createSpyObj('StoreService',
    ['getStore','getFunctionalAreasOfStore', 'saveStore']);

    const bpServiceSpy = jasmine.createSpyObj('BestPracticeService',['getAllBestPracticesByPlatform','getAllBestPracticesByType']);
    TestBed.configureTestingModule({
        imports:[
            MatCardModule,
            MatFormFieldModule,
            MatInputModule,
            CdkTableModule,
            ToastrModule.forRoot(),
            CommonModule,
            MatPaginatorModule,
            MatDialogModule,
            MatSelectModule,
            MatCheckboxModule,
            MatSortModule,
            MatIconModule,
            MatStepperModule,
            MatOptionModule,
            MatListModule,
            FormsModule,
            ReactiveFormsModule,
            MatMenuModule,
            MatDividerModule,
            MatProgressSpinnerModule,
            HttpClientTestingModule,
            NoopAnimationsModule,
            TreeModule,
            MatDialogModule,
            RouterModule.forRoot([])


            
        ],
        declarations : [
            AddStoreComponent, LoaderDialogueComponent, BestPracticeTree
        ],
        providers:[
            StoreService, ProjectService, AuthService, BestPracticeService, FunctionalAreaService, FunctionalUnitService, 
            ToastrService, LaunchDarklyService,
            { provide: Router, useClass: MockRouter },
            { provide: MAT_DIALOG_DATA, useValue: data },
            { provide: MatDialogRef, useValue: dialogMock }
        ]
    }).overrideModule(BrowserDynamicTestingModule,
        { set: { entryComponents: [LoaderDialogueComponent,AddStoreComponent, BestPracticeTree]}});
        authService = TestBed.get(AuthService);
        storeService = TestBed.get(StoreService);
        projectService = TestBed.get(ProjectService);
        bestPracticeService = TestBed. get(BestPracticeService);
        functionalAreaService = TestBed.get(FunctionalAreaService);
        functionalUnitService = TestBed.get(FunctionalUnitService);
        routerStub = TestBed.get(Router);

    }));   
    beforeEach(() =>{
        fixture = TestBed.createComponent(AddStoreComponent);
        component = fixture.componentInstance;
        _formBuilder = TestBed.get(FormBuilder); 
        component.firstFormGroup = _formBuilder.group({ 
          recipientTypes: new FormControl(
          {
              value: ["mock"],
              disabled: true
          },
          Validators.required
          )
          });
          component.secondFormGroup = _formBuilder.group({ 
              recipientTypes: new FormControl(
              {
                  value: ["mock"],
                  disabled: true
              },
              Validators.required
              )
              });
        fixture.detectChanges();
    })

    const mock_bp_response : any ={
      "isBestPractice": 1,
      "isSSS": 0,
      "bestPracticeName": "21AugBP",
      "platform": {
        "id": null,
        "platformName": "FLEX",
        "platformCode": "flex",
        "selected": true
      },
      "versionCount": 0,
      "version": 0,
      "failed": false,
      "id": "baa890d3-28bf-4ca7-942c-2488a033adab",
      "recordType": "BestPracticeInfo"
    }
    const best_practice_response_list : BestPracticeObject[] = [

          {
            "isBestPractice": 1,
            "isSSS": 0,
            "bestPracticeName": "21AugBP",
            "platform": {
              "platformName": "FLEX",
              "platformCode": "flex",
              "selected": true
            },
            "version": 0,
            "failed": false,
            "id": "baa890d3-28bf-4ca7-942c-2488a033adab",
            "recordType": "BestPracticeInfo"
          }
    ];

    const us_store : any ={
      "storeName": "test8",
      "streetAddress": "hyd",
      "city": "hyd",
      "province": "Alabama",
      "zipcode": "45678",
      "glCompanyNumber": "400",
      "logonName": "AGNI",
      "sharedLogonName": "AGNI",
      "clientStoreAdvocate": null,
      "language": null,
      "country": "United States",
      "timezone": null,
      "cdku_coordinator": null,
      "oem": null,
      "businessPhone": null,
      "enterpriseStore": false,
      "activeVersion": false,
      "ipAddress": "207.186.134.120",
      "dmsCNumber": "C300539",
      "cmfNumber": "C300539",
      "url": null,
      "storeNumber": null,
      "locked": true,
      "id": "9d3508f7-c0d9-408f-b575-5dd0bf83629b",
      "recordType": "9faa4afb-d7c5-479b-aa8a-3a3d8faaab86"
    }

    let canada_store : any = {
      "country" : "Canada",
      "id": "9d3508f7-c0d9-408f-b575-5dd0bf83629b",
      "recordType": "9faa4afb-d7c5-479b-aa8a-3a3d8faaab86",
      "locked" : true,
      "sharedLogonName": "AGNI"
    }

    const list_of_stores : any =[{
      "country" : "Canada",
      "id": "9d3508f7-c0d9-408f-b575-5dd0bf83629b",
      "recordType": "9faa4afb-d7c5-479b-aa8a-3a3d8faaab86",
      "locked" : true,
      "sharedLogonName": "AGNI",
      "storeName" : "store1"
    }]

    let other_store : any = {
      "country" : "Other",
      "id": "9d3508f7-c0d9-408f-b575-5dd0bf83629b",
      "recordType": "9faa4afb-d7c5-479b-aa8a-3a3d8faaab86",
      "locked" : true,
      "sharedLogonName": "AGNI"
    }

    const list_of_master_functional_are_response: MasterFunctionalArea[] =[
      {
          "functionalAreaType": "MasterFunctionalArea",
          "functionalAreaName": "FATestToday",
          "oemName": null,
          "platforms": [
            {
              "id": null,
              "platformName": "FLEX",
              "platformCode": "flex",
              "selected": true,
              "recordType":null

            }
          ],
          "productCode": "ACCT",
          "productVersion": "1",
          "noOfFunctionalUnits": null,
          "version": "0",
          "propagationStarted": false,
          "id": "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
          "recordType": "FunctionalAreaInfo"
        }
    ]

    const list_of_template_response: TemplateObject[] =[
      {
        "functionalAreaName": "Sales",
        "functionalAreaType": null,
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Work in Progress",
        "platforms": [
          {
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true
          }
        ],
        "vic": {
          "loginId" : "myLogin",
          "firstName" : null,
          "lastName" : "last",
          "employeeId" : null
        },
        "secondaryVic":  {
          "firstName" : null,
          "lastName" : null,
          "loginId" : "myLogin",
          "employeeId" : null
        },
        "clientFunctionalAreaUser": null,
        "version": 43,
        "isFailed": null,
        "inProcess": false,
        "productCode": "SLS",
        "productVersion": null,
        "bpId": "63f38af3-92e3-4509-81b5-c59365cc7df1",
        "bpVersionId": "70766cde-1b7b-46b1-9c73-a8adf96ceac8",
        "bpTemplateId": "46675d78-a8d5-41ca-8801-c679ef00cff4",
        "isDealerApproved": false,
        "stateStandardId": "sssId",
        "stateStandardName": "sss",
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": false,
        "showValidateOrTransferButton": false,
        "showProcessValidationResultsButton": true,
        "createdDate": null,
        "lastUpdatedDate": null,
        "screenIds":null,
        "createdBy": null,
        "updatedBy": "Harika.Gajabimkar@cdk.com",
        "incorporateBpChanges": false,
        "isLocked":false,
        "storeId":null,
        "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
        "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
      }
  ];

  const currentProject: ProjectObject = {
      "isProject": 1,
      "enterpriseId": "172935",
      "projectNumber": "PM525916",
      "dealerName": "CDK Automation",
      "location": null,
      "storeIds":null,
      "platform": {
        "platformName": "DRIVE",
        "platformCode": "drive",
        "selected": false
      },
      "status": "OPEN",
      "clientManager": null,
      "vic": null,
      "css": null,
      "projectManager": null,
      "language": null,
      "country": "Other",
      "timezone": null,
      "cdku": false,
      "cdku_coordinator": null,
      "cdku_domain": null,
      "cdku_division": null,
      "cdku_login": null,
      "cdku_password": null,
      "clientProjectAdvocate": null,
      "version": 0,
      "failed": false,
      "projectSourceEnv": null,
      "dealerApproverContact": null,
      "dealerApproverRequired": false,
      "createdDate": null,
      "lastUpdatedDate": null,
      "createdBy": "dotdemouser3@cdk.com",
      "updatedBy": "dotdemouser3@cdk.com",
      "id": "9d3508f7-c0d9-408f-b575-5dd0bf83629b",
      "recordType": "ProjectInfo"

  };

  const currentProjectNull: any = {
    "isProject": 1,
    "enterpriseId": "172935",
    "projectNumber": "PM525916",
    "platform": {
      "platformName": "DRIVE",
      "platformCode": "drive",
      "selected": false
    },
    "status": "OPEN",
    "clientManager": null,
    "vic": null,
    "css": null,
    "projectManager": null,
    "language": null,
    "country": null,      
    "id": "9d3508f7-c0d9-408f-b575-5dd0bf83629b",
    "recordType": "ProjectInfo"
  };

  it('test ng init method', async() =>{
      
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    spyOn(authService, 'isAuthorised').and.returnValue(false);
    spyOn(storeService, 'getStore').and.returnValue(Observable.of((us_store)));
    spyOn(bestPracticeService,'getAllBestPracticesByPlatform').and.returnValue(Observable.of(best_practice_response_list));
    spyOn(bestPracticeService,'getAllBestPracticesByType').and.returnValue(Observable.of(best_practice_response_list));
    best_practice_response_list[0].platform.platformName = "FLEX";
    component.stateStandardFlagStatus.current = true;
    component.currentProject = currentProject;
    component.ngOnInit();
    
  }); 	

  it('test are valid functional areas selected method', async() =>{
      component.selections = {ACCT: {template: {
        platforms: {
        0: {id: null, platformName: "DRIVE", platformCode: "drive", selected: true},
        1: {id: null, platformName: "FLEX", platformCode: "flex", selected: true}
        },
        productCode: "ACCT",
        productVersion: null,
        recordType: "9ce6049f-dee8-495a-be7f-e61e2d715452",
        status: "Work in Progress",
        updatedBy: null,
        version: 0,
        vic: {firstName: "Jeff", lastName: "Grence", loginId: "jeff.grence@cdk.com", employeeId: null}
      },
      screens: [{}]
    },
      PTS: {template: {}, screens: Array(16), nodeId: 234}};
    component.selections["ACCT"].screens.length = 0;
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
      component.isValidFunctionalAreasSelected(dialogRefSpyObj);
  });

  it('test load data method',() =>{
    component.stateStandardFlagStatus = true;
    spyOn(bestPracticeService, 'getAllBestPracticesByPlatform').and.returnValue(Observable.of(best_practice_response_list));
    spyOn(component,'getUSersFromCommonServices');
    let data = {
      selectedIndex : 0 
    }
    let data1 = {
      selectedIndex : 1
    }
    let data2 = {
      selectedIndex : 2
    }
    component.loadData(data);
    component.loadData(data1);
    component.loadData(data2);
  });

  it('test check for state method', () =>{

    let data = {
      value : "United States"
    }
    let data1  = {
      value : "Canada"
    }
    component.checkForState(data);
    component.checkForState(data1);
    
  });

  it('test is valid sss and version selected method', ()=>{
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    component.selectedTemplates = list_of_template_response;
    component.isValidSSSAndVersionSelected(dialogRefSpyObj);
  
  });

  it('test apply oem filter method', ()=>{
    component.oemList = best_practice_response_list;
    component.applyOEMFilter("21AugBP");
  });

  it('test on focus reload oems', () =>{
    let data :{};
    component.oemList = best_practice_response_list;
    component.onFocusReloadOEMs(data);
  });

  it('populate selected templates method', () =>{
    component.bestPracticeTree.selections = {ACCT: {template: {
      platforms: {
      0: {id: null, platformName: "DRIVE", platformCode: "drive", selected: true},
      1: {id: null, platformName: "FLEX", platformCode: "flex", selected: true}
      },
      productCode: "ACCT",
      productVersion: null,
      recordType: "9ce6049f-dee8-495a-be7f-e61e2d715452",
      status: "Work in Progress",
      updatedBy: null,
      version: 0,
      vic: {firstName: "Jeff", lastName: "Grence", loginId: "jeff.grence@cdk.com", employeeId: null}
    },
    screens: [{}]
  },
    PTS: {template: {}, screens: Array(16), productCode: "PTS", nodeId: 234}};
    component.populateSelectedTemplates();
  });

  it('set store for edit method', ()=>{
    spyOn(storeService,'getFunctionalAreasOfStore').and.returnValue(Observable.of(list_of_template_response));
    component.currentProject = currentProject;
    component.setStoreForEdit(us_store);
    component.setStoreForEdit(canada_store);
    component.setStoreForEdit(other_store);
    component.currentProject = currentProjectNull;
    component.setStoreForEdit(us_store);
    component.setStoreForEdit(canada_store);
    expect(storeService.getFunctionalAreasOfStore).toHaveBeenCalledTimes(5);

  });

  it('test change company sharingA method', () =>{
    let event = {
      checked : true,
      vicType : "vic"
    }
    let event1 = {
      checked : false,
      vicType : "secondaryVic"
    }
    component.changeCompanySharingA(event1);
    component.changeCompanySharingA(event);
    component.checkEnterpriseStore(event);
    component.checkEnterpriseStore(event1);
  });

  it('test on focus reload vic method', () =>{
    let event = {
      value : "vic"
    }
    component.onFocusReloadVic(event, list_of_template_response[0], "vic");
    component.onFocusReloadVic(event, list_of_template_response[0], "secondaryVic");
    component.onChangeVicOrSecondaryVic(event, list_of_template_response[0], "vic");
  });
  
  it('display select state standards method', ()=>{
    spyOn(bestPracticeService, 'getVersionsByBestPracticeId').and.returnValue(Observable.of(best_practice_response_list));
    component.selectedTemplates = list_of_template_response;
    component.displaySelectedStateStandards();
    expect(bestPracticeService.getVersionsByBestPracticeId).toHaveBeenCalledTimes(1);
  });

  it('test on change state standard method', ()=>{
    component.selectedTemplates = list_of_template_response;
    spyOn(bestPracticeService, 'getVersionsByBestPracticeId').and.returnValue(Observable.of(best_practice_response_list));
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    let event : any = {
      value : {
        id: "id1",
        bestPracticeName : "bpName"
      }
    }
    let eventEmp : any = {
      value : ""
    }
  component.onChangeStateStandard(event, best_practice_response_list[0]);
  component.onChangeStateStandard(eventEmp, best_practice_response_list[0]);

  });

  it('test on change state standard method error case', ()=>{
    component.selectedTemplates = list_of_template_response;
    spyOn(bestPracticeService, 'getVersionsByBestPracticeId').and.returnValue(Observable.throwError('error'));
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    let event : any = {
      value : {
        id: "id1",
        bestPracticeName : "bpName"
      }
    }
  component.onChangeStateStandard(event, best_practice_response_list[0]);
  });

  it('test on change state standard version method', () =>{
    component.selectedTemplates = list_of_template_response;
    let event : any = {
      value : {
          id: "id1",
          bestPracticeName : "bpName"
        }
      }
      let eventEmp : any = {
        value : ""
      }
    component.onChangeStateStandardVersion(event, event);
    component.onChangeStateStandardVersion(eventEmp, eventEmp);
  });

  it('test apply filter on vic method', ()=>{
    let userList : any =[{
      user:{
        loginId : "myLogin"
      }
    }]
    component.usersList = userList;
    component.applyVICFilter("myLogin", "vic");
    component.applyVICFilter("myLogin", "secondaryVic");
  });

  it('test get users form common services error case', () =>{
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    spyOn(authService, 'fetchCommonServicesUsersWithDotVICRole').and.returnValue(Observable.throwError('error'));
    component.getUSersFromCommonServices();
  });

  it('test get users from common services method', () =>{
    let userList : any = [{
      user:{
        loginId : "myLogin"
      }
    }];
    component.usersList = userList;

    let selectedTemplates:TemplateObject[]=[
      {
        "functionalAreaName": "Sales",
        "functionalAreaType": null,
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Work in Progress",
        "platforms": [
          {
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true
          }
        ],
        "vic": {
          "loginId" : "myLogin",
          "firstName" : null,
          "lastName" : "last",
          "employeeId" : null
        },
        "secondaryVic":  {
          "firstName" : null,
          "lastName" : null,
          "loginId" : "myLogin",
          "employeeId" : null
        },
        "clientFunctionalAreaUser": null,
        "version": 43,
        "isFailed": null,
        "inProcess": false,
        "productCode": "SLS",
        "productVersion": null,
        "bpId": "63f38af3-92e3-4509-81b5-c59365cc7df1",
        "bpVersionId": "70766cde-1b7b-46b1-9c73-a8adf96ceac8",
        "bpTemplateId": "46675d78-a8d5-41ca-8801-c679ef00cff4",
        "isDealerApproved": false,
        "stateStandardId": "sssId",
        "stateStandardName": "sss",
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": false,
        "showValidateOrTransferButton": false,
        "showProcessValidationResultsButton": true,
        "createdDate": null,
        "lastUpdatedDate": null,
        "screenIds":null,
        "createdBy": null,
        "updatedBy": "Harika.Gajabimkar@cdk.com",
        "incorporateBpChanges": false,
        "isLocked":false,
        "storeId":null,
        "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
        "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
      }
    ]
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    component.selectedTemplates = selectedTemplates;
    spyOn(authService,'fetchCommonServicesUsersWithDotVICRole').and.returnValue(Observable.of(userList));
    component.getUSersFromCommonServices();
    expect(authService.fetchCommonServicesUsersWithDotVICRole).toHaveBeenCalledTimes(1);    
  });

  it('test get users from common services method where vic  login Id not present', () =>{
    let userList : any = [{
      user:{
        loginId : "myLogin"
      }
    }];
    component.usersList = userList;

    let selectedTemplates:TemplateObject[]=[
      {
        "functionalAreaName": "Sales",
        "functionalAreaType": null,
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Work in Progress",
        "platforms": [
          {
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true
          }
        ],
        "vic": {
          "loginId" : undefined,
          "firstName" : null,
          "lastName" : "last",
          "employeeId" : null
        },
        "secondaryVic":  {
          "firstName" : null,
          "lastName" : null,
          "loginId" : "myLogin",
          "employeeId" : null
        },
        "clientFunctionalAreaUser": null,
        "version": 43,
        "isFailed": null,
        "inProcess": false,
        "productCode": "SLS",
        "productVersion": null,
        "bpId": "63f38af3-92e3-4509-81b5-c59365cc7df1",
        "bpVersionId": "70766cde-1b7b-46b1-9c73-a8adf96ceac8",
        "bpTemplateId": "46675d78-a8d5-41ca-8801-c679ef00cff4",
        "isDealerApproved": false,
        "stateStandardId": "sssId",
        "stateStandardName": "sss",
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": false,
        "showValidateOrTransferButton": false,
        "showProcessValidationResultsButton": true,
        "createdDate": null,
        "lastUpdatedDate": null,
        "screenIds":null,
        "createdBy": null,
        "updatedBy": "Harika.Gajabimkar@cdk.com",
        "incorporateBpChanges": false,
        "isLocked":false,
        "storeId":null,
        "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
        "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
      }
    ]
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    component.selectedTemplates = selectedTemplates;
    spyOn(authService,'fetchCommonServicesUsersWithDotVICRole').and.returnValue(Observable.of(userList));
    component.getUSersFromCommonServices();
    expect(authService.fetchCommonServicesUsersWithDotVICRole).toHaveBeenCalledTimes(1);    
  });

  it('test get users from common services method where second vic  login Id not present', () =>{
    let userList : any = [{
      user:{
        loginId : "myLogin"
      }
    }];
    component.usersList = userList;

    let selectedTemplates:TemplateObject[]=[
      {
        "functionalAreaName": "Sales",
        "functionalAreaType": null,
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Work in Progress",
        "platforms": [
          {
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true
          }
        ],
        "vic": {
          "loginId" : undefined,
          "firstName" : null,
          "lastName" : "last",
          "employeeId" : null
        },
        "secondaryVic":  {
          "firstName" : null,
          "lastName" : null,
          "loginId" : undefined,
          "employeeId" : null
        },
        "clientFunctionalAreaUser": null,
        "version": 43,
        "isFailed": null,
        "inProcess": false,
        "productCode": "SLS",
        "productVersion": null,
        "bpId": "63f38af3-92e3-4509-81b5-c59365cc7df1",
        "bpVersionId": "70766cde-1b7b-46b1-9c73-a8adf96ceac8",
        "bpTemplateId": "46675d78-a8d5-41ca-8801-c679ef00cff4",
        "isDealerApproved": false,
        "stateStandardId": "sssId",
        "stateStandardName": "sss",
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": false,
        "showValidateOrTransferButton": false,
        "showProcessValidationResultsButton": true,
        "createdDate": null,
        "lastUpdatedDate": null,
        "screenIds":null,
        "createdBy": null,
        "updatedBy": "Harika.Gajabimkar@cdk.com",
        "incorporateBpChanges": false,
        "isLocked":false,
        "storeId":null,
        "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
        "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
      }
    ]
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    component.selectedTemplates = selectedTemplates;
    spyOn(authService,'fetchCommonServicesUsersWithDotVICRole').and.returnValue(Observable.of(userList));
    component.getUSersFromCommonServices();
    expect(authService.fetchCommonServicesUsersWithDotVICRole).toHaveBeenCalledTimes(1);    
  });

  it('test save store method', ()=>{
    component.currentProject = currentProject;
    component.bestPracticeTree.storeFunctionalUnits = [
      {
        templateScreen : "tempScreen"
      }
    ]
    component.selectedTemplates = list_of_template_response;
    component.storeTemplates = [
      {
        bpTemplateId : "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
      }
    ]
    component.selections = {SLS: { template: {
      platforms : {
      0: {id: null, platformName: "DRIVE", platformCode: "drive", selected: true},
      1: {id: null, platformName: "FLEX", platformCode: "flex", selected: true}
      },
      productCode : "SLS",
      productVersion: null,
      recordType: "9ce6049f-dee8-495a-be7f-e61e2d715452",
      status: "Work in Progress",
      updatedBy: null,
      version: 0,
      vic: {firstName: "Jeff", lastName: "Grence", loginId: "jeff.grence@cdk.com", employeeId: null}
    }
    }};

    component.selections["SLS"].screens = [{ autoAdded: false,
      bpPropagationCompleted: false,
      bpScreenId: null,
      copyRowData: false,
      deleted: false,
      description: "AA_fu",
      gridOptionsModel: {animatedRows: false, rowSelection: "multiple", columnDefs: Array(1)},
      id: "9ce6049f-dee8-495a-be7f-e61e2d715452",
      index: 0,
      masterScreenId: null,
      productCode: "SLS",
      recordType: "76c252aa-b3b1-4fc1-99c0-b3eb239087a3",
      rowDataEmpty: false,
      screenName: "AA_fu",
      updated: false,
      version: 0}];
    spyOn(storeService, 'saveStore').and.returnValue(Observable.of(us_store));
    spyOn(functionalAreaService, 'saveFunctionalArea').and.returnValue(Observable.of(list_of_template_response[0]));
    spyOn(storeService, 'getFunctionalAreasOfStore').and.returnValue(Observable.of(list_of_template_response));
    spyOn(functionalUnitService, 'saveFunctionalUnits').and.returnValue(Observable.of(list_of_template_response));
    
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    component.saveStore(dialogRefSpyObj);
    expect(storeService.saveStore).toHaveBeenCalledTimes(1);
    expect(functionalAreaService.saveFunctionalArea).toHaveBeenCalledTimes(1);
  });

  it('test save store method else case', ()=>{
    component.currentProject = currentProject;
    component.bestPracticeTree.storeFunctionalUnits = [
      {
        templateScreen : "tempScreen",
        bpScreenId : "76c252aa-b3b1-4fc1-99c0-b3eb239087a3"
      }
    ]
    component.selectedTemplates =list_of_template_response;
    component.storeTemplates = [
      {
        bpTemplateId : "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
      }
    ]
    component.selections = {SLS: { template: {
      platforms : {
      0: {id: null, platformName: "DRIVE", platformCode: "drive", selected: true},
      1: {id: null, platformName: "FLEX", platformCode: "flex", selected: true}
      },
      productCode : "SLS",
      productVersion: null,
      recordType: "9ce6049f-dee8-495a-be7f-e61e2d715452",
      status: "Work in Progress",
      updatedBy: null,
      version: 0,
      vic: {firstName: "Jeff", lastName: "Grence", loginId: "jeff.grence@cdk.com", employeeId: null}
    }
    }};

    component.selections["SLS"].screens = [{ autoAdded: true,
      bpPropagationCompleted: false,
      bpScreenId: null,
      copyRowData: false,
      deleted: false,
      description: "AA_fu",
      gridOptionsModel: {animatedRows: false, rowSelection: "multiple", columnDefs: Array(1)},
      id: "9ce6049f-dee8-495a-be7f-e61e2d715452",
      index: 0,
      masterScreenId: null,
      productCode: "SLS",
      recordType: "76c252aa-b3b1-4fc1-99c0-b3eb239087a3",
      rowDataEmpty: false,
      screenName: "AA_fu",
      updated: false,
      version: 0}];
    spyOn(storeService, 'saveStore').and.returnValue(Observable.of(us_store));
    spyOn(functionalAreaService, 'saveFunctionalArea').and.returnValue(Observable.of(list_of_template_response[0]));
    spyOn(storeService, 'getFunctionalAreasOfStore').and.returnValue(Observable.of(list_of_template_response));
    spyOn(functionalUnitService, 'saveFunctionalUnits');
    
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    component.saveStore(dialogRefSpyObj);
    expect(storeService.saveStore).toHaveBeenCalledTimes(1);
    expect(functionalAreaService.saveFunctionalArea).toHaveBeenCalledTimes(1);
  });

  it('test validate and save store method', ()=>{
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    component.store.storeName = "store1";
    spyOn(projectService, 'getStoresOfProject').and.returnValue(Observable.of(list_of_stores));
    component.currentProject.projectNumber = "PM525916";
    component.isEdit = false;
    spyOn(component,'isValidFunctionalAreasSelected').and.returnValue(true);
    spyOn(component,'isValidSSSAndVersionSelected').and.returnValue(true);
    spyOn(component,'saveStore');
    component.validateAndSaveTheStore();
    expect(projectService.getStoresOfProject).toHaveBeenCalledTimes(1);
  });

  it('test validate and save store method else case', ()=>{
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    component.store.storeName = "store1";
    spyOn(projectService, 'getStoresOfProject').and.returnValue(Observable.of(list_of_stores));
    component.currentProject.projectNumber = "PM525916";
    component.isEdit = true;
    spyOn(component,'isValidFunctionalAreasSelected').and.returnValue(true);
    spyOn(component,'isValidSSSAndVersionSelected').and.returnValue(true);
    spyOn(component,'saveStore');
    component.validateAndSaveTheStore();
    expect(projectService.getStoresOfProject).toHaveBeenCalledTimes(1);
  });

  it('test validate and save store method stores length zero case', ()=>{
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    component.store.storeName = "store1";
    spyOn(projectService, 'getStoresOfProject').and.returnValue(Observable.of([]));
    component.currentProject.projectNumber = "PM525916";
    component.isEdit = false;
    spyOn(component,'isValidFunctionalAreasSelected').and.returnValue(true);
    spyOn(component,'isValidSSSAndVersionSelected').and.returnValue(true);
    spyOn(component,'saveStore');
    component.validateAndSaveTheStore();
    expect(projectService.getStoresOfProject).toHaveBeenCalledTimes(1);
  });
  
  it('test close popup method', () =>{
    component.closePopup();
  });

  it('test validate name from DB method', () =>{
    component.store.storeName = "store1";
    spyOn(projectService, 'getStoresOfProject').and.returnValue(Observable.of(list_of_stores));
    component.validateNameFromDB("store1");
    expect(projectService.getStoresOfProject).toHaveBeenCalledTimes(1);
  });
  

  it('test saveStore',()=>{

    let selectedTemplates:any[]=[
      {
        "autoAdded":true,
        "functionalAreaName": "Accounting",
        "functionalAreaType": "BestPracticeFunctionalArea",
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Work in Progress",
        "platforms": [
            {
                "id": null,
                "platformName": "DRIVE",
                "platformCode": "drive",
                "selected": true
            }
        ],
        "vic": {
            "userGuid": "95B987AA7657728BE053440B6364CA78",
            "loginId": "Abraham.Joseph@cdk.com",
            "firstName": "Abraham",
            "middleInitial": null,
            "lastName": "Joseph",
            "dmsUserIdentifier": [],
            "locked": false,
            "adminNotes": null,
            "creationDate": "2019-11-01T13:14:41+0000",
            "lastLoginDate": null,
            "locale": "en_US",
            "state": 2,
            "prefix": null,
            "suffix": null,
            "nickName": null,
            "employeeId": null,
            "jobTitle": null,
            "selfServiceEnabled": 0,
            "accountStatus": "Active",
            "communicationEdgeId": "abrahamjosephcdkcom@dit.cdkcollaborate.com",
            "uniquePrincipalName": "Abraham.Joseph@cdk.com",
            "externallyFederated": true
        },
        "secondaryVic": {
            "userGuid": "A128560F646D3FA7E053440B63645B12",
            "loginId": "Amrita.das@cdk.com",
            "firstName": "Amrita",
            "middleInitial": null,
            "lastName": "das",
            "dmsUserIdentifier": [],
            "locked": false,
            "adminNotes": null,
            "creationDate": "2020-04-16T15:09:48+0000",
            "lastLoginDate": null,
            "locale": "en_US",
            "state": 2,
            "prefix": null,
            "suffix": null,
            "nickName": null,
            "employeeId": null,
            "jobTitle": null,
            "selfServiceEnabled": 0,
            "accountStatus": "Active",
            "communicationEdgeId": "amritadascdkcom@dit.cdkcollaborate.com",
            "uniquePrincipalName": "Amrita.das@cdk.com",
            "externallyFederated": true
        },
        "clientFunctionalAreaUser": null,
        "version": 19,
        "isFailed": null,
        "inProcess": false,
        "productCode": "ACCT",
        "productVersion": null,
        "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
        "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
        "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
        "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
        "isDealerApproved": false,
        "stateStandardId": null,
        "stateStandardName": null,
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": false,
        "showValidateOrTransferButton": false,
        "showProcessValidationResultsButton": true,
        "createdDate": null,
        "lastUpdatedDate": null,
        "createdBy": null,
        "updatedBy": null,
        "incorporateBpChanges": false,
        "locked": false,
        "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
        "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
        "selectedVic": {},
        "selectedsecondaryVic": {}
    }
    ]
    component.selectedTemplates = selectedTemplates;

    component.bestPracticeTree.storeFunctionalUnits = [
      {
        screenName:'AccountPayable'
      }
    ]
    let loaderDialogRef:any={
      close
    }
    function close(){

    }

    let storeTemplates:any[]=[
      {
        bpTemplateId:'305e00b1-a4f7-42dc-ad70-5885730756e6',
        recordType:'305e00b1-a4f7-42dc-ad70-5885730756e6',
        "stateStandardId": 'SS123',
        "stateStandardName": 'TestSSS',
        "stateStandardVersionRecordType": '455e00b1-a4f7-42dc-ad70-5885730756e6',
        "stateStandardVersionName":'2021'
      }
    ]
    component.storeTemplates = storeTemplates;

    let selections:any={
      ACCT:{
        screens:[
          {
            'autoAdded': false,
            'bpPropagationCompleted': false,
            'bpScreenId': null,
            'copyRowData': false,
            'deleted': false,
            'description': "Accounts Payable",
            'id': "305e00b1-a4f7-42dc-ad70-5885730756e6",
            'index': 0,
            'masterScreenId': null,
            'productCode': "ACCT",
            'recordType': "519dcbc5-6d64-4629-8b6d-41f4e9200ff4",
            'rowDataEmpty': false,
            'screenName': "Accounts Payable",
            'updated': false,
            'version': 0

          }
        ]
      }
    }
    let storeData:any={
      recordType:'955e00b1-a4f7-42dc-ad70-5885730756e6'
    }
    let templates:any[] = [
      {
        'productCode': "ACCT",
        'recordType':'305e00b1-a4f7-42dc-ad70-5885730756e6'
      }
    ]
    component.selections = selections;
    spyOn(storeService,'saveStore').and.returnValue(Observable.of(storeData));
    spyOn(functionalAreaService,'saveFunctionalArea').and.returnValue(Observable.of({}));
    spyOn(storeService,'getFunctionalAreasOfStore').and.returnValue(Observable.of(templates));
 
    let saveFU:any={}
    spyOn(functionalUnitService,'saveFunctionalUnits').and.returnValue(Observable.of(saveFU));
    
    component.saveStore(loaderDialogRef)

    expect(storeService.saveStore).toHaveBeenCalledTimes(1);
    expect(functionalAreaService.saveFunctionalArea).toHaveBeenCalledTimes(1);
    expect(storeService.getFunctionalAreasOfStore).toHaveBeenCalledTimes(1);
  });

  it('test saveStore if screen autoAdded if false',()=>{

    let selectedTemplates:any[]=[
      {
        "autoAdded":true,
        "functionalAreaName": "Accounting",
        "functionalAreaType": "BestPracticeFunctionalArea",
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Work in Progress",
        "platforms": [
            {
                "id": null,
                "platformName": "DRIVE",
                "platformCode": "drive",
                "selected": true
            }
        ],
        "vic": {
            "userGuid": "95B987AA7657728BE053440B6364CA78",
            "loginId": "Abraham.Joseph@cdk.com",
            "firstName": "Abraham",
            "middleInitial": null,
            "lastName": "Joseph",
            "dmsUserIdentifier": [],
            "locked": false,
            "adminNotes": null,
            "creationDate": "2019-11-01T13:14:41+0000",
            "lastLoginDate": null,
            "locale": "en_US",
            "state": 2,
            "prefix": null,
            "suffix": null,
            "nickName": null,
            "employeeId": null,
            "jobTitle": null,
            "selfServiceEnabled": 0,
            "accountStatus": "Active",
            "communicationEdgeId": "abrahamjosephcdkcom@dit.cdkcollaborate.com",
            "uniquePrincipalName": "Abraham.Joseph@cdk.com",
            "externallyFederated": true
        },
        "secondaryVic": {
            "userGuid": "A128560F646D3FA7E053440B63645B12",
            "loginId": "Amrita.das@cdk.com",
            "firstName": "Amrita",
            "middleInitial": null,
            "lastName": "das",
            "dmsUserIdentifier": [],
            "locked": false,
            "adminNotes": null,
            "creationDate": "2020-04-16T15:09:48+0000",
            "lastLoginDate": null,
            "locale": "en_US",
            "state": 2,
            "prefix": null,
            "suffix": null,
            "nickName": null,
            "employeeId": null,
            "jobTitle": null,
            "selfServiceEnabled": 0,
            "accountStatus": "Active",
            "communicationEdgeId": "amritadascdkcom@dit.cdkcollaborate.com",
            "uniquePrincipalName": "Amrita.das@cdk.com",
            "externallyFederated": true
        },
        "clientFunctionalAreaUser": null,
        "version": 19,
        "isFailed": null,
        "inProcess": false,
        "productCode": "ACCT",
        "productVersion": null,
        "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
        "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
        "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
        "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
        "isDealerApproved": false,
        "stateStandardId": null,
        "stateStandardName": null,
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": false,
        "showValidateOrTransferButton": false,
        "showProcessValidationResultsButton": true,
        "createdDate": null,
        "lastUpdatedDate": null,
        "createdBy": null,
        "updatedBy": null,
        "incorporateBpChanges": false,
        "locked": false,
        "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
        "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
        "selectedVic": {},
        "selectedsecondaryVic": {}
    }
    ]
    component.selectedTemplates = selectedTemplates;

    component.bestPracticeTree.storeFunctionalUnits = [
      {
        screenName:'AccountPayable',
        bpScreenId:'519dcbc5-6d64-4629-8b6d-41f4e9200ff4',

      }
    ]
    let loaderDialogRef:any={
      close
    }
    function close(){

    }

    let storeTemplates:any[]=[
      {
        bpTemplateId:'305e00b1-a4f7-42dc-ad70-5885730756e6',
        recordType:'305e00b1-a4f7-42dc-ad70-5885730756e6',
        "stateStandardId": 'SS123',
        "stateStandardName": 'TestSSS',
        "stateStandardVersionRecordType": '455e00b1-a4f7-42dc-ad70-5885730756e6',
        "stateStandardVersionName":'2021'
      }
    ]
    component.storeTemplates = storeTemplates;

    let selections:any={
      ACCT:{
        screens:[
          {
            'autoAdded': true,
            'bpPropagationCompleted': false,
            'bpScreenId': null,
            'copyRowData': false,
            'deleted': false,
            'description': "Accounts Payable",
            'id': "305e00b1-a4f7-42dc-ad70-5885730756e6",
            'index': 0,
            'masterScreenId': null,
            'productCode': "ACCT",
            'recordType': "519dcbc5-6d64-4629-8b6d-41f4e9200ff4",
            'rowDataEmpty': false,
            'screenName': "Accounts Payable",
            'updated': false,
            'version': 0

          }
        ]
      }
    }
    let storeData:any={
      recordType:'955e00b1-a4f7-42dc-ad70-5885730756e6'
    }
    let templates:any[] = [
      {
        'productCode': "ACCT",
        'recordType':'305e00b1-a4f7-42dc-ad70-5885730756e6'
      }
    ]
    component.selections = selections;
    spyOn(storeService,'saveStore').and.returnValue(Observable.of(storeData));
    spyOn(functionalAreaService,'saveFunctionalArea').and.returnValue(Observable.of({}));
    spyOn(storeService,'getFunctionalAreasOfStore').and.returnValue(Observable.of(templates));
 
    let saveFU:any={}
    spyOn(functionalUnitService,'saveFunctionalUnits').and.returnValue(Observable.of(saveFU));
    
    component.saveStore(loaderDialogRef);
    expect(storeService.saveStore).toHaveBeenCalledTimes(1);
    expect(functionalAreaService.saveFunctionalArea).toHaveBeenCalledTimes(1);
    expect(storeService.getFunctionalAreasOfStore).toHaveBeenCalledTimes(1);
  });


 it('test saveStore no screens to save',()=>{

    let selectedTemplates:any[]=[
      {
        "autoAdded":true,
        "functionalAreaName": "Accounting",
        "functionalAreaType": "BestPracticeFunctionalArea",
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Work in Progress",
        "platforms": [
            {
                "id": null,
                "platformName": "DRIVE",
                "platformCode": "drive",
                "selected": true
            }
        ],
        "vic": {
            "userGuid": "95B987AA7657728BE053440B6364CA78",
            "loginId": "Abraham.Joseph@cdk.com",
            "firstName": "Abraham",
            "middleInitial": null,
            "lastName": "Joseph",
            "dmsUserIdentifier": [],
            "locked": false,
            "adminNotes": null,
            "creationDate": "2019-11-01T13:14:41+0000",
            "lastLoginDate": null,
            "locale": "en_US",
            "state": 2,
            "prefix": null,
            "suffix": null,
            "nickName": null,
            "employeeId": null,
            "jobTitle": null,
            "selfServiceEnabled": 0,
            "accountStatus": "Active",
            "communicationEdgeId": "abrahamjosephcdkcom@dit.cdkcollaborate.com",
            "uniquePrincipalName": "Abraham.Joseph@cdk.com",
            "externallyFederated": true
        },
        "secondaryVic": {
            "userGuid": "A128560F646D3FA7E053440B63645B12",
            "loginId": "Amrita.das@cdk.com",
            "firstName": "Amrita",
            "middleInitial": null,
            "lastName": "das",
            "dmsUserIdentifier": [],
            "locked": false,
            "adminNotes": null,
            "creationDate": "2020-04-16T15:09:48+0000",
            "lastLoginDate": null,
            "locale": "en_US",
            "state": 2,
            "prefix": null,
            "suffix": null,
            "nickName": null,
            "employeeId": null,
            "jobTitle": null,
            "selfServiceEnabled": 0,
            "accountStatus": "Active",
            "communicationEdgeId": "amritadascdkcom@dit.cdkcollaborate.com",
            "uniquePrincipalName": "Amrita.das@cdk.com",
            "externallyFederated": true
        },
        "clientFunctionalAreaUser": null,
        "version": 19,
        "isFailed": null,
        "inProcess": false,
        "productCode": "ACCT",
        "productVersion": null,
        "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
        "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
        "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
        "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
        "isDealerApproved": false,
        "stateStandardId": null,
        "stateStandardName": null,
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": false,
        "showValidateOrTransferButton": false,
        "showProcessValidationResultsButton": true,
        "createdDate": null,
        "lastUpdatedDate": null,
        "createdBy": null,
        "updatedBy": null,
        "incorporateBpChanges": false,
        "locked": false,
        "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
        "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
        "selectedVic": {},
        "selectedsecondaryVic": {}
    }
    ]
    component.selectedTemplates = selectedTemplates;

    component.bestPracticeTree.storeFunctionalUnits = [
      {
        screenName:'AccountPayable',
        bpScreenId:'519dcbc5-6d64-4629-8b6d-41f4e9200ff4',

      }
    ]
    let loaderDialogRef:any={
      close
    }
    function close(){}

    let storeTemplates:any[]=[
      {
        bpTemplateId:'305e00b1-a4f7-42dc-ad70-5885730756e6',
        recordType:'305e00b1-a4f7-42dc-ad70-5885730756e6',
        "stateStandardId": 'SS123',
        "stateStandardName": 'TestSSS',
        "stateStandardVersionRecordType": '455e00b1-a4f7-42dc-ad70-5885730756e6',
        "stateStandardVersionName":'2021'
      }
    ]
    component.storeTemplates = storeTemplates;

    let selections:any={
      ACCT:{
        screens:[]
      }
    }
    let storeData:any={
      recordType:'955e00b1-a4f7-42dc-ad70-5885730756e6'
    }
    let templates:any[] = []
    component.selections = selections;
    spyOn(storeService,'saveStore').and.returnValue(Observable.of(storeData));
    spyOn(functionalAreaService,'saveFunctionalArea').and.returnValue(Observable.of({}));
    spyOn(storeService,'getFunctionalAreasOfStore').and.returnValue(Observable.of(templates));
 
    let saveFU:any[]=[]
    spyOn(functionalUnitService,'saveFunctionalUnits').and.returnValue(Observable.empty);
    
    component.saveStore(loaderDialogRef);
    expect(storeService.saveStore).toHaveBeenCalledTimes(1);
    expect(functionalAreaService.saveFunctionalArea).toHaveBeenCalledTimes(1);
    expect(storeService.getFunctionalAreasOfStore).toHaveBeenCalledTimes(1);
    expect(functionalUnitService.saveFunctionalUnits).toHaveBeenCalledTimes(0);
  });

})

describe('AddStoreComponent for add store', () =>{
  let component : AddStoreComponent;
  let fixture : ComponentFixture<AddStoreComponent>;
  let storeService : StoreService;
  let authService : AuthService;
  let bestPracticeService : BestPracticeService;
  let projectService : ProjectService;
  let functionalAreaService : FunctionalAreaService;
  let functionalUnitService : FunctionalUnitService;
  let launchDarklyService : LaunchDarklyService;
  let _formBuilder : FormBuilder;
  let bestPracticeTree : BestPracticeTree;
  let routerStub : Router;

  class MatDialogMock {
      open() {
        return {
          afterClosed: () => Observable.of(true)
        };
      }
    };

  const dialogMock = {
    close: () => { }
    };
  
  class MockRouter {
    navigateByUrl(url: string) { return url; }
  }
  const testUrl  = 'projects/PM525916';
  beforeEach(async(() =>{
    let mockRouter = {
        navigate: jasmine.createSpy('navigateByUrl')
    }
    let data = {
      project : {
        "isProject": 1,
        "enterpriseId": "172935",
        "projectNumber": "PM525916",
        "dealerName": "CDK Automation",
        "location": null,
        "storeIds":null,
        "platform": {
          "platformName": "DRIVE",
          "platformCode": "drive",
          "selected": false
        },
        "status": "OPEN",
        "clientManager": null,
        "vic": null,
        "css": null,
        "projectManager": null,
        "language": null,
        "country": null,
        "timezone": null,
        "cdku": false,
        "cdku_coordinator": null,
        "cdku_domain": null,
        "cdku_division": null,
        "cdku_login": null,
        "cdku_password": null,
        "clientProjectAdvocate": null,
        "version": 0,
        "failed": false,
        "projectSourceEnv": null,
        "dealerApproverContact": null,
        "dealerApproverRequired": false,
        "createdDate": null,
        "lastUpdatedDate": null,
        "createdBy": "dotdemouser3@cdk.com",
        "updatedBy": "dotdemouser3@cdk.com",
        "id": "9d3508f7-c0d9-408f-b575-5dd0bf83629b",
        "recordType": "ProjectInfo"
      },
      storeRecordType : "9faa4afb-d7c5-479b-aa8a-3a3d8faaab86",
      addStore : true
    }
  const storeServiceSpy = jasmine.createSpyObj('StoreService',
  ['getStore','getFunctionalAreasOfStore', 'saveStore']);

  const bpServiceSpy = jasmine.createSpyObj('BestPracticeService',['getAllBestPracticesByPlatform','getAllBestPracticesByType']);
  TestBed.configureTestingModule({
      imports:[
          MatCardModule,
          MatFormFieldModule,
          MatInputModule,
          CdkTableModule,
          ToastrModule.forRoot(),
          CommonModule,
          MatPaginatorModule,
          MatDialogModule,
          MatSelectModule,
          MatCheckboxModule,
          MatSortModule,
          MatIconModule,
          MatStepperModule,
          MatOptionModule,
          MatListModule,
          FormsModule,
          ReactiveFormsModule,
          MatMenuModule,
          MatDividerModule,
          MatProgressSpinnerModule,
          HttpClientTestingModule,
          NoopAnimationsModule,
          TreeModule,
          MatDialogModule,
          RouterModule.forRoot([])


          
      ],
      declarations : [
          AddStoreComponent, LoaderDialogueComponent, BestPracticeTree
      ],
      providers:[
          StoreService, ProjectService, AuthService, BestPracticeService, FunctionalAreaService, FunctionalUnitService, 
          ToastrService, LaunchDarklyService,
          { provide: Router, useClass: MockRouter },
          { provide: MAT_DIALOG_DATA, useValue: data },
          { provide: MatDialogRef, useValue: dialogMock }
      ]
  }).overrideModule(BrowserDynamicTestingModule,
      { set: { entryComponents: [LoaderDialogueComponent,AddStoreComponent, BestPracticeTree]}});
      authService = TestBed.get(AuthService);
      storeService = TestBed.get(StoreService);
      projectService = TestBed.get(ProjectService);
      bestPracticeService = TestBed. get(BestPracticeService);
      functionalAreaService = TestBed.get(FunctionalAreaService);
      functionalUnitService = TestBed.get(FunctionalUnitService);
      routerStub = TestBed.get(Router);

  }));   
  beforeEach(() =>{
      fixture = TestBed.createComponent(AddStoreComponent);
      component = fixture.componentInstance;
      _formBuilder = TestBed.get(FormBuilder); 
      component.firstFormGroup = _formBuilder.group({ 
        recipientTypes: new FormControl(
        {
            value: ["mock"],
            disabled: true
        },
        Validators.required
        )
        });
        component.secondFormGroup = _formBuilder.group({ 
            recipientTypes: new FormControl(
            {
                value: ["mock"],
                disabled: true
            },
            Validators.required
            )
            });
      fixture.detectChanges();
  })

  const mock_bp_response : any ={
    "isBestPractice": 1,
    "isSSS": 0,
    "bestPracticeName": "21AugBP",
    "platform": {
      "id": null,
      "platformName": "FLEX",
      "platformCode": "flex",
      "selected": true
    },
    "versionCount": 0,
    "version": 0,
    "failed": false,
    "id": "baa890d3-28bf-4ca7-942c-2488a033adab",
    "recordType": "BestPracticeInfo"
  }
  const best_practice_response_list : BestPracticeObject[] = [

        {
          "isBestPractice": 1,
          "isSSS": 0,
          "bestPracticeName": "21AugBP",
          "platform": {
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true
          },
          "version": 0,
          "failed": false,
          "id": "baa890d3-28bf-4ca7-942c-2488a033adab",
          "recordType": "BestPracticeInfo"
        }
  ];

  const us_store : any ={
    "storeName": "test8",
    "streetAddress": "hyd",
    "city": "hyd",
    "province": "Alabama",
    "zipcode": "45678",
    "glCompanyNumber": "400",
    "logonName": "AGNI",
    "sharedLogonName": "AGNI",
    "clientStoreAdvocate": null,
    "language": null,
    "country": "United States",
    "timezone": null,
    "cdku_coordinator": null,
    "oem": null,
    "businessPhone": null,
    "enterpriseStore": false,
    "activeVersion": false,
    "ipAddress": "207.186.134.120",
    "dmsCNumber": "C300539",
    "cmfNumber": "C300539",
    "url": null,
    "storeNumber": null,
    "locked": true,
    "id": "9d3508f7-c0d9-408f-b575-5dd0bf83629b",
    "recordType": "9faa4afb-d7c5-479b-aa8a-3a3d8faaab86"
  }


  const storeObject: StoreObject={
    "storeId" : "S000000000",	
      "storeName": "SWANSON FAHRNEY FORD",
      "streetAddress": "3105 HIGHLAND AVE",
      "city": "SELMA",
      "province": "California",
      "zipcode": "93662",
      "templateIds":null,
      "projectId":'123',
      "glCompanyNumber": "5",
      "logonName": "FF-FI",
      "sharedLogonName": null,
      "clientStoreAdvocate": null,
      "language": "en_US",
      "country": "United States",
      "timezone": "UTC-6: Central Standard Time (CST)",
      "cdku_coordinator": null,
      "oem": null,
      "businessPhone": null,
      "enterpriseStore": false,
      "ipAddress": "207.187.74.84",
      "dmsCNumber": "C208605",
      "cmfNumber": "05236540",
      "url": null,
      "storeNumber": null,
      "createdDate": null,
      "lastUpdatedDate": null,
      "createdBy": "Ravi.Musinada@cdk.com",
      "updatedBy": "Ravi.Musinada@cdk.com",
      "locked": false,
      "id": "d6111967-f46e-4bf1-99f7-d877f8655872",
      "recordType": "26573770-757a-42c3-8e11-307f6e8051ac"

  }


  let canada_store : any = {
    "country" : "Canada",
    "id": "9d3508f7-c0d9-408f-b575-5dd0bf83629b",
    "recordType": "9faa4afb-d7c5-479b-aa8a-3a3d8faaab86",
    "locked" : true,
    "sharedLogonName": "AGNI"
  }

  const list_of_stores : any =[{
    "country" : "Canada",
    "id": "9d3508f7-c0d9-408f-b575-5dd0bf83629b",
    "recordType": "9faa4afb-d7c5-479b-aa8a-3a3d8faaab86",
    "locked" : true,
    "sharedLogonName": "AGNI",
    "storeName" : "store1"
  }]

  let other_store : any = {
    "country" : "Other",
    "id": "9d3508f7-c0d9-408f-b575-5dd0bf83629b",
    "recordType": "9faa4afb-d7c5-479b-aa8a-3a3d8faaab86",
    "locked" : true,
    "sharedLogonName": "AGNI"
  }

  const list_of_master_functional_are_response: MasterFunctionalArea[] =[
    {
        "functionalAreaType": "MasterFunctionalArea",
        "functionalAreaName": "FATestToday",
        "oemName": null,
        "platforms": [
          {
            "id": null,
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true,
            "recordType":null

          }
        ],
        "productCode": "ACCT",
        "productVersion": "1",
        "noOfFunctionalUnits": null,
        "version": "0",
        "propagationStarted": false,
        "id": "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
        "recordType": "FunctionalAreaInfo"
      }
  ]

  const list_of_template_response: TemplateObject[] =[
    {
      "functionalAreaName": "Sales",
      "functionalAreaType": null,
      "oemName": null,
      "clientSignoffDate": null,
      "selected": false,
      "status": "Work in Progress",
      "platforms": [
        {
          "platformName": "FLEX",
          "platformCode": "flex",
          "selected": true
        }
      ],
      "vic": {
        "loginId" : "myLogin",
        "firstName" : null,
        "lastName" : "last",
        "employeeId" : null
      },
      "secondaryVic":  {
        "firstName" : null,
        "lastName" : null,
        "loginId" : "myLogin",
        "employeeId" : null
      },
      "clientFunctionalAreaUser": null,
      "version": 43,
      "isFailed": null,
      "inProcess": false,
      "productCode": "SLS",
      "productVersion": null,
      "bpId": "63f38af3-92e3-4509-81b5-c59365cc7df1",
      "bpVersionId": "70766cde-1b7b-46b1-9c73-a8adf96ceac8",
      "bpTemplateId": "46675d78-a8d5-41ca-8801-c679ef00cff4",
      "isDealerApproved": false,
      "stateStandardId": "sssId",
      "stateStandardName": "sss",
      "stateStandardVersionRecordType": null,
      "stateStandardVersionName": null,
      "copyRowData": false,
      "showValidateOrTransferButton": false,
      "showProcessValidationResultsButton": true,
      "createdDate": null,
      "lastUpdatedDate": null,
      "screenIds":null,
      "createdBy": null,
      "updatedBy": "Harika.Gajabimkar@cdk.com",
      "incorporateBpChanges": false,
      "isLocked":false,
      "storeId":null,
      "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
      "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
    }
];

const currentProject: ProjectObject = {
    "isProject": 1,
    "enterpriseId": "172935",
    "projectNumber": "PM525916",
    "dealerName": "CDK Automation",
    "location": null,
    "storeIds":null,
    "platform": {
      "platformName": "DRIVE",
      "platformCode": "drive",
      "selected": false
    },
    "status": "OPEN",
    "clientManager": null,
    "vic": null,
    "css": null,
    "projectManager": null,
    "language": null,
    "country": "Other",
    "timezone": null,
    "cdku": false,
    "cdku_coordinator": null,
    "cdku_domain": null,
    "cdku_division": null,
    "cdku_login": null,
    "cdku_password": null,
    "clientProjectAdvocate": null,
    "version": 0,
    "failed": false,
    "projectSourceEnv": null,
    "dealerApproverContact": null,
    "dealerApproverRequired": false,
    "createdDate": null,
    "lastUpdatedDate": null,
    "createdBy": "dotdemouser3@cdk.com",
    "updatedBy": "dotdemouser3@cdk.com",
    "id": "9d3508f7-c0d9-408f-b575-5dd0bf83629b",
    "recordType": "ProjectInfo"

};

const currentProjectNull: any = {
  "isProject": 1,
  "enterpriseId": "172935",
  "projectNumber": "PM525916",
  "platform": {
    "platformName": "DRIVE",
    "platformCode": "drive",
    "selected": false
  },
  "status": "OPEN",
  "clientManager": null,
  "vic": null,
  "css": null,
  "projectManager": null,
  "language": null,
  "country": null,      
  "id": "9d3508f7-c0d9-408f-b575-5dd0bf83629b",
  "recordType": "ProjectInfo"
};

it('test ng init method', async() =>{
    
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  spyOn(authService, 'isAuthorised').and.returnValue(false);
  spyOn(storeService, 'getStore').and.returnValue(Observable.of(storeObject));
  spyOn(bestPracticeService,'getAllBestPracticesByPlatform').and.returnValue(Observable.of(best_practice_response_list));
  spyOn(bestPracticeService,'getAllBestPracticesByType').and.returnValue(Observable.of(best_practice_response_list));
  best_practice_response_list[0].platform.platformName = "FLEX";
  component.stateStandardFlagStatus.current = true;
  component.currentProject = currentProject;
  component.store = new StoreObject;
  component.ngOnInit();
  
}); 	

it('test are valid functional areas selected method', async() =>{
    component.selections = {ACCT: {template: {
      platforms: {
      0: {id: null, platformName: "DRIVE", platformCode: "drive", selected: true},
      1: {id: null, platformName: "FLEX", platformCode: "flex", selected: true}
      },
      productCode: "ACCT",
      productVersion: null,
      recordType: "9ce6049f-dee8-495a-be7f-e61e2d715452",
      status: "Work in Progress",
      updatedBy: null,
      version: 0,
      vic: {firstName: "Jeff", lastName: "Grence", loginId: "jeff.grence@cdk.com", employeeId: null}
    },
    screens: [{}]
  },
    PTS: {template: {}, screens: Array(16), nodeId: 234}};
  component.selections["ACCT"].screens.length = 0;
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    component.isValidFunctionalAreasSelected(dialogRefSpyObj);
});

it('test load data method',() =>{
  component.stateStandardFlagStatus = true;
  spyOn(bestPracticeService, 'getAllBestPracticesByPlatform').and.returnValue(Observable.of(best_practice_response_list));
  spyOn(component,'getUSersFromCommonServices');
  let data = {
    selectedIndex : 0 
  }
  let data1 = {
    selectedIndex : 1
  }
  let data2 = {
    selectedIndex : 2
  }
  component.loadData(data);
  component.loadData(data1);
  component.loadData(data2);
});

it('test check for state method', () =>{

  let data = {
    value : "United States"
  }
  let data1  = {
    value : "Canada"
  }
  component.checkForState(data);
  component.checkForState(data1);
  
});

it('test is valid sss and version selected method', ()=>{
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  component.selectedTemplates = list_of_template_response;
  component.isValidSSSAndVersionSelected(dialogRefSpyObj);

});

it('test apply oem filter method', ()=>{
  component.oemList = best_practice_response_list;
  component.applyOEMFilter("21AugBP");
});

it('test on focus reload oems', () =>{
  let data :{};
  component.oemList = best_practice_response_list;
  component.onFocusReloadOEMs(data);
});

it('populate selected templates method', () =>{
  component.bestPracticeTree.selections = {ACCT: {template: {
    platforms: {
    0: {id: null, platformName: "DRIVE", platformCode: "drive", selected: true},
    1: {id: null, platformName: "FLEX", platformCode: "flex", selected: true}
    },
    productCode: "ACCT",
    productVersion: null,
    recordType: "9ce6049f-dee8-495a-be7f-e61e2d715452",
    status: "Work in Progress",
    updatedBy: null,
    version: 0,
    vic: {firstName: "Jeff", lastName: "Grence", loginId: "jeff.grence@cdk.com", employeeId: null}
  },
  screens: [{}]
},
  PTS: {template: {}, screens: Array(16), productCode: "PTS", nodeId: 234}};
  component.populateSelectedTemplates();
});

it('set store for edit method', ()=>{
  spyOn(storeService,'getFunctionalAreasOfStore').and.returnValue(Observable.of(list_of_template_response));
  component.currentProject = currentProject;
  component.setStoreForEdit(us_store);
  component.setStoreForEdit(canada_store);
  component.setStoreForEdit(other_store);
  component.currentProject = currentProjectNull;
  component.setStoreForEdit(us_store);
  component.setStoreForEdit(canada_store);
  expect(storeService.getFunctionalAreasOfStore).toHaveBeenCalledTimes(5);

});

it('pre populate store info method', () =>{
  component.prePopulateStoreInfo(storeObject);
})


it('test change company sharingA method', () =>{
  let event = {
    checked : true,
    vicType : "vic"
  }
  let event1 = {
    checked : false,
    vicType : "secondaryVic"
  }
  component.changeCompanySharingA(event1);
  component.changeCompanySharingA(event);
  component.checkEnterpriseStore(event);
  component.checkEnterpriseStore(event1);
});

it('test on focus reload vic method', () =>{
  let event = {
    value : "vic"
  }
  component.onFocusReloadVic(event, list_of_template_response[0], "vic");
  component.onFocusReloadVic(event, list_of_template_response[0], "secondaryVic");
  component.onChangeVicOrSecondaryVic(event, list_of_template_response[0], "vic");
});

it('display select state standards method', ()=>{
  spyOn(bestPracticeService, 'getVersionsByBestPracticeId').and.returnValue(Observable.of(best_practice_response_list));
  component.selectedTemplates = list_of_template_response;
  component.displaySelectedStateStandards();
  expect(bestPracticeService.getVersionsByBestPracticeId).toHaveBeenCalledTimes(1);
});

it('test on change state standard method', ()=>{
  component.selectedTemplates = list_of_template_response;
  spyOn(bestPracticeService, 'getVersionsByBestPracticeId').and.returnValue(Observable.of(best_practice_response_list));
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  let event : any = {
    value : {
      id: "id1",
      bestPracticeName : "bpName"
    }
  }
  let eventEmp : any = {
    value : ""
  }
component.onChangeStateStandard(event, best_practice_response_list[0]);
component.onChangeStateStandard(eventEmp, best_practice_response_list[0]);

});

it('test on change state standard method error case', ()=>{
  component.selectedTemplates = list_of_template_response;
  spyOn(bestPracticeService, 'getVersionsByBestPracticeId').and.returnValue(Observable.throwError('error'));
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  let event : any = {
    value : {
      id: "id1",
      bestPracticeName : "bpName"
    }
  }
component.onChangeStateStandard(event, best_practice_response_list[0]);
});

it('test on change state standard version method', () =>{
  component.selectedTemplates = list_of_template_response;
  let event : any = {
    value : {
        id: "id1",
        bestPracticeName : "bpName"
      }
    }
    let eventEmp : any = {
      value : ""
    }
  component.onChangeStateStandardVersion(event, event);
  component.onChangeStateStandardVersion(eventEmp, eventEmp);
});

it('test apply filter on vic method', ()=>{
  let userList : any =[{
    user:{
      loginId : "myLogin"
    }
  }]
  component.usersList = userList;
  component.applyVICFilter("myLogin", "vic");
  component.applyVICFilter("myLogin", "secondaryVic");
});

it('test get users form common services error case', () =>{
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  spyOn(authService, 'fetchCommonServicesUsersWithDotVICRole').and.returnValue(Observable.throwError('error'));
  component.getUSersFromCommonServices();
});

it('test get users from common services method', () =>{
  let userList : any = [{
    user:{
      loginId : "myLogin"
    }
  }];
  component.usersList = userList;

  let selectedTemplates:TemplateObject[]=[
    {
      "functionalAreaName": "Sales",
      "functionalAreaType": null,
      "oemName": null,
      "clientSignoffDate": null,
      "selected": false,
      "status": "Work in Progress",
      "platforms": [
        {
          "platformName": "FLEX",
          "platformCode": "flex",
          "selected": true
        }
      ],
      "vic": {
        "loginId" : "myLogin",
        "firstName" : null,
        "lastName" : "last",
        "employeeId" : null
      },
      "secondaryVic":  {
        "firstName" : null,
        "lastName" : null,
        "loginId" : "myLogin",
        "employeeId" : null
      },
      "clientFunctionalAreaUser": null,
      "version": 43,
      "isFailed": null,
      "inProcess": false,
      "productCode": "SLS",
      "productVersion": null,
      "bpId": "63f38af3-92e3-4509-81b5-c59365cc7df1",
      "bpVersionId": "70766cde-1b7b-46b1-9c73-a8adf96ceac8",
      "bpTemplateId": "46675d78-a8d5-41ca-8801-c679ef00cff4",
      "isDealerApproved": false,
      "stateStandardId": "sssId",
      "stateStandardName": "sss",
      "stateStandardVersionRecordType": null,
      "stateStandardVersionName": null,
      "copyRowData": false,
      "showValidateOrTransferButton": false,
      "showProcessValidationResultsButton": true,
      "createdDate": null,
      "lastUpdatedDate": null,
      "screenIds":null,
      "createdBy": null,
      "updatedBy": "Harika.Gajabimkar@cdk.com",
      "incorporateBpChanges": false,
      "isLocked":false,
      "storeId":null,
      "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
      "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
    }
  ]
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  component.selectedTemplates = selectedTemplates;
  spyOn(authService,'fetchCommonServicesUsersWithDotVICRole').and.returnValue(Observable.of(userList));
  component.getUSersFromCommonServices();
  expect(authService.fetchCommonServicesUsersWithDotVICRole).toHaveBeenCalledTimes(1);    
});

it('test get users from common services method where vic  login Id not present', () =>{
  let userList : any = [{
    user:{
      loginId : "myLogin"
    }
  }];
  component.usersList = userList;

  let selectedTemplates:TemplateObject[]=[
    {
      "functionalAreaName": "Sales",
      "functionalAreaType": null,
      "oemName": null,
      "clientSignoffDate": null,
      "selected": false,
      "status": "Work in Progress",
      "platforms": [
        {
          "platformName": "FLEX",
          "platformCode": "flex",
          "selected": true
        }
      ],
      "vic": {
        "loginId" : undefined,
        "firstName" : null,
        "lastName" : "last",
        "employeeId" : null
      },
      "secondaryVic":  {
        "firstName" : null,
        "lastName" : null,
        "loginId" : "myLogin",
        "employeeId" : null
      },
      "clientFunctionalAreaUser": null,
      "version": 43,
      "isFailed": null,
      "inProcess": false,
      "productCode": "SLS",
      "productVersion": null,
      "bpId": "63f38af3-92e3-4509-81b5-c59365cc7df1",
      "bpVersionId": "70766cde-1b7b-46b1-9c73-a8adf96ceac8",
      "bpTemplateId": "46675d78-a8d5-41ca-8801-c679ef00cff4",
      "isDealerApproved": false,
      "stateStandardId": "sssId",
      "stateStandardName": "sss",
      "stateStandardVersionRecordType": null,
      "stateStandardVersionName": null,
      "copyRowData": false,
      "showValidateOrTransferButton": false,
      "showProcessValidationResultsButton": true,
      "createdDate": null,
      "lastUpdatedDate": null,
      "screenIds":null,
      "createdBy": null,
      "updatedBy": "Harika.Gajabimkar@cdk.com",
      "incorporateBpChanges": false,
      "isLocked":false,
      "storeId":null,
      "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
      "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
    }
  ]
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  component.selectedTemplates = selectedTemplates;
  spyOn(authService,'fetchCommonServicesUsersWithDotVICRole').and.returnValue(Observable.of(userList));
  component.getUSersFromCommonServices();
  expect(authService.fetchCommonServicesUsersWithDotVICRole).toHaveBeenCalledTimes(1);    
});

it('test get users from common services method where second vic  login Id not present', () =>{
  let userList : any = [{
    user:{
      loginId : "myLogin"
    }
  }];
  component.usersList = userList;

  let selectedTemplates:TemplateObject[]=[
    {
      "functionalAreaName": "Sales",
      "functionalAreaType": null,
      "oemName": null,
      "clientSignoffDate": null,
      "selected": false,
      "status": "Work in Progress",
      "platforms": [
        {
          "platformName": "FLEX",
          "platformCode": "flex",
          "selected": true
        }
      ],
      "vic": {
        "loginId" : undefined,
        "firstName" : null,
        "lastName" : "last",
        "employeeId" : null
      },
      "secondaryVic":  {
        "firstName" : null,
        "lastName" : null,
        "loginId" : undefined,
        "employeeId" : null
      },
      "clientFunctionalAreaUser": null,
      "version": 43,
      "isFailed": null,
      "inProcess": false,
      "productCode": "SLS",
      "productVersion": null,
      "bpId": "63f38af3-92e3-4509-81b5-c59365cc7df1",
      "bpVersionId": "70766cde-1b7b-46b1-9c73-a8adf96ceac8",
      "bpTemplateId": "46675d78-a8d5-41ca-8801-c679ef00cff4",
      "isDealerApproved": false,
      "stateStandardId": "sssId",
      "stateStandardName": "sss",
      "stateStandardVersionRecordType": null,
      "stateStandardVersionName": null,
      "copyRowData": false,
      "showValidateOrTransferButton": false,
      "showProcessValidationResultsButton": true,
      "createdDate": null,
      "lastUpdatedDate": null,
      "screenIds":null,
      "createdBy": null,
      "updatedBy": "Harika.Gajabimkar@cdk.com",
      "incorporateBpChanges": false,
      "isLocked":false,
      "storeId":null,
      "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
      "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
    }
  ]
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  component.selectedTemplates = selectedTemplates;
  spyOn(authService,'fetchCommonServicesUsersWithDotVICRole').and.returnValue(Observable.of(userList));
  component.getUSersFromCommonServices();
  expect(authService.fetchCommonServicesUsersWithDotVICRole).toHaveBeenCalledTimes(1);    
});

it('test save store method', ()=>{
  component.currentProject = currentProject;
  component.bestPracticeTree.storeFunctionalUnits = [
    {
      templateScreen : "tempScreen"
    }
  ]
  component.selectedTemplates = list_of_template_response;
  component.storeTemplates = [
    {
      bpTemplateId : "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
    }
  ]
  component.selections = {SLS: { template: {
    platforms : {
    0: {id: null, platformName: "DRIVE", platformCode: "drive", selected: true},
    1: {id: null, platformName: "FLEX", platformCode: "flex", selected: true}
    },
    productCode : "SLS",
    productVersion: null,
    recordType: "9ce6049f-dee8-495a-be7f-e61e2d715452",
    status: "Work in Progress",
    updatedBy: null,
    version: 0,
    vic: {firstName: "Jeff", lastName: "Grence", loginId: "jeff.grence@cdk.com", employeeId: null}
  }
  }};

  component.selections["SLS"].screens = [{ autoAdded: false,
    bpPropagationCompleted: false,
    bpScreenId: null,
    copyRowData: false,
    deleted: false,
    description: "AA_fu",
    gridOptionsModel: {animatedRows: false, rowSelection: "multiple", columnDefs: Array(1)},
    id: "9ce6049f-dee8-495a-be7f-e61e2d715452",
    index: 0,
    masterScreenId: null,
    productCode: "SLS",
    recordType: "76c252aa-b3b1-4fc1-99c0-b3eb239087a3",
    rowDataEmpty: false,
    screenName: "AA_fu",
    updated: false,
    version: 0}];
  spyOn(storeService, 'saveStore').and.returnValue(Observable.of(us_store));
  spyOn(functionalAreaService, 'saveFunctionalArea').and.returnValue(Observable.of(list_of_template_response[0]));
  spyOn(storeService, 'getFunctionalAreasOfStore').and.returnValue(Observable.of(list_of_template_response));
  spyOn(functionalUnitService, 'saveFunctionalUnits').and.returnValue(Observable.of(list_of_template_response));
  
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  component.saveStore(dialogRefSpyObj);
  expect(storeService.saveStore).toHaveBeenCalledTimes(1);
  expect(functionalAreaService.saveFunctionalArea).toHaveBeenCalledTimes(1);
});

it('test save store method else case', ()=>{
  component.currentProject = currentProject;
  component.bestPracticeTree.storeFunctionalUnits = [
    {
      templateScreen : "tempScreen",
      bpScreenId : "76c252aa-b3b1-4fc1-99c0-b3eb239087a3"
    }
  ]
  component.selectedTemplates =list_of_template_response;
  component.storeTemplates = [
    {
      bpTemplateId : "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
    }
  ]
  component.selections = {SLS: { template: {
    platforms : {
    0: {id: null, platformName: "DRIVE", platformCode: "drive", selected: true},
    1: {id: null, platformName: "FLEX", platformCode: "flex", selected: true}
    },
    productCode : "SLS",
    productVersion: null,
    recordType: "9ce6049f-dee8-495a-be7f-e61e2d715452",
    status: "Work in Progress",
    updatedBy: null,
    version: 0,
    vic: {firstName: "Jeff", lastName: "Grence", loginId: "jeff.grence@cdk.com", employeeId: null}
  }
  }};

  component.selections["SLS"].screens = [{ autoAdded: true,
    bpPropagationCompleted: false,
    bpScreenId: null,
    copyRowData: false,
    deleted: false,
    description: "AA_fu",
    gridOptionsModel: {animatedRows: false, rowSelection: "multiple", columnDefs: Array(1)},
    id: "9ce6049f-dee8-495a-be7f-e61e2d715452",
    index: 0,
    masterScreenId: null,
    productCode: "SLS",
    recordType: "76c252aa-b3b1-4fc1-99c0-b3eb239087a3",
    rowDataEmpty: false,
    screenName: "AA_fu",
    updated: false,
    version: 0}];
  spyOn(storeService, 'saveStore').and.returnValue(Observable.of(us_store));
  spyOn(functionalAreaService, 'saveFunctionalArea').and.returnValue(Observable.of(list_of_template_response[0]));
  spyOn(storeService, 'getFunctionalAreasOfStore').and.returnValue(Observable.of(list_of_template_response));
  spyOn(functionalUnitService, 'saveFunctionalUnits');
  
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  component.saveStore(dialogRefSpyObj);
  expect(storeService.saveStore).toHaveBeenCalledTimes(1);
  expect(functionalAreaService.saveFunctionalArea).toHaveBeenCalledTimes(1);
});

it('test validate and save store method', ()=>{
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  component.store.storeName = "store1";
  spyOn(projectService, 'getStoresOfProject').and.returnValue(Observable.of(list_of_stores));
  component.currentProject.projectNumber = "PM525916";
  component.isEdit = false;
  spyOn(component,'isValidFunctionalAreasSelected').and.returnValue(true);
  spyOn(component,'isValidSSSAndVersionSelected').and.returnValue(true);
  spyOn(component,'saveStore');
  component.validateAndSaveTheStore();
  expect(projectService.getStoresOfProject).toHaveBeenCalledTimes(1);
});

it('test validate and save store method else case', ()=>{
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  component.store.storeName = "store1";
  spyOn(projectService, 'getStoresOfProject').and.returnValue(Observable.of(list_of_stores));
  component.currentProject.projectNumber = "PM525916";
  component.isEdit = true;
  spyOn(component,'isValidFunctionalAreasSelected').and.returnValue(true);
  spyOn(component,'isValidSSSAndVersionSelected').and.returnValue(true);
  spyOn(component,'saveStore');
  component.validateAndSaveTheStore();
  expect(projectService.getStoresOfProject).toHaveBeenCalledTimes(1);
});

it('test validate and save store method stores length zero case', ()=>{
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  component.store.storeName = "store1";
  spyOn(projectService, 'getStoresOfProject').and.returnValue(Observable.of([]));
  component.currentProject.projectNumber = "PM525916";
  component.isEdit = false;
  spyOn(component,'isValidFunctionalAreasSelected').and.returnValue(true);
  spyOn(component,'isValidSSSAndVersionSelected').and.returnValue(true);
  spyOn(component,'saveStore');
  component.validateAndSaveTheStore();
  expect(projectService.getStoresOfProject).toHaveBeenCalledTimes(1);
});

it('test close popup method', () =>{
  component.closePopup();
});

it('test validate name from DB method', () =>{
  component.store.storeName = "store1";
  spyOn(projectService, 'getStoresOfProject').and.returnValue(Observable.of(list_of_stores));
  component.validateNameFromDB("store1");
  expect(projectService.getStoresOfProject).toHaveBeenCalledTimes(1);
});


it('test saveStore',()=>{

  let selectedTemplates:any[]=[
    {
      "autoAdded":true,
      "functionalAreaName": "Accounting",
      "functionalAreaType": "BestPracticeFunctionalArea",
      "oemName": null,
      "clientSignoffDate": null,
      "selected": false,
      "status": "Work in Progress",
      "platforms": [
          {
              "id": null,
              "platformName": "DRIVE",
              "platformCode": "drive",
              "selected": true
          }
      ],
      "vic": {
          "userGuid": "95B987AA7657728BE053440B6364CA78",
          "loginId": "Abraham.Joseph@cdk.com",
          "firstName": "Abraham",
          "middleInitial": null,
          "lastName": "Joseph",
          "dmsUserIdentifier": [],
          "locked": false,
          "adminNotes": null,
          "creationDate": "2019-11-01T13:14:41+0000",
          "lastLoginDate": null,
          "locale": "en_US",
          "state": 2,
          "prefix": null,
          "suffix": null,
          "nickName": null,
          "employeeId": null,
          "jobTitle": null,
          "selfServiceEnabled": 0,
          "accountStatus": "Active",
          "communicationEdgeId": "abrahamjosephcdkcom@dit.cdkcollaborate.com",
          "uniquePrincipalName": "Abraham.Joseph@cdk.com",
          "externallyFederated": true
      },
      "secondaryVic": {
          "userGuid": "A128560F646D3FA7E053440B63645B12",
          "loginId": "Amrita.das@cdk.com",
          "firstName": "Amrita",
          "middleInitial": null,
          "lastName": "das",
          "dmsUserIdentifier": [],
          "locked": false,
          "adminNotes": null,
          "creationDate": "2020-04-16T15:09:48+0000",
          "lastLoginDate": null,
          "locale": "en_US",
          "state": 2,
          "prefix": null,
          "suffix": null,
          "nickName": null,
          "employeeId": null,
          "jobTitle": null,
          "selfServiceEnabled": 0,
          "accountStatus": "Active",
          "communicationEdgeId": "amritadascdkcom@dit.cdkcollaborate.com",
          "uniquePrincipalName": "Amrita.das@cdk.com",
          "externallyFederated": true
      },
      "clientFunctionalAreaUser": null,
      "version": 19,
      "isFailed": null,
      "inProcess": false,
      "productCode": "ACCT",
      "productVersion": null,
      "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
      "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
      "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
      "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
      "isDealerApproved": false,
      "stateStandardId": null,
      "stateStandardName": null,
      "stateStandardVersionRecordType": null,
      "stateStandardVersionName": null,
      "copyRowData": false,
      "showValidateOrTransferButton": false,
      "showProcessValidationResultsButton": true,
      "createdDate": null,
      "lastUpdatedDate": null,
      "createdBy": null,
      "updatedBy": null,
      "incorporateBpChanges": false,
      "locked": false,
      "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
      "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
      "selectedVic": {},
      "selectedsecondaryVic": {}
  }
  ]
  component.selectedTemplates = selectedTemplates;

  component.bestPracticeTree.storeFunctionalUnits = [
    {
      screenName:'AccountPayable'
    }
  ]
  let loaderDialogRef:any={
    close
  }
  function close(){

  }

  let storeTemplates:any[]=[
    {
      bpTemplateId:'305e00b1-a4f7-42dc-ad70-5885730756e6',
      recordType:'305e00b1-a4f7-42dc-ad70-5885730756e6',
      "stateStandardId": 'SS123',
      "stateStandardName": 'TestSSS',
      "stateStandardVersionRecordType": '455e00b1-a4f7-42dc-ad70-5885730756e6',
      "stateStandardVersionName":'2021'
    }
  ]
  component.storeTemplates = storeTemplates;

  let selections:any={
    ACCT:{
      screens:[
        {
          'autoAdded': false,
          'bpPropagationCompleted': false,
          'bpScreenId': null,
          'copyRowData': false,
          'deleted': false,
          'description': "Accounts Payable",
          'id': "305e00b1-a4f7-42dc-ad70-5885730756e6",
          'index': 0,
          'masterScreenId': null,
          'productCode': "ACCT",
          'recordType': "519dcbc5-6d64-4629-8b6d-41f4e9200ff4",
          'rowDataEmpty': false,
          'screenName': "Accounts Payable",
          'updated': false,
          'version': 0

        }
      ]
    }
  }
  let storeData:any={
    recordType:'955e00b1-a4f7-42dc-ad70-5885730756e6'
  }
  let templates:any[] = [
    {
      'productCode': "ACCT",
      'recordType':'305e00b1-a4f7-42dc-ad70-5885730756e6'
    }
  ]
  component.selections = selections;
  spyOn(storeService,'saveStore').and.returnValue(Observable.of(storeData));
  spyOn(functionalAreaService,'saveFunctionalArea').and.returnValue(Observable.of({}));
  spyOn(storeService,'getFunctionalAreasOfStore').and.returnValue(Observable.of(templates));

  let saveFU:any={}
  spyOn(functionalUnitService,'saveFunctionalUnits').and.returnValue(Observable.of(saveFU));
  
  component.saveStore(loaderDialogRef)

  expect(storeService.saveStore).toHaveBeenCalledTimes(1);
  expect(functionalAreaService.saveFunctionalArea).toHaveBeenCalledTimes(1);
  expect(storeService.getFunctionalAreasOfStore).toHaveBeenCalledTimes(1);
});

it('test saveStore if screen autoAdded if false',()=>{

  let selectedTemplates:any[]=[
    {
      "autoAdded":true,
      "functionalAreaName": "Accounting",
      "functionalAreaType": "BestPracticeFunctionalArea",
      "oemName": null,
      "clientSignoffDate": null,
      "selected": false,
      "status": "Work in Progress",
      "platforms": [
          {
              "id": null,
              "platformName": "DRIVE",
              "platformCode": "drive",
              "selected": true
          }
      ],
      "vic": {
          "userGuid": "95B987AA7657728BE053440B6364CA78",
          "loginId": "Abraham.Joseph@cdk.com",
          "firstName": "Abraham",
          "middleInitial": null,
          "lastName": "Joseph",
          "dmsUserIdentifier": [],
          "locked": false,
          "adminNotes": null,
          "creationDate": "2019-11-01T13:14:41+0000",
          "lastLoginDate": null,
          "locale": "en_US",
          "state": 2,
          "prefix": null,
          "suffix": null,
          "nickName": null,
          "employeeId": null,
          "jobTitle": null,
          "selfServiceEnabled": 0,
          "accountStatus": "Active",
          "communicationEdgeId": "abrahamjosephcdkcom@dit.cdkcollaborate.com",
          "uniquePrincipalName": "Abraham.Joseph@cdk.com",
          "externallyFederated": true
      },
      "secondaryVic": {
          "userGuid": "A128560F646D3FA7E053440B63645B12",
          "loginId": "Amrita.das@cdk.com",
          "firstName": "Amrita",
          "middleInitial": null,
          "lastName": "das",
          "dmsUserIdentifier": [],
          "locked": false,
          "adminNotes": null,
          "creationDate": "2020-04-16T15:09:48+0000",
          "lastLoginDate": null,
          "locale": "en_US",
          "state": 2,
          "prefix": null,
          "suffix": null,
          "nickName": null,
          "employeeId": null,
          "jobTitle": null,
          "selfServiceEnabled": 0,
          "accountStatus": "Active",
          "communicationEdgeId": "amritadascdkcom@dit.cdkcollaborate.com",
          "uniquePrincipalName": "Amrita.das@cdk.com",
          "externallyFederated": true
      },
      "clientFunctionalAreaUser": null,
      "version": 19,
      "isFailed": null,
      "inProcess": false,
      "productCode": "ACCT",
      "productVersion": null,
      "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
      "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
      "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
      "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
      "isDealerApproved": false,
      "stateStandardId": null,
      "stateStandardName": null,
      "stateStandardVersionRecordType": null,
      "stateStandardVersionName": null,
      "copyRowData": false,
      "showValidateOrTransferButton": false,
      "showProcessValidationResultsButton": true,
      "createdDate": null,
      "lastUpdatedDate": null,
      "createdBy": null,
      "updatedBy": null,
      "incorporateBpChanges": false,
      "locked": false,
      "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
      "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
      "selectedVic": {},
      "selectedsecondaryVic": {}
  }
  ]
  component.selectedTemplates = selectedTemplates;

  component.bestPracticeTree.storeFunctionalUnits = [
    {
      screenName:'AccountPayable',
      bpScreenId:'519dcbc5-6d64-4629-8b6d-41f4e9200ff4',

    }
  ]
  let loaderDialogRef:any={
    close
  }
  function close(){

  }

  let storeTemplates:any[]=[
    {
      bpTemplateId:'305e00b1-a4f7-42dc-ad70-5885730756e6',
      recordType:'305e00b1-a4f7-42dc-ad70-5885730756e6',
      "stateStandardId": 'SS123',
      "stateStandardName": 'TestSSS',
      "stateStandardVersionRecordType": '455e00b1-a4f7-42dc-ad70-5885730756e6',
      "stateStandardVersionName":'2021'
    }
  ]
  component.storeTemplates = storeTemplates;

  let selections:any={
    ACCT:{
      screens:[
        {
          'autoAdded': true,
          'bpPropagationCompleted': false,
          'bpScreenId': null,
          'copyRowData': false,
          'deleted': false,
          'description': "Accounts Payable",
          'id': "305e00b1-a4f7-42dc-ad70-5885730756e6",
          'index': 0,
          'masterScreenId': null,
          'productCode': "ACCT",
          'recordType': "519dcbc5-6d64-4629-8b6d-41f4e9200ff4",
          'rowDataEmpty': false,
          'screenName': "Accounts Payable",
          'updated': false,
          'version': 0

        }
      ]
    }
  }
  let storeData:any={
    recordType:'955e00b1-a4f7-42dc-ad70-5885730756e6'
  }
  let templates:any[] = [
    {
      'productCode': "ACCT",
      'recordType':'305e00b1-a4f7-42dc-ad70-5885730756e6'
    }
  ]
  component.selections = selections;
  spyOn(storeService,'saveStore').and.returnValue(Observable.of(storeData));
  spyOn(functionalAreaService,'saveFunctionalArea').and.returnValue(Observable.of({}));
  spyOn(storeService,'getFunctionalAreasOfStore').and.returnValue(Observable.of(templates));

  let saveFU:any={}
  spyOn(functionalUnitService,'saveFunctionalUnits').and.returnValue(Observable.of(saveFU));
  
  component.saveStore(loaderDialogRef);
  expect(storeService.saveStore).toHaveBeenCalledTimes(1);
  expect(functionalAreaService.saveFunctionalArea).toHaveBeenCalledTimes(1);
  expect(storeService.getFunctionalAreasOfStore).toHaveBeenCalledTimes(1);
});


it('test saveStore no screens to save',()=>{

  let selectedTemplates:any[]=[
    {
      "autoAdded":true,
      "functionalAreaName": "Accounting",
      "functionalAreaType": "BestPracticeFunctionalArea",
      "oemName": null,
      "clientSignoffDate": null,
      "selected": false,
      "status": "Work in Progress",
      "platforms": [
          {
              "id": null,
              "platformName": "DRIVE",
              "platformCode": "drive",
              "selected": true
          }
      ],
      "vic": {
          "userGuid": "95B987AA7657728BE053440B6364CA78",
          "loginId": "Abraham.Joseph@cdk.com",
          "firstName": "Abraham",
          "middleInitial": null,
          "lastName": "Joseph",
          "dmsUserIdentifier": [],
          "locked": false,
          "adminNotes": null,
          "creationDate": "2019-11-01T13:14:41+0000",
          "lastLoginDate": null,
          "locale": "en_US",
          "state": 2,
          "prefix": null,
          "suffix": null,
          "nickName": null,
          "employeeId": null,
          "jobTitle": null,
          "selfServiceEnabled": 0,
          "accountStatus": "Active",
          "communicationEdgeId": "abrahamjosephcdkcom@dit.cdkcollaborate.com",
          "uniquePrincipalName": "Abraham.Joseph@cdk.com",
          "externallyFederated": true
      },
      "secondaryVic": {
          "userGuid": "A128560F646D3FA7E053440B63645B12",
          "loginId": "Amrita.das@cdk.com",
          "firstName": "Amrita",
          "middleInitial": null,
          "lastName": "das",
          "dmsUserIdentifier": [],
          "locked": false,
          "adminNotes": null,
          "creationDate": "2020-04-16T15:09:48+0000",
          "lastLoginDate": null,
          "locale": "en_US",
          "state": 2,
          "prefix": null,
          "suffix": null,
          "nickName": null,
          "employeeId": null,
          "jobTitle": null,
          "selfServiceEnabled": 0,
          "accountStatus": "Active",
          "communicationEdgeId": "amritadascdkcom@dit.cdkcollaborate.com",
          "uniquePrincipalName": "Amrita.das@cdk.com",
          "externallyFederated": true
      },
      "clientFunctionalAreaUser": null,
      "version": 19,
      "isFailed": null,
      "inProcess": false,
      "productCode": "ACCT",
      "productVersion": null,
      "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
      "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
      "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
      "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
      "isDealerApproved": false,
      "stateStandardId": null,
      "stateStandardName": null,
      "stateStandardVersionRecordType": null,
      "stateStandardVersionName": null,
      "copyRowData": false,
      "showValidateOrTransferButton": false,
      "showProcessValidationResultsButton": true,
      "createdDate": null,
      "lastUpdatedDate": null,
      "createdBy": null,
      "updatedBy": null,
      "incorporateBpChanges": false,
      "locked": false,
      "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
      "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
      "selectedVic": {},
      "selectedsecondaryVic": {}
  }
  ]
  component.selectedTemplates = selectedTemplates;

  component.bestPracticeTree.storeFunctionalUnits = [
    {
      screenName:'AccountPayable',
      bpScreenId:'519dcbc5-6d64-4629-8b6d-41f4e9200ff4',

    }
  ]
  let loaderDialogRef:any={
    close
  }
  function close(){}

  let storeTemplates:any[]=[
    {
      bpTemplateId:'305e00b1-a4f7-42dc-ad70-5885730756e6',
      recordType:'305e00b1-a4f7-42dc-ad70-5885730756e6',
      "stateStandardId": 'SS123',
      "stateStandardName": 'TestSSS',
      "stateStandardVersionRecordType": '455e00b1-a4f7-42dc-ad70-5885730756e6',
      "stateStandardVersionName":'2021'
    }
  ]
  component.storeTemplates = storeTemplates;

  let selections:any={
    ACCT:{
      screens:[]
    }
  }
  let storeData:any={
    recordType:'955e00b1-a4f7-42dc-ad70-5885730756e6'
  }
  let templates:any[] = []
  component.selections = selections;
  spyOn(storeService,'saveStore').and.returnValue(Observable.of(storeData));
  spyOn(functionalAreaService,'saveFunctionalArea').and.returnValue(Observable.of({}));
  spyOn(storeService,'getFunctionalAreasOfStore').and.returnValue(Observable.of(templates));

  let saveFU:any[]=[]
  spyOn(functionalUnitService,'saveFunctionalUnits').and.returnValue(Observable.empty);
  
  component.saveStore(loaderDialogRef);
  expect(storeService.saveStore).toHaveBeenCalledTimes(1);
  expect(functionalAreaService.saveFunctionalArea).toHaveBeenCalledTimes(1);
  expect(storeService.getFunctionalAreasOfStore).toHaveBeenCalledTimes(1);
  expect(functionalUnitService.saveFunctionalUnits).toHaveBeenCalledTimes(0);
});

})


})

