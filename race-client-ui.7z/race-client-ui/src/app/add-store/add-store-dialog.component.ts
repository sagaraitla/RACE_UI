import {forkJoin as observableForkJoin,  Observable, iif } from 'rxjs';
import { Component, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, FormControlName } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';
import { MatStepper } from '@angular/material/stepper';

import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { ProjectService } from '../services/project-service';
import { StoreService } from '../services/store-service';
import { FunctionalAreaService } from '../services/functional-area-service';
import { FunctionalUnitService } from '../services/functional-unit-service';
import { StoreObject } from '../model/store-object';
import { TemplateObject } from '../model/template-object';
import { ProjectObject } from '../model/project-object';
import { BestPracticeObject } from '../model/bestpractice-object';
import { BestPracticeVersionObject } from '../model/bestpractice-version-object';
import { PlatformObject } from '../model/platform-object';
import { UserObject } from '../model/user-object';
import { AuthService } from '../services/auth-service';
import { BestPracticeService } from '../services/bestpractice-service';
import { BestPracticeTree } from '../bestpractice-tree/bestpractice-tree.component'
import { MasterFunctionalUnit } from '../model/master-functional-unit';
import { ScreenObject } from '../model/screen-object';
import { LaunchDarklyService } from '../services/launchdarkly-service';
import { Constants } from '../constant/constants';
import { ToastrService } from 'ngx-toastr'; 

@Component({
	  selector: 'app-add-store-dialog',
	  templateUrl: './add-store-dialog.component.html',
	  styleUrls: ['./add-store-dialog.component.css']
})

export class AddStoreComponent {
  
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  states = [];
  storeTemplates = [];
  usersList = [];
  vicUsersList = [];
  secondaryVicUsersList = [];
  oemList = [];
  oemFilteredList = [];
  oemPlatformList = [];
  sssList = [];
  sssVersionList = [];
  selectedTemplates : TemplateObject[];
  selections = {};
  allowOemSelection = false;
  store: StoreObject = new StoreObject();
  currentProject: ProjectObject = new ProjectObject();
  assignUserPermission = false;
  templateType: string = '';
  isEdit = false;
  selectedOem = '';
  company_sharing_A = false;
  isOemChecked = false;
  isCustomChecked = false;
  isTemplateSetForFirstTime = false;
  dialogLabel: string = 'Add Store';
  hasEnterpriseStore : boolean;
  addStorePermission : boolean;
  selectedStepIndex: number = 0;
  showStateStandardsTab = false;
  assignVICandSSSTabLabel = 'Assign VIC';
  stateStandardFlagStatus : any;
  loaderDialogRef:any;
  loader:any;

  @ViewChild( BestPracticeTree ,{static: false}) bestPracticeTree: BestPracticeTree ;

    CDKU_Coordinators :any[];
    countries :any[];
    languages :any[];
    timezones :any[];
    UnitedStates :any[];
    Canada :any[];
    
constructor(private projectService : ProjectService, private storeService : StoreService, private functionalAreaService: FunctionalAreaService, private functionalUnitService: FunctionalUnitService, private authService: AuthService, private bestPracticeService: BestPracticeService,
      private dialogRef: MatDialogRef<AddStoreComponent>, private _formBuilder: FormBuilder, @Inject(MAT_DIALOG_DATA) private data: any, private dialog: MatDialog, private toastrService: ToastrService,
		  private router: Router, private launchDarklyService : LaunchDarklyService) {
    dialogRef.disableClose = true;
    this.currentProject.platform = new PlatformObject();
    this.CDKU_Coordinators=Constants.CDKU_COORDINATORS;
    this.countries=Constants.COUNTRIES;
    this.languages=Constants.LANGUAGES;
    this.timezones=Constants.TIMEZONES;
    this.UnitedStates=Constants.UNITED_STATES;
    this.Canada=Constants.CANADA;
  }

  ngOnInit() {
    
    this.loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
      width: '300px',
      height: '150px',
      data: { message: "Fetching store information" }
          });   

    this.firstFormGroup = this._formBuilder.group({
		    storeName: ['', Validators.required],
		    streetAddress: ['', Validators.required],
		    city: ['', Validators.required],
		    province: ['', Validators.required],
		    zipcode: ['', Validators.required],
		    company: ['', Validators.required],
		    logon: ['', Validators.required],
		    ipAddress: new FormControl('', Validators.compose([Validators.pattern('^([0-9]{1,3})[.]([0-9]{1,3})[.]([0-9]{1,3})[.]([0-9]{1,3})$')])),
		    dmsCNumber: new FormControl('', Validators.compose([Validators.pattern('[Cc][0-9]{6}')])),
		    businessPhone: new FormControl('', Validators.compose([Validators.pattern('^[0-9]+$')])),
		    sharedLogonName: new FormControl('', Validators.compose([Validators.pattern('^((?!-A).)*$')])),
		    storeNumber: new FormControl('', Validators.compose([Validators.pattern('^[a-zA-Z0-9]{1,6}')])),
		    cmfNumber: new FormControl('', Validators.compose([Validators.pattern('^[a-zA-Z0-9]*$')])),
		    url: new FormControl('', Validators.compose([Validators.pattern('^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$')]))
      });
    
	  this.secondFormGroup = this._formBuilder.group({
		  secondCtrl: ''
	  });
	  
	  this.assignUserPermission = this.authService.isAuthorised('DOT_ASSIGN_USERS');
      this.currentProject = JSON.parse(JSON.stringify(this.data.project));
      this.store.cdku_coordinator = this.currentProject.cdku_coordinator;
      this.store.timezone = this.currentProject.timezone;
      this.store.country = ((this.currentProject.country) || ("United States"));
      this.store.language = this.currentProject.language;
      this.hasEnterpriseStore = this.data.hasEnterpriseStore;
      this.addStorePermission = this.data.addStorePermission;
      this.store.id = this.currentProject.id;

	  if(this.data.storeRecordType && this.data.addStore == false) {
		  this.isEdit = true;
		  this.dialogLabel = this.isEdit ? 'Edit Store' : 'Add Store';
      this.storeService.getStore(this.store.id, this.data.storeRecordType).subscribe(store => this.setStoreForEdit(store));
	  }else if(this.data.storeRecordType && this.data.addStore == true){
      this.storeService.getStore(this.store.id, this.data.storeRecordType)
      .subscribe(store => this.prePopulateStoreInfo(store));
    }

    else{
      this.loaderDialogRef.close();
    }
    
   
    this.bestPracticeService.getAllBestPracticesByPlatform(false, this.currentProject.platform.platformName).subscribe((data: any[]) => {
      this.oemPlatformList = Object.assign([], data).filter(
        item => item.platform.platformName.indexOf(this.currentProject.platform.platformName) > -1
      );
      this.oemList = this.oemPlatformList;
      this.oemFilteredList = this.oemList;  
    });

    this.bestPracticeService.getAllBestPracticesByTypeInternal('SSS', false).subscribe((data: any[]) => {
      this.sssList  = data;
    });

    if(this.store.country === "United States")
      this.states = this.UnitedStates;
    if(this.store.country === "Canada")
      this.states = this.Canada;
    
    this.stateStandardFlagStatus = this.launchDarklyService.flags['race-sales-state-standards'];
    if(this.stateStandardFlagStatus.current != undefined && this.stateStandardFlagStatus.current != null){
      this.stateStandardFlagStatus = this.stateStandardFlagStatus.current;
    }
    this.launchDarklyService.flagChange.subscribe((flags) => {
      this.stateStandardFlagStatus = flags['race-sales-state-standards'].current;
    });
   
  };
  
  loadData(event){
   
	  if (event.selectedIndex == 0) {
		  this.selectedStepIndex = 0;
	  }
	  if (event.selectedIndex == 1) {
		  this.selectedStepIndex = 1;
		  this.bestPracticeTree.loadBestPractices(this.currentProject.platform.platformName);
  	  }
	  if (event.selectedIndex == 2) {
		  this.selectedStepIndex = 2;
		  this.assignVICandSSSTabLabel = 'Assign VIC';
		  if (this.stateStandardFlagStatus){
		      this.displaySelectedStateStandards();
		  }
	      this.getUSersFromCommonServices();           
  	  }
  }

  checkForState(event){
    this.store.province = "";
    this.store.country = event.value;
    this.store.zipcode = null;
    this.firstFormGroup.get('zipcode').setValidators([Validators.required]);
    if(event.value === "United States"){ 
      this.states = this.UnitedStates;      
    }
    else if(event.value === "Canada"){
      this.states = this.Canada;         
    }
  }
  
  isValidFunctionalAreasSelected(loaderDialogRef : any) : boolean
  {
    let productCodesSelected = Object.keys(this.selections);
    let productsHavingZeroFU : string = "";
    for(let productCode of productCodesSelected) {
      if(this.selections[productCode].screens.length === 0)
      {
        productsHavingZeroFU = productsHavingZeroFU + " "+ productCode;
      }
    }
    if(productsHavingZeroFU.length>0)
    {
      this.toastrService.error("At least one Functional Unit must be selected for the "+productsHavingZeroFU+" Functional Area");
      loaderDialogRef.close();
      this.router.navigateByUrl('projects/' + this.currentProject.projectNumber);
      return false;
    }
    return true;
  }
  
  isValidSSSAndVersionSelected(loaderDialogRef : any) : boolean
  {
	var validSssSelected = true;  
    this.selectedTemplates.forEach(template => {
		  if( 'SLS' == template.productCode) {
			  if ((template.stateStandardName!= null && template.stateStandardName != undefined) && (template.stateStandardVersionName == null || template.stateStandardVersionName == undefined )){
				  this.toastrService.warning("No version selected for State Standard " + template.stateStandardName);
			      loaderDialogRef.close();
			      validSssSelected = false;  
			  }
		  }
    });
    return validSssSelected;
  }
  
  applyOEMFilter(value: string) {
	  if (value.trim()) {
		  this.oemFilteredList = Object.assign([], this.oemList).filter(
		    item => item.bestPracticeName.toLowerCase().indexOf(value.toLowerCase()) > -1
		  );
	  }
	  value = "";
  }
    
  onFocusReloadOEMs(event: any) {
	  this.oemFilteredList = Object.assign([], this.oemList);
  } 

  setStoreForEdit(store: StoreObject) {
	  if(store.id === this.store.id && store.recordType === this.data.storeRecordType) {
      this.store = store;
      if (this.store.locked){
          this.firstFormGroup.controls['ipAddress'].disable();
          this.firstFormGroup.controls['dmsCNumber'].disable();  	  
      }

      if (this.store.sharedLogonName) {
        this.company_sharing_A = true;
      }
      this.storeService.getFunctionalAreasOfStore(store.recordType).subscribe(templates => {
        this.storeTemplates = templates;
      });
    
      if(this.store.country === "United States" && this.currentProject.country != null && this.currentProject.country != "United States"){
        this.states = this.UnitedStates;
        this.firstFormGroup.get('zipcode').setValidators([Validators.required]);
      }
      else if(this.store.country === "United States" && this.currentProject.country == null)
        this.states = this.UnitedStates;
      if(this.store.country === "Canada" && this.currentProject.country != null && this.currentProject.country != "Canada"){
        this.states = this.Canada;
        this.firstFormGroup.get('zipcode').setValidators([Validators.required]);
      }
      else if(this.store.country === "Canada" && this.currentProject.country == null){
        this.states = this.Canada;
        this.firstFormGroup.get('zipcode').setValidators([Validators.required]);
      }
      if(this.store.country === "Other"){
        this.firstFormGroup.get('zipcode').setValidators([Validators.required]);
      } 
    }
    this.loaderDialogRef.close();
  }

  prePopulateStoreInfo(store : StoreObject){
        this.store.storeId = store.storeId;
        this.store.storeName = store.storeName +"_"+ Math.floor((Math.random() * 100) + 1);
        this.store.country = store.country;
        this.store.streetAddress = store.streetAddress;
        this.store.city = store.city;
        this.store.province = store.province;
        this.store.zipcode = store.zipcode;
        this.store.language = store.language;
        this.store.ipAddress = store.ipAddress;
        this.store.dmsCNumber = store.dmsCNumber;
        this.store.cmfNumber = store.cmfNumber;
        this.store.glCompanyNumber = store.glCompanyNumber;
        this.store.logonName = store.logonName;
        this.store.timezone = store.timezone;
        this.store.oem = store.oem;
        this.store.cdku_coordinator = store.cdku_coordinator;
        this.store.url = store.url;
        this.store.storeNumber = store.storeNumber;
        this.loaderDialogRef.close();
  }
  
  populateSelectedTemplates(){
	  //get all the templates selected via best practices as selected Templates.
	  this.selectedTemplates = [];
	  this.selections = this.bestPracticeTree.selections;
	  let productCodes = Object.keys(this.selections);
	  for(let productCode of productCodes) {
		  this.selectedTemplates.push(this.selections[productCode].template);
	  }
  }

  getUSersFromCommonServices() {  
	  let dialogRef = this.dialog.open(LoaderDialogueComponent, {
	      width: '300px',
	      height: '150px',
	      data: { message: 'Fetching VICs.' }
	  });

	  if (!this.selectedTemplates){
		this.populateSelectedTemplates();  
	  }

	  this.authService.fetchCommonServicesUsersWithDotVICRole().subscribe((data: any) => {
	      this.usersList = data;
          this.vicUsersList = this.usersList;
          this.secondaryVicUsersList = this.usersList;
	      this.selectedTemplates.forEach((template, index) => {
				if(template.vic && template.vic.loginId) {
					let vics = this.usersList.filter(function(user) {return user.user.loginId === template.vic.loginId;});
					if(vics.length > 0) {
						template['selectedVic'] = vics[0].user;
					}
				} else {
          template['selectedVic'] = {};
				}
				if(template.secondaryVic && template.secondaryVic.loginId) {
					let secondaryVics = this.usersList.filter(function(user) {return user.user.loginId === template.secondaryVic.loginId;});
					if(secondaryVics.length > 0) {
						template['selectedsecondaryVic'] = secondaryVics[0].user;
					}
        } else {
          template['selectedsecondaryVic'] = {};
				}
		  });
	      dialogRef.close();
	  },
      err => {
          console.log(err);
          dialogRef.close();
      });
  }

  changeCompanySharingA(event: any) {
      if (event.checked) {
          this.company_sharing_A = true;
      } else {
          this.company_sharing_A = false;
          this.store.sharedLogonName = null;
      }
  }

  checkEnterpriseStore(event : any){
	  if(event.checked){
		  this.store.enterpriseStore=true;
	  }

	  else{
		  this.store.enterpriseStore=false;
	  }
  }

  onFocusReloadVic(event: any, template: TemplateObject, vicType: string) {
      if (vicType === 'vic') {
          this.vicUsersList = this.usersList;
      }
      if (vicType === 'secondaryVic') {
          this.secondaryVicUsersList = this.usersList;
      }
  }

  onChangeVicOrSecondaryVic(event: any, template: TemplateObject, vicType: string) {
	  template[vicType] = event.value;
  }
  
  
  displaySelectedStateStandards(){
	  this.showStateStandardsTab = false;
	  if (!this.selectedTemplates) {
			this.populateSelectedTemplates();  
	  }
	  this.selectedTemplates.forEach(template => {
		  if( 'SLS' == template.productCode) {
			  this.showStateStandardsTab = true;
			  this.assignVICandSSSTabLabel = 'Assign VIC & Apply State Standard'
			   if (template.stateStandardId)
			   {
				  let dialogRef = this.dialog.open(LoaderDialogueComponent, {
				      width: '300px',
				      height: '150px',
				      data: { message: 'Fetching Versions for State Standard.' }
				  });
				   if (template.stateStandardId){
					   this.bestPracticeService.getVersionsByBestPracticeId(template.stateStandardId, false).subscribe((data: any) => {
						      this.sssVersionList = data;
						  });
				   }
				   dialogRef.close();
			 }
		  }
	  });
  }
  
  onChangeStateStandard(event: any, stateStandard: BestPracticeObject){
	  this.selectedTemplates.forEach(template => {
			  if( 'SLS' == template.productCode) {
				  if (event.value){
					  let dialogRef = this.dialog.open(LoaderDialogueComponent, {
					      width: '300px',
					      height: '150px',
					      data: { message: 'Fetching Versions for State Standard.' }
					  });
					  
					  template.stateStandardId = event.value.id;
					  template.stateStandardName = event.value.bestPracticeName;
					  template.stateStandardVersionRecordType = null;
					  template.stateStandardVersionName = null;
					  
					  this.bestPracticeService.getVersionsByBestPracticeId(template.stateStandardId, false).subscribe((data: any) => {
					      this.sssVersionList = data;
					      dialogRef.close();
					  },
				      err => {
				          console.log(err);
				          dialogRef.close();
				      });
					  
				  }
				  else{
					  template.stateStandardId = null;
					  template.stateStandardName = null;
					  template.stateStandardVersionRecordType = null;
					  template.stateStandardVersionName = null;
					  this.sssVersionList = [];
				  }
			  }
	  });
  }

  onChangeStateStandardVersion(event: any, stateStandard: BestPracticeVersionObject){
	    this.selectedTemplates.forEach(template => {
			  if( 'SLS' == template.productCode) {
				  if (event.value){
					  template.stateStandardVersionRecordType = event.value.recordType;
					  template.stateStandardVersionName = event.value.versionName;
				  }
				  else {
					  template.stateStandardVersionRecordType = null;
					  template.stateStandardVersionName = null;
				  }
			  }
	    });
  }


  applyVICFilter(value: string, vicType: string) {
      if (value.trim()) {
          if (vicType === 'vic') {
              this.vicUsersList = Object.assign([], this.usersList).filter(
                  item => item.user.loginId.toLowerCase().indexOf(value.toLowerCase()) > -1
              );
          }
          if (vicType === 'secondaryVic') {
              this.secondaryVicUsersList = Object.assign([], this.usersList).filter(
                  item => item.user.loginId.toLowerCase().indexOf(value.toLowerCase()) > -1
              );
          }
      }
    value = "";
  }

  validateAndSaveTheStore() {
	  let storeExistFlag = false;
      let currentStoreName = this.store.storeName;
      let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
		  width: '300px',
		  height: '150px',
      data: { message: 'Saving Store...' }
   
      });

      if(this.isValidFunctionalAreasSelected(loaderDialogRef) && this.isValidSSSAndVersionSelected(loaderDialogRef)) 
      {            
	      this.projectService.getStoresOfProject(this.store.id)
	      .subscribe(stores => {
	    	  if(stores.length !== 0){
	    			  let foundStores: any[] = stores.filter(function(store) {return store.storeName === currentStoreName;})
	    			  storeExistFlag = foundStores.length > 0;
	    			  if (storeExistFlag && !this.isEdit) {
	    				  this.toastrService.error("Store "+ currentStoreName+" already exist!!!!");
	    				  loaderDialogRef.close();
	    				  this.router.navigateByUrl('projects/' + this.currentProject.projectNumber);
	    			  } else {
	    				  this.saveStore(loaderDialogRef);
	    			  }
	    	  } else {
	    		  this.saveStore(loaderDialogRef);
	    	  }
	      });
    }
  }

  saveStore(loaderDialogRef: any) {
	  this.store.projectId = this.currentProject.id;
	  if(!Array.isArray(this.currentProject.storeIds) || !this.isEdit) {
		  this.currentProject.storeIds = [];
	  }
	  let storeScreens = [];
	  if(this.bestPracticeTree.storeFunctionalUnits) {
		  this.bestPracticeTree.storeFunctionalUnits.forEach(templateScreens => {
			  storeScreens = storeScreens.concat(templateScreens);
		  });
	  }
	  this.selectedTemplates.forEach(template => {
		  if(!template['autoAdded']) { // Newly Selected FA
			  template.recordType = null;
		  } else {
			  let templates = this.storeTemplates.filter(function(tempTemplate) {return tempTemplate.bpTemplateId === template.recordType;});
			  if(templates.length > 0) {
				  templates[0].vic = template.vic;
				  templates[0].secondaryVic = template.secondaryVic;
				  templates[0].stateStandardId = template.stateStandardId;
				  templates[0].stateStandardName = template.stateStandardName;
				  templates[0].stateStandardVersionRecordType = template.stateStandardVersionRecordType;
				  templates[0].stateStandardVersionName = template.stateStandardVersionName;
				  this.selectedTemplates[this.selectedTemplates.indexOf(template)] = templates[0];
			  }
		  }

		  let screens = this.selections[template.productCode].screens;
		  for(let screen of screens) {
			  if(!screen.autoAdded) { // New Selected Screen
				  screen.bpScreenId = screen.recordType;
				  screen.recordType = null;
				  screen.copyRowData = true;
			  } else {
				  let tempScreens = storeScreens.filter(function(storeScreen) {return storeScreen.bpScreenId === screen.recordType;});
				  if(tempScreens.length > 0) {
					  screens[screens.indexOf(screen)] = tempScreens[0];
				  }
			  }
		  }
	  });
      
	  let selectedTemplatesCopy : TemplateObject[] = this.selectedTemplates;
	  this.storeService.saveStore(this.store, this.selectedTemplates)
	  .subscribe(storeData => {
      let functionalAreasToSave:TemplateObject[] = [];
      selectedTemplatesCopy.forEach((template, index) => {
        let fa = new TemplateObject();
        fa = Object.assign({}, template);
        fa.id = storeData.recordType;
        fa.functionalAreaType = null;
        fa.copyRowData = true;
        functionalAreasToSave.push(fa);
      });
      this.functionalAreaService.saveFunctionalArea(this.store.recordType,this.store.storeName, this.currentProject.projectNumber, functionalAreasToSave).subscribe( savedTemplate => {
        this.storeService.getFunctionalAreasOfStore(storeData.recordType).subscribe(templates => {
          let requests = [];
          for(let template of templates) {
            let screens = this.selections[template.productCode].screens;
            let functionalUnitsToSave: ScreenObject[] = [];
            screens.forEach((screen, index) => {
              let fu = new ScreenObject();
              fu = Object.assign({}, screen);
              fu.id = template.recordType;  // or screen.id
              functionalUnitsToSave.push(fu);
            });
            requests.push( this.functionalUnitService.saveFunctionalUnits(functionalUnitsToSave,template.id,template.recordType));
          }
          if(requests.length > 0) {
            observableForkJoin(requests)
              .subscribe(data => {
                loaderDialogRef.close();
                this.dialogRef.close();
              }, error=> {
                this.toastrService.warning('Error occurred while saving store.');
                loaderDialogRef.close();
                this.dialogRef.close();
              });
          } else {
            loaderDialogRef.close();
            this.dialogRef.close();
          }
        });
      });
	  });
  }

  closePopup() {
	  this.dialogRef.close(Constants.POPUP_CANCEL);
  };

  validateNameFromDB(storeName: any) {
	  let existFlag = false;
	  this.projectService.getStoresOfProject(this.store.id)
	  .subscribe(stores => {
		  stores.forEach((store,index) => {
              if(store.storeName === this.store.storeName) {
                  existFlag = true;
                  this.toastrService.error('Store with Store Name ' + this.store.storeName + ' already exists!');
                  this.toastrService.error("Store "+ this.store.storeName+" already exist!!!!");
        	  }
          });
	  });
  }
  
  goToNextStep(stepper: MatStepper){
	  stepper.next();
  }

}