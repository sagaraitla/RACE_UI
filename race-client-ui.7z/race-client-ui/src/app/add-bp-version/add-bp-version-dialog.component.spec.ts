import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatDialogRef, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatSelectModule, MatSortModule, MatStepperModule, MAT_DIALOG_DATA } from "@angular/material";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { Observable, of } from "rxjs";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { BestPracticeObject } from "../model/bestpractice-object";
import { BestPracticeVersionObject } from '../model/bestpractice-version-object';
import { Platform } from "../model/master-platform";
import { TemplateObject } from '../model/template-object';
import { AuthService } from "../services/auth-service";
import { BestPracticeService } from '../services/bestpractice-service';
import { AddBPVersionComponent } from './add-bp-version-dialog.component';
import { FormBuilder, FormControl, FormsModule, ReactiveFormsModule, Validators } from "@angular/forms";

describe('AddBPVersionComponent',() => {

    let component : AddBPVersionComponent;
    let fixture : ComponentFixture<AddBPVersionComponent>;
    let bestPracticeService: BestPracticeService;
    let authService : AuthService;
    let _formBuilder : FormBuilder;

    const testUrl  = 'dashboard';
    const dialogMock = {
        close: () => { }
    };
    beforeEach(async(() =>{

        let data= {
            bpVersionName:"2021",
            project:"testProject"
        }
        let mockRouter = {
            navigate: jasmine.createSpy('navigateByUrl')
        } 

        TestBed.configureTestingModule({
           imports: [
                MatCardModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatPaginatorModule,
                MatDialogModule,
                ToastrModule.forRoot(),
                CommonModule,
                MatSelectModule,
                MatCheckboxModule,
                MatSortModule,
                MatIconModule,
                FormsModule,
                MatMenuModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                SortableModule,
                MatSortModule,
                ReactiveFormsModule,
                MatStepperModule
            ],
            declarations : [AddBPVersionComponent,LoaderDialogueComponent],
            providers : [
                BestPracticeService,
                AuthService,
                ToastrService,
                { provide: Router, useValue: {url:testUrl} },
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: dialogMock},
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent]}});
         
            authService = TestBed.get(AuthService);
            bestPracticeService = TestBed.get(BestPracticeService);
            fixture = TestBed.createComponent(AddBPVersionComponent);
            component = fixture.componentInstance;

            
      }));

      beforeEach(() =>{
        component = fixture.componentInstance;
        _formBuilder = TestBed.get(FormBuilder); 
        component.firstFormGroup = _formBuilder.group({ 
          recipientTypes: new FormControl(
          {
              value: ["mock"],
              disabled: true
          },
          Validators.required
          )
          });
          component.secondFormGroup = _formBuilder.group({ 
              recipientTypes: new FormControl(
              {
                  value: ["mock"],
                  disabled: true
              },
              Validators.required
              )
              });
        fixture.detectChanges();
    })

  
      let platForm :Platform={
        "platformName": "FLEX",
        "platformCode": "flex",
        "selected": false,
        "id":"1",
        "recordType":"platform"
      }

      const bestPracticeVersionObjectList: BestPracticeVersionObject[]=[
        {
            id : "444",
            recordType : "BestPracticeVersionObject",
            versionName : "2021",
            active : false,
            objectType : null,
            functionalAreaList : null,
            propagationStarted:false
          }
      ]

      const bestPracticeVersionObject: BestPracticeVersionObject={
        id : "444",
        recordType : "BestPracticeVersionObject",
        versionName : "2021",
        active : false,
        objectType : null,
        functionalAreaList : null,
        propagationStarted:false
      }

      const currentBestPractice: BestPracticeObject={
        isBestPractice : 1,
        bestPracticeName : "testbp",
        platform : platForm,	
        version : 123,
        failed : false,
        isSSS : 0,
        id:"1",
        recordType:null
      }


      const bpVersionList: BestPracticeVersionObject[]=[
          {
            id : "123",
            recordType : "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
            versionName : "2021",
            active : true,
            objectType : "test",
            functionalAreaList : null,
            propagationStarted:true, 
          }
      ]

      const templateList :any[]=[
        {
            "functionalAreaName": "Service",
            "functionalAreaType": null,
            "oemName": null,
            "clientSignoffDate": null,
            "selected": false,
            "status": "Work in Progress",
            "platforms": [
              {
                "platformName": "FLEX",
                "platformCode": "flex",
                "selected": true
              }
            ],
            "vic": {
              "firstName": "Abraham",
              "lastName": "Joseph",
              "loginId": "Abraham.Joseph@cdk.com",
              "employeeId": null
            },
            "secondaryVic": {
              "firstName": "Amrita",
              "lastName": "das",
              "loginId": "Amrita.das@cdk.com",
              "employeeId": null
            },
            "clientFunctionalAreaUser": null,
            "version": 6,
            "isFailed": null,
            "inProcess": false,
            "productCode": "SVC",
            "productVersion": null,
            "bpId": "c0adde0a-71fe-48f0-a5c1-89c63b37029d",
            "bpVersionId": "8c68b65d-cc7a-4c3b-a91a-9d0febb5b85f",
            "bpTemplateId": "4e524a60-7103-4c84-9f34-79cfa7531dfe",
            "isDealerApproved": false,
            "stateStandardId": null,
            "stateStandardName": null,
            "stateStandardVersionRecordType": null,
            "stateStandardVersionName": null,
            "copyRowData": false,
            "showValidateOrTransferButton": false,
            "showProcessValidationResultsButton": true,
            "createdDate": null,
            "lastUpdatedDate": null,
            "createdBy": "Sagar.Aitla@cdk.com",
            "updatedBy": "Sagar.Aitla@cdk.com",
            "incorporateBpChanges": false,
            "id": "506bf3e4-9a22-4feb-b75d-4377fd6832a8",
            "recordType": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
            "isLocked":false,
            "storeId":null,
            "screenIds":[]
          }
      ]

      const templateObject : TemplateObject={
        "functionalAreaName": "Service",
        "functionalAreaType": null,
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Work in Progress",
        "platforms": [
          {
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true
          }
        ],
        "vic": {
          "firstName": "Abraham",
          "lastName": "Joseph",
          "loginId": "Abraham.Joseph@cdk.com",
          "employeeId": null
        },
        "secondaryVic": {
          "firstName": "Amrita",
          "lastName": "das",
          "loginId": "Amrita.das@cdk.com",
          "employeeId": null
        },
        "clientFunctionalAreaUser": null,
        "version": 6,
        "isFailed": null,
        "inProcess": false,
        "productCode": "SVC",
        "productVersion": null,
        "bpId": "c0adde0a-71fe-48f0-a5c1-89c63b37029d",
        "bpVersionId": "8c68b65d-cc7a-4c3b-a91a-9d0febb5b85f",
        "bpTemplateId": "4e524a60-7103-4c84-9f34-79cfa7531dfe",
        "isDealerApproved": false,
        "stateStandardId": null,
        "stateStandardName": null,
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": false,
        "showValidateOrTransferButton": false,
        "showProcessValidationResultsButton": true,
        "createdDate": null,
        "lastUpdatedDate": null,
        "createdBy": "Sagar.Aitla@cdk.com",
        "updatedBy": "Sagar.Aitla@cdk.com",
        "incorporateBpChanges": false,
        "id": "506bf3e4-9a22-4feb-b75d-4377fd6832a8",
        "recordType": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
        "isLocked":false,
        "storeId":null,
        "screenIds":[]
      }

      const list_of_template_response: TemplateObject[] =[
        {
          "functionalAreaName": "Sales",
          "functionalAreaType": null,
          "oemName": null,
          "clientSignoffDate": null,
          "selected": false,
          "status": "Work in Progress",
          "platforms": [
            {
              "platformName": "FLEX",
              "platformCode": "flex",
              "selected": true
            }
          ],
          "vic": {
            "loginId" : "myLogin",
            "firstName" : null,
            "lastName" : "last",
            "employeeId" : null
          },
          "secondaryVic":  {
            "firstName" : null,
            "lastName" : null,
            "loginId" : "myLogin",
            "employeeId" : null
          },
          "clientFunctionalAreaUser": null,
          "version": 43,
          "isFailed": null,
          "inProcess": false,
          "productCode": "SLS",
          "productVersion": null,
          "bpId": "63f38af3-92e3-4509-81b5-c59365cc7df1",
          "bpVersionId": "70766cde-1b7b-46b1-9c73-a8adf96ceac8",
          "bpTemplateId": "46675d78-a8d5-41ca-8801-c679ef00cff4",
          "isDealerApproved": false,
          "stateStandardId": "sssId",
          "stateStandardName": "sss",
          "stateStandardVersionRecordType": null,
          "stateStandardVersionName": null,
          "copyRowData": false,
          "showValidateOrTransferButton": false,
          "showProcessValidationResultsButton": true,
          "createdDate": null,
          "lastUpdatedDate": null,
          "screenIds":null,
          "createdBy": null,
          "updatedBy": "Harika.Gajabimkar@cdk.com",
          "incorporateBpChanges": false,
          "isLocked":false,
          "storeId":null,
          "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
          "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
        }
    ];
      it('test setVersionForEdit',()=>{
        let templateObject = new TemplateObject();
        spyOn(bestPracticeService,'getFunctionalAreasOfBpVersion').and.returnValue(Observable.of(templateObject));
        component.setVersionForEdit(bpVersionList);
      });

      it('test checkActiveVersion',()=>{
          let event : any={
              checked : true
          }
          component.checkActiveVersion(event);
          expect(component.bpVersionObj.active).toBeTruthy();
      });

      it('test checkActiveVersion event checked false',()=>{
        let event : any={
            checked : false
        }
        component.checkActiveVersion(event);
        expect(component.bpVersionObj.active).toBeFalsy();
    });

    it('test selectFunctionalArea event checked false',()=>{

       let event : any={checked : false}
       let selectedTemplates:any[]=[
           {
            "functionalAreaName": "Service"  
           }
       ]
       component.selectedTemplates = selectedTemplates;
       component.selectFunctionalArea(event,templateObject)
       expect(component.selectedTemplates.length).toEqual(0);
    });

    it('test selectFunctionalArea event checked true',()=>{

        let event : any={checked : true}
        let selectedTemplates:any[];
        let storeTemplates:any[]=[
            {
             "functionalAreaName": "Service"  
            }
        ]
        component.storeTemplates = storeTemplates;
        component.selectedTemplates = selectedTemplates;
        component.selectFunctionalArea(event,templateObject) 
        expect(component.selectedTemplates.length).toEqual(1);
     });

     it('test selectFunctionalArea event checked true and empty templateList',()=>{

        let event : any={checked : true}
        let selectedTemplates:any[];
        let storeTemplates:any[]=[
            {
             "functionalAreaName": "Account"  
            }
        ]
        component.storeTemplates = storeTemplates;
        component.selectedTemplates = selectedTemplates;
        component.selectFunctionalArea(event,templateObject) 
        expect(component.selectedTemplates.length).toEqual(1);
     });

     it('test selectAllFunctionalAreas',()=>{
        let event : any={checked : true}
        component.templateList = templateList;
        component.selectAllFunctionalAreas(event);
        expect(component.isAllChecked).toBeTruthy();
     });

     it('test selectAllFunctionalAreas event false',()=>{
        let event : any={checked : false}
        component.selectAllFunctionalAreas(event);
        expect(component.isAllChecked).toBeFalsy();
        expect(component.deSelectAll).toBeTruthy();
     });

     it('test isTemplateChecked',()=>{  
        component.deSelectAll = false;
        component.bpVersionObj = new BestPracticeVersionObject();
        let storeTemplates:any[]=[
            {
             "functionalAreaName": "Service"  
            }
        ]
        let selectedTemplates:any[];
        component.selectedTemplates = selectedTemplates;
        component.storeTemplates = storeTemplates;
        component.isTemplateSetForFirstTime = false;
        let checked  = component.isTemplateChecked('Service');
         expect(checked).toBeTruthy();
     });

     it('test isTemplateChecked for SelectAll',()=>{ 
        component.deSelectAll = true;
        component.bpVersionObj = new BestPracticeVersionObject();
        let checked  = component.isTemplateChecked('Service');
        expect(checked).toBeFalsy();
     });

     it('test isAllTemplatesChecked',()=>{ 
        component.bpVersionObj = new BestPracticeVersionObject();
        let storeTemplates:any[]=[
            {
             "functionalAreaName": "Service"  
            }
        ]
        let selectedTemplates:any[];
        component.selectedTemplates = selectedTemplates;
        component.storeTemplates = storeTemplates;
        let checked  = component.isAllTemplatesChecked(templateList);
        expect(checked).toBeTruthy();
     });

     it('test getAllFunctionalAreaArtifacts',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        let allTemplates:any[]=[];
        component.allTemplates = allTemplates;
        component.currentBestPractice = currentBestPractice;
        spyOn(bestPracticeService,'getAllFunctionalAreaArtifacts').and.returnValue(Observable.of(templateList));
        component.getAllFunctionalAreaArtifacts();
        expect(component.allTemplates.length).toEqual(1);    
     });

     it('loadData',()=>{
        let event : any={selectedIndex : 1}
        spyOn(component,'getAllFunctionalAreaArtifacts');
        component.loadData(event);
        expect(component.isButtonDisabled).toBeFalsy();
     });

     it('test saveBestPracticeVersion',()=>{

        component.currentBestPractice = currentBestPractice;
        component.isEdit = true;
        component.existingVersionName = "2021";
        component.bpVersionObj= bestPracticeVersionObject;
        spyOn(bestPracticeService,'getByBestPracticeNameAndPlatform').and.returnValue(Observable.of({}));
        spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.of(bpVersionList));
        component.saveBestPracticeVersion();
        expect(component.isButtonDisabled).toBeTruthy();
     });

     it('test saveBestPracticeVersion throw error',()=>{

      component.currentBestPractice = currentBestPractice;
      component.isEdit = true;
      component.existingVersionName = "2021";
      component.bpVersionObj= bestPracticeVersionObject;
      spyOn(bestPracticeService,'getByBestPracticeNameAndPlatform').and.returnValue(Observable.throwError('error'));
      spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.of(bpVersionList));
      component.saveBestPracticeVersion();
      expect(component.isButtonDisabled).toBeFalsy();
   });

     it('test saveBestPracticeVersion for Propagation false',()=>{

        let bpVersionList1: BestPracticeVersionObject[]=[
            {
              id : "123",
              recordType : "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
              versionName : "2021",
              active : true,
              objectType : "test",
              functionalAreaList : null,
              propagationStarted:false, 
            }
        ]
        component.currentBestPractice = currentBestPractice;
        component.isEdit = true;
        component.existingVersionName = "2021";
        component.bpVersionObj= bestPracticeVersionObject;
        spyOn(component,'callBestPracticeServiceBPVersionSave');
        spyOn(bestPracticeService,'getByBestPracticeNameAndPlatform').and.returnValue(Observable.of({}));
        spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.of(bpVersionList1));
        component.saveBestPracticeVersion();
        expect(component.isButtonDisabled).toBeFalsy();
     });

     it('test saveBestPracticeVersion version name are different',()=>{

        let bpVersionList1: BestPracticeVersionObject[]=[
            {
              id : "123",
              recordType : "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
              versionName : "2023",
              active : true,
              objectType : "test",
              functionalAreaList : null,
              propagationStarted:false, 
            }
        ]
        component.currentBestPractice = currentBestPractice;
        component.isEdit = true;
        component.existingVersionName = "2026";
        component.bpVersionObj= bestPracticeVersionObject;
        spyOn(component,'duplicateBpVersionCheckAndSave');
        spyOn(bestPracticeService,'getByBestPracticeNameAndPlatform').and.returnValue(Observable.of({}));
        spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.of(bpVersionList1));
        component.saveBestPracticeVersion();
        expect(component.isButtonDisabled).toBeFalsy();
     });

     it('test saveBestPracticeVersion for create',()=>{

        let bpVersionList1: BestPracticeVersionObject[]=[
            {
              id : "123",
              recordType : "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
              versionName : "2023",
              active : true,
              objectType : "test",
              functionalAreaList : null,
              propagationStarted:false, 
            }
        ]
        component.currentBestPractice = currentBestPractice;
        component.isEdit = false;
        component.existingVersionName = "2026";
        component.bpVersionObj= bestPracticeVersionObject;
        spyOn(component,'duplicateBpVersionCheckAndSave');
        spyOn(bestPracticeService,'getByBestPracticeNameAndPlatform').and.returnValue(Observable.of({}));
        spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.of(bpVersionList1));
        component.saveBestPracticeVersion();
        expect(component.isButtonDisabled).toBeFalsy();
     });

     it('test saveBestPracticeVersion best practice versions length empty',()=>{

        let bpVersionList1: BestPracticeVersionObject[]=[]
        component.currentBestPractice = currentBestPractice;
        component.bpVersionObj= bestPracticeVersionObject;
        spyOn(component,'callBestPracticeServiceBPVersionSave');
        spyOn(bestPracticeService,'getByBestPracticeNameAndPlatform').and.returnValue(Observable.of({}));
        spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.of(bpVersionList1));
        component.saveBestPracticeVersion();
        expect(component.isButtonDisabled).toBeFalsy();
     }); 

     it('test validateNameFromDB',()=>{

        component.currentBestPractice = currentBestPractice;
        spyOn(bestPracticeService,'getByBestPracticeNameAndPlatform').and.returnValue(Observable.of({}));
        spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.of(bestPracticeVersionObjectList));
        component.validateNameFromDB('2021');

     });

     it('test duplicateBpVersionCheckAndSave',()=>{      
          let bestPracticeVersionObject:BestPracticeVersionObject={
            id : "123",
            recordType : "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
            versionName : "2021",
            active : true,
            objectType : "test",
            functionalAreaList : null,
            propagationStarted:false, 
        };
        component.bpVersionObj = bestPracticeVersionObject;
        component.duplicateBpVersionCheckAndSave(bpVersionList,"test");
        expect(component.isButtonDisabled).toBeTruthy();
     }); 

     it('test duplicateBpVersionCheckAndSave if duplicate BP Version Does not exist',()=>{      
          let bestPracticeVersionObject:BestPracticeVersionObject={
            id : "123",
            recordType : "a536ba2e-e3b5-42c8-9f9e-b9785f1ea9a7",
            versionName : "2025",
            active : true,
            objectType : "test",
            functionalAreaList : null,
            propagationStarted:false, 
        };
        component.bpVersionObj = bestPracticeVersionObject;
        spyOn(component,'callBestPracticeServiceBPVersionSave');
        component.duplicateBpVersionCheckAndSave(bpVersionList,"test");
        expect(component.isButtonDisabled).toBeFalsy();
    }); 
    
    it('test closePopup',()=>{
      component.closePopup();
    });


    it('test callBestPracticeServiceBPVersionSave',()=>{
      let storeData:any={}
      component.currentBestPractice = currentBestPractice;
      spyOn(bestPracticeService,'saveBestPracticeVersion').and.returnValue(Observable.of(storeData))
      spyOn(component.loaderDialogRef,'close').and.returnValue(false);
      component.callBestPracticeServiceBPVersionSave(bestPracticeVersionObject,list_of_template_response)
      expect(bestPracticeService.saveBestPracticeVersion).toHaveBeenCalledTimes(1);
   

    });
});