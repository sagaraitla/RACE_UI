import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { Routes, RouterModule, CanActivate } from '@angular/router';

import { NoopAnimationsModule, BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {AgGridModule} from "ag-grid-angular/main";
import {TreeModule} from 'ng2-tree';
import {MatTabsModule} from '@angular/material/tabs';

import { CustomMaterialModule } from './custom_material_modules/custom-material-modules';

import { AuditLogService } from './services/audit-log-service';
import { BestPracticeService } from './services/bestpractice-service';
import { ProjectService } from './services/project-service';
import { StoreService } from './services/store-service';
import { FunctionalAreaService } from './services/functional-area-service';
import { FunctionalUnitService } from './services/functional-unit-service';
import { RowDataService } from './services/rowdata-service';
import { ServerCommunicationService } from './services/server-communication-service';
import { MasterFunctionalUnitService } from './services/master-functional-unit-service';
import { AmazonS3LogsService } from './services/amazonS3Logs-service';
import { MasterFunctionalAreaService } from './services/master-functional-area-service';
import { DataTransferService } from './services/data-transfer-service';
import { AuthService } from './services/auth-service';
import {PermissionGuardService} from './services/permission-guard-service';

import { ExcelService} from './services/excel-service';
import { ValidationService} from './services/validation-service';
import { FormattingService } from './services/formatting-service';
import { LaunchDarklyService } from './services/launchdarkly-service';

import { DashboardComponent } from './dashboard/dashboard.component';
import { BestPracticeMaintenanceComponent } from './bestpractice-maintenance/bestpractice-maintenance.component';
import { CreateProjectComponent } from './create-project/create-project.component';
import { CreateBestPracticeComponent } from './create-bestpractice/create-bestpractice.component';
import { ProjectInformationComponent } from './project-information/project-information.component';
import { BestPracticeInformationComponent } from './bestpractice-information/bestpractice-information.component';
import { TemplateInformationComponent } from './template-information/template-information.component';
import { AddStoreComponent } from  './add-store/add-store-dialog.component';
import { AddBPVersionComponent } from  './add-bp-version/add-bp-version-dialog.component';
import { AuditLogsComponent } from  './audit-logs/audit-logs.component';
import { AuditLogsFAComponent } from  './audit-logs/functionalarea/audit-logsfa.component';
import { AuditLogsFUComponent } from './audit-logs/functionalunit/audit-logsfu.component';
import {AuditLogsVTComponent} from './audit-logs/validatetransfer/audit-logsvt.component';
import {AuditVTDialogComponent} from './audit-logs/validate-transfer-dialog/audit-vt-dialog.component';
import { AuditLogDialogComponent } from  './audit-log-dialog/audit-log-dialog.component';

import { LoaderDialogueComponent } from './loader-dialog/loader-dialog.component';
import { ConfirmDialogComponent } from './confirm-dialog/confirm-dialog.component';
import { AlertDialogComponent } from './alert-dialog/alert-dialog.component';
import { SteppedProgressbarComponent } from './stepped-progressbar/stepped-progressbar.component';
import { FunctionalUnitVerticalStepper } from './vertical-stepper-fu/vertical-stepper-fu.component';
import { AgGridCellTooltipRenderer } from './template-information/cell-tooltip.component';
import { ComponentFactoryResolver } from '@angular/core';
import {DatepickerModule} from 'ngx-bootstrap';
import {CdkTableModule} from '@angular/cdk/table';
import {BootstrapDatePickerComponent} from "./editor-components/date-picker.component";
import { MultivalueDialogComponent } from './multivalue-dialog/multivalue-dialog.component';
import { MultivalueDropdownDialogComponent } from './multivalue-dropdown-dialog/multivalue-dropdown-dialog.component';
import { GroupedMultivalueDialogComponent } from './multivalue-dropdown-with-grouping/multivalue-dropdown-with-grouping.component';
import {ImportDialog} from './import-dialog/import-dialog.component';

import {MatDialogModule} from '@angular/material';
import {ExistingFunctionalUnitComponent} from "./existing-functional-unit/existing-functional-unit.component";
import {NewFunctionalUnitComponent} from "./new-functional-unit/new-functional-unit.component";
import {NewFunctionalAreaComponent} from "./new-functional-area/new-functional-area.component";
import {ExistingFunctionalAreaComponent} from "./existing-functional-area/existing-functional-area.component";
import {BestPracticeTree} from "./bestpractice-tree/bestpractice-tree.component";
import {FlexDashService} from './services/flex-dash.service';
import { DashReportComponent } from './dash-report/dash-report.component';
import { ToastrModule } from 'ngx-toastr';
import { AddBPSSSVersionComponent } from  './add-bp-sss-version/add-bp-sss-version-dialog.component';
import { DatePipe } from '@angular/common';
import { ValidationRuleService } from './services/validation-rule-service';
import {NewValidationRuleComponent} from "./new-validation-rule/new-validation-rule.component";
import {ExistingValidationRulesComponent} from "./existing-validation-rules/existing-validation-rules.component";
import { FlexValidationService } from './services/flex-validation.service';

import { AuditLogsVRComponent } from './audit-logs/validation-rule/audit-log-validation-rule.component';
import { AuditLogDialogDetailsComponent } from './audit-log-dialog-details/audit-log-dialog-details.component';
import { AuditLogsS3DialogComponent } from './audit-logs/audit-logs-s3-dialog/audit-logs-s3-dialog.component';
import { ProcessValidationResultsComponent } from './process-validation-results/process-validation-results.component';
import { ModifyVICComponent } from './modify-vic/modify-vic.component';
import { WarningAcknowledgementComponent } from './warning-acknowledgement/warning-acknowledgement.component';
import { AuditLogsS3LogContent } from './fetch-s3log-content/fetch-s3log-content.component';
import {AuditLogsBPComponent} from './audit-logs/bestpractice/audit-log-bestpractice.component';
import { AuditLogGomDialogComponent } from './audit-log-gom-dialog-details/audit-log-gom-dialog.component';
import { AdminConsoleComponent } from './admin-console/admin-console.component';
import { PropagationAcknowledgementComponent } from './propagation-acknowledgement/propagation-acknowledgement.component';
import { BPFUPropagateChangesDialogComponent } from './bp-fu-propagate-changes-dialog-details/bp-fu-propagate-changes-dialog.component';
import { AuditLogsPropagationComponent } from './audit-logs/change-propagation/audit-logs-propagation.component';
import {FuPropagationAuditLogDialogComponent} from './fu-propagation-audit-log-details/fu-propagation-audit-log-dialog.component'
import { HttpClientModule } from '@angular/common/http';
import { HasPermissionDirective } from './directive/has-permission.directive';

const routes: Routes = [
  {path: 'dashboard', component: DashboardComponent},
  {path: 'bestpractice', component: BestPracticeMaintenanceComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_BP_VIEW"} },
  {path: 'projects/create', component: CreateProjectComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_PROJECT_CREATE"} },  
  {path: 'bestpractice/create', component: CreateBestPracticeComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_BP_CREATE"} },
  {path: 'projects/:name', component: ProjectInformationComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_PROJECT_VIEW"} },
  {path: 'bestPractice/stateStandard/:name/:isStateStandard', component: BestPracticeInformationComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_BP_VIEW"} },
  {path: 'bestpractice/getOne/:name/:platformCode', component: BestPracticeInformationComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_BP_VIEW"} },
  {path: 'projects/:projectNumber/stores/:storeId/functionalAreas/:functionalAreaId/:enterpriseStore', component: TemplateInformationComponent},
  {path: 'bestpractice/:projectNumber/statestandard/version/:storeId/functionalAreas/:functionalAreaId/:enterpriseStore/:isStateStandard', component: TemplateInformationComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_BP_VIEW"} },
  {path: 'bestpractice/:projectNumber/:platformCode/version/:storeId/functionalAreas/:functionalAreaId/:enterpriseStore/:isBestPractice', component: TemplateInformationComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_BP_VIEW"} },
  {path: 'functionalUnits' , component : ExistingFunctionalUnitComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_SCREEN_VIEW"} },
  {path: 'functionalUnits/newFunctionalUnit' , component : NewFunctionalUnitComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_SCREEN_CREATE"} },
  {path: 'functionalArea' , component : ExistingFunctionalAreaComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_TEMPLATE_VIEW"} },
  {path: 'functionalArea/newFunctionalArea' , component : NewFunctionalAreaComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_TEMPLATE_CREATE"} },
  {path: 'auditLogsP', component: AuditLogsComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_AUDIT_VIEW"} },
  {path: 'auditLogsFA', component: AuditLogsFAComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_AUDIT_VIEW"} },
  {path: 'auditLogsFU', component: AuditLogsFUComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_AUDIT_VIEW"} },
  {path: 'auditLogsVT', component: AuditLogsVTComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_AUDIT_VIEW"} },
  {path: 'auditLogsVR', component: AuditLogsVRComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_AUDIT_VIEW"} },
  {path: 'auditLogsBP', component: AuditLogsBPComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_AUDIT_VIEW"} },
  {path: 'auditLogsS3Dialog', component: AuditLogsS3DialogComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_AUDIT_VIEW"} },
  {path: 'auditLogsS3LogContent', component: AuditLogsS3LogContent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_AUDIT_VIEW"} },
  {path: 'auditLogGomDialog', component: AuditLogGomDialogComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_AUDIT_VIEW"} },
  {path: 'auditLogsPropagation',component:AuditLogsPropagationComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_AUDIT_VIEW"} },
  {path: 'sss/:isSSSNavigatedFromProject', component: TemplateInformationComponent},
  {path: 'validationRule', component: ExistingValidationRulesComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_VR_VIEW"} },
  {path: 'validationRule/newValidationRule' , component : NewValidationRuleComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_VR_CREATE"} },
  {path: 'processValidationResults',component:ProcessValidationResultsComponent},
  {path: 'modifyVIC',component:ModifyVICComponent},
  {path: 'warningAcknowledgement',component:WarningAcknowledgementComponent},
  {path: 'adminConsole',component:AdminConsoleComponent, canActivate: [PermissionGuardService],  data: {expectedPermission: "DOT_ADMIN"} },
  {path: 'propagationAcknowledgement',component:PropagationAcknowledgementComponent},
  {path: 'bpFuPropagateChangesDialog',component:BPFUPropagateChangesDialogComponent},
  {path:'fuPropagationAuditLogsDetails',component:FuPropagationAuditLogDialogComponent},
  {path: '**', redirectTo: 'dashboard'}
];

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    BestPracticeMaintenanceComponent,
    CreateProjectComponent,
    CreateBestPracticeComponent,
    ProjectInformationComponent,
    BestPracticeInformationComponent,
    AddStoreComponent,
    AddBPVersionComponent,
    LoaderDialogueComponent,
    ConfirmDialogComponent,
    AlertDialogComponent,
    AgGridCellTooltipRenderer,
    TemplateInformationComponent,
    BootstrapDatePickerComponent,
    SteppedProgressbarComponent,
    FunctionalUnitVerticalStepper,
    MultivalueDialogComponent,
    MultivalueDropdownDialogComponent,
    GroupedMultivalueDialogComponent,
    AuditLogsComponent,
    AuditLogsFAComponent,
    AuditLogsFUComponent,
    AuditLogsVTComponent,
    AuditVTDialogComponent,
    AuditLogDialogComponent,
    AuditLogsS3DialogComponent,
    ExistingFunctionalUnitComponent,
    NewFunctionalUnitComponent,
    ExistingFunctionalAreaComponent,
    ModifyVICComponent,
    NewFunctionalAreaComponent,
    BestPracticeTree,
    ImportDialog,
    DashReportComponent,
    AddBPSSSVersionComponent,
    ExistingValidationRulesComponent,
    NewValidationRuleComponent,
    AuditLogsVRComponent,
    AuditLogDialogDetailsComponent,
    ProcessValidationResultsComponent,
    WarningAcknowledgementComponent,
    AuditLogsBPComponent,
    AuditLogsS3LogContent,
    AuditLogGomDialogComponent,
    AdminConsoleComponent,
    PropagationAcknowledgementComponent,
    BPFUPropagateChangesDialogComponent,
    AuditLogsPropagationComponent,
    FuPropagationAuditLogDialogComponent,
    HasPermissionDirective,
  ],
  imports: [
    BrowserModule,
    CdkTableModule,
    NoopAnimationsModule,
    CustomMaterialModule,
    AgGridModule.withComponents(
            [
            ]),
    DatepickerModule.forRoot(),
    HttpClientModule,
    TreeModule,
    MatTabsModule,
    RouterModule.forRoot(routes, {useHash: true}),
    MatDialogModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      timeOut: 5000,
      positionClass: 'toast-top-center',
      preventDuplicates: true,
      closeButton: false,
      
      
    })
    
  ],
  entryComponents: [
      LoaderDialogueComponent, ConfirmDialogComponent, AlertDialogComponent, AddStoreComponent, AddBPVersionComponent,
  	  BootstrapDatePickerComponent, MultivalueDialogComponent, MultivalueDropdownDialogComponent,AuditLogDialogComponent,
      AuditVTDialogComponent, AgGridCellTooltipRenderer, GroupedMultivalueDialogComponent, BestPracticeTree,ImportDialog,
      DashReportComponent,AddBPSSSVersionComponent,AuditLogDialogDetailsComponent
  ],
  providers: [
    AmazonS3LogsService,
    AuditLogService,
    ProjectService,
    StoreService,
    FunctionalAreaService,
    FunctionalUnitService,
    RowDataService,
    ServerCommunicationService,
    MasterFunctionalUnitService,
    MasterFunctionalAreaService,
    DataTransferService,
    AuthService,
    PermissionGuardService,
    ExcelService,
    ValidationService,
    FormattingService,
    BestPracticeService,
    LaunchDarklyService,
    FlexDashService,
    DatePipe,
    ValidationRuleService,
    FlexValidationService
  ],
  bootstrap: [AppComponent]
})

export class AppModule {
}
