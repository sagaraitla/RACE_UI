import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormsModule } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialogModule, MatDialogRef, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatSnackBar, MatSortModule, MatTableDataSource, MAT_DIALOG_DATA } from "@angular/material";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router, RouterModule } from "@angular/router";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { Observable } from 'rxjs';
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { GenericResponse } from "../model/generic-response";
import { PropagateFuChangesToBp } from "../model/propagate-fu-changes-to-bp";
import { AuditLogService } from "../services/audit-log-service";
import { AuthService } from "../services/auth-service";
import { ServerCommunicationService } from "../services/server-communication-service";
import { FuPropagationAuditLogDialogComponent } from "./fu-propagation-audit-log-dialog.component";

describe('FuPropagationAuditLogDialogComponent',() => {

    
    let component : FuPropagationAuditLogDialogComponent;
    let fixture : ComponentFixture<FuPropagationAuditLogDialogComponent>;
    let auditLogService: AuditLogService;
    let authService : AuthService;
    let routerStub: Router;

    class MatDialogMock {
        open() {
          return {
            afterClosed: () => Observable.of(true)
          };
        }
      };

      const dialogMock = {
        close: () => { }
        };
      beforeEach(async(() =>{
        let mockRouter = { navigate: jasmine.createSpy('navigateByUrl')
        } 
        let data= {
            displayName:'test',
            auditLog:'test_audit_log'
        }
        TestBed.configureTestingModule({
           imports: [
                MatCardModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatPaginatorModule,
                MatDialogModule,
                ToastrModule.forRoot(),
                CommonModule,
                MatSelectModule,
                MatCheckboxModule,
                MatRadioModule,
                MatSortModule,
                MatIconModule,
                FormsModule,
                MatMenuModule,
                MatDividerModule,
                RouterModule.forRoot([]),
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                SortableModule,
                MatSortModule
            ],
            declarations : [
                FuPropagationAuditLogDialogComponent,LoaderDialogueComponent],
            providers : [
                MatSnackBar,
                FormBuilder!,
                ServerCommunicationService,
                AuditLogService,
                AuthService,
                ToastrService,
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: dialogMock},
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent]}});
            authService = TestBed.get(AuthService);
            routerStub  = TestBed.get(Router);
            auditLogService = TestBed.get(AuditLogService);
        
      }));

      beforeEach(() => {
        fixture = TestBed.createComponent(FuPropagationAuditLogDialogComponent);
        component = fixture.componentInstance;
    });

    const generic_response : GenericResponse = {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [],
          "executionTime" : null
      }

    it('test ngOnInit',()=>{
        component.dataSource = new MatTableDataSource<PropagateFuChangesToBp>(generic_response.resultObj);
        spyOn(auditLogService,'getPropagatedFuAuditlogById').and.returnValue(Observable.of(generic_response));
        fixture.detectChanges();
        expect(auditLogService.getPropagatedFuAuditlogById).toHaveBeenCalledTimes(1);
    });

    it('test closePopup',()=>{
        component.closePopup();
    });
});