import { Component, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar, MatTableDataSource , MatSort, Sort,MatPaginator} from '@angular/material';
import { Router } from '@angular/router';

import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { AuditLogService } from '../services/audit-log-service';
import { AuthService } from '../services/auth-service';
import { AuditLogsObject } from '../model/audit-logs-object';
import { ToastrService } from 'ngx-toastr';
import { PropagateFuChangesToBp } from '../model/propagate-fu-changes-to-bp';

@Component({
      selector: 'app-fu-propagation-audit-log-dialog',
      templateUrl: './fu-propagation-audit-log-dialog.component.html',
      styleUrls: ['./fu-propagation-audit-log-dialog.component.css']
})

export class FuPropagationAuditLogDialogComponent {
    
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
        
      auditLog : AuditLogsObject;
      dataSource : any;
      displayName:string;
      fuName:string;

      displayedColumns = ['item','itemType','platform'];
      constructor(private auditLogService: AuditLogService, private dialogRef: MatDialogRef<FuPropagationAuditLogDialogComponent>, private authService: AuthService,
              private _formBuilder: FormBuilder, @Inject(MAT_DIALOG_DATA) private data: any,  private dialog: MatDialog, private toastrService:ToastrService,
              private snackBar: MatSnackBar, private router: Router) {
          dialogRef.disableClose = true;
          
          this.displayName = this.data.displayName;
          this.auditLog = JSON.parse(JSON.stringify(this.data.auditLog));

      }
  
      ngOnInit() {
        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
          width: '300px',
          height: '150px',
          data: { message: 'Fetching FU propagation details..' }
        });

      this.auditLogService.getPropagatedFuAuditlogById(this.auditLog.id).subscribe(genericResponse => {
          if(genericResponse != null && genericResponse != undefined && genericResponse.resultDescription == "OK" && genericResponse.resultDescription != null){
              this.dataSource =  new MatTableDataSource<PropagateFuChangesToBp>(genericResponse.resultObj);   
              this.dataSource.paginator = this.paginator;
              this.dataSource.sort = this.sort;
              loaderDialogRef.close();
          }else{
          loaderDialogRef.close();
          }
          },error => {
              this.toastrService.error('Error while fetching the data ' + error.error.message);
              loaderDialogRef.close();
              }
          ); 
          
      }
  
      closePopup() {
          this.dialogRef.close();
      };

}
