import { CdkTableModule } from '@angular/cdk/table';
import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule, MatCheckboxModule, MatDialogModule, MatDividerModule, MatFormFieldModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatSidenavModule, MatTableModule } from '@angular/material';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router, RouterModule } from '@angular/router';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { ProjectObject } from '../model/project-object';
import { AuthService } from '../services/auth-service';
import { ProjectService } from '../services/project-service';
import { CreateProjectComponent } from "./create-project.component";

describe('CreateProjectComponent', () => {

    let component : CreateProjectComponent;
    let fixture: ComponentFixture<CreateProjectComponent>;
    let projectService: ProjectService;
    let authService: AuthService;
    let routerStub: Router;
    let toastrService : ToastrService;

    beforeEach(async(() => {

        TestBed.configureTestingModule({
          imports: [
            MatProgressSpinnerModule,
            MatMenuModule,
            MatDividerModule,
            FormsModule,
            MatCardModule,
            FormsModule,
            MatFormFieldModule,
            MatInputModule,
            CdkTableModule,
            MatMenuModule,
            MatTableModule,
            MatPaginatorModule,
            MatDialogModule,
            HttpClientTestingModule,
            ToastrModule.forRoot(),
            RouterModule.forRoot([]),
            NoopAnimationsModule,
            ReactiveFormsModule,
            CommonModule,
            MatSelectModule,
            MatRadioModule,
            MatCheckboxModule,
            MatSidenavModule],
          declarations: [ CreateProjectComponent,LoaderDialogueComponent],
          providers:[
            ProjectService,
            AuthService,
           ToastrService
          ]
        }).overrideModule(BrowserDynamicTestingModule,
           { set: { entryComponents: [LoaderDialogueComponent]}});

            authService = TestBed.get(AuthService);
            projectService = TestBed.get(ProjectService);
            routerStub  = TestBed.get(Router);
            toastrService  = TestBed.get(ToastrService);

            fixture = TestBed.createComponent(CreateProjectComponent);
            component = fixture.componentInstance;
      }));

    

    const project:ProjectObject = {

        "isProject": 1,
        "enterpriseId": "E218665",
        "projectNumber": "P1233",
        "dealerName": "EAGLE RIVER MOTORS",
        "location": null,
        "platform": {
          "platformName": "FLEX",
          "platformCode": "flex",
          "selected": false
        },
        "storeIds":null,
        "status": "OPEN",
        "clientManager": null,
        "vic": null,
        "css": null,
        "projectManager": null,
        "language": "en_US",
        "country": "United States",
        "timezone": "UTC-6: Central Standard Time (CST)",
        "cdku": false,
        "cdku_coordinator": null,
        "cdku_domain": null,
        "cdku_division": null,
        "cdku_login": null,
        "cdku_password": null,
        "clientProjectAdvocate": null,
        "version": 9,
        "failed": false,
        "projectSourceEnv": "DASH",
        "dealerApproverContact": null,
        "dealerApproverRequired": false,
        "createdDate": null,
        "lastUpdatedDate": null,
        "createdBy": null,
        "updatedBy": "terry.campbell@cdk.com",
        "id": "f606e381-ea3a-40c6-9340-afe65fe21498",
        "recordType": "ProjectInfo"
      }
    const platforms:any=[
        {
            platformName:"FLEX"
        }
    ]


    it('test ngOnInit ',()=>{
      spyOn(authService,'isAuthorised').and.returnValue(Observable.of({}));
      fixture.detectChanges();
    });


    it('should create Create Project Component',()=>{
      expect(component).toBeTruthy();
    });

     it('test create project',()=>{

        component.selectedPlatform ="FLEX";
        component.platforms = platforms;
        component.projectObject.projectNumber ="123";
        spyOn(component,'isValidForm').and.returnValue(true);
        spyOn(routerStub, 'navigate');
        spyOn(projectService,'createProject').and.returnValue(Observable.of(project));
        component.createProject();
        expect(routerStub.navigate).toHaveBeenCalledWith(['projects/123']);
        expect(projectService.createProject).toHaveBeenCalledTimes(1);
     })


     it('test create project project service return error',()=>{

      component.selectedPlatform ="FLEX";
      component.platforms = platforms;
      component.projectObject.projectNumber ="123";
      spyOn(component,'isValidForm').and.returnValue(true);
      spyOn(projectService,'createProject').and.returnValue(Observable.throw('error'));
      component.createProject();
   
    })

    it('test create project mandatory fields not filled ',()=>{

      spyOn(component,'isValidForm').and.returnValue(false);
      spyOn(component,'checkMissingField');
      component.createProject();
      expect(component.checkMissingField).toHaveBeenCalledTimes(1);
    });

    it('test checkMissingField',()=>{

      
      project.projectNumber = null;
      component.projectObject = project;
      component.checkMissingField();
    
      let eid =  project.enterpriseId; 
      project.enterpriseId= null;
      component.projectObject = project;
      component.checkMissingField();

      project.dealerName = null;
      component.projectObject = project;
      component.checkMissingField();
    });

    it('test resetPlatformCSS',()=>{
      component.resetPlatformCSS({});
      expect(component.isPlatformNotSelected).toBeFalsy();
    });

    it('test changeStatus',()=>{
      let event={
        checked:false
      }
      component.changeStatus(event);
      expect(component.projectObject.cdku_domain).toEqual('');
      expect(component.projectObject.cdku_login).toEqual('');
    });

    it('test isValidForm',()=>{

      const myProject:ProjectObject = {

        "isProject": 1,
        "enterpriseId": "E218665",
        "projectNumber": "P1233",
        "dealerName": "EAGLE RIVER MOTORS",
        "location": null,
        "platform": {
          "platformName": "FLEX",
          "platformCode": "flex",
          "selected": false
        },
        "storeIds":null,
        "status": "OPEN",
        "clientManager": null,
        "vic": null,
        "css": null,
        "projectManager": null,
        "language": "en_US",
        "country": "United States",
        "timezone": "UTC-6: Central Standard Time (CST)",
        "cdku": false,
        "cdku_coordinator": null,
        "cdku_domain": null,
        "cdku_division": null,
        "cdku_login": null,
        "cdku_password": null,
        "clientProjectAdvocate": null,
        "version": 9,
        "failed": false,
        "projectSourceEnv": "DASH",
        "dealerApproverContact": null,
        "dealerApproverRequired": false,
        "createdDate": null,
        "lastUpdatedDate": null,
        "createdBy": null,
        "updatedBy": "terry.campbell@cdk.com",
        "id": "f606e381-ea3a-40c6-9340-afe65fe21498",
        "recordType": "ProjectInfo"
      }
      component.projectObject = myProject;
      expect(component.isValidForm()).toBeTruthy();
    });

    it('test validateNameFromDB if project already exists',()=>{
      let formData:any={

        form:{
          status:'VALID'
        }
      }
      spyOn(projectService,'getProjectByNumber').and.returnValue(Observable.of(project));
      component.validateNameFromDB(formData);
      expect(formData.form.status).toEqual('INVALID');
      expect(projectService.getProjectByNumber).toHaveBeenCalledTimes(1);
    
    
    });

    it('test validateNameFromDB VALID if getProjectNumber response is not null',()=>{
      let formData:any={

        form:{
          status:'VALID'
        }
      }
      spyOn(projectService,'getProjectByNumber').and.returnValue(Observable.of(null));
      component.validateNameFromDB(formData);
      expect(formData.form.status).toEqual('VALID');
    
    });

    it('test validateNameFromDB In case of api error ',()=>{
      let currentProject  = project;
      currentProject.projectNumber = 'P2233@';
      component.projectObject = currentProject;
      let formData:any={
        form:{
          status:'VALID'
        }
      }

      spyOn(projectService,'getProjectByNumber').and.returnValue(Observable.throwError('error'));
      component.validateNameFromDB(formData);
      expect(formData.form.status).toBe('INVALID')
    });

    it('test checkIfValidField in case of valid project number',()=>{
        let currentProject  = project;
        currentProject.projectNumber = 'P4456';
        component.projectObject = currentProject;
        component.checkIfValidField('projectNumber');
        expect(component.projectObject.projectNumber).toEqual('P4456');
    });

    it('test checkIfValidField in case of Invalid project number',()=>{
      let currentProject  = project;
      currentProject.projectNumber = '$';
      component.projectObject = currentProject;
      component.checkIfValidField('projectNumber');
      expect(component['toastrService'].previousToastMessage).toBe('Please enter valid Project Number.')
      expect(component.projectObject.projectNumber).toEqual('');
    });

    it('test cancelProjectCreation',()=>{
      const navigateSpy = spyOn(routerStub, 'navigateByUrl');
      component.cancelProjectCreation();
      expect(navigateSpy).toHaveBeenCalledWith('dashboard');
    });
}); 