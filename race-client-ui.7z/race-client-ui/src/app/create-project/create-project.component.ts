import { Component, OnInit } from '@angular/core';

import { ProjectService } from '../services/project-service';
import { AuthService } from '../services/auth-service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { ProjectObject } from '../model/project-object';
import { ToastrModule, Toast } from 'ngx-toastr';
import { ToastrService } from 'ngx-toastr'; 
import { FormControl, Validators, CheckboxControlValueAccessor } from '@angular/forms';
import { isEmpty } from 'rxjs/operators';
import { Constants } from '../constant/constants';




@Component({
  selector: 'app-create-project',
  templateUrl: './create-project.component.html',
  styleUrls: ['./create-project.component.css']
})
export class CreateProjectComponent implements OnInit {

    projectObject: ProjectObject = new ProjectObject();
    selectedPlatform : string;
    createProjectPermission = false; 
    private user: any = {};
  
    platforms = [];
    CDKU_Logins :any[];
    CDKU_Domains :any[];
    CDKU_Coordinators :any[];
    countries:any[];
    languages :any[];
    timezones :any[];

    isPlatformNotSelected: boolean = false;

    constructor(private projectService: ProjectService, private authService: AuthService, private route: ActivatedRoute, 
    		private router: Router, private dialog: MatDialog, private toastrService: ToastrService,private toast :ToastrModule) { 
        this.user = this.authService.getLoggedInUser().user;
        this.timezones=Constants.TIMEZONES;
        this.languages=Constants.LANGUAGES;
        this.countries=Constants.COUNTRIES;
        this.CDKU_Coordinators=Constants.CDKU_COORDINATORS;
        this.CDKU_Domains=Constants.CDKU_DOMAINS;
        this.CDKU_Logins=Constants.CDKU_LOGINS;
        this.platforms=Constants.PLATFORMS;
        
    }

    ngOnInit() {
    	this.createProjectPermission = this.authService.isAuthorised('DOT_PROJECT_CREATE');
    }
  
    createProject() {
    	const platform =  this.selectedPlatform;
        const selectedPlatforms = this.platforms.filter(function (e) {
        	return e.platformName === platform;
        });
        
        this.projectObject.platform =  selectedPlatforms[0] ;
        this.projectObject.status ='OPEN'; //While project creation, project status will be OPEN by default.
        this.projectObject.isProject = 1;
        this.projectObject.storeIds = [];
        
        // Post request for Rest endpoint
        if(this.isValidForm()) {
        	let dialogRef = this.dialog.open(LoaderDialogueComponent, {
        		width: '300px',
      	      	height: '150px',
      	      	data: { message: 'Creating new on-boarding project.' }
        	});
        	this.projectService
            .createProject(this.projectObject)
            .subscribe(data => {
            	dialogRef.close();
      		  	this.router.navigate(['projects/' +  this.projectObject.projectNumber]);
            },
            error => {
                this.toastrService.warning('Error while creating project');
                dialogRef.close();
            });
        } else {
        	this.checkMissingField();
        }
    }
    checkMissingField(){
        let missingField: String[] = [];        
        if((this.projectObject.projectNumber == null)||(this.projectObject.projectNumber == '' )||((this.projectObject.projectNumber === undefined)))
            missingField.push('Project Number');
        if((this.projectObject.enterpriseId == null)||(this.projectObject.enterpriseId == '' )||((this.projectObject.enterpriseId === undefined)))
            missingField.push(' Enterprise Id'); 
        if((this.projectObject.dealerName == null)||(this.projectObject.dealerName == '' )||((this.projectObject.dealerName === undefined)))
            missingField.push(' Dealer Name');
        if((this.selectedPlatform == null)||((this.selectedPlatform === undefined))){
            missingField.push(' Platform');
            this.isPlatformNotSelected = true;
        }
         
        this.toastrService.error('Please enter '+ missingField+'.',"");  
    }
         
    resetPlatformCSS(event){        
           this.isPlatformNotSelected = false;
           this.selectedPlatform = event;          
    }

    changeStatus(event : any) {
    	this.projectObject.cdku = event.checked;   
    	if(!this.projectObject.cdku){
    		this.projectObject.cdku_coordinator = '';
    		this.projectObject.cdku_domain = '';
    		this.projectObject.cdku_division = '';
    		this.projectObject.cdku_login = ''; 
    		this.projectObject.cdku_password = '';   
    	} 
    }
    
    isValidForm() {
        let flag = false;
    	if(this.projectObject.projectNumber && this.projectObject.dealerName && this.projectObject.enterpriseId && this.projectObject.platform != null) {
    		flag = true;
    	}
    	return flag;
    }
  
    cancelProjectCreation() {
    	this.router.navigateByUrl('dashboard');
    }

    validateNameFromDB(formData: any) {
    	this.projectService
        .getProjectByNumber(this.projectObject.projectNumber)
        .subscribe(data => {
        	if (data !== null) {
	            this.toastrService.error('Project with ProjectNumber ' + this.projectObject.projectNumber + ' already exists.', "");
	            formData.form.status = 'INVALID';
        	} else {
        		formData.form.status = 'VALID';
        	}
        },
        error => {
            formData.form.status = 'VALID';
            if (this.projectObject.projectNumber.match('^[A-Za-z0-9_-\\s]+$' ) == null ) {
                formData.form.status = 'INVALID';
            }
        });
    }
    
    checkIfValidField(fieldName: string) {
    	let pattern = /[Cc][0-9]+/g;
        let messageFieldName = 'DMS C#';
        if(fieldName === 'projectNumber') {
            pattern= /^[a-zA-Z0-9]*$/;
            messageFieldName = "Project Number";
        }
    	var matchString = this.projectObject[fieldName].match(pattern);
    	if(matchString == null || this.projectObject[fieldName] != matchString[0]) {
            this.toastrService.error('Please enter valid ' + messageFieldName + '.', "");
            this.projectObject[fieldName] = '';
        };
    }    
}
