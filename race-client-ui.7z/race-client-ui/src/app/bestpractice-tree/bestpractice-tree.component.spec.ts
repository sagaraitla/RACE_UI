import { JsonpClientBackend } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogModule } from '@angular/material';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { EventEmitter } from 'events';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { expand } from 'rxjs/operators';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { AuthService } from '../services/auth-service';
import { BestPracticeService } from '../services/bestpractice-service';
import { FunctionalUnitService } from '../services/functional-unit-service';
import { BestPracticeTree } from './bestpractice-tree.component';

describe('BestPracticeTree', () => {

	  let component : BestPracticeTree;
    let fixture: ComponentFixture<BestPracticeTree>;
    let bestPracticeService: BestPracticeService;
	  let functionalUnitService : FunctionalUnitService;
    let authService: AuthService;
    let routerStub: Router;
    let toastrService : ToastrService;
    let treeRenderedEvent : EventEmitter;
    const testUrl  = 'dashboard';

    class treeComponent {
    }

  const childComponent = jasmine.createSpyObj('treeComponent', ['getControllerByNodeId']);
   // const childComponent = jasmine.createSpyObj('treeComponent');
   const observableForkJoin = jasmine.createSpyObj('observableForkJoin', ['subscribe']);
   observableForkJoin
	beforeEach(async(() => {

   
        TestBed.configureTestingModule({
          imports: [
            HttpClientTestingModule,
            MatDialogModule,
            ToastrModule.forRoot(),
            BrowserAnimationsModule
           ],
           schemas: [ NO_ERRORS_SCHEMA ],
          declarations: [BestPracticeTree,LoaderDialogueComponent],
          providers:[
            BestPracticeService,
            FunctionalUnitService,
            EventEmitter,
            AuthService,
            ToastrService,
            {provide: treeComponent, useValue: childComponent},
            { provide: Router, useValue: {url:testUrl} },
          ]
        }).overrideModule(BrowserDynamicTestingModule,
           { set: { entryComponents: [LoaderDialogueComponent]}});
            authService = TestBed.get(AuthService);
            bestPracticeService = TestBed.get(BestPracticeService);
            functionalUnitService = TestBed.get(FunctionalUnitService);
            treeRenderedEvent = TestBed.get(EventEmitter);

           fixture = TestBed.createComponent(BestPracticeTree);
           component = fixture.componentInstance;
      }));


      it('test ngOnInit',()=>{


        let eventData:any[]=[
          {},
          {}
        ]
        spyOn(component.treeRenderedEvent,'subscribe').and.returnValue(Observable.of({eventData}))
        fixture.detectChanges();
      });

	  it('test loadBestPractices',()=>{
      let bestPracticeList:any[]=[
        {
            "isBestPractice": 1,
            "isSSS": 0,
            "bestPracticeName": "33463",
            "platform": {
                "id": null,
                "platformName": "DRIVE",
                "platformCode": "drive",
                "selected": false
            },
            "versionCount": 0,
            "version": 0,
            "failed": false,
            "id": "570c502c-c454-4ae6-a1bc-cd4d276eb373",
            "recordType": "BestPracticeInfo"
        },
        {
            "isBestPractice": 1,
            "isSSS": 0,
            "bestPracticeName": "BPAudit1 - Clone",
            "platform": {
                "id": null,
                "platformName": "DRIVE",
                "platformCode": "drive",
                "selected": false
            },
            "versionCount": 0,
            "version": 0,
            "failed": false,
            "id": "254b60bc-f5e1-4188-a078-bbc56c45988e",
            "recordType": "BestPracticeInfo"
        }
    ]
		  component.loadBestPractices('Flex')
	  });

    it('test loadChildren',()=>{

      let event:any={
        node:{
          node:{
            bestPractice:'test'
          }
        }
      }
      const pspy = spyOn<any>(component,`loadBestPracticeVersions`)
      component['loadChildren'](event);
    });

    it('test loadChildren if node has version',()=>{

      let event:any={
        node:{
          node:{
            version:'test'
          }
        }
      }
      const pspy = spyOn<any>(component,`loadTemplates`)
      component['loadChildren'](event);
    });

    it('test loadChildren if node has template',()=>{

      let event:any={
        node:{
          node:{
            template: {}
          }
        }
      }
      const pspy = spyOn<any>(component,`loadScreens`)
      component['loadChildren'](event);
    });

    it('test handleNodeSelected if isCollapsed true',()=>{
      let event:any={
        node:{
          id:"123"
        }
      }
      let nodeController:any={
        isCollapsed,
        expand
      }
      function isCollapsed(){
        return true;
      }
      function expand(){
        return false;
      }
     childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent;  
      component.handleNodeSelected(event);
    });


    it('test handleNodeSelected if isCollapsed false',()=>{
      let event:any={
        node:{
          id:"123"
        }
      }
      let nodeController:any={
        isCollapsed,
        collapse
      }
      function isCollapsed(){
        return false;
      }
      function collapse(){
        return false;
      }
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent;  
      component.handleNodeSelected(event);
    });
	  
    it('test populateVicsAndSecondaryVicsForAutoAddedTemplates',()=>{

      let storeTemplates:any[]=[
        {
            "functionalAreaName": "Accounting",
            "functionalAreaType": null,
            "oemName": null,
            "clientSignoffDate": null,
            "selected": false,
            "status": "Work in Progress",
            "platforms": [
                {
                    "id": null,
                    "platformName": "DRIVE",
                    "platformCode": "drive",
                    "selected": true
                }
            ],
            "vic": null,
            "secondaryVic": null,
            "clientFunctionalAreaUser": null,
            "version": 23,
            "isFailed": null,
            "inProcess": false,
            "productCode": "ACCT",
            "productVersion": null,
            "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
            "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
            "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
            "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "isDealerApproved": false,
            "stateStandardId": null,
            "stateStandardName": null,
            "stateStandardVersionRecordType": null,
            "stateStandardVersionName": null,
            "copyRowData": false,
            "showValidateOrTransferButton": false,
            "showProcessValidationResultsButton": true,
            "createdDate": "2021-08-19T09:37:41.402+0000",
            "lastUpdatedDate": "2021-08-24T07:13:27.226+0000",
            "createdBy": "Sagar.Aitla@cdk.com",
            "updatedBy": "Sagar.Aitla@cdk.com",
            "incorporateBpChanges": false,
            "locked": false,
            "id": "049f755a-c1fc-43b4-b019-b7ab356411ea",
            "recordType": "16be07c7-6a23-40ca-9565-a4f1ae02c9c7"
        }
      ]
      component.storeTemplates = storeTemplates;
      let template:any={
        "functionalAreaName": "Accounting",
        "functionalAreaType": "BestPracticeFunctionalArea",
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Work in Progress",
        "platforms": [
            {
                "id": null,
                "platformName": "DRIVE",
                "platformCode": "drive",
                "selected": true
            }
        ],
        "vic": null,
        "secondaryVic": null,
        "clientFunctionalAreaUser": null,
        "version": 19,
        "isFailed": null,
        "inProcess": false,
        "productCode": "ACCT",
        "productVersion": null,
        "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
        "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
        "bpVersionId": null,
        "bpTemplateId": null,
        "isDealerApproved": false,
        "stateStandardId": null,
        "stateStandardName": null,
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": false,
        "showValidateOrTransferButton": false,
        "showProcessValidationResultsButton": true,
        "createdDate": null,
        "lastUpdatedDate": null,
        "createdBy": null,
        "updatedBy": null,
        "incorporateBpChanges": false,
        "locked": false,
        "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
        "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6"
    }
      component['populateVicsAndSecondaryVicsForAutoAddedTemplates'](template);

    });

    it('test selectFunctionalArea',()=>{
      
      let treeNode:any={
        node:{
          template:{
            "autoAdded": true,
            "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
            "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
            "clientFunctionalAreaUser": null,
            "clientSignoffDate": null,
            "copyRowData": false,
            "createdBy": null,
            "createdDate": null,
            "functionalAreaName": "Parts",
            "functionalAreaType": "BestPracticeFunctionalArea",
            "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
            "inProcess": false,
            "incorporateBpChanges": false,
            "isDealerApproved": false,
            "isFailed": null,
            "lastUpdatedDate": null,
            "locked": false,
            "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
            "oemName": null,
            "platforms": [],
            "productCode": "PTS",
            "productVersion": null,
            "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "secondaryVic": null,
            "selected": false,
            "showProcessValidationResultsButton": true,
            "showValidateOrTransferButton": false,
            "stateStandardId": null,
            "stateStandardName": null,
            "stateStandardVersionName": null,
            "stateStandardVersionRecordType": null,
            "status": "Work in Progress",
            "updatedBy": null,
            "version": 19,
            "vic": null,
          }
        }
      }
      let removeRejected:boolean=false;

      let selections:any={
        "ACCT": {
          "template": {
            "functionalAreaName": "Accounting",
            "functionalAreaType": "BestPracticeFunctionalArea",
            "oemName": null,
            "clientSignoffDate": null,
            "selected": false,
            "status": "Work in Progress",
            "platforms": [
              {
                "id": null,
                "platformName": "DRIVE",
                "platformCode": "drive",
                "selected": true
              }
            ],
            "vic": null,
            "secondaryVic": null,
            "clientFunctionalAreaUser": null,
            "version": 19,
            "isFailed": null,
            "inProcess": false,
            "productCode": "ACCT",
            "productVersion": null,
            "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
            "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
            "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
            "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "isDealerApproved": false,
            "stateStandardId": null,
            "stateStandardName": null,
            "stateStandardVersionRecordType": null,
            "stateStandardVersionName": null,
            "copyRowData": false,
            "showValidateOrTransferButton": false,
            "showProcessValidationResultsButton": true,
            "createdDate": null,
            "lastUpdatedDate": null,
            "createdBy": null,
            "updatedBy": null,
            "incorporateBpChanges": false,
            "locked": false,
            "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
            "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "autoAdded": true
          },
          "nodeId": 54
        }
      }
      component.selections = selections;
      const ppspy = spyOn<any>(component,'markScreenNodeForSelectionOrDeselection')
      component['selectFunctionalArea'](treeNode,removeRejected);
    });


    it('test selectFunctionalArea if product codes are same',()=>{
      
      let treeNode:any={
        node:{
          template:{
            "autoAdded": true,
            "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
            "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
            "clientFunctionalAreaUser": null,
            "clientSignoffDate": null,
            "copyRowData": false,
            "createdBy": null,
            "createdDate": null,
            "functionalAreaName": "Accounting",
            "functionalAreaType": "BestPracticeFunctionalArea",
            "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d87",
            "inProcess": false,
            "incorporateBpChanges": false,
            "isDealerApproved": false,
            "isFailed": null,
            "lastUpdatedDate": null,
            "locked": false,
            "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
            "oemName": null,
            "platforms": [],
            "productCode": "ACCT",
            "productVersion": null,
            "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "secondaryVic": null,
            "selected": false,
            "showProcessValidationResultsButton": true,
            "showValidateOrTransferButton": false,
            "stateStandardId": null,
            "stateStandardName": null,
            "stateStandardVersionName": null,
            "stateStandardVersionRecordType": null,
            "status": "Work in Progress",
            "updatedBy": null,
            "version": 19,
            "vic": null,
          }
        }
      }
      let removeRejected:boolean=false;

      let selections:any={
        "ACCT": {
          "template": {
            "functionalAreaName": "Accounting",
            "functionalAreaType": "BestPracticeFunctionalArea",
            "oemName": null,
            "clientSignoffDate": null,
            "selected": false,
            "status": "Work in Progress",
            "platforms": [
              {
                "id": null,
                "platformName": "DRIVE",
                "platformCode": "drive",
                "selected": true
              }
            ],
            "vic": null,
            "secondaryVic": null,
            "clientFunctionalAreaUser": null,
            "version": 19,
            "isFailed": null,
            "inProcess": false,
            "productCode": "ACCT",
            "productVersion": null,
            "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
            "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
            "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
            "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "isDealerApproved": false,
            "stateStandardId": null,
            "stateStandardName": null,
            "stateStandardVersionRecordType": null,
            "stateStandardVersionName": null,
            "copyRowData": false,
            "showValidateOrTransferButton": false,
            "showProcessValidationResultsButton": true,
            "createdDate": null,
            "lastUpdatedDate": null,
            "createdBy": null,
            "updatedBy": null,
            "incorporateBpChanges": false,
            "locked": false,
            "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
            "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "autoAdded": true
          },
          "nodeId": 54
        }
      }
      component.selections = selections;

      let nodeController:any={
        tree:{
          'checked':true
        }
      }
    
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent;  
     
      spyOn(window, 'confirm').and.returnValue(true);
      const privateSpy = spyOn<any>(component,'markScreenNodeForSelectionOrDeselection')
      component['selectFunctionalArea'](treeNode,removeRejected);
    });

    it('test selectFunctionalArea if product codes are same and confirm of same fa are selected false',()=>{
      
      let treeNode:any={
        node:{
          template:{
            "autoAdded": true,
            "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
            "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
            "clientFunctionalAreaUser": null,
            "clientSignoffDate": null,
            "copyRowData": false,
            "createdBy": null,
            "createdDate": null,
            "functionalAreaName": "Accounting",
            "functionalAreaType": "BestPracticeFunctionalArea",
            "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d87",
            "inProcess": false,
            "incorporateBpChanges": false,
            "isDealerApproved": false,
            "isFailed": null,
            "lastUpdatedDate": null,
            "locked": false,
            "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
            "oemName": null,
            "platforms": [],
            "productCode": "ACCT",
            "productVersion": null,
            "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "secondaryVic": null,
            "selected": false,
            "showProcessValidationResultsButton": true,
            "showValidateOrTransferButton": false,
            "stateStandardId": null,
            "stateStandardName": null,
            "stateStandardVersionName": null,
            "stateStandardVersionRecordType": null,
            "status": "Work in Progress",
            "updatedBy": null,
            "version": 19,
            "vic": null,
          }
        }
      }
      let removeRejected:boolean=false;

      let selections:any={
        "ACCT": {
          "template": {
            "functionalAreaName": "Accounting",
            "functionalAreaType": "BestPracticeFunctionalArea",
            "oemName": null,
            "clientSignoffDate": null,
            "selected": false,
            "status": "Work in Progress",
            "platforms": [
              {
                "id": null,
                "platformName": "DRIVE",
                "platformCode": "drive",
                "selected": true
              }
            ],
            "vic": null,
            "secondaryVic": null,
            "clientFunctionalAreaUser": null,
            "version": 19,
            "isFailed": null,
            "inProcess": false,
            "productCode": "ACCT",
            "productVersion": null,
            "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
            "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
            "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
            "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "isDealerApproved": false,
            "stateStandardId": null,
            "stateStandardName": null,
            "stateStandardVersionRecordType": null,
            "stateStandardVersionName": null,
            "copyRowData": false,
            "showValidateOrTransferButton": false,
            "showProcessValidationResultsButton": true,
            "createdDate": null,
            "lastUpdatedDate": null,
            "createdBy": null,
            "updatedBy": null,
            "incorporateBpChanges": false,
            "locked": false,
            "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
            "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "autoAdded": true
          },
          "nodeId": 54
        }
      }
      component.selections = selections;

      let nodeController:any={
        tree:{
          'checked':true
        }
      }
    
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent;  
     
      spyOn(window, 'confirm').and.returnValue(false);
      const privateSpy = spyOn<any>(component,'markScreenNodeForSelectionOrDeselection')
      component['selectFunctionalArea'](treeNode,removeRejected);
    });


    it('test selectFunctionalArea if product codes are same and node rejected true',()=>{
      
      let treeNode:any={
        node:{
          template:{
            "autoAdded": true,
            "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
            "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
            "clientFunctionalAreaUser": null,
            "clientSignoffDate": null,
            "copyRowData": false,
            "createdBy": null,
            "createdDate": null,
            "functionalAreaName": "Accounting",
            "functionalAreaType": "BestPracticeFunctionalArea",
            "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d87",
            "inProcess": false,
            "incorporateBpChanges": false,
            "isDealerApproved": false,
            "isFailed": null,
            "lastUpdatedDate": null,
            "locked": false,
            "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
            "oemName": null,
            "platforms": [],
            "productCode": "ACCT",
            "productVersion": null,
            "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "secondaryVic": null,
            "selected": false,
            "showProcessValidationResultsButton": true,
            "showValidateOrTransferButton": false,
            "stateStandardId": null,
            "stateStandardName": null,
            "stateStandardVersionName": null,
            "stateStandardVersionRecordType": null,
            "status": "Work in Progress",
            "updatedBy": null,
            "version": 19,
            "vic": null,
          },
          'rejected':true
        },
      }
      let removeRejected:boolean=true;

      let selections:any={
        "ACCT": {
          "template": {
            "functionalAreaName": "Accounting",
            "functionalAreaType": "BestPracticeFunctionalArea",
            "oemName": null,
            "clientSignoffDate": null,
            "selected": false,
            "status": "Work in Progress",
            "platforms": [
              {
                "id": null,
                "platformName": "DRIVE",
                "platformCode": "drive",
                "selected": true
              }
            ],
            "vic": null,
            "secondaryVic": null,
            "clientFunctionalAreaUser": null,
            "version": 19,
            "isFailed": null,
            "inProcess": false,
            "productCode": "ACCT",
            "productVersion": null,
            "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
            "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
            "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
            "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "isDealerApproved": false,
            "stateStandardId": null,
            "stateStandardName": null,
            "stateStandardVersionRecordType": null,
            "stateStandardVersionName": null,
            "copyRowData": false,
            "showValidateOrTransferButton": false,
            "showProcessValidationResultsButton": true,
            "createdDate": null,
            "lastUpdatedDate": null,
            "createdBy": null,
            "updatedBy": null,
            "incorporateBpChanges": false,
            "locked": false,
            "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
            "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "autoAdded": true
          },
          "nodeId": 54
        }
      }
      component.selections = selections;

      let nodeController:any={
        uncheck
      }
      function uncheck(){
        return false;
      }
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent;  
     
      spyOn(window, 'confirm').and.returnValue(false);
      const privateSpy = spyOn<any>(component,'markScreenNodeForSelectionOrDeselection')
      component['selectFunctionalArea'](treeNode,removeRejected);
    });

    it('test markScreenNodeForSelectionOrDeselection',()=>{
      let markChecked:boolean = true;
      let mark:boolean = false;
      let treeNode:any={
        children:[
          {
            node:{
              'parentSelected':true
            }
          }
        ]
      }
      
      let nodeController:any={
        tree:{
          'checked':true
        }
      }
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent; 
      component['markScreenNodeForSelectionOrDeselection'](treeNode,mark,markChecked);
    });


    it('test markScreenNodeForSelectionOrDeselection if Node controller is false',()=>{
      let markChecked:boolean = true;
      let mark:boolean = false;
      let treeNode:any={
        children:[
          {
            node:{
              'parentSelected':true
            }
          }
        ]
      }
      
      let nodeController:any= undefined;
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent; 
      component['markScreenNodeForSelectionOrDeselection'](treeNode,mark,markChecked);
    });

    
    it('test handleNodeChecked',()=>{

      let event:any={
        node:{
          node:{
            'bestPractice':'TestBP',
            'version':'2020',
            'template':undefined,
            'screen':undefined,
        }
        }
      }
      let nodeController:any={
        isCollapsed,
        collapse,
        expand
      }
      function isCollapsed(){
        return true;
      }
      function collapse(){
        return false;
      }
      function expand(){
        return true;
      }
      
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent; 
      component.handleNodeChecked(event)
    });
   
    it('test handleNodeChecked if template present at node level',()=>{

      let event:any={
        node:{
          node:{
            'bestPractice':undefined,
            'version':undefined,
            'template':{},
            'screen':false,
        }
        }
         
      }
      let nodeController:any={
        isCollapsed,
        collapse,
        expand,
        dataFetched:false
      }
      function isCollapsed(){
        return true;
      }
      function collapse(){
        return false;
      }
      function expand(){
        return true;
      }
      
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent; 
      const privateSpy = spyOn<any>(component,'selectFunctionalArea')
      component.handleNodeChecked(event)
    });

    it('test handleNodeChecked if screen present at node level',()=>{

      let event:any={
        node:{
          node:{
            'bestPractice':undefined,
            'version':undefined,
            'template':undefined,
            'screen':{},
        }
        }
         
      }
      let nodeController:any={
      }
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent; 
      const privateSpy = spyOn<any>(component,'selectFunctionalUnit')
      component.handleNodeChecked(event)
    });


    it('test handleNodeUnChecked',()=>{
      let event:any={
        node:{
          node:{
            'bestPractice':'TestBP',
            'version':'2020',
            'template':{},
            'screen':undefined,
            'rejected':false
        }
        }
      }
      const privateSpy = spyOn<any>(component,'deselectFunctionalArea')
      component.handleNodeUnChecked(event);
    });

    it('test handleNodeUnChecked if screen obj present',()=>{
      let event:any={
        node:{
          node:{
            'bestPractice':'TestBP',
            'version':'2020',
            'template':undefined,
            'screen':{},
            'rejected':false
        }
        }
      }
      const privateSpy = spyOn<any>(component,'deselectFunctionalUnit')
      component.handleNodeUnChecked(event);
    });

    it('test loadTemplates if auto expand is true',()=>{

      let templates:any[]=[];
      let currentNode:any={
        version:{
          recordType:"345"
        }
      }
      let nodeController:any={
        tree:{
         node:{
          dataFetched:true,
          isAutoExpand:true
         },
         checkedChildren:{
           length:0
         },
         children:{
           splice,
           length:0
         }
        },
        setChildren,
        
      }
      function splice(){
      }
      function setChildren(){
      }
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent;

      let loaderDialogRef:any={
        close
      }
      function close(){
        return true
      }
      const privateSpy = spyOn<any>(component,'displayLoader').and.returnValue(loaderDialogRef)
      spyOn(bestPracticeService,'getFunctionalAreasOfBpVersion').and.returnValue(Observable.of(templates))
      component['loadTemplates'](currentNode);
    });

    it('test loadTemplates if auto expand is false',()=>{

      let templates:any[]=[];
      let currentNode:any={
        version:{
          recordType:"345"
        }
      }
      let nodeController:any={
        tree:{
          checked:true,
         node:{
          version:{
            active:true
          },
          dataFetched:true,
          isAutoExpand:false
         },
         checkedChildren:[{},{}],
         children:{
           splice,
           length:0
         }
        },
        setChildren,
        
      }
      function splice(){
      }
      function setChildren(){
      }
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent;

      let loaderDialogRef:any={
        close
      }
      function close(){
        return true
      }
      const privateSpy = spyOn<any>(component,'displayLoader').and.returnValue(loaderDialogRef)
      spyOn(bestPracticeService,'getFunctionalAreasOfBpVersion').and.returnValue(Observable.of(templates))
      component['loadTemplates'](currentNode);
    });

    it('test loadScreens if auto expand is true',()=>{

      let screenList:any[]=[];
      let currentNode:any={
        template:{
          recordType:"123"
        }
      }
      let nodeController:any={
        tree:{
         node:{
          dataFetched:true,
          isAutoExpand:true
         },
         checkedChildren:{
           length:0
         },
         children:{
           splice,
           length:0
         }
        },
        setChildren,
        
      }
      function splice(){
      }
      function setChildren(){
      }
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent;

      let loaderDialogRef:any={
        close
      }
      function close(){
        return true
      }
      const privateSpy = spyOn<any>(component,'displayLoader').and.returnValue(loaderDialogRef)
      spyOn(functionalUnitService,'getFunctionalUnitsOfFunctionalAreaForBpTree').and.returnValue(Observable.of(screenList))
      component['loadScreens'](currentNode);
    });

    it('test loadScreens if auto expand is false',()=>{

      let screenList:any[]=[];
      let currentNode:any={
        template:{
          recordType:"123"
        }
      }
      let nodeController:any={
        tree:{
         node:{
          dataFetched:true,
          isAutoExpand:false,
          rejected:true
         },
         checkedChildren:[{

         }],
         children:{
           splice,
           length:0
         }
        },
        setChildren,
        collapse
      }
      function collapse(){}
      function splice(){}
      function setChildren(){}
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent;

      let loaderDialogRef:any={
        close
      }
      function close(){
        return true
      }
      const privateSpy = spyOn<any>(component,'displayLoader').and.returnValue(loaderDialogRef)
      spyOn(functionalUnitService,'getFunctionalUnitsOfFunctionalAreaForBpTree').and.returnValue(Observable.of(screenList))
      component['loadScreens'](currentNode);
    });


    it('test deselectFunctionalUnit',()=>{

      let treeNode:any={
        parent:{
          node:{
            "template": {
              "productCode": "ACCT",
            }
          }
        }
      }
      JSON.stringify(treeNode);

      let selections:any={
        ACCT: {
          "template": {
            "productCode": "ACCT",
          },
          "nodeId": 54
        }
      }
      JSON.stringify(selections);
      component.selections = selections;
      
      component['deselectFunctionalUnit'](treeNode);
    });

    it('test deselectFunctionalArea',()=>{

      let node:any={
        "template": {
          "functionalAreaName": "Accounting",
          "functionalAreaType": "BestPracticeFunctionalArea",
          "oemName": null,
          "clientSignoffDate": null,
          "selected": false,
          "status": "Work in Progress",
          "platforms": [
              {
                  "id": null,
                  "platformName": "DRIVE",
                  "platformCode": "drive",
                  "selected": true
              }
          ],
          "vic": null,
          "secondaryVic": null,
          "clientFunctionalAreaUser": null,
          "version": 19,
          "isFailed": null,
          "inProcess": false,
          "productCode": "ACCT",
          "productVersion": null,
          "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
          "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
          "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
          "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
          "isDealerApproved": false,
          "stateStandardId": null,
          "stateStandardName": null,
          "stateStandardVersionRecordType": null,
          "stateStandardVersionName": null,
          "copyRowData": false,
          "showValidateOrTransferButton": false,
          "showProcessValidationResultsButton": true,
          "createdDate": null,
          "lastUpdatedDate": null,
          "createdBy": null,
          "updatedBy": null,
          "incorporateBpChanges": false,
          "locked": false,
          "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
          "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
          "autoAdded": true
      }
      }
      let selections1:any={
        "ACCT": {
          "template": {
              "functionalAreaName": "Accounting",
              "functionalAreaType": "BestPracticeFunctionalArea",
              "oemName": null,
              "clientSignoffDate": null,
              "selected": false,
              "status": "Work in Progress",
              "platforms": [
                  {
                      "id": null,
                      "platformName": "DRIVE",
                      "platformCode": "drive",
                      "selected": true
                  }
              ],
              "vic": null,
              "secondaryVic": null,
              "clientFunctionalAreaUser": null,
              "version": 19,
              "isFailed": null,
              "inProcess": false,
              "productCode": "ACCT",
              "productVersion": null,
              "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
              "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
              "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
              "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
              "isDealerApproved": false,
              "stateStandardId": null,
              "stateStandardName": null,
              "stateStandardVersionRecordType": null,
              "stateStandardVersionName": null,
              "copyRowData": false,
              "showValidateOrTransferButton": false,
              "showProcessValidationResultsButton": true,
              "createdDate": null,
              "lastUpdatedDate": null,
              "createdBy": null,
              "updatedBy": null,
              "incorporateBpChanges": false,
              "locked": false,
              "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
              "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
              "autoAdded": true
          }
      }
      }
      component.selections = selections1;

      let nodeController:any={
        tree:{
          'checked':true
        }
      }
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent; 
      const privateSpy = spyOn<any>(component,'markScreenNodeForSelectionOrDeselection')
      component['deselectFunctionalArea'](node);
    });

    it('test selectFunctionalUnit',()=>{

      let event:any={
        node:{
          node:{
            'bestPractice':undefined,
            'version':undefined,
            'template':undefined,
            'screen':{},
            'parentSelected':false
          },
           parent:{
              node:{
                 template:{
                  "productCode": "ACCT"
                 }
              },
              children:[
                {
                  node:{
                     template:{
                      "productCode": "ACCT"
                     }
                  },

               }
              ]
           }
        }
           
        }
        let node:null;
        let selections:any={
          "ACCT": {
            "template": {
              "functionalAreaName": "Accounting",
              "functionalAreaType": "BestPracticeFunctionalArea",
              "oemName": null,
              "clientSignoffDate": null,
              "selected": false,
              "status": "Work in Progress",
              "platforms": [
                {
                  "id": null,
                  "platformName": "DRIVE",
                  "platformCode": "drive",
                  "selected": true
                }
              ],
              "vic": null,
              "secondaryVic": null,
              "clientFunctionalAreaUser": null,
              "version": 19,
              "isFailed": null,
              "inProcess": false,
              "productCode": "ACCT",
              "productVersion": null,
              "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
              "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
              "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
              "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
              "isDealerApproved": false,
              "stateStandardId": null,
              "stateStandardName": null,
              "stateStandardVersionRecordType": null,
              "stateStandardVersionName": null,
              "copyRowData": false,
              "showValidateOrTransferButton": false,
              "showProcessValidationResultsButton": true,
              "createdDate": null,
              "lastUpdatedDate": null,
              "createdBy": null,
              "updatedBy": null,
              "incorporateBpChanges": false,
              "locked": false,
              "id": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
              "recordType": "305e00b1-a4f7-42dc-ad70-5885730756e6",
              "autoAdded": true
            },
            "nodeId": 54
          }
        }
        component.selections = selections;
        const privateSpy = spyOn<any>(component,'selectFunctionalArea')
        component['selectFunctionalUnit'](event,node);

    });
  

    it('test checkTemplatesOfExistingStore',()=>{

     
      let nodeController:any={
        tree:{
         node:{
          dataFetched:true,
          isAutoExpand:true
         }
        },
        isCollapsed,
        expand
      }
      function isCollapsed(){
        return true;
      }
      function expand(){
        return true;
      }
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent;  
      let loaderDialogRef :any={
          close
      }; 
      function close(){
      }
      let bestPracticeList:any[]=[
        {
          "isBestPractice": 1,
          "isSSS": 0,
          "bestPracticeName": "33463",
          "platform": {
              "id": null,
              "platformName": "DRIVE",
              "platformCode": "drive",
              "selected": false
          },
          "versionCount": 0,
          "version": 0,
          "failed": false,
          "id":"87c7d8ca-327e-45ba-a592-ebabf475b4a3",
          "recordType": "BestPracticeInfo",
          "treeNodeId": 3
      },
      {
          "isBestPractice": 1,
          "isSSS": 0,
          "bestPracticeName": "BPAudit1 - Clone",
          "platform": {
              "id": null,
              "platformName": "DRIVE",
              "platformCode": "drive",
              "selected": false
          },
          "versionCount": 0,
          "version": 0,
          "failed": false,
          "id": "254b60bc-f5e1-4188-a078-bbc56c45988e",
          "recordType": "BestPracticeInfo",
          "treeNodeId": 4
      },
      {
          "isBestPractice": 1,
          "isSSS": 0,
          "bestPracticeName": "BPAudit11",
          "platform": {
              "id": null,
              "platformName": "DRIVE",
              "platformCode": "drive",
              "selected": false
          },
          "versionCount": 0,
          "version": 0,
          "failed": false,
          "id": "16460839-d288-458d-a2b9-c78883d70c11",
          "recordType": "BestPracticeInfo",
          "treeNodeId": 5
      }
      ]

      let storeTemplates:any[]=[
        {
          "functionalAreaName": "Accounting",
          "functionalAreaType": null,
          "oemName": null,
          "clientSignoffDate": null,
          "selected": false,
          "status": "Work in Progress",
          "platforms": [
              {
                  "id": null,
                  "platformName": "DRIVE",
                  "platformCode": "drive",
                  "selected": true
              }
          ],
          "vic": null,
          "secondaryVic": null,
          "clientFunctionalAreaUser": null,
          "version": 23,
          "isFailed": null,
          "inProcess": false,
          "productCode": "ACCT",
          "productVersion": null,
          "masterFAId": "9f344289-fa1e-40da-bc78-db49cbcdf105",
          "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
          "bpVersionId": "49ad2478-4ff7-4eb3-a708-47be1fbe9d86",
          "bpTemplateId": "305e00b1-a4f7-42dc-ad70-5885730756e6",
          "isDealerApproved": false,
          "stateStandardId": null,
          "stateStandardName": null,
          "stateStandardVersionRecordType": null,
          "stateStandardVersionName": null,
          "copyRowData": false,
          "showValidateOrTransferButton": false,
          "showProcessValidationResultsButton": true,
          "createdDate": "2021-08-19T09:37:41.402+0000",
          "lastUpdatedDate": "2021-08-24T07:13:27.226+0000",
          "createdBy": "Sagar.Aitla@cdk.com",
          "updatedBy": "Sagar.Aitla@cdk.com",
          "incorporateBpChanges": false,
          "locked": false,
          "id": "049f755a-c1fc-43b4-b019-b7ab356411ea",
          "recordType": "16be07c7-6a23-40ca-9565-a4f1ae02c9c7"
      }
      ]
      component.storeTemplates = storeTemplates;
      let data:any[]=[
          {
            "screenName": "Accounts Payable",
            "gridOptionsModel": {
              "animatedRows": false,
              "rowSelection": "multiple",
              "columnDefs": []
            },
            "description": "Accounts Payable",
            "updated": false,
            "version": 0,
            "productCode": "ACCT",
            "index": 0,
            "deleted": false,
            "bpScreenId": null,
            "masterScreenId": null,
            "copyRowData": false,
            "rowDataEmpty": false,
            "bpPropagationCompleted": false,
            "id": "305e00b1-a4f7-42dc-ad70-5885730756e6",
            "recordType": "519dcbc5-6d64-4629-8b6d-41f4e9200ff4"
          }
      ] 
      spyOn(functionalUnitService,'getFunctionalUnitsOfFunctionalAreaForBpTree').and.returnValue(Observable.of(data))
      component['checkTemplatesOfExistingStore'](bestPracticeList,loaderDialogRef);
    });

    it('test loadBestPracticeVersions if auto expand is true',()=>{

      let versions:any[]=[];
      let currentNode:any={
        bestPractice:{
          id:"345"
        }
      }
      let nodeController:any={
        tree:{
         node:{
          dataFetched:true,
          isAutoExpand:true
         },
         checkedChildren:{
           length:0
         },
         children:{
           splice,
           length:0
         }
        },
        setChildren,
        
      }
      function splice(){
      }
      function setChildren(){
      }
      childComponent.getControllerByNodeId.and.returnValue(nodeController);
      component.tree =  childComponent;

      let loaderDialogRef:any={
        close
      }
      function close(){
        return true
      }
      const privateSpy = spyOn<any>(component,'displayLoader').and.returnValue(loaderDialogRef)
      spyOn(bestPracticeService,'getVersionsByBestPracticeId').and.returnValue(Observable.of(versions))
      component['loadBestPracticeVersions'](currentNode,{});
    });

})	


