
import {forkJoin as observableForkJoin,  Observable } from 'rxjs';

import { Component, Input, ViewChild, OnInit, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { Tree, TreeModel, NodeEvent, Ng2TreeSettings, TreeController } from 'ng2-tree';
import { BestPracticeService } from '../services/bestpractice-service';
import { FunctionalUnitService } from '../services/functional-unit-service';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import {BestPracticeVersionObject} from '../model/bestpractice-version-object';
import { ToastrService } from 'ngx-toastr';

@Component({
	  selector: 'best-practice-tree',
	  templateUrl: './bestpractice-tree.component.html',
	  styleUrls: ['./bestpractice-tree.component.css']
})
export class BestPracticeTree implements OnInit {

	@ViewChild('treeComponent',{static: false}) tree;
	public selections : any = {};
	@Input()store: BestPracticeVersionObject;
	@Input() storeTemplates: any[];
	storeBpIds: string[];
	storeBpTemplateIds: string[];
	storeBpVersionIds: string[];
	storeBpScreenIds: string[];
	storeFunctionalUnits: any[];
	bestPracticeList: any[];
	nodeId: number = 1;
	changeDetector: ChangeDetectorRef

	treeRenderedEvent : EventEmitter<any> = new EventEmitter();

	treeModel: TreeModel = { value: '', id: this.nodeId++, loadChildren : (callback) => {callback([]);} };
    treeSettings: Ng2TreeSettings = {
	  rootIsVisible: false,
	  showCheckboxes: true,
      enableCheckboxes: true
	}

	constructor(private bestPracticeService: BestPracticeService, private functionalUnitService : FunctionalUnitService, private dialog: MatDialog, changeDetector: ChangeDetectorRef, private toastrService: ToastrService) {
		this.changeDetector = changeDetector;
	}

	ngOnInit() {
		this.treeRenderedEvent.subscribe(eventData =>{
			let loaderDialogRef = eventData[0];
			let treeComp = eventData[1];
			treeComp.checkTemplatesOfExistingStore(treeComp.bestPracticeList, loaderDialogRef);
		});
	}

	public loadBestPractices(platformName:string) {
		this.selections = {}
		let loaderDialogRef = this.displayLoader('Fetching Best Practices...');
		this.bestPracticeService.getAllBestPracticesByPlatform(false,platformName).subscribe(
		    bestPracticeList => {
		    	let children = [];
		    	let id = this.nodeId++;
		    	for(let bestPractice of bestPracticeList) {
		    		this.bestPracticeList = bestPracticeList;
		    		bestPractice['treeNodeId'] = this.nodeId++;
		    		let node = {
		    			value : bestPractice.bestPracticeName,
		    			id: bestPractice['treeNodeId'],
		    			bestPractice : bestPractice,
		    			loadChildren : (callback) => {callback([]);}
		    		}
		    		children.push({
		    			value : bestPractice.bestPracticeName,
		    			id: bestPractice['treeNodeId'],
		    			bestPractice : bestPractice,
		    			loadChildren : (callback) => {callback([]);}
		    		});
		    	}
		    	this.treeModel = {value: '', id : id, children: children};
		    	if(this.store.id) {
		    		let me = this;
		    		setTimeout(() => {
		    			this.treeRenderedEvent.emit([loaderDialogRef, me]);
				    }, 0);
		    	} else {
		    		loaderDialogRef.close();
		    	}
		    }
		);
	}

	private checkTemplatesOfExistingStore(bestPracticeList: any[], loaderDialogRef: any) {
		this.storeBpIds = this.storeTemplates.map(template => template.bpId);
		this.storeBpTemplateIds = this.storeTemplates.map(template => template.bpTemplateId);
		this.storeBpVersionIds = this.storeTemplates.map(template => template.bpVersionId);

		//remove duplicate bp ids from store.
		this.storeBpIds = this.storeBpIds.filter(function(elem, index, self) {
		    return index === self.indexOf(elem);
		});
		//remove duplicate bp version ids from store.
		this.storeBpVersionIds = this.storeBpVersionIds.filter(function(elem, index, self) {
		    return index === self.indexOf(elem);
		});
		let requests = [];
		this.storeTemplates.forEach(template => {
			requests.push(this.functionalUnitService.getFunctionalUnitsOfFunctionalAreaForBpTree(template['recordType']));
		});
		this.storeBpScreenIds = [];
		if(requests.length > 0) {
			observableForkJoin(requests).subscribe(templateScreensList => {
				this.storeFunctionalUnits = templateScreensList;
				templateScreensList.forEach(screens => {
					let screenList: any[] = <any[]> screens;
					this.storeBpScreenIds = this.storeBpScreenIds.concat(screenList.map(screen => screen['bpScreenId']));
				});
				for(let bestPractice of bestPracticeList) {
		          if(this.storeBpIds.indexOf(bestPractice['id'])>-1)
		          {
		            let nodeController = this.tree.getControllerByNodeId(bestPractice.treeNodeId);
		            if (nodeController.isCollapsed()) {
		              nodeController.tree.node['isAutoExpand'] = true;
		              nodeController.expand();
		            }
		          }
				}
				loaderDialogRef.close();
			}, error=> {
				this.toastrService.error('Error Occurred while fetching screens of selected Store!!!');
				loaderDialogRef.close();
			});
		} else {
			loaderDialogRef.close();
		}
	}

	loadChildren(event: any) {
		let currentNode = event.node.node;
		if(currentNode.bestPractice) {
			this.loadBestPracticeVersions(currentNode, this);
		} else if(currentNode.version) {
			this.loadTemplates(currentNode);
		} else if(currentNode.template) {
			this.loadScreens(currentNode);
		}
	}

	private loadBestPracticeVersions(currentNode: any, me: any) {
		const nodeController = this.tree.getControllerByNodeId(currentNode.id);
		if(nodeController.tree.children.length === 0) {
			let loaderDialogRef = this.displayLoader('Fetching Best Practice Versions...');
			this.bestPracticeService.getVersionsByBestPracticeId(currentNode.bestPractice.id, false).subscribe(
				versions => {
					this.changeDetector.detectChanges();
					let versionsRenderedEvent : EventEmitter<any> = new EventEmitter();
					this.finaliseNodes(nodeController, versions, 'versionName', 'version', true, versionsRenderedEvent, loaderDialogRef);
					versionsRenderedEvent.subscribe(eventData =>{
						let nodeController = eventData[0];
						let loaderDialogRef = eventData[1];
						let treeComponent = eventData[2];

						if(nodeController.tree.node.isAutoExpand) {
							delete nodeController.tree.node.isAutoExpand;
							for(let child of nodeController.tree.children) {
								let childNodeController = treeComponent.tree.getControllerByNodeId(child.node.id);
								if(treeComponent.storeBpVersionIds.indexOf(child.node.version.recordType) > -1) {
									childNodeController.tree.node['isAutoExpand'] = true;
									if(childNodeController.isCollapsed) {
										childNodeController.expand();
									}
								} else {
									childNodeController.uncheck();
									childNodeController.collapse();
								}
							}
						} else {
							for(let childNode of nodeController.component.tree.children) {
								childNode.checked = childNode.node.version.active && nodeController.tree.checked;
								let childNodeController = treeComponent.tree.getControllerByNodeId(childNode.node.id);
								if(childNode.node.version.active) {
									childNodeController.expand();
								} else {
									childNodeController.collapse();
								}
							}
						}
						loaderDialogRef.close();
					});
				}
			);
		}
	}

	private loadTemplates(currentNode: any) {
		const nodeController = this.tree.getControllerByNodeId(currentNode.id);
		if(nodeController.tree.children.length ==0 ) {
			let loaderDialogRef = this.displayLoader('Fetching Functional Areas...');
			this.bestPracticeService.getFunctionalAreasOfBpVersion(currentNode.version['recordType'], false).subscribe(
				templates => {
					let templatesRenderedEvent : EventEmitter<any> = new EventEmitter();
					this.finaliseNodes(nodeController, templates, 'functionalAreaName', 'template', true, templatesRenderedEvent, loaderDialogRef);
					templatesRenderedEvent.subscribe(eventData =>{
						let nodeController = eventData[0];
						let loaderDialogRef = eventData[1];
						let treeComponent = eventData[2];
						if(nodeController.tree.node.isAutoExpand) {
							delete nodeController.tree.node.isAutoExpand;
							for(let child of nodeController.tree.children) {
								let childNodeController = treeComponent.tree.getControllerByNodeId(child.node.id);
								if(treeComponent.storeBpTemplateIds.indexOf(child.node.template.recordType) > -1) {
									let currentTemplate = child.node.template;
									if(!treeComponent.selections.hasOwnProperty(currentTemplate.productCode)) {
										currentTemplate = treeComponent.populateVicsAndSecondaryVicsForAutoAddedTemplates(child.node.template);
										treeComponent.selections[currentTemplate.productCode] = { template : currentTemplate, screens : [], nodeId : child.node.id };
									}
									childNodeController.tree.node['isAutoExpand'] = true;
									if(childNodeController.isCollapsed) {
										childNodeController.expand();
									}
								} else {
									childNodeController.uncheck();
								}
							}
						} else {
							if(nodeController.tree.checked || nodeController.tree.node.version.active) {
								for(let childNode of nodeController.tree.children) {
									let childNodeController = this.tree.getControllerByNodeId(childNode.node.id);
									childNodeController.expand();
								}
							}
						}
						loaderDialogRef.close();
					})
				}
			);
		}
	}

	private loadScreens(currentNode: any) {
		const nodeController = this.tree.getControllerByNodeId(currentNode.id);
		if(nodeController.tree.node.dataFetched && nodeController.tree.checkedChildren.length === 0){
			let child =[];
			nodeController.setChildren(child);
		}
		if(nodeController.tree.children.length ==0) {
			let loaderDialogRef = this.displayLoader('Fetching Functional Units...');
			this.functionalUnitService.getFunctionalUnitsOfFunctionalAreaForBpTree(currentNode.template['recordType']).subscribe(
				screenList => {
					let screensRenderedEvent : EventEmitter<any> = new EventEmitter();
					this.finaliseNodes(nodeController, screenList, 'screenName', 'screen', false, screensRenderedEvent, loaderDialogRef);
					screensRenderedEvent.subscribe(eventData =>{
						let nodeController = eventData[0];
						let loaderDialogRef = eventData[1];
						let treeComponent = eventData[2];
						nodeController.tree.children.splice(screenList.length, nodeController.tree.children.length - screenList.length);
						if(nodeController.tree.node.isAutoExpand) {
							delete nodeController.tree.node.isAutoExpand;
							let currentTemplate = nodeController.tree.node.template;
							for(let child of nodeController.tree.children) {
								let childNodeController = treeComponent.tree.getControllerByNodeId(child.node.id);
								if(treeComponent.storeBpScreenIds.indexOf(child.node.screen.recordType) > -1) {
									child.node.screen['autoAdded'] = true;
									if(treeComponent.selections.hasOwnProperty(currentTemplate.productCode)) {
										let screens = treeComponent.selections[currentTemplate.productCode].screens;
										screens.push(child.node.screen);
									} else {
										currentTemplate = treeComponent.populateVicsAndSecondaryVicsForAutoAddedTemplates(child.node.template);
										this.selections[currentTemplate.productCode] = { template : currentTemplate, screens : [child.node.screen], nodeId : child.node.id };
									}
									childNodeController.check();
								} else {
									let childNodeController = treeComponent.tree.getControllerByNodeId(child.node.id);
									childNodeController.uncheck();
								}
							}
						} else {
							if(nodeController.tree.checked) {
								for(let treeNode of nodeController.tree.checkedChildren) {
									treeComponent.selectFunctionalUnit(null, treeNode);
								}
							}
						}
						currentNode['dataFetched'] = true;
						//nodeController.collapse();
						loaderDialogRef.close();	
					});
					if(nodeController.tree.node.rejected != undefined && nodeController.tree.node.rejected){
							nodeController.collapse();
						}
				}
			);
		}
	}

	handleNodeSelected(event) {
		let nodeController = this.tree.getControllerByNodeId(event.node.id);
		if(nodeController.isCollapsed()) {
			nodeController.expand();
		} else {
			nodeController.collapse();
		}
	}

	private finaliseNodes(nodeController: any, nodeData: any[], valueFieldName: string,
			dataFieldName: string, addChildren: boolean, event: EventEmitter<any>, loader: any) {
		let children = [];
		for(let i=0; i < nodeData.length; i++) {
			let node = {
				value: nodeData[i][valueFieldName],
				id: this.nodeId++
			}
			if(dataFieldName != 'screen') {
				node['loadChildren'] = (callback) => {callback([]);}
			}
			node[dataFieldName] = nodeData[i];
			children.push(node);
		}
		nodeController.setChildren(children);
		this.changeDetector.detectChanges();
		let me = this;
		setTimeout(() => {
			event.emit([nodeController, loader, me]);
	    }, 0);
	}

	handleNodeChecked(event) {
		let node = event.node.node;
		let nodeController = this.tree.getControllerByNodeId(node.id);
		if(node.bestPractice || node.version) {
			if(nodeController.isCollapsed()) {
				nodeController.expand();
			}
		} else if(node.template) {
			this.selectFunctionalArea(event.node, false);
			if(nodeController.isCollapsed() && !node.dataFetched) {
				nodeController.expand();
			}
			if(nodeController.isCollapsed()) {
				nodeController.expand();
			}
		} else if(node.screen) {
			this.selectFunctionalUnit(event, null);
		}
	}

	handleNodeUnChecked(event) {
		let node = event.node.node;
		if(node.template) {
			this.deselectFunctionalArea(node);
			delete event.node.node.rejected;
		} else if(node.screen) {
			this.deselectFunctionalUnit(event.node);
		}
	}

	private selectFunctionalArea(treeNode: any, removeRejected: boolean) {
		let node = treeNode.node;
		if(!this.selections.hasOwnProperty(node.template.productCode)) {
			node.template['bpVersionId'] = node.template['id'];
			node.template['bpTemplateId'] = node.template['recordType'];
			node.template['bpId'] = node.template['bpId'];
			this.selections[node.template.productCode] = { template : node.template, screens : [], nodeId : node.id };
			this.markScreenNodeForSelectionOrDeselection(treeNode, true, false);
		} else {
			if(this.selections[node.template.productCode].template.id != node.template.id) {
				if(!treeNode.node['rejected']) {
					let nodeController = null;
					let existingFAName = this.selections[node.template.productCode].template.functionalAreaName;
					if(confirm('Functional Area with the name ' + existingFAName + ' has already been selected. Would you like to replace it ?')) {
						nodeController = this.tree.getControllerByNodeId(this.selections[node.template.productCode].nodeId);
						node.template['bpVersionId'] = node.template['id'];
						node.template['bpTemplateId'] = node.template['recordType'];
						node.template['bpId'] = node.template['bpId'];
						this.selections[node.template.productCode] = { template : node.template, screens : [], nodeId : node.id };
						this.markScreenNodeForSelectionOrDeselection(treeNode, true, false);
					} else {
						nodeController = this.tree.getControllerByNodeId(node.id);
						treeNode.node['rejected'] = true;
					}
					nodeController.tree.checked = false;
					this.markScreenNodeForSelectionOrDeselection(nodeController.tree, false, true);
				} else {
					if(removeRejected) {
						delete treeNode.node['rejected'];
					}
					let nodeController = this.tree.getControllerByNodeId(treeNode.node.id);
					this.markScreenNodeForSelectionOrDeselection(nodeController.tree, false, true);
					setTimeout(() => {
						nodeController.uncheck();
				    }, 5);
				}
			}
		}
	}

	private markScreenNodeForSelectionOrDeselection(treeNode: any, mark: boolean, markChecked: boolean) {
		if(treeNode.children) {
			for(let childNode of treeNode.children) {
				childNode.node['parentSelected'] = mark;
				if(markChecked) {
					let nodeController = this.tree.getControllerByNodeId(childNode.node.id);
					if(nodeController) {
						nodeController.tree.checked = false;
					} else {
						childNode.checked = false;
					}
				}
			}
		}

	}

	private deselectFunctionalArea(node: any) {
		if(this.selections.hasOwnProperty(node.template.productCode)) {
			if(this.selections[node.template.productCode].template == node.template) {
				let nodeController = this.tree.getControllerByNodeId(node.id);
				this.markScreenNodeForSelectionOrDeselection(nodeController.tree, false, true);
				delete this.selections[node.template.productCode];
			}
		}
	}

	private selectFunctionalUnit(event: any, node: any) {
		let treeNode = event ?event.node : node;
		if(!treeNode.node.parentSelected) {
			let removeRejected = treeNode.parent.children.indexOf(treeNode) == treeNode.parent.children.length-1;
			this.selectFunctionalArea(treeNode.parent, removeRejected);
		}
		let functionalAreaNode = treeNode.parent.node;
		if(this.selections[functionalAreaNode.template.productCode].template == functionalAreaNode.template) {
			let screens = this.selections[functionalAreaNode.template.productCode].screens;
			if(screens.indexOf(treeNode.node.screen) < 0) {
				screens.push(treeNode.node.screen);
			}
		} else {
			treeNode.checked = false;
		}
	}

	private deselectFunctionalUnit(treeNode: any) {
		let functionalAreaNode = treeNode.parent.node;
		if(this.selections.hasOwnProperty(functionalAreaNode.template.productCode)) {
			let addedFunctionalArea = this.selections[functionalAreaNode.template.productCode].template;
			if(addedFunctionalArea == functionalAreaNode.template) {
				let screens = this.selections[functionalAreaNode.template.productCode].screens;
				if(screens.indexOf(treeNode.node.screen) > -1) {
					screens.splice(screens.indexOf(treeNode.node.screen), 1);
				}
			}
		}
		treeNode.checked = false;
	}

	private populateVicsAndSecondaryVicsForAutoAddedTemplates(template: any): any {
		template['autoAdded'] = true;
		let tempStoreTemplate = this.storeTemplates.filter(function(storeTemplate){ return storeTemplate.bpTemplateId == template.recordType});
		if(tempStoreTemplate.length > 0) {
			template.vic = tempStoreTemplate[0].vic;
			template.secondaryVic = tempStoreTemplate[0].secondaryVic;
			template.bpVersionId = tempStoreTemplate[0].bpVersionId;
			template.bpTemplateId = tempStoreTemplate[0].bpTemplateId;
			template.bpId = tempStoreTemplate[0].bpId;
			template.stateStandardId = tempStoreTemplate[0].stateStandardId;
			template.stateStandardName = tempStoreTemplate[0].stateStandardName;
			template.stateStandardVersionRecordType = tempStoreTemplate[0].stateStandardVersionRecordType;
			template.stateStandardVersionName = tempStoreTemplate[0].stateStandardVersionName;
		}
		return template;
	}

	private displayLoader(message: string) {
		let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
            width: '300px',
            height: '150px',
            data: { message: message }
		});
		return loaderDialogRef
	}
}
