import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialogModule, MatDialogRef, MatDividerModule, MatExpansionModule, MatFormFieldModule, MatIconModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatSelectModule, MatSortModule, MAT_DIALOG_DATA } from "@angular/material";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule } from "ngx-toastr";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { AuthService } from "../services/auth-service";
import { GroupedMultivalueDialogComponent } from "./multivalue-dropdown-with-grouping.component";

describe('GroupedMultivalueDialogComponent',() => {

    let component : GroupedMultivalueDialogComponent;
    let fixture : ComponentFixture<GroupedMultivalueDialogComponent>;

    const dialogMock = {close: () => { }};
    beforeEach(async(() =>{

        const testUrl  = 'dashboard';
        let data= {
           cell:"test_cell",
           list:['test1','test2']
        }
        TestBed.configureTestingModule({
           imports: [
                MatExpansionModule,
                MatCardModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatPaginatorModule,
                MatDialogModule,
                ToastrModule.forRoot(),
                CommonModule,
                MatSelectModule,
                MatCheckboxModule,
                MatSortModule,
                MatIconModule,
                FormsModule,
                MatMenuModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                SortableModule,
                MatSortModule
            ],
            declarations : [GroupedMultivalueDialogComponent,LoaderDialogueComponent],
            providers : [
                AuthService,
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: dialogMock},
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent]}});
      }));

      beforeEach(() => {
        fixture = TestBed.createComponent(GroupedMultivalueDialogComponent);
        component = fixture.componentInstance;
        expect(component).toBeTruthy();
    });

    it('test closePopup',()=>{
        component.closePopup();
    });

    it('test optionChecked',()=>{
        let event= { checked: true}
        component.optionChecked(event,'Test');
        expect(component.selectedValues.length).toEqual(1);    
    });
    it('test optionChecked event false',()=>{
        let event= { checked: false}
        let selectedValues=['test1','test2','Test'];
        component.selectedValues = selectedValues;
        component.optionChecked(event,'Test');
        expect(component.selectedValues.length).toEqual(2);    
    });

    it('test isChecked',()=>{
        component.isChecked('MultiValue')
    });
}); 