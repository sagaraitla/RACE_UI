import { Component, Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

@Component({
  selector: 'grouped-multivalue-dropdown',
  templateUrl: './multivalue-dropdown-with-grouping.component.html',
  styleUrls: ['./multivalue-dropdown-with-grouping.component.css']
})
export class GroupedMultivalueDialogComponent {
  
  list = {};
  keys = [];
  cell: any;
  selectedValues=[];
	
  constructor(
    public dialogRef: MatDialogRef<GroupedMultivalueDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
	  dialogRef.disableClose = true;
	  this.cell = data.cell;
	  this.list = data.list;
	  if(this.cell.value) {
		  let currentValueArray = this.cell.value.split(',');
		  if(currentValueArray.length > 0) {
			  this.selectedValues = currentValueArray;
		  }
	  }
  }
  
  ngOnInit() {
	  this.keys = Object.keys(this.list)
  }
  
  
  isChecked(value: string) {
	  let flag = false;
	  if(this.cell && this.cell.value) {
		  let currentValueArray = this.cell.value.split(',');
		  flag = currentValueArray.indexOf(value) > -1;
	  }
	  return flag;
  }
  
  closePopup() {
	  this.dialogRef.close(this.selectedValues);
  };
  
  optionChecked(event: any, label: string) {
	  if(event.checked) {
		  this.selectedValues.push(label);
	  } else {
		  if(this.selectedValues.indexOf(label) > -1) {
			  this.selectedValues.splice(this.selectedValues.indexOf(label), 1);
		  }
	  }
  }
}