import  {Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
	  selector: 'app-loader-dialog',
	  templateUrl: './loader-dialog.component.html',
	  styleUrls: ['./loader-dialog.component.css']
})

export class LoaderDialogueComponent {

  message: string;

  constructor(public dialogRef: MatDialogRef<LoaderDialogueComponent>, @Inject(MAT_DIALOG_DATA) private data: any) {
	  this.message = data.message;
	  dialogRef.disableClose = true;
  }
}