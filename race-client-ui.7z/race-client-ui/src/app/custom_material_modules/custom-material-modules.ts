import { NgModule } from '@angular/core';

import { MatButtonModule } from '@angular/material';
import { MatToolbarModule } from '@angular/material';
import { MatFormFieldModule } from '@angular/material';
import { MatInputModule } from '@angular/material';
import { MatSidenavModule } from '@angular/material';
import { MatCardModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { MatTableModule } from '@angular/material';
import { MatSelectModule } from '@angular/material';
import { MatCheckboxModule } from '@angular/material';
import { MatStepperModule } from '@angular/material';
import { MatListModule, MatMenuModule } from '@angular/material';
import {MatIconModule} from '@angular/material/icon';
import {MatDividerModule} from '@angular/material/divider';
import {MatDatepickerModule, MatNativeDateModule} from '@angular/material';
import {MatTooltipModule} from '@angular/material';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatRadioModule} from '@angular/material';
import {MatDialogModule} from '@angular/material';
import {MatProgressSpinnerModule} from '@angular/material';
import {MatPaginatorModule} from '@angular/material';
import {MatSortModule} from '@angular/material';
import {MatSnackBarModule} from '@angular/material/snack-bar';



@NgModule({
    imports: [MatButtonModule, MatToolbarModule, MatFormFieldModule, MatInputModule,
                MatSidenavModule, MatCardModule, FormsModule, MatTableModule,
                MatCheckboxModule, MatSelectModule, MatStepperModule, ReactiveFormsModule,
                MatListModule, MatIconModule, MatDialogModule, MatMenuModule, MatDividerModule,
                MatDatepickerModule, MatNativeDateModule, MatTooltipModule, MatExpansionModule,
                MatRadioModule, MatDialogModule, MatProgressSpinnerModule, MatPaginatorModule,
                MatSortModule, MatSnackBarModule],
    exports: [MatButtonModule, MatToolbarModule, MatFormFieldModule, MatInputModule,
                MatSidenavModule, MatCardModule, FormsModule, MatTableModule,
                MatCheckboxModule, MatSelectModule, MatStepperModule, ReactiveFormsModule,
                MatListModule, MatIconModule, MatDialogModule, MatMenuModule, MatDividerModule,
                MatDatepickerModule, MatNativeDateModule, MatTooltipModule, MatExpansionModule,
                MatRadioModule, MatDialogModule, MatProgressSpinnerModule, MatPaginatorModule,
                MatSortModule, MatSnackBarModule],
})
export class CustomMaterialModule {

}
