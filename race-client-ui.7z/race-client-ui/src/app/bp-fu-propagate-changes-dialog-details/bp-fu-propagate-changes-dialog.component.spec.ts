import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatDialogRef, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatSort, MatSortModule, MatTableDataSource, MAT_DIALOG_DATA } from "@angular/material";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router, RouterModule } from "@angular/router";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { Observable, of } from 'rxjs';
import { AuditLogGomDialogComponent } from "../audit-log-gom-dialog-details/audit-log-gom-dialog.component";
import { ConfirmDialogComponent } from "../confirm-dialog/confirm-dialog.component";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { GenericResponse } from "../model/generic-response";
import { ScreenObject } from "../model/screen-object";
import { PropagationAcknowledgementComponent } from "../propagation-acknowledgement/propagation-acknowledgement.component";
import { AuthService } from "../services/auth-service";
import { FunctionalUnitService } from "../services/functional-unit-service";
import { BPFUPropagateChangesDialogComponent } from "./bp-fu-propagate-changes-dialog.component";

describe('BPFUPropagateChangesDialogComponent',() => {

    let component : BPFUPropagateChangesDialogComponent;
    let fixture : ComponentFixture<BPFUPropagateChangesDialogComponent>;
    let functionalUnitService: FunctionalUnitService
    let authService : AuthService;
    let routerStub: Router;

    class MatDialogMock {
        open() {
          return {
            afterClosed: () => Observable.of(true)
          };
        }
      };

      const dialogMock = {
        close: () => { }
        };

      const testUrl  = 'dashboard';
      beforeEach(async(() =>{
        let mockRouter = { navigate: jasmine.createSpy('navigateByUrl')
        } 
        let data= {
            projectId:'Project1',
            storeId:'Store1',
            faId:'faId1',
            faName:'Account',
        }
        TestBed.configureTestingModule({
           imports: [
                MatCardModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatPaginatorModule,
                MatDialogModule,
                ToastrModule.forRoot(),
                CommonModule,
                MatSelectModule,
                MatCheckboxModule,
                MatRadioModule,
                MatSortModule,
                MatIconModule,
                FormsModule,
                MatMenuModule,
                MatDividerModule,
                RouterModule.forRoot([]),
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                SortableModule,
                MatSortModule
            ],
            declarations : [
                BPFUPropagateChangesDialogComponent,LoaderDialogueComponent,AuditLogGomDialogComponent,
                PropagationAcknowledgementComponent],
            providers : [
                FunctionalUnitService,
                AuthService,
                ToastrService,
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: dialogMock},
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent,AuditLogGomDialogComponent,PropagationAcknowledgementComponent]}});
            authService = TestBed.get(AuthService);
            routerStub  = TestBed.get(Router);
            functionalUnitService = TestBed.get(FunctionalUnitService);

      }));

      beforeEach(() => {
        fixture = TestBed.createComponent(BPFUPropagateChangesDialogComponent);
        component = fixture.componentInstance;
    });
    const screenObject : ScreenObject = {
        "screenName": "Account Definition",
        "gridOptionsModel": {
          "animatedRows": false,
          "rowSelection": "multiple",
          "columnDefs": [
            {
              "headerName": "Starting RO Number",
              "field": "starting_ro_number",
              "dataType": "INT",
              "required": "false",
              "editable": "true",
              "editableByCDKOnly": "false",
              "defaultValue": "",
              "validationRule": "",
              "dataLength": 9,
              "cellEditor": "agLargeTextCellEditor",
              "cellEditorParams": {
                "maxLength": 9
              }
            }
          ],
          "rowData":null
        },
        "description": "Account Definition",
        "updated": false,
        "version": 0,
        "productCode": "SVC",
        "index": 0,
        "bpScreenId": "6e260b12-03d5-4a9e-854c-ea29eba80dbd",
         "selected": false,
         "templateId": null,
        "copyRowData": true,
        "rowDataEmpty": false,
        "bpPropagationCompleted": false,
        "id": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
        "recordType": "ff991af6-3c55-4642-a500-bed944b7f574" 
    }

    const screenObjectList :ScreenObject[]=[
        {
            "screenName": "Account Definition",
            "gridOptionsModel": {
              "animatedRows": false,
              "rowSelection": "multiple",
              "columnDefs": [
                {
                  "headerName": "Starting RO Number",
                  "field": "starting_ro_number",
                  "dataType": "INT",
                  "required": "false",
                  "editable": "true",
                  "editableByCDKOnly": "false",
                  "defaultValue": "",
                  "validationRule": "",
                  "dataLength": 9,
                  "cellEditor": "agLargeTextCellEditor",
                  "cellEditorParams": {
                    "maxLength": 9
                  }
                }
              ],
              "rowData":null
            },
            "description": "Account Definition",
            "updated": false,
            "version": 0,
            "productCode": "SVC",
            "index": 0,
            "bpScreenId": "6e260b12-03d5-4a9e-854c-ea29eba80dbd",
             "selected": false,
             "templateId": null,
            "copyRowData": true,
            "rowDataEmpty": false,
            "bpPropagationCompleted": false,
            "id": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
            "recordType": "ff991af6-3c55-4642-a500-bed944b7f574" 
        }
    ]
    const generic_response : GenericResponse = {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [
            {
                "screenName": "Account Definition",
                "gridOptionsModel": {
                  "animatedRows": false,
                  "rowSelection": "multiple",
                  "columnDefs": [
                    {
                      "headerName": "Starting RO Number",
                      "field": "starting_ro_number",
                      "dataType": "INT",
                      "required": "false",
                      "editable": "true",
                      "editableByCDKOnly": "false",
                      "defaultValue": "",
                      "validationRule": "",
                      "dataLength": 9,
                      "cellEditor": "agLargeTextCellEditor",
                      "cellEditorParams": {
                        "maxLength": 9
                      }
                    }
                  ],
                  "rowData":null
                },
                "description": "Account Definition",
                "updated": false,
                "version": 0,
                "productCode": "SVC",
                "index": 0,
                "bpScreenId": "6e260b12-03d5-4a9e-854c-ea29eba80dbd",
                 "selected": false,
                 "templateId": null,
                "copyRowData": true,
                "rowDataEmpty": false,
                "bpPropagationCompleted": false,
                "id": "5ab64385-d12c-4398-a666-2e3ee008b4fa",
                "recordType": "ff991af6-3c55-4642-a500-bed944b7f574" 
            }
        ],
          "executionTime" : null
      }
      
    it('test ngOnInit',()=>{
        spyOn(component,'fetchPropagatedBPFUChanges');
        spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of({}));
        spyOn(authService, 'isAuthorised').and.returnValue(false);
        fixture.detectChanges();
    });


    it('test fetchPropagatedBPFUChanges',()=>{
        spyOn(functionalUnitService,'getModifiedBestPracticeFus').and.returnValue(Observable.of(generic_response));
        component.dataSource = new MatTableDataSource<GenericResponse>(generic_response.resultObj);
        component.sort = new MatSort();
        component.dataSource.sort = component.sort;
        component.fetchPropagatedBPFUChanges();
        expect(functionalUnitService.getModifiedBestPracticeFus).toHaveBeenCalledTimes(1);
    });

    it('test fetchPropagatedBPFUChanges throws error',()=>{
        spyOn(functionalUnitService,'getModifiedBestPracticeFus').and.returnValue(Observable.throwError('error'));
        component.dataSource = new MatTableDataSource<GenericResponse>(generic_response.resultObj);
        component.sort = new MatSort();
        component.dataSource.sort = component.sort;
        component.fetchPropagatedBPFUChanges();
        expect(functionalUnitService.getModifiedBestPracticeFus).toHaveBeenCalledTimes(1);
    });


    it('test masterToggle',()=>{
        spyOn(component,'isAllSelected').and.returnValue(true);
        spyOn(component,'clearAllRows')
        component.masterToggle();
        expect(component.clearAllRows).toHaveBeenCalledTimes(1);
        expect(component.selectedFuList.length).toEqual(0);
    });

    it('test masterToggle isAllSelected false',()=>{
        spyOn(component,'isAllSelected').and.returnValue(false);
        spyOn(component,'selectAllRows')
        component.masterToggle();
        expect(component.selectAllRows).toHaveBeenCalledTimes(1);
        expect(component.selectedFuList.length).toEqual(0);
    });


    it('test disableButton',()=>{
        component.selectedFuList.length =1;
        let result  = component.disableButton();
        expect(result).toBeFalsy();
    });

    it('test openDialogToViewChanges',()=>{
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        component.openDialogToViewChanges(screenObject);        
    });

    
    it('test incorporateBPChanges',()=>{

        component.actualFuListSize =1;
        component.selectedFuList.length =1;
        let result={
            event : 'Confirm'
        }
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(result), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        component.incorporateBPChanges();        
    });

    it('test incorporateBPChanges for different selectedFuList length',()=>{

        component.actualFuListSize =2;
        component.selectedFuList.length =3;
        let result={
            event :'Confirm'
        }
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(result), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        spyOn(component,'ngOnInit');
        spyOn(component,'clearAllRows');
        component.incorporateBPChanges();        
    });

    it('test selectAllRows',()=>{
        component.dataSource = new MatTableDataSource<ScreenObject>(screenObjectList);
        component.selectAllRows();
        expect(component.selectedFuList.length).toEqual(1); 
    });

    it('test clearAllRows',()=>{
        component.clearAllRows();
    });

    it('test isAllSelected',()=>{
        component.dataSource = new MatTableDataSource<ScreenObject>(screenObjectList);
        component.isAllSelected();
    });

    it('test openDialogToDiscardChanges',()=>{

        let result={ event :'Confirm'}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(result), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(functionalUnitService,'discardPropagatedFuChanges').and.returnValue(Observable.of({}));
        component.openDialogToDiscardChanges(screenObject);
        expect(functionalUnitService.discardPropagatedFuChanges).toHaveBeenCalledTimes(1);
  
    });

    it('test openDialogToDiscardChanges for fuList size more than 1',()=>{

        let result={ event :'Confirm'}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(result), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        component.actualFuListSize = 3;
        spyOn(component,'ngOnInit');
        spyOn(component,'clearAllRows');
        spyOn(functionalUnitService,'discardPropagatedFuChanges').and.returnValue(Observable.of({}));
        component.openDialogToDiscardChanges(screenObject);
        expect(functionalUnitService.discardPropagatedFuChanges).toHaveBeenCalledTimes(1);
  
    });

    
    it('test openDialogToDiscardChanges in case of error',()=>{

        let result={ event :'Confirm'}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(result), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(component,'ngOnInit');
        spyOn(functionalUnitService,'discardPropagatedFuChanges').and.returnValue(Observable.throwError('error'));
        component.openDialogToDiscardChanges(screenObject);
        expect(functionalUnitService.discardPropagatedFuChanges).toHaveBeenCalledTimes(1);
    });

    it('test select row ', () =>{
        component.selectedFuList = screenObjectList;
        component.selectRow(false, screenObject);
        expect(component.selectedFuList.length).toEqual(0);
    })

    it('test select row in event true ', () =>{
        let event={checked :true}
        component.selectedFuList = screenObjectList;
        component.selectRow(event, screenObject);
        expect(component.selectedFuList.length).toEqual(2);
    })
});

