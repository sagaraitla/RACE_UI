import { Component, Inject, OnInit, ViewChild } from "@angular/core";
import { MatDialog, MatDialogRef, MatPaginator, MatSort, MatTableDataSource, MAT_DIALOG_DATA, Sort } from "@angular/material";
import { Router } from "@angular/router";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { MasterFunctionalUnit } from "../model/master-functional-unit";
import { AuthService } from "../services/auth-service";
import { MasterFunctionalUnitService } from "../services/master-functional-unit-service";
import { ToastrService } from "ngx-toastr";
import { AuditLogGomDialogComponent } from "../audit-log-gom-dialog-details/audit-log-gom-dialog.component";
import { FunctionalUnitService } from "../services/functional-unit-service";
import { SelectionModel } from "@angular/cdk/collections";
import { ScreenObject } from "../model/screen-object";
import { PropagationAcknowledgementComponent } from "../propagation-acknowledgement/propagation-acknowledgement.component";
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';

@Component({
    selector: 'bp-fu-propagate-changes-dialog',
    templateUrl: './bp-fu-propagate-changes-dialog.component.html',
    styleUrls: ['./bp-fu-propagate-changes-dialog.component.css']
  })
export class BPFUPropagateChangesDialogComponent implements OnInit {

    adminConsolePermission: boolean = false;
    dataSource: any;
    faId: string;
    storeId: string;
    projectId: string;
    selectedFuList: any = [];
    selection = new SelectionModel<ScreenObject>(true, []);
    actualFuListSize:number;
    displayedColumns = ['select', 'functionalUnitName','actions'];
    faName:string;
    @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
    @ViewChild(MatSort, { static: false }) sort: MatSort;

    constructor(private router: Router, private dialog: MatDialog, @Inject(MAT_DIALOG_DATA) private data: any,
              private authService: AuthService,private dialogRef: MatDialogRef<BPFUPropagateChangesDialogComponent>,private toastrService: ToastrService,
              private functionalUnitService: FunctionalUnitService) {
    
      }

    ngOnInit(): void {
        this.authService.fetchLoggedInUserAndPermissions().subscribe((data: any) => {
            this.adminConsolePermission = this.authService.isAuthorised('DOT_ADMIN');
          });
         this.projectId = this.data.projectId;
         this.storeId = this.data.storeId;
         this.faId = this.data.faId;
         this.faName = this.data.faName;
         this.fetchPropagatedBPFUChanges();
    }

    fetchPropagatedBPFUChanges() {
        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
          width: '300px',
          height: '150px',
          data: { message: 'Fetching Functional Units...' }
        });

        this.functionalUnitService.getModifiedBestPracticeFus(this.storeId,this.faId).subscribe(genericResponse => {
          if (genericResponse != null && genericResponse != undefined && genericResponse.resultDescription == "OK" && genericResponse.resultDescription != null) {
            this.actualFuListSize = genericResponse.resultObj.length;
            this.dataSource = new MatTableDataSource<ScreenObject>(genericResponse.resultObj);
            this.dataSource.data.forEach(element => {
              for (const key in element) {
                if (!element[key] || element[key] === null || element[key] === undefined) {
                  element[key] = '';
                }
              }
            });
         this.dataSource.paginator = this.paginator;
         this.dataSource.sort = this.sort;
          loaderDialogRef.close();
         } else {
          loaderDialogRef.close();
          }
    
        },error => {
          this.toastrService.error('Error Occurred while fetching the Functional Unit');
          loaderDialogRef.close();
        }
        )
      }

       /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
      if (this.dataSource != undefined && this.dataSource != null && this.dataSource.data != undefined && this.dataSource.data != null) {
        const numSelected = this.selection.selected.length;
        const numRows = this.dataSource.data.length;
        return numSelected === numRows;
      } else {
        return false;
      }
    }

     /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
      this.selectedFuList = [];
      this.isAllSelected() ?
      this.clearAllRows() :
      this.selectAllRows();
    }

    /** The label for the checkbox on the passed row */
    checkboxLabel(row?: ScreenObject): string {
        if (!row) {
        return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
      }
      return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.screenName}`;
    }

    selectRow($event, row?: ScreenObject) {
      if ($event.checked) {
        this.selectedFuList.push(row);
      } else {
        this.selectedFuList = this.selectedFuList.filter(fu => fu.recordType != row.recordType);
      }
    }

    clearAllRows() {
      this.selection.clear();
      this.selectedFuList = [];
    }

    selectAllRows() {
      this.selectedFuList = [];
      this.dataSource.data.forEach(row => {
        this.selection.select(row);
        this.selectedFuList.push(row);
      });
    }

     disableButton(): boolean {
       if (this.selectedFuList.length > 0) {
          return false;
        }
      return true;
  }


    openDialogToViewChanges(screenObject: ScreenObject) {
      let dialogRef = this.dialog.open(AuditLogGomDialogComponent, {
        width: '60%',
        height: '80%',
        data: {
          displayName: 'IncorporateBPChanges',
          storeId : this.storeId,
          screenObject:screenObject,
          faName:this.faName
        }
      });
    }
    incorporateBPChanges(){
      let dialogRef = this.dialog.open(PropagationAcknowledgementComponent, {
        width: "28%",
        height: "41%",
        data:{
          message : 'incorporateBPChanges',
          selectedFuList : this.selectedFuList,
          projectId: this.projectId,
          storeId: this.storeId,
          faId:this.faId
        }
      });
      dialogRef.afterClosed().subscribe(result => {
          if(result.event === 'Confirm'){
              if(this.actualFuListSize === this.selectedFuList.length){
                this.dialogRef.close();
              }else{
                this.ngOnInit();
                this.clearAllRows();
              }
          }
      });
    }

      close() {
        this.dialogRef.close();
  };

  openDialogToDiscardChanges(screenObject: ScreenObject){
    let confirmDialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '300px',
      height: '160px',
      data: { message: 'Are you sure you want to discard this Functional Unit changes ?' }
  });
  confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
          let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
              width: '300px',
              height: '150px',
              data: { message: 'Discarding the FunctionalUnit changes..' }
          });
          this.functionalUnitService.discardPropagatedFuChanges(this.storeId,this.faId,screenObject.recordType,screenObject).subscribe((data: any) => {
              loaderDialogRef.close();
              if(this.actualFuListSize-1>=1){
                this.ngOnInit();
                this.clearAllRows();
              }else{
                this.dialogRef.close();
              }
            
          }, error => {
            this.toastrService.error('Error Occurred while discarding the Functional Unit changes.');
            loaderDialogRef.close();
            this.ngOnInit();
          });
      }
  });
  }

}