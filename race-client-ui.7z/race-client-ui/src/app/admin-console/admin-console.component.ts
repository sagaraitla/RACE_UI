import { SelectionModel } from "@angular/cdk/collections";
import { Component, OnInit, ViewChild } from "@angular/core";
import { MatDialog, MatTableDataSource, MatPaginator, MatSort, Sort } from "@angular/material";
import { Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { MasterFunctionalUnit } from "../model/master-functional-unit";
import { AuthService } from "../services/auth-service";
import { MasterFunctionalUnitService } from "../services/master-functional-unit-service";
import { AuditLogGomDialogComponent } from "../audit-log-gom-dialog-details/audit-log-gom-dialog.component"
import { PropagationAcknowledgementComponent } from "../propagation-acknowledgement/propagation-acknowledgement.component";
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-admin-console',
  templateUrl: './admin-console.component.html',
  styleUrls: ['./admin-console.component.css']
})
export class AdminConsoleComponent implements OnInit {
  adminConsolePermission: boolean = false;
  dataSource: any;
  filter: any;
  selectedFuList: any = [];
  selection = new SelectionModel<MasterFunctionalUnit>(true, []);
  displayedColumns = ['select', 'functionalUnitName', 'description', 'productCode', 'lastUpdatedDate', 'actions'];
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;

  constructor(private router: Router, private dialog: MatDialog, private masterFuService: MasterFunctionalUnitService, private authService: AuthService,
    private toastrService: ToastrService) {

  }

  ngOnInit() {
    this.authService.fetchLoggedInUserAndPermissions().subscribe((data: any) => {
      this.adminConsolePermission = this.authService.isAuthorised('DOT_ADMIN');
    });
    this.fetchGOMModifiedFus();
  }

  fetchGOMModifiedFus() {
    let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
      width: '300px',
      height: '150px',
      data: { message: 'Fetching Functional Units ..' }
    });
    this.masterFuService.fetchAllFunctionalUnitsByGOMModified().subscribe(genericResponse => {
      if (genericResponse != null && genericResponse != undefined && genericResponse.resultDescription != null && genericResponse.resultDescription == "OK") {
        this.dataSource = new MatTableDataSource<MasterFunctionalUnit>(genericResponse.resultObj);
        this.dataSource.data.forEach(element => {
          for (const key in element) {
            if (!element[key] || element[key] === null || element[key] === undefined) {
              element[key] = '';
            }
          }
        });
        this.dataSource.filterPredicate = function (data, filter: string): boolean {
          return data.functionalUnitName.toLowerCase().includes(filter)
            || data.description.toLowerCase().includes(filter)
            || data.productCode.toLowerCase().includes(filter)
            || data.lastUpdatedDate.toLowerCase().includes(filter)
        };

        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        const sortState: Sort = { active: 'lastUpdatedDate', direction: 'desc' };
        this.sort.active = sortState.active;
        this.sort.direction = sortState.direction;
        this.sort.sortChange.emit(sortState);
        if (this.filter) {
          this.applyFilter(this.filter);
        }

        loaderDialogRef.close();
      } else {
        loaderDialogRef.close();
      }
    }, error => {
      this.toastrService.error('Error Occurred while fetching the Functional Unit');
      loaderDialogRef.close();
    });
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    if (this.dataSource != undefined && this.dataSource != null && this.dataSource.data != undefined && this.dataSource.data != null) {
      const numSelected = this.selection.selected.length;
      const numRows = this.dataSource.data.length;
      return numSelected === numRows;
    } else {
      return false;
    }

  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.selectedFuList = [];
    this.isAllSelected() ?
      this.clearAllRows() :
      this.selectAllRows();
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: MasterFunctionalUnit): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.functionalUnitName}`;
  }

  selectRow($event, row?: MasterFunctionalUnit) {
    if ($event.checked) {
      this.selectedFuList.push(row);
      
      console.log(row.functionalUnitName);
    } else {
      this.selectedFuList = this.selectedFuList.filter(fu => fu.id != row.id);
      console.log(row.functionalUnitName);
    }
  }

  gotoDashboard() {
    this.router.navigateByUrl('dashboard');
  }

  openDialogToViewChanges(masterFunctionalUnit: MasterFunctionalUnit) {
    let dialogRef = this.dialog.open(AuditLogGomDialogComponent, {
      width: '60%',
      height: '80%',
      data: {
        masterFunctionalUnit: masterFunctionalUnit,
        displayName: 'PropagateFUGOM',
        fuName: masterFunctionalUnit.functionalUnitName
      }
    });
  }

  clearAllRows() {
    this.selection.clear();
    this.selectedFuList = [];
  }

  selectAllRows() {
    this.selectedFuList = [];
    this.dataSource.data.forEach(row => {
      this.selection.select(row);
      this.selectedFuList.push(row);
    });
  }

  disableButton(): boolean {
    if (this.adminConsolePermission && this.selectedFuList.length > 0) {
      return false;
    }
    return true;
  }
  
  openDialogToPropagationAcknowledgment(){
    let dialogRef = this.dialog.open(PropagationAcknowledgementComponent, {
      width: "28%",
      height: "41%",
      data:{
        selectedFuList : this.selectedFuList
      }
  });
  
    dialogRef.afterClosed().subscribe(result => {
        if(result.event === 'Confirm'){
           this.ngOnInit();
          this.clearAllRows()
        }
    });
  }

  openDialogToDiscardChanges(masterFunctionalUnit: MasterFunctionalUnit){
    let confirmDialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '300px',
      height: '160px',
      data: { message: 'Are you sure you want to discard this Functional Unit changes ?' }
  });
  confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
          let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
              width: '300px',
              height: '150px',
              data: { message: 'Discarding FunctionalUnit changes..' }
          });
          this.masterFuService.discardModifiedFuChanges(masterFunctionalUnit).subscribe((data: any) => {
              loaderDialogRef.close();
              this.ngOnInit();
          }, error => {
            this.toastrService.error('Error Occurred while discarding the Functional Unit changes.');
            loaderDialogRef.close();
            this.ngOnInit();
          });
      }
  });
  }

}