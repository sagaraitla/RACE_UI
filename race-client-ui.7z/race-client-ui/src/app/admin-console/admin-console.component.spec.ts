import { AdminConsoleComponent } from "./admin-console.component";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AuthService } from "../services/auth-service";
import { Router } from "@angular/router";
import { Observable, of } from 'rxjs';
import { MasterFunctionalUnitService } from "../services/master-functional-unit-service";
import { MatCardModule, MatCheckboxModule, MatDialogModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatMenuModule, MatPaginatorIntl, MatPaginatorModule, MatSelectModule, MatSortModule, MatTableDataSource, MatDialog, MatProgressSpinnerModule } from "@angular/material";
import { CdkTableModule } from "@angular/cdk/table";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { CommonModule } from "@angular/common";
import { AuditLogGomDialogComponent } from "../audit-log-gom-dialog-details/audit-log-gom-dialog.component";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { ConfirmDialogComponent } from "../confirm-dialog/confirm-dialog.component";
import { PropagationAcknowledgementComponent } from "../propagation-acknowledgement/propagation-acknowledgement.component";
import { MasterFunctionalUnit } from "../model/master-functional-unit";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { FormsModule } from "@angular/forms";
import { EventEmitter } from "@angular/core";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { GenericResponse } from "../model/generic-response";
import { SortableModule } from "ngx-bootstrap";
import { symlink } from "fs";

describe('test admin console component',() => {
    let component : AdminConsoleComponent;
    let fixture : ComponentFixture<AdminConsoleComponent>;
    let masterFuSrevice : MasterFunctionalUnitService;
    let authService : AuthService;
    let router : Router;

    class MatDialogMock {
        open() {
          return {
            afterClosed: () => Observable.of(true)
          };
        }
      };

      const testUrl  = 'dashboard';
      beforeEach(async(() =>{
        let mockRouter = {
            navigate: jasmine.createSpy('navigateByUrl')
        } 
        const masterFunctionalUnitServiceSpy = jasmine.createSpyObj('MasterFunctionalUnitService',
        ['fetchAllFunctionalUnitsByGOMModified','discardModifiedFuChanges']);

        TestBed.configureTestingModule({
           imports: [
                MatCardModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatPaginatorModule,
                MatDialogModule,
                ToastrModule.forRoot(),
                CommonModule,
                MatSelectModule,
                MatCheckboxModule,
                MatSortModule,
                MatIconModule,
                FormsModule,
                MatMenuModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                SortableModule,
                MatSortModule
            ],
            declarations : [
                AdminConsoleComponent, AuditLogGomDialogComponent, LoaderDialogueComponent, ConfirmDialogComponent,
                PropagationAcknowledgementComponent
            ],
            providers : [
                MasterFunctionalUnitService,
                AuthService,
                ToastrService,{ provide: Router, useValue: {url:testUrl} }
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent,ConfirmDialogComponent,AuditLogGomDialogComponent,PropagationAcknowledgementComponent]}});
            authService = TestBed.get(AuthService);
            masterFuSrevice = TestBed.get(MasterFunctionalUnitService);
      }));

      beforeEach(() => {
        fixture = TestBed.createComponent(AdminConsoleComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();

    });

    const mock_functional_unit : any = {
        "functionalUnitType" : "MasterFunctionalUnit",
        "functionalUnitName" : "Deal Retention",
        "description" : "Deal Retention",
        "version" : "0",
        "gomModified" : false,
        "propagationStarted" : false,
        "propagationStatus" : "0",
        "id" : "b722f8ca-cd29-4b9d-aa30-0a72a6797322",
        "recordType" : "FunctionalUnitInfo"

    }

    const master_fu_response_list : any[] = [
        {
        "functionalUnitType" : "MasterFunctionalUnit",
        "functionalUnitName" : "Deal Retention",
        "description" : "Deal Retention",
        "version" : "0",
        "gomModified" : false,
        "propagationStarted" : false,
        "propagationStatus" : "0",
        "id" : "b722f8ca-cd29-4b9d-aa30-0a72a6797322",
        "recordType" : "FunctionalUnitInfo"
    }
]

const generic_response : GenericResponse = {
    "resultCode": "CDK_200",
    "resultDescription": "OK",
    "resultObj": [
      {
        "objectType": "Propagation",
        "date": "2020-10-29T09:56:13.635+0000",
        "objectIdentifier": "ProjOct21 : store1 : Propagate_Fu_To_BP_Drive",
        "user": "Suresh.Vanga@cdk.com",
        "event": undefined,
        "id": "65768c40-62ff-4d0c-ade9-0ebffc74b69a",
        "recordType": "PropagationInfo"
      }
      ],
      "executionTime" : null
  }

  const generic_response_fail : GenericResponse = {
    "resultCode": "CDK_200",
    "resultDescription": "NotOK",
    "resultObj": [
      {
        "objectType": "Propagation",
        "date": "2020-10-29T09:56:13.635+0000",
        "objectIdentifier": "ProjOct21 : store1 : Propagate_Fu_To_BP_Drive",
        "user": "Suresh.Vanga@cdk.com",
        "event": undefined,
        "id": "65768c40-62ff-4d0c-ade9-0ebffc74b69a",
        "recordType": "PropagationInfo"
      }
      ],
      "executionTime" : null
  }

    it('test the init function', async()=>{
        let data:{

        }
       spyOn(authService, 'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data))
       spyOn(authService, 'isAuthorised').and.returnValue(false)
       fixture.detectChanges;
       component.ngOnInit();
       expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(1);
    });

    it('test fetch GOM Mofified functional units', async() => {
        component.filter = true;
        spyOn(component,'applyFilter');
        spyOn(masterFuSrevice,'fetchAllFunctionalUnitsByGOMModified').and.returnValue(Observable.of(generic_response));
        component.fetchGOMModifiedFus();
        expect(masterFuSrevice.fetchAllFunctionalUnitsByGOMModified).toHaveBeenCalledTimes(1);
    });

    it('test fetch GOM Mofified functional units else case', async() => {
        component.filter = true;
        spyOn(component,'applyFilter');
        spyOn(masterFuSrevice,'fetchAllFunctionalUnitsByGOMModified').and.returnValue(Observable.of(generic_response_fail));
        component.fetchGOMModifiedFus();
    });

    it('test fetch GOM Mofified functional units fail case', async() => {
        component.filter = true;
        spyOn(component,'applyFilter');
        spyOn(masterFuSrevice,'fetchAllFunctionalUnitsByGOMModified').and.returnValue(Observable.throwError('error'));
        component.fetchGOMModifiedFus();
    });

    it('test isAllSelected method', async() =>{
        component.isAllSelected();
        component.dataSource= new MatTableDataSource<MasterFunctionalUnit>(master_fu_response_list);
        component.isAllSelected();
    });

    it('test navigate to dashboard method', async() =>{
        component.gotoDashboard();
    });

    it('test clear all rows method', async() =>{
        component.clearAllRows();
    });

    it('test select all rows method', () => {
        component.dataSource= new MatTableDataSource<MasterFunctionalUnit>(master_fu_response_list);
        component.selectAllRows();
    })

    it('test disable button method', ()=>{
        component.adminConsolePermission = true;
        component.selectedFuList.length = 2;
        let res = component.disableButton();
        expect(res).toBe(false);

        component.adminConsolePermission = false;
        component.selectedFuList.length = 0;
        let result = component.disableButton();
        expect(result).toBe(true);
    })

    it('test open dialog to view components method', async() => {
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        component.openDialogToViewChanges(mock_functional_unit);
    })

    it('test open dialog to propagation acknowledgment method', async() =>{

        let result:any={
            "event":"Confirm"
        }
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(result), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        spyOn(component,'ngOnInit');
        spyOn(component,'clearAllRows')
        component.openDialogToPropagationAcknowledgment();
        
    });
 
    it('test open dialog to discard changes', async() => {
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(masterFuSrevice,'discardModifiedFuChanges').and.returnValue(Observable.of(mock_functional_unit));
        component.openDialogToDiscardChanges(mock_functional_unit);
    });

    it('test open dialog to discard changes fail case', async() => {
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(masterFuSrevice,'discardModifiedFuChanges').and.returnValue(Observable.throwError('error'));
        component.openDialogToDiscardChanges(mock_functional_unit);
    });

    it('test master togle method', () =>{
        spyOn(component,'isAllSelected').and.returnValue(true);
        component.masterToggle();
    });

    it('test check box label method', () => {
        component.checkboxLabel(mock_functional_unit);
        component.checkboxLabel();
    });

    it('test select row method', () =>{

        const mock_functional_unit1 : any = {
            "functionalUnitType" : "MasterFunctionalUnit",
            "functionalUnitName" : "Deal Retention",
            "description" : "Deal Retention",
            "version" : "0",
            "gomModified" : false,
            "propagationStarted" : false,
            "propagationStatus" : "0",
            "id" : "b722f8ca-cd29-4b9d-aa30-0a72a6797322",
            "recordType" : "FunctionalUnitInfo"
    
        }
        let selectedFuList: any = [
            {
            "functionalUnitType" : "MasterFunctionalUnit",
            "functionalUnitName" : "Deal Retention",
            "description" : "Deal Retention",
            "version" : "0",
            "gomModified" : false,
            "propagationStarted" : false,
            "propagationStatus" : "0",
            "id" : "b722f8ca-cd29-4b9d-aa30-0a72a6797344",
            "recordType" : "FunctionalUnitInfo"    
            }
        ];
        component.selectedFuList = selectedFuList;

        component.selectRow(false,mock_functional_unit1);
    })

    it('test select row method for true event', () =>{
        let selectedFuList: any = [];
        component.selectedFuList= selectedFuList;
        let event:any={
            checked:true
        }
        component.selectRow(event,mock_functional_unit);
    })


    it('test apply filter module', ()=>{
        component.dataSource = new MatTableDataSource<MasterFunctionalUnit>(master_fu_response_list);
        component.applyFilter("filterString");
      });

})

