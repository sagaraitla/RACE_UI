import { Component, OnInit,Inject, Input} from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog,MatDialogRef,MAT_DIALOG_DATA } from '@angular/material';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { ValidationRuleObject } from '../model/validation-rule-object';
import { ValidationRuleService } from '../services/validation-rule-service';
import { FunctionalAreaService } from '../services/functional-area-service';
import { TemplateObject } from '../model/template-object';
import { MasterFunctionalUnitService } from '../services/master-functional-unit-service';
import { MasterFunctionalUnit } from '../model/master-functional-unit';
import { Constants } from '../constant/constants';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-new-validation-rule',
  templateUrl: './new-validation-rule.component.html',
  styleUrls: ['./new-validation-rule.component.css']
})
export class NewValidationRuleComponent implements OnInit {
	
	
	editMode : boolean = false;
	copyMode : boolean = false;

	validationRule : ValidationRuleObject = new ValidationRuleObject();
	existingValidationRule : ValidationRuleObject = new ValidationRuleObject();
	label : string;
	loaderDialogRef: any;
	validationFormGroup: FormGroup;

	sourceFAsLoading:boolean = false;
	sourceFUsLoading:boolean = false;
	sourceFHNamesLoading:boolean = false;

	targetFAsLoading:boolean = false;
	targetFUsLoading:boolean = false;
	targetFHNamesLoading:boolean = false;
	
	sourceTemplateObject : TemplateObject = new TemplateObject();
	targetTemplateObject : TemplateObject = new TemplateObject();

	selectedSourceTemplateObjects : TemplateObject[];
	selectedTargetTemplateObjects : TemplateObject[];

	sourceFunctionalUnit : MasterFunctionalUnit = new MasterFunctionalUnit();
	targetFunctionalUnit : MasterFunctionalUnit = new MasterFunctionalUnit();

	selectedSourceFunctionalUnitObjects : MasterFunctionalUnit[];
	selectedTargetFunctionalUnitObjects : MasterFunctionalUnit[];

	selectedSourceFHNames : string[];
	selectedTargetFHNames : string[];

	productCodes :any = [];
	conditions : any = [];
	platforms : any = [];
	conditionTypes : any =[];
    
     constructor(private validationRuleService: ValidationRuleService,private _formBuilder: FormBuilder, @Inject(MAT_DIALOG_DATA) private data: any,
			private dialog : MatDialog, private dialogRef: MatDialogRef<NewValidationRuleComponent>, private toastrService : ToastrService,
			private functionalAreaService: FunctionalAreaService,private masterFunctionalUnitService: MasterFunctionalUnitService){
	   dialogRef.disableClose = true;
	   this.validationRule = new ValidationRuleObject();
	  
	   this.selectedSourceTemplateObjects = [];
	   this.selectedTargetTemplateObjects = [];

	   this.selectedSourceFunctionalUnitObjects = [];
	   this.selectedTargetFunctionalUnitObjects = [];
	
 	   if(this.data.edit){
           this.label=' Edit Validation Rule';
		   this.updateExistingData(this.data.validationRule);
		   this.existingValidationRule = this.data.validationRule;
		   this.validationRule.platformName = this.data.validationRule.platformName;
		   this.editMode = true;
		   this.populateSourceInformation();
		   this.populateTargetInformation();
 	   } else if(this.data.copy){
			this.updateExistingData(this.data.validationRule);
			this.existingValidationRule = this.data.validationRule;
			if(this.existingValidationRule.platformName === this.data.initial){
			 if(this.existingValidationRule.platformName === 'DRIVE'){
				this.validationRule.platformName = 'FLEX';
				this.existingValidationRule.platformName = 'FLEX'
			 } else if(this.existingValidationRule.platformName === 'FLEX'){
				this.validationRule.platformName = 'DRIVE';
				this.existingValidationRule.platformName = 'DRIVE'
			 } 
			} else{
				this.validationRule.platformName = this.existingValidationRule.platformName;
			}
			this.label = "Copy To "+this.existingValidationRule.platformName+" Platform"
			this.copyMode = true;
			this.populateSourceInformation();
			this.populateTargetInformation();
		}
	   else{
		   this.label=' Add Validation Rule';
	   }  
	   this.productCodes = Constants.PRODUCT_CODES.filter(pr => pr.value != 'SSS');	  
	   this.conditions = Constants.CONDITONS;
	   this.platforms = Constants.PLATFOMRS;
	   this.conditionTypes = Constants.CONDITION_TYPES;
	
	}
	
	updateExistingData(data:any){
		this.validationRule.sourceProductCode = this.data.validationRule.sourceProductCode;
		this.validationRule.targetProductCode = this.data.validationRule.targetProductCode;
		this.validationRule.condition = this.data.validationRule.condition
		this.validationRule.conditionType = this.data.validationRule.conditionType
		this.validationRule.validationMessage = this.data.validationRule.validationMessage
		this.validationRule.active = this.data.validationRule.active
	}
	
    ngOnInit() {
		this.validationFormGroup = this._formBuilder.group({
			platformName: ['', Validators.required],
			sourceProductCode: ['', Validators.required],
			sourceFunctionalAreaName: ['', Validators.required],
			sourceFunctionalUnitName: ['', Validators.required],
			sourceFieldHeaderName: ['', Validators.required],
			condition: ['', Validators.required],
			conditionType: ['', Validators.required],
			targetProductCode: ['', Validators.required],
			targetFunctionalAreaName: ['', Validators.required],
			targetFunctionalUnitName: ['', Validators.required],
			targetFieldHeaderName: ['', Validators.required],
			validationMessage: new FormControl('', Validators.compose([Validators.pattern('.*\\S.*[a-zA-z0-9 ]*$')]))
	});	
	}
	
	closePopup() {
		this.dialogRef.close(Constants.POPUP_CANCEL);
	};

	checkActiveVersion(event : any){
		if(event.checked){
			this.validationRule.active=true;
		}else{
			this.validationRule.active=false;
		}
	}

	platformChange(){

		if(this.editMode || this.copyMode){ 
			this.validationFormGroup.get('platformName').disable();
		}
		this.validationRule.platformName = this.validationRule.platformName;
		if(this.validationRule.sourceProductCode != null && this.validationRule.sourceProductCode != undefined && !this.data.edit){
			this.changeSourceProductCode();
		}
		if(this.validationRule.targetProductCode != null && this.validationRule.targetProductCode != undefined && !this.data.edit){
			this.changeTargetProductCode();
		}
	}

	changeSourceProductCode(){
		this.validationRule.sourceFunctionalAreaName = "";
		let platformName = this.validationRule.platformName;
		let sourceProductCode = this.validationRule.sourceProductCode;
		
		if(platformName != null && platformName != undefined){
			if(sourceProductCode != null && sourceProductCode != undefined){
				this.sourceFAsLoading = true;
				this.selectedSourceTemplateObjects =[];
				this.selectedSourceFunctionalUnitObjects = [];
				this.selectedSourceFHNames = [];
				this.functionalAreaService.getFunctionalAreasByPlatformAndProductCode(platformName,sourceProductCode)
				.subscribe(genericResponse=>{
					this.sourceFAsLoading = false;
					if(genericResponse != null && genericResponse.resultCode === Constants.CDK_200){
						this.selectedSourceTemplateObjects = genericResponse.resultObj;
					}
				});	
			}
		}
	}

	changeSourceFunctionalArea(){
		this.validationRule.sourceFunctionalUnitName = "";
		let sourceFAName = this.validationRule.sourceFunctionalAreaName;
		let selectedSourceFAId:string;
		this.selectedSourceTemplateObjects.forEach((sourceFunctionalAreaObj)=>{
			if(sourceFunctionalAreaObj.functionalAreaName === sourceFAName){
					selectedSourceFAId = sourceFunctionalAreaObj.id;
			}
		})

		if(selectedSourceFAId != null && selectedSourceFAId != undefined){
				this.sourceFUsLoading = true;
				this.selectedSourceFunctionalUnitObjects = [];
				this.selectedSourceFHNames = [];
				this.masterFunctionalUnitService.fetchFunctionalUnitsOfMasterFunctionalArea(selectedSourceFAId)
					.subscribe((functionalUnits=>{
						this.sourceFUsLoading = false;
						if(functionalUnits != null && functionalUnits != undefined){
							this.selectedSourceFunctionalUnitObjects = functionalUnits;
						}
					}));
		}		
	}

	changeSourceFunctionalUnitToGetHeaderNames(){
		this.validationRule.sourceFieldHeaderName = "";
		let sourceFUName = this.validationRule.sourceFunctionalUnitName;
		let columnHeaders:any;
		this.selectedSourceFHNames = [];
		this.selectedSourceFunctionalUnitObjects.forEach((functionalUnitObj)=>{
			if(sourceFUName === functionalUnitObj.functionalUnitName){
				columnHeaders = functionalUnitObj.gridOptionsModel.columnDefs; 
				if(this.showErrorMessage(columnHeaders,sourceFUName) == false){
					functionalUnitObj.gridOptionsModel.columnDefs.forEach(columnDef=>{
						this.selectedSourceFHNames.push(columnDef['headerName']);
						
					}); 	
				}
			}
		})
		this.selectedSourceFHNames.sort();
	}

	changeTargetProductCode(){
		this.validationRule.targetFunctionalAreaName = "";
		let platformName = this.validationRule.platformName;
		let targetProductCode = this.validationRule.targetProductCode;

		if(platformName != null && platformName != undefined){
			if(targetProductCode != null && targetProductCode != undefined){
				if(!this.validationRule.validationMessage){
					if(this.validationRule.targetProductCode == 'ACCT'){
						this.validationRule.validationMessage = 'Missing Account or not valid';
					}
					else if(this.validationRule.targetProductCode == 'PTS'){
						this.validationRule.validationMessage = 'Price code missing or not valid';
					}
					else if(this.validationRule.targetProductCode == 'SVC'){
						this.validationRule.validationMessage = 'Tax code missing or not valid';
					}
					else if(this.validationRule.targetProductCode == 'SLS'){
						this.validationRule.validationMessage = 'Lienholder code Missing or not valid ';
					}
				}
				this.targetFAsLoading = true;
				this.selectedTargetTemplateObjects =[];
				this.selectedTargetFunctionalUnitObjects = [];
				this.selectedTargetFHNames = [];
				this.functionalAreaService.getFunctionalAreasByPlatformAndProductCode(platformName,targetProductCode)
				.subscribe(genericResponse=>{
					this.targetFAsLoading = false;
					 if(genericResponse != null && genericResponse.resultCode===Constants.CDK_200){
						this.selectedTargetTemplateObjects = genericResponse.resultObj;
					}
				});
			}
		}
	}
	
	changeTargetFunctionalArea(){
		this.validationRule.targetFunctionalUnitName = "";
		let targetFAName = this.validationRule.targetFunctionalAreaName;
		let selectedTargetFAId:string;
		this.selectedTargetTemplateObjects.forEach((targetFunctionalAreaObj)=>{
			if(targetFunctionalAreaObj.functionalAreaName === targetFAName){
				selectedTargetFAId = targetFunctionalAreaObj.id;
			}
		})
		if(selectedTargetFAId != null && selectedTargetFAId != undefined){
			this.targetFUsLoading = true;
			this.selectedTargetFunctionalUnitObjects = [];
			this.selectedTargetFHNames = [];
			this.masterFunctionalUnitService.fetchFunctionalUnitsOfMasterFunctionalArea(selectedTargetFAId)
				.subscribe((functionalUnits=>{
					this.targetFUsLoading = false;
					if(functionalUnits != null && functionalUnits != undefined){
						this.selectedTargetFunctionalUnitObjects =functionalUnits;
					}
				}));
		}
	}

	changeTargetFunctionalUnitToGetHeaderNames(){
		this.validationRule.targetFieldHeaderName = "";
		let targetFUName = this.validationRule.targetFunctionalUnitName;
		let columnHeaders:any;
		this.selectedTargetFHNames = [];
		this.selectedTargetFunctionalUnitObjects.forEach((functionalUnitObj)=>{
			if(targetFUName === functionalUnitObj.functionalUnitName){
				columnHeaders = functionalUnitObj.gridOptionsModel.columnDefs; 
				if(this.showErrorMessage(columnHeaders,targetFUName) == false){
					functionalUnitObj.gridOptionsModel.columnDefs.forEach(columnDef=>{
						this.selectedTargetFHNames.push(columnDef['headerName']);
					 });
				 }
			}
		})
		this.selectedTargetFHNames.sort();
	}

	showErrorMessage(columnHeaders:any,fuName:any){
		let flag:boolean= false;
		 if(Array.isArray(columnHeaders) && columnHeaders.length === 0){
			 flag= true;
			 this.toastrService.error('Functional Unit '+'"'+fuName+'"'+ ' does not have header fields.Please Choose another');
		 } 
		 return flag;
	 }

	 

	 saveValidationRule(){
		console.log("** saveValidationRule **")
		let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
			width: '300px',
			height: '150px',
			data: { message: 'Saving Validation Rule.' }
		});
		if(this.copyMode){
			this.validationRule.id = "";
			this.validationRule.isVR = 1;
		}
		if(this.editMode){
			this.validationRule.id = this.existingValidationRule.id;
			this.validationRule.recordType = this.existingValidationRule.recordType;
			this.validationRule.isVR = 1;
		}
		if(this.validationRule.sourceProductCode == this.validationRule.targetProductCode
			&& this.validationRule.sourceFunctionalAreaName == this.validationRule.targetFunctionalAreaName
			&& this.validationRule.sourceFunctionalUnitName == this.validationRule.targetFunctionalUnitName
			&& this.validationRule.sourceFieldHeaderName == this.validationRule.targetFieldHeaderName){
				this.toastrService.error('Validation Rule with the same Source and Target details cannot be created');
				loaderDialogRef.close();
		}else{
		this.validationRuleService.createValidationRule(this.validationRule)
		.subscribe(results=>{
			if(results != null && results != undefined){
				if(results.resultCode === 'CDK_200'){
					loaderDialogRef.close();
					if (results.resultDescription == "DUPLICATE_RECORD"){
						this.toastrService.error('Validation Rule with the same Source Field, Target Field and Condition already exists');
					}
					else {
						this.dialogRef.close();
					}
				}
			}
		   },error=> {
			this.toastrService.warning('Error Occurred while Saving Validation Rule');
			loaderDialogRef.close();
		  });
		}	
	}

	populateSourceInformation(){
		let sourceFAId:string;
		this.sourceFAsLoading = true;
		this.functionalAreaService.getFunctionalAreasByPlatformAndProductCode(this.existingValidationRule.platformName,this.existingValidationRule.sourceProductCode)
		.subscribe((genericResponse)=>{
			this.sourceFAsLoading = false;
			if(genericResponse != null && genericResponse.resultCode===Constants.CDK_200){
			     this.selectedSourceTemplateObjects = genericResponse.resultObj;
				 this.selectedSourceTemplateObjects.forEach((surceTemplateObjNew)=>{
					 if(surceTemplateObjNew.functionalAreaName == this.existingValidationRule.sourceFunctionalAreaName){
						sourceFAId = surceTemplateObjNew.id;
					 }
				 })
				 let sourceFANotFound : boolean = false;
					let matchedValidationRule =  this.selectedSourceTemplateObjects.find(sto => sto.functionalAreaName === this.existingValidationRule.sourceFunctionalAreaName)
					
					if(matchedValidationRule === null || matchedValidationRule === undefined){	
						this.toastrService.error('Source Functional Area '+'"'+this.existingValidationRule.sourceFunctionalAreaName+'"'+ ' not configured for the Platform '+
							this.existingValidationRule.platformName+' and Source Product code '+this.existingValidationRule.sourceProductCode);
							sourceFANotFound = true;
						} else{
							this.validationRule.sourceFunctionalAreaName = this.existingValidationRule.sourceFunctionalAreaName;
						}

				 if(!sourceFANotFound){
					this.sourceFUsLoading = true;
					this.masterFunctionalUnitService.fetchFunctionalUnitsOfMasterFunctionalArea(sourceFAId)
					.subscribe((functionalUnits=>{
						this.sourceFUsLoading = false;
							if(functionalUnits != null && functionalUnits.length > 0){
								this.selectedSourceFunctionalUnitObjects = functionalUnits;
									
									  	let sourceFUNotFound : boolean = false;
										let matchedValidationRule = this.selectedSourceFunctionalUnitObjects.find(sfuo=>sfuo.functionalUnitName === this.existingValidationRule.sourceFunctionalUnitName)
										if(matchedValidationRule === null || matchedValidationRule === undefined){
											this.toastrService.error('Source Functional Unit '+'"'+this.existingValidationRule.sourceFunctionalUnitName+'"'+
											'is not configured for the Source Functional Area '+'"'+this.existingValidationRule.sourceFunctionalAreaName+'"');
											sourceFUNotFound = true;
										} else{
											this.validationRule.sourceFunctionalUnitName = this.existingValidationRule.sourceFunctionalUnitName;
										}
									

									let columnHeaders:any;
									this.selectedSourceFunctionalUnitObjects.forEach((functionalUnitObj)=>{
									if(this.existingValidationRule.sourceFunctionalUnitName === functionalUnitObj.functionalUnitName){
										this.selectedSourceFHNames = [];
										columnHeaders = functionalUnitObj.gridOptionsModel.columnDefs; 
										if(this.showErrorMessage(columnHeaders,this.existingValidationRule.sourceFunctionalUnitName) == false){
											functionalUnitObj.gridOptionsModel.columnDefs.forEach(columnDef=>{
											this.selectedSourceFHNames.push(columnDef['headerName']);
										}); 	
									}}})
									if(!sourceFUNotFound){
										let matchedValidationRule  = this.selectedSourceFHNames.find(sfhn =>sfhn === this.existingValidationRule.sourceFieldHeaderName);
										if(matchedValidationRule === null || matchedValidationRule === undefined){
											this.toastrService.error('Source Header Name'+'"'+this.existingValidationRule.sourceFieldHeaderName+'""'+ 'is not found for the Source Functional Unit'+'"'+this.existingValidationRule.sourceFunctionalUnitName+'"');
										} else{
											this.validationRule.sourceFieldHeaderName = this.existingValidationRule.sourceFieldHeaderName;
										}
								}
						}
					}));
				 }
			 }
		})
		
	   }

	 populateTargetInformation(){
		let targetFAId:string;
		this.targetFAsLoading = true;
		
		this.functionalAreaService.getFunctionalAreasByPlatformAndProductCode(this.existingValidationRule.platformName,this.existingValidationRule.targetProductCode)
		.subscribe((genericResponse)=>{
			this.targetFAsLoading = false;
			if(genericResponse != null && genericResponse.resultCode===Constants.CDK_200){
				this.selectedTargetTemplateObjects = genericResponse.resultObj; 
				 this.selectedTargetTemplateObjects.forEach((targetTemplateObjNew)=>{
					 if(targetTemplateObjNew.functionalAreaName == this.existingValidationRule.targetFunctionalAreaName){
						targetFAId = targetTemplateObjNew.id;
					 }
				 })
				 let targetFANotFound : boolean = false;;
				
					let matchedValidationRule =  this.selectedTargetTemplateObjects.find(sto => sto.functionalAreaName === this.existingValidationRule.targetFunctionalAreaName)
					if(matchedValidationRule === null || matchedValidationRule === undefined){
						this.toastrService.error('Target Functional Area '+'"'+this.existingValidationRule.targetFunctionalAreaName+'"'+ ' not configured for the Platform '+
							this.existingValidationRule.platformName+' and Target Product code '+this.existingValidationRule.targetProductCode);
							targetFANotFound = true;
					} else{
						this.validationRule.targetFunctionalAreaName = this.existingValidationRule.targetFunctionalAreaName;
					}
				 
				 if(!targetFANotFound){
					this.targetFUsLoading = true;
					 this.masterFunctionalUnitService.fetchFunctionalUnitsOfMasterFunctionalArea(targetFAId)
					 .subscribe((functionalUnits=>{
					 	this.targetFUsLoading = false;
					 	if(functionalUnits != null && functionalUnits.length > 0){
					 		this.selectedTargetFunctionalUnitObjects = functionalUnits;
					
					   let targetFUNotFound : boolean = false;
						let matchedValidationRule = this.selectedTargetFunctionalUnitObjects.find(tfuo=>tfuo.functionalUnitName === this.existingValidationRule.targetFunctionalUnitName)
						if(matchedValidationRule === null || matchedValidationRule === undefined){
							this.toastrService.error('Target Functional Unit '+'"'+this.existingValidationRule.targetFunctionalUnitName+'"'+
							'is not configured for the Target Functional Area '+'"'+this.existingValidationRule.targetFunctionalAreaName+'"');
							targetFUNotFound = true;
						} else{
							this.validationRule.targetFunctionalUnitName = this.existingValidationRule.targetFunctionalUnitName;
						}
					

					   let columnHeaders:any;
					   this.selectedTargetFunctionalUnitObjects.forEach((functionalUnitObj)=>{
					 		if(this.existingValidationRule.targetFunctionalUnitName === functionalUnitObj.functionalUnitName){
					 			this.selectedTargetFHNames = [];
						 		columnHeaders = functionalUnitObj.gridOptionsModel.columnDefs; 
						 		if(this.showErrorMessage(columnHeaders,this.existingValidationRule.targetFunctionalUnitName) == false){
									 functionalUnitObj.gridOptionsModel.columnDefs.forEach(columnDef=>{
								 	this.selectedTargetFHNames.push(columnDef['headerName']);
							 	}); 	
						 	}
						 }})
						 if(!targetFUNotFound){
							let matchedValidationRule  = this.selectedTargetFHNames.find(tfhn =>tfhn === this.existingValidationRule.targetFieldHeaderName);
							if(matchedValidationRule === null || matchedValidationRule === undefined){
								this.toastrService.error('Target Header Name'+'"'+this.existingValidationRule.targetFieldHeaderName+'""'+ 'is not found for the Target Functional Unit'+'"'+this.existingValidationRule.targetFunctionalUnitName+'"');
							} else {
								this.validationRule.targetFieldHeaderName = this.existingValidationRule.targetFieldHeaderName;
							}
						}
					 }
				 }));
				 }	
			 }	
		})
	   } 

}
