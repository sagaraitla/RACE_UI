import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatTableModule } from "@angular/material";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { ToastrModule } from "ngx-toastr";
import { Observable, of } from "rxjs";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { TemplateObject } from "../model/template-object";
import { ValidationRuleObject } from "../model/validation-rule-object";
import { AuthService } from "../services/auth-service";
import { FunctionalAreaService } from "../services/functional-area-service";
import { MasterFunctionalUnitService } from "../services/master-functional-unit-service";
import { ServerCommunicationService } from "../services/server-communication-service";
import { ValidationRuleService } from "../services/validation-rule-service";
import { NewValidationRuleComponent } from "./new-validation-rule.component";

describe('NewValidationRuleComponent', () => {


  describe('NewValidationRuleComponent for edit is true and platform is DRIVE', () => {
    let component : NewValidationRuleComponent;
    let fixture: ComponentFixture<NewValidationRuleComponent>;
    let validationRuleService: ValidationRuleService;
    let functionalAreaService: FunctionalAreaService;
    let masterFunctionalUnitService: MasterFunctionalUnitService;
   
    beforeEach(() => {

        let data= {
            edit:false,
            copy:true,
            initial:'DRIVE',
            validationRule:{
                 sourceProductCode:"PTS",
                 targetProductCode:"ACCT",
                 condition:"must be equal",
                 conditionType:"test",
                 validationMessage:"test message",
                 active:true,
                platformName:'DRIVE'
            }
        }
        const dialogMock = {
            close: () => { },
        };
        
        TestBed.configureTestingModule({
            imports: [
                MatDialogModule,
                MatFormFieldModule,
                MatRadioModule,
                FormsModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatInputModule,
                MatTableModule,
                MatPaginatorModule,
                MatDialogModule,
                HttpClientTestingModule,
                ToastrModule.forRoot(),
                NoopAnimationsModule,
                MatProgressSpinnerModule ,
                ReactiveFormsModule,
                CommonModule,
                MatSelectModule,
                MatCheckboxModule,
                MatCardModule
            ],
            declarations: [NewValidationRuleComponent,LoaderDialogueComponent],
            providers:[
                ValidationRuleService,
                FunctionalAreaService,
                MasterFunctionalUnitService,
                ServerCommunicationService,
                AuthService,
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: dialogMock},
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent]}});

            functionalAreaService = TestBed.get(FunctionalAreaService);
            masterFunctionalUnitService = TestBed.get(MasterFunctionalUnitService);
            validationRuleService = TestBed.get(ValidationRuleService);

            fixture = TestBed.createComponent(NewValidationRuleComponent);
            component = fixture.componentInstance;
          
    });

    it('test NewValidationRuleComponent created',()=>{
      expect(component).toBeTruthy();
    });

  });

  describe('NewValidationRuleComponent if edit true', () => {

    let component : NewValidationRuleComponent;
    let fixture: ComponentFixture<NewValidationRuleComponent>;
    let validationRuleService: ValidationRuleService;
    let functionalAreaService: FunctionalAreaService;
    let masterFunctionalUnitService: MasterFunctionalUnitService;
   
    beforeEach(() => {

        let data= {
            edit:true,
            validationRule:{
                platformName:'flex'
            }
        }
        const dialogMock = {
            close: () => { },
        };
        
        TestBed.configureTestingModule({
            imports: [
                MatDialogModule,
                MatFormFieldModule,
                MatRadioModule,
                FormsModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatInputModule,
                MatTableModule,
                MatPaginatorModule,
                MatDialogModule,
                HttpClientTestingModule,
                ToastrModule.forRoot(),
                NoopAnimationsModule,
                MatProgressSpinnerModule ,
                ReactiveFormsModule,
                CommonModule,
                MatSelectModule,
                MatCheckboxModule,
                MatCardModule
            ],
            declarations: [NewValidationRuleComponent,LoaderDialogueComponent],
            providers:[
                ValidationRuleService,
                FunctionalAreaService,
                MasterFunctionalUnitService,
                ServerCommunicationService,
                AuthService,
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: dialogMock},
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent]}});

            functionalAreaService = TestBed.get(FunctionalAreaService);
            masterFunctionalUnitService = TestBed.get(MasterFunctionalUnitService);
            validationRuleService = TestBed.get(ValidationRuleService);

            fixture = TestBed.createComponent(NewValidationRuleComponent);
            component = fixture.componentInstance;
          
    });


    const createValidationRule_generic_response:any={
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": []
    }

    const createValidationRule_generic_response_duplicate:any={
        "resultCode": "CDK_200",
        "resultDescription": "DUPLICATE_RECORD",
        "resultObj": []
    }
    const genericResponse_getFunctionalAreasByPlatformAndProductCode :any ={
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [
            {
            "functionalAreaType": "MasterFunctionalArea",
            "functionalAreaName": "04_feb1_fa changed",
            "oemName": null,
            "platforms": [
                {
                "id": null,
                "platformName": "DRIVE",
                "platformCode": "drive",
                "selected": true
                }
            ],
            "version": 0,
            "productCode": "SVC",
            "productVersion": null,
            "propagationStarted": false,
            "id": "2205fa57-a47c-405f-9051-6716ee3e0d09",
            "recordType": "FunctionalAreaInfo"
            }
     ]
    }
    const validationRule_obj:ValidationRuleObject={
        isVR: 1,
        platformName: 'DRIVE',
        sourceProductCode : 'ACCT',
        sourceFunctionalAreaName : 'Service',
        sourceFunctionalUnitName : 'Tax Code',
        sourceFieldHeaderName: 'Code',
        condition : 'Must Exist In',
        conditionType : 'Error',
        validationMessage : 'my validation msg',
        targetProductCode : 'ACC',
        targetFunctionalAreaName: 'Account',
        targetFunctionalUnitName: 'Tax Percentage',
        targetFieldHeaderName: 'Journal',
        active: true,
        status: 'open',
        id:'77777',
        recordType:'ValidationRule'
    }

    const validationRule_without_validation_msg:ValidationRuleObject={
        isVR: 1,
        platformName: 'DRIVE',
        sourceProductCode : 'ACC',
        sourceFunctionalAreaName: 'Service',
        sourceFunctionalUnitName: 'Tax Code',
        sourceFieldHeaderName: 'Code',
        condition : 'Must Exist In',
        conditionType : 'Error',
        validationMessage : null,
        targetProductCode : 'ACCT',
        targetFunctionalAreaName: 'Account',
        targetFunctionalUnitName: 'Tax Percentage',
        targetFieldHeaderName: 'Journal',
        active: true,
        status: 'open',
        id:'1233',
        recordType:'ValidationRule'
    }

    const validationRule_without_validation_msg_PTS:ValidationRuleObject={
        isVR: 1,
        platformName: 'DRIVE',
        sourceProductCode : 'ACC',
        sourceFunctionalAreaName: 'Service',
        sourceFunctionalUnitName: 'Tax Code',
        sourceFieldHeaderName: 'Code',
        condition : 'Must Exist In',
        conditionType : 'Error',
        validationMessage : null,
        targetProductCode : 'PTS',
        targetFunctionalAreaName: 'Parts',
        targetFunctionalUnitName: 'Tax Percentage',
        targetFieldHeaderName: 'Journal',
        active: true,
        status: 'open',
        id:'1233',
        recordType:'ValidationRule'
    }
    const validationRule_without_validation_msg_SVC:ValidationRuleObject={
        isVR: 1,
        platformName: 'DRIVE',
        sourceProductCode : 'ACC',
        sourceFunctionalAreaName: 'Service',
        sourceFunctionalUnitName: 'Default Tax Accounting',
        sourceFieldHeaderName: 'Code',
        condition : 'Must Exist In',
        conditionType : 'Error',
        validationMessage : null,
        targetProductCode : 'SVC',
        targetFunctionalAreaName: 'Parts',
        targetFunctionalUnitName: 'Tax Percentage',
        targetFieldHeaderName: 'Journal',
        active: true,
        status: 'open',
        id:'1233',
        recordType:'ValidationRule'
    }
    const validationRule_without_validation_msg_SLS:ValidationRuleObject={
        isVR: 1,
        platformName: 'DRIVE',
        sourceProductCode : 'ACC',
        sourceFunctionalAreaName: 'Service',
        sourceFunctionalUnitName: 'Tax Code',
        sourceFieldHeaderName: 'Code',
        condition : 'Must Exist In',
        conditionType : 'Error',
        validationMessage : null,
        targetProductCode : 'SLS',
        targetFunctionalAreaName: 'Parts',
        targetFunctionalUnitName: 'Tax Percentage',
        targetFieldHeaderName: 'Journal',
        active: true,
        status: 'open',
        id:'1233',
        recordType:'ValidationRule'
    }

    const validationRule_with_same_Source_and_Target:ValidationRuleObject={
      isVR: 1,
      platformName: 'DRIVE',
      sourceProductCode : 'ACCT',
      sourceFunctionalAreaName: 'Accounting',
      sourceFunctionalUnitName: 'COA',
      sourceFieldHeaderName: 'Account',
      condition : 'Must Exist In',
      conditionType : 'Error',
      validationMessage : null,
      targetProductCode : 'ACCT',
      targetFunctionalAreaName: 'Accounting',
      targetFunctionalUnitName: 'COA',
      targetFieldHeaderName: 'Account',
      active: true,
      status: 'open',
      id:'1233',
      recordType:'ValidationRule'
  }

    const funitsOfMasterFA :any = [
            {
              "functionalUnitType": "ChildFunctionalUnit",
              "functionalUnitName": "Default Tax Accounting",
              "description": "Default Tax Accounting",
              "version": 0,
              "productCode": "SVC",
              "gomModified": false,
              "propagationStarted": false,
              "propagationStatus": 0,
              "id": "4602d541-2de2-40c1-a1bd-6892e1344224",
              "recordType": "e5e627f3-3ba6-4bc3-8959-38a60a0aea87"
            }
    ]

    const selectedTemplateObjects:TemplateObject[] =[
        {
            functionalAreaName: 'Service',
            functionalAreaType: 'MasterFunctionalArea',
            oemName: null,
            platforms:null,
            clientSignoffDate: null,
            selected: false,
            screenIds : null,
            vic: null,
            secondaryVic: null,
            clientFunctionalAreaUser: null,
            status: null,
            productCode : 'SVC',
            productVersion: '1.0',
            isLocked: false,
            storeId: null,
            version : null,
            isFailed : false,
            inProcess : false,
            bpId : null,
            bpTemplateId: null,
            bpVersionId: null,
            isDealerApproved: null,
            stateStandardId: null,
            stateStandardName: null,
            stateStandardVersionRecordType: null,
            stateStandardVersionName: null,
            copyRowData: null,
            showProcessValidationResultsButton:false,
            showValidateOrTransferButton:false,
            createdDate: new Date(), 
            lastUpdatedDate: new Date(),
            createdBy:null,
            updatedBy:null,
            incorporateBpChanges: false,
            id:"1233",
            recordType:null
        }
    ] 

    it('test NewValidationRuleComponent created',()=>{
        expect(component).toBeTruthy();
    });


    it('test changeSourceProductCode',()=>{
        component.validationRule = validationRule_obj;
        spyOn(functionalAreaService,'getFunctionalAreasByPlatformAndProductCode').and.returnValue(Observable.of(genericResponse_getFunctionalAreasByPlatformAndProductCode));
        component.changeSourceProductCode();
        expect(functionalAreaService.getFunctionalAreasByPlatformAndProductCode).toHaveBeenCalledTimes(1);
        expect(component.selectedSourceTemplateObjects.length).toEqual(1);
        
    });

    it('test changeTargetProductCode',()=>{
        component.validationRule = validationRule_obj;
        spyOn(functionalAreaService,'getFunctionalAreasByPlatformAndProductCode').and.returnValue(Observable.of(genericResponse_getFunctionalAreasByPlatformAndProductCode));
        component.changeTargetProductCode();
        expect(functionalAreaService.getFunctionalAreasByPlatformAndProductCode).toHaveBeenCalledTimes(1);
        expect(component.selectedTargetTemplateObjects.length).toEqual(1);
        
    });


    
    it('test changeTargetProductCode if validation message does not exist and ProductCode is ACCT',()=>{
        component.validationRule = validationRule_without_validation_msg;
        spyOn(functionalAreaService,'getFunctionalAreasByPlatformAndProductCode').and.returnValue(Observable.of(genericResponse_getFunctionalAreasByPlatformAndProductCode));
        component.changeTargetProductCode();
        expect(functionalAreaService.getFunctionalAreasByPlatformAndProductCode).toHaveBeenCalledTimes(1);
        expect(component.selectedTargetTemplateObjects.length).toEqual(1);
        expect(component.validationRule.validationMessage).toEqual('Missing Account or not valid');
        
    });

    it('test changeTargetProductCode if validation message does not exist and ProductCode is PTS',()=>{
      
        component.validationRule = validationRule_without_validation_msg_PTS;
        spyOn(functionalAreaService,'getFunctionalAreasByPlatformAndProductCode').and.returnValue(Observable.of(genericResponse_getFunctionalAreasByPlatformAndProductCode));
        component.changeTargetProductCode();
        expect(functionalAreaService.getFunctionalAreasByPlatformAndProductCode).toHaveBeenCalledTimes(1);
        expect(component.selectedTargetTemplateObjects.length).toEqual(1);
        expect(component.validationRule.validationMessage).toEqual('Price code missing or not valid');
        
    });

    
    it('test changeTargetProductCode if validation message does not exist and ProductCode is SVC',()=>{
      
        component.validationRule = validationRule_without_validation_msg_SVC;
        spyOn(functionalAreaService,'getFunctionalAreasByPlatformAndProductCode').and.returnValue(Observable.of(genericResponse_getFunctionalAreasByPlatformAndProductCode));
        component.changeTargetProductCode();
        expect(functionalAreaService.getFunctionalAreasByPlatformAndProductCode).toHaveBeenCalledTimes(1);
        expect(component.selectedTargetTemplateObjects.length).toEqual(1);
        expect(component.validationRule.validationMessage).toEqual('Tax code missing or not valid');
        
    });

    
    it('test changeTargetProductCode if validation message does not exist and ProductCode is SLS',()=>{
      
        component.validationRule = validationRule_without_validation_msg_SLS;
        spyOn(functionalAreaService,'getFunctionalAreasByPlatformAndProductCode').and.returnValue(Observable.of(genericResponse_getFunctionalAreasByPlatformAndProductCode));
        component.changeTargetProductCode();
        expect(functionalAreaService.getFunctionalAreasByPlatformAndProductCode).toHaveBeenCalledTimes(1);
        expect(component.selectedTargetTemplateObjects.length).toEqual(1);
        expect(component.validationRule.validationMessage).toEqual('Lienholder code Missing or not valid ');
        
    });

    it('test changeSourceFunctionalArea',()=>{

        const validationRule_obj1:ValidationRuleObject={
            isVR: 1,
            platformName: 'DRIVE',
            sourceProductCode : 'ACCT',
            sourceFunctionalAreaName : 'Service',
            sourceFunctionalUnitName : 'Tax Code',
            sourceFieldHeaderName: 'Code',
            condition : 'Must Exist In',
            conditionType : 'Error',
            validationMessage : 'my validation msg',
            targetProductCode : 'ACC',
            targetFunctionalAreaName: 'Account',
            targetFunctionalUnitName: 'Tax Percentage',
            targetFieldHeaderName: 'Journal',
            active: true,
            status: 'open',
            id:'77777',
            recordType:'ValidationRule'
        }
        component.validationRule = validationRule_obj1;
        component.selectedSourceTemplateObjects = selectedTemplateObjects;
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitsOfMasterFunctionalArea').and.returnValue(Observable.of(funitsOfMasterFA));
        component.changeSourceFunctionalArea();
        expect(masterFunctionalUnitService.fetchFunctionalUnitsOfMasterFunctionalArea).toHaveBeenCalledTimes(1);
        expect(component.sourceFUsLoading).toBeFalsy();
        expect(component.selectedSourceFunctionalUnitObjects.length).toEqual(1);

    });


    it('test changeSourceFunctionalUnitToGetHeaderNames',()=>{

        let functional_units: any[]=[
            {
                "functionalUnitType": "ChildFunctionalUnit",
                "functionalUnitName": "Default Tax Accounting",
                "gridOptionsModel": {
                  "columnDefs": [
                    {
                      "headerName": "Agency Type",
                      "field": "agency_type",
                      "cellEditorParams": {
                        "values": [
                          "State",
                          "Supplemental",
                          "Supplemental2",
                          "Supplemental3",
                          "Supplemental4"
                        ]
                      }
                    }
                  ]
                },
                "description": "Default Tax Accounting",
                "id": "4602d541-2de2-40c1-a1bd-6892e1344224",
                "recordType": "e5e627f3-3ba6-4bc3-8959-38a60a0aea87"
              }
        ]

        component.validationRule = validationRule_without_validation_msg_SVC;
        component.selectedSourceFunctionalUnitObjects = functional_units;
        component.changeSourceFunctionalUnitToGetHeaderNames()

        expect(component.selectedSourceFHNames.length).toEqual(1);
        expect(component.selectedSourceFHNames[0]).toEqual('Agency Type');
        
    });

    it('test platformChange',()=>{
     
        component.editMode = false;
        component.copyMode = false;
        component['data'].edit = false;
        component.validationRule = validationRule_without_validation_msg_SVC;
        component.platformChange();
    });

    it('test checkActiveVersion',()=>{

        let event={
            checked : true
        }
        component.checkActiveVersion(event);
        expect(component.validationRule.active).toBeTruthy();
        
        let event1={
            checked : false
        }
        component.checkActiveVersion(event1);
        expect(component.validationRule.active).toBeFalsy();

    });

    it('test changeTargetFunctionalArea',()=>{

        const validationRule_obj1:ValidationRuleObject={
            isVR: 1,
            platformName: 'DRIVE',
            sourceProductCode : 'ACCT',
            sourceFunctionalAreaName : 'Service',
            sourceFunctionalUnitName : 'Tax Code',
            sourceFieldHeaderName: 'Code',
            condition : 'Must Exist In',
            conditionType : 'Error',
            validationMessage : 'my validation msg',
            targetProductCode : 'SVC',
            targetFunctionalAreaName: 'Service',
            targetFunctionalUnitName: 'Tax Percentage',
            targetFieldHeaderName: 'Journal',
            active: true,
            status: 'open',
            id:'77777',
            recordType:'ValidationRule'
        }
        component.validationRule = validationRule_obj1;
        component.selectedTargetTemplateObjects = selectedTemplateObjects;
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitsOfMasterFunctionalArea').and.returnValue(Observable.of(funitsOfMasterFA));
        component.changeTargetFunctionalArea();
        expect(masterFunctionalUnitService.fetchFunctionalUnitsOfMasterFunctionalArea).toHaveBeenCalledTimes(1);
        expect(component.targetFUsLoading).toBeFalsy();
        expect(component.selectedTargetFunctionalUnitObjects.length).toEqual(1);
    });

    it('test changeTargetFunctionalUnitToGetHeaderNames',()=>{

        let functional_units: any[]=[
            {
                "functionalUnitType": "ChildFunctionalUnit",
                "functionalUnitName": "Tax Percentage",
                "gridOptionsModel": {
                  "columnDefs": [
                    {
                      "headerName": "Agency Type",
                      "field": "agency_type",
                      "cellEditorParams": {
                        "values": [
                          "State",
                          "Supplemental",
                          "Supplemental2",
                          "Supplemental3",
                          "Supplemental4"
                        ]
                      }
                    }
                  ]
                },
                "description": "Tax Percentage",
                "id": "4602d541-2de2-40c1-a1bd-6892e1344224",
                "recordType": "e5e627f3-3ba6-4bc3-8959-38a60a0aea87"
              }
        ]

        component.validationRule = validationRule_without_validation_msg_SVC;
        component.selectedTargetFunctionalUnitObjects = functional_units;
        component.changeTargetFunctionalUnitToGetHeaderNames();

        expect(component.selectedTargetFHNames.length).toEqual(1);
        expect(component.selectedTargetFHNames[0]).toEqual('Agency Type');
        
    });

    it('test showErrorMessage',()=>{
         let columnHeaders:any[]=[
          ]
          let result = component.showErrorMessage(columnHeaders,'Agency Type');
          expect(result).toBeTruthy();
    });

    it('test saveValidationRule in editMode',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        component.editMode = true;
        component.validationRule = validationRule_obj;
        component.existingValidationRule = validationRule_obj;
        spyOn(validationRuleService,'createValidationRule').and.returnValue(Observable.of(createValidationRule_generic_response));
        component.saveValidationRule();
        expect(validationRuleService.createValidationRule).toHaveBeenCalledTimes(1);
        expect(component.validationRule.isVR).toEqual(1);

    });

    it('test saveValidationRule in copyMode',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        component.copyMode = true;
        component.validationRule = validationRule_obj;
        component.existingValidationRule = validationRule_obj;
        spyOn(validationRuleService,'createValidationRule').and.returnValue(Observable.of(createValidationRule_generic_response));
        component.saveValidationRule();
        expect(validationRuleService.createValidationRule).toHaveBeenCalledTimes(1);
        expect(component.validationRule.isVR).toEqual(1);

    });

    it('test saveValidationRule for Duplicate Record ',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        component.editMode = true;
        component.validationRule = validationRule_obj;
        component.existingValidationRule = validationRule_obj;
        spyOn(validationRuleService,'createValidationRule').and.returnValue(Observable.of(createValidationRule_generic_response_duplicate));
        component.saveValidationRule();
        expect(validationRuleService.createValidationRule).toHaveBeenCalledTimes(1);
        expect(component.validationRule.isVR).toEqual(1);

    });

    it('saveValidationRule throw error',()=>{

        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

        component.editMode = true;
        component.validationRule = validationRule_obj;
        component.existingValidationRule = validationRule_obj;
        spyOn(validationRuleService,'createValidationRule').and.returnValue(Observable.throw('error'));
        component.saveValidationRule();
        expect(validationRuleService.createValidationRule).toHaveBeenCalledTimes(1);
        expect(component.validationRule.isVR).toEqual(1);

    });

    it('test save validation rule with same source and target details',() =>{
      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
      dialogRefSpyObj.componentInstance = { body: '' };
      dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
      component.editMode = true;
      component.validationRule = validationRule_with_same_Source_and_Target;
      spyOn(validationRuleService,'createValidationRule').and.returnValue(Observable.throw('error'));
      component.saveValidationRule();
    
  });

    it('test populateSourceInformation',()=>{
        const genericResponse_getFunctionalAreasByPlatformAndProductCode1 :any ={
            "resultCode": "CDK_200",
            "resultDescription": "OK",
            "resultObj": [
                {
                "functionalAreaType": "MasterFunctionalArea",
                "functionalAreaName": "Service",
                "id": "2205fa57-a47c-405f-9051-6716ee3e0d09",
                "recordType": "FunctionalAreaInfo"
                }
         ]
        }
        const validationRule_obj1:ValidationRuleObject={
            isVR: 1,
            platformName: 'DRIVE',
            sourceProductCode : 'ACCT',
            sourceFunctionalAreaName : 'Service',
            sourceFunctionalUnitName : 'Tax Code',
            sourceFieldHeaderName: 'Code',
            condition : 'Must Exist In',
            conditionType : 'Error',
            validationMessage : 'my validation msg',
            targetProductCode : 'ACC',
            targetFunctionalAreaName: 'Account',
            targetFunctionalUnitName: 'Tax Percentage',
            targetFieldHeaderName: 'Journal',
            active: true,
            status: 'open',
            id:'77777',
            recordType:'ValidationRule'
        }
    
        const funitsOfMasterFA :any = [
            {
              "functionalUnitType": "ChildFunctionalUnit",
              "functionalUnitName": "Tax Code",
              "gridOptionsModel": {
                "columnDefs": [
                  {
                    "headerName": "Agency Type",
                    "field": "agency_type",
                    "cellEditorParams": {
                      "values": [
                        "State",
                        "Supplemental",
                        "Supplemental2",
                        "Supplemental3",
                        "Supplemental4"
                      ]
                    }
                  }
                ]
              },
              "id": "4602d541-2de2-40c1-a1bd-6892e1344224",
              "recordType": "e5e627f3-3ba6-4bc3-8959-38a60a0aea87"
            }
        ]
        component.existingValidationRule = validationRule_obj1;
        spyOn(functionalAreaService,'getFunctionalAreasByPlatformAndProductCode').and.returnValue(Observable.of(genericResponse_getFunctionalAreasByPlatformAndProductCode1));
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitsOfMasterFunctionalArea').and.returnValue(Observable.of(funitsOfMasterFA));
        component.populateSourceInformation();
        expect(component.selectedSourceFHNames.length).toEqual(1);
    });


    it('test populateSourceInformation Source Functional Unit is not configured for the Source Functional Area',()=>{
        const genericResponse_getFunctionalAreasByPlatformAndProductCode1 :any ={
            "resultCode": "CDK_200",
            "resultDescription": "OK",
            "resultObj": [
                {
                "functionalAreaType": "MasterFunctionalArea",
                "functionalAreaName": "Service",
                "id": "2205fa57-a47c-405f-9051-6716ee3e0d09",
                "recordType": "FunctionalAreaInfo"
                }
         ]
        }
        const validationRule_obj1:ValidationRuleObject={
            isVR: 1,
            platformName: 'DRIVE',
            sourceProductCode : 'ACCT',
            sourceFunctionalAreaName : 'Service',
            sourceFunctionalUnitName : 'Tax Code1',
            sourceFieldHeaderName: 'Code',
            condition : 'Must Exist In',
            conditionType : 'Error',
            validationMessage : 'my validation msg',
            targetProductCode : 'ACC',
            targetFunctionalAreaName: 'Account',
            targetFunctionalUnitName: 'Tax Percentage',
            targetFieldHeaderName: 'Journal',
            active: true,
            status: 'open',
            id:'77777',
            recordType:'ValidationRule'
        }
    
        const funitsOfMasterFA :any = [
            {
              "functionalUnitType": "ChildFunctionalUnit",
              "functionalUnitName": "Tax Code",
              "gridOptionsModel": {
                "columnDefs": [
                  {
                    "headerName": "Agency Type",
                    "field": "agency_type",
                    "cellEditorParams": {
                      "values": [
                        "State",
                        "Supplemental",
                        "Supplemental2",
                        "Supplemental3",
                        "Supplemental4"
                      ]
                    }
                  }
                ]
              },
              "id": "4602d541-2de2-40c1-a1bd-6892e1344224",
              "recordType": "e5e627f3-3ba6-4bc3-8959-38a60a0aea87"
            }
    ]
        component.existingValidationRule = validationRule_obj1;
        spyOn(functionalAreaService,'getFunctionalAreasByPlatformAndProductCode').and.returnValue(Observable.of(genericResponse_getFunctionalAreasByPlatformAndProductCode1));
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitsOfMasterFunctionalArea').and.returnValue(Observable.of(funitsOfMasterFA));
        component.populateSourceInformation();
    });



    it('test populateSourceInformation if there are no matched validation rule',()=>{

      const genericResponse_getFunctionalAreasByPlatformAndProductCode1 :any ={
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [
            {
            "functionalAreaType": "MasterFunctionalArea",
            "functionalAreaName": "Service11",
            "id": "2205fa57-a47c-405f-9051-6716ee3e0d09",
            "recordType": "FunctionalAreaInfo"
            }
     ]
     }
     const validationRule_obj1:ValidationRuleObject={
      isVR: 1,
      platformName: 'DRIVE',
      sourceProductCode : 'ACCT',
      sourceFunctionalAreaName : 'Service',
      sourceFunctionalUnitName : 'Tax Code',
      sourceFieldHeaderName: 'Code',
      condition : 'Must Exist In',
      conditionType : 'Error',
      validationMessage : 'my validation msg',
      targetProductCode : 'ACC',
      targetFunctionalAreaName: 'Account',
      targetFunctionalUnitName: 'Tax Percentage',
      targetFieldHeaderName: 'Journal',
      active: true,
      status: 'open',
      id:'77777',
      recordType:'ValidationRule'
     }
     component.existingValidationRule = validationRule_obj1;
      spyOn(functionalAreaService,'getFunctionalAreasByPlatformAndProductCode').and.returnValue(Observable.of(genericResponse_getFunctionalAreasByPlatformAndProductCode1));
      spyOn(masterFunctionalUnitService,'fetchFunctionalUnitsOfMasterFunctionalArea').and.returnValue(Observable.of(funitsOfMasterFA));
      component.populateSourceInformation();
      expect(component['toastrService'].previousToastMessage).toBe('Source Functional Area "Service" not configured for the Platform DRIVE and Source Product code ACCT');
    });

    it('test populateTargetInformation',()=>{
        const genericResponse_getFunctionalAreasByPlatformAndProductCode1 :any ={
            "resultCode": "CDK_200",
            "resultDescription": "OK",
            "resultObj": [
                {
                "functionalAreaType": "MasterFunctionalArea",
                "functionalAreaName": "Account",
                "id": "2205fa57-a47c-405f-9051-6716ee3e0d09",
                "recordType": "FunctionalAreaInfo"
                }
         ]
        }
        const validationRule_obj1:ValidationRuleObject={
            isVR: 1,
            platformName: 'DRIVE',
            sourceProductCode : 'ACCT',
            sourceFunctionalAreaName : 'Service',
            sourceFunctionalUnitName : 'Tax Code',
            sourceFieldHeaderName: 'Code',
            condition : 'Must Exist In',
            conditionType : 'Error',
            validationMessage : 'my validation msg',
            targetProductCode : 'ACC',
            targetFunctionalAreaName: 'Account',
            targetFunctionalUnitName: 'Tax Percentage',
            targetFieldHeaderName: 'Journal',
            active: true,
            status: 'open',
            id:'77777',
            recordType:'ValidationRule'
        }
    
        const funitsOfMasterFA :any = [
            {
              "functionalUnitType": "ChildFunctionalUnit",
              "functionalUnitName": "Tax Percentage",
              "gridOptionsModel": {
                "columnDefs": [
                  {
                    "headerName": "Agency Type",
                    "field": "agency_type",
                    "cellEditorParams": {
                      "values": [
                        "State",
                        "Supplemental",
                        "Supplemental2",
                        "Supplemental3",
                        "Supplemental4"
                      ]
                    }
                  }
                ]
              },
              "id": "4602d541-2de2-40c1-a1bd-6892e1344224",
              "recordType": "e5e627f3-3ba6-4bc3-8959-38a60a0aea87"
            }
    ]
        component.existingValidationRule = validationRule_obj1;
        spyOn(functionalAreaService,'getFunctionalAreasByPlatformAndProductCode').and.returnValue(Observable.of(genericResponse_getFunctionalAreasByPlatformAndProductCode1));
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitsOfMasterFunctionalArea').and.returnValue(Observable.of(funitsOfMasterFA));
        component.populateTargetInformation();
        expect(component.selectedTargetFHNames.length).toEqual(1);
       
    });

    it('test populateTargetInformation Target Functional Unit is not configured for the Target Functional Area',()=>{
        const genericResponse_getFunctionalAreasByPlatformAndProductCode1 :any ={
            "resultCode": "CDK_200",
            "resultDescription": "OK",
            "resultObj": [
                {
                "functionalAreaType": "MasterFunctionalArea",
                "functionalAreaName": "Account",
                "id": "2205fa57-a47c-405f-9051-6716ee3e0d09",
                "recordType": "FunctionalAreaInfo"
                }
         ]
        }
        const validationRule_obj1:ValidationRuleObject={
            isVR: 1,
            platformName: 'DRIVE',
            sourceProductCode : 'ACCT',
            sourceFunctionalAreaName : 'Service',
            sourceFunctionalUnitName : 'Tax Code',
            sourceFieldHeaderName: 'Code',
            condition : 'Must Exist In',
            conditionType : 'Error',
            validationMessage : 'my validation msg',
            targetProductCode : 'ACC',
            targetFunctionalAreaName: 'Account',
            targetFunctionalUnitName: 'Tax Percentage1',
            targetFieldHeaderName: 'Journal',
            active: true,
            status: 'open',
            id:'77777',
            recordType:'ValidationRule'
        }
    
        const funitsOfMasterFA :any = [
            {
              "functionalUnitType": "ChildFunctionalUnit",
              "functionalUnitName": "Tax Percentage",
              "gridOptionsModel": {
                "columnDefs": [
                  {
                    "headerName": "Agency Type",
                    "field": "agency_type",
                    "cellEditorParams": {
                      "values": [
                        "State",
                        "Supplemental",
                        "Supplemental2",
                        "Supplemental3",
                        "Supplemental4"
                      ]
                    }
                  }
                ]
              },
              "id": "4602d541-2de2-40c1-a1bd-6892e1344224",
              "recordType": "e5e627f3-3ba6-4bc3-8959-38a60a0aea87"
            }
    ]
        component.existingValidationRule = validationRule_obj1;
        spyOn(functionalAreaService,'getFunctionalAreasByPlatformAndProductCode').and.returnValue(Observable.of(genericResponse_getFunctionalAreasByPlatformAndProductCode1));
        spyOn(masterFunctionalUnitService,'fetchFunctionalUnitsOfMasterFunctionalArea').and.returnValue(Observable.of(funitsOfMasterFA));
        component.populateTargetInformation();
       
    });

     it('test populateTargetInformation if there are no matched validation rule',()=>{
      const genericResponse_getFunctionalAreasByPlatformAndProductCode1 :any ={
          "resultCode": "CDK_200",
          "resultDescription": "OK",
          "resultObj": [
              {
              "functionalAreaType": "MasterFunctionalArea",
              "functionalAreaName": "Account",
              "id": "2205fa57-a47c-405f-9051-6716ee3e0d09",
              "recordType": "FunctionalAreaInfo"
              }
       ]
      }
      const validationRule_obj1:ValidationRuleObject={
          isVR: 1,
          platformName: 'DRIVE',
          sourceProductCode : 'ACCT',
          sourceFunctionalAreaName : 'Service',
          sourceFunctionalUnitName : 'Tax Code',
          sourceFieldHeaderName: 'Code',
          condition : 'Must Exist In',
          conditionType : 'Error',
          validationMessage : 'my validation msg',
          targetProductCode : 'ACC',
          targetFunctionalAreaName: 'Service',
          targetFunctionalUnitName: 'Tax Percentage',
          targetFieldHeaderName: 'Journal',
          active: true,
          status: 'open',
          id:'77777',
          recordType:'ValidationRule'
      }
  
      const funitsOfMasterFA :any = [
          {
            "functionalUnitType": "ChildFunctionalUnit",
            "functionalUnitName": "Tax Percentage",
            "gridOptionsModel": {
              "columnDefs": [
                {
                  "headerName": "Agency Type",
                  "field": "agency_type",
                  "cellEditorParams": {
                    "values": [
                      "State",
                      "Supplemental",
                      "Supplemental2",
                      "Supplemental3",
                      "Supplemental4"
                    ]
                  }
                }
              ]
            },
            "id": "4602d541-2de2-40c1-a1bd-6892e1344224",
            "recordType": "e5e627f3-3ba6-4bc3-8959-38a60a0aea87"
          }
  ]
      component.existingValidationRule = validationRule_obj1;
      spyOn(functionalAreaService,'getFunctionalAreasByPlatformAndProductCode').and.returnValue(Observable.of(genericResponse_getFunctionalAreasByPlatformAndProductCode1));
      spyOn(masterFunctionalUnitService,'fetchFunctionalUnitsOfMasterFunctionalArea').and.returnValue(Observable.of(funitsOfMasterFA));
      component.populateTargetInformation();
      expect(component['toastrService'].previousToastMessage).toBe('Target Functional Area "Service" not configured for the Platform DRIVE and Target Product code ACC');
  }); 

  });
});


