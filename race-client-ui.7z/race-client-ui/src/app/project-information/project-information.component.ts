
import {forkJoin as observableForkJoin, interval as observableInterval } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material';

import { ProjectService } from '../services/project-service';
import { StoreService } from '../services/store-service';
import { FunctionalAreaService } from '../services/functional-area-service';
import { AuthService } from '../services/auth-service';

import { ProjectObject } from '../model/project-object';
import { StoreObject } from '../model/store-object';
import { TemplateObject } from '../model/template-object';
import { PlatformObject } from '../model/platform-object'

import { AddStoreComponent } from '../add-store/add-store-dialog.component';
import { ModifyVICComponent } from '../modify-vic/modify-vic.component';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { SSSObject } from '../model/sss-object';
import { BestPracticeService } from '../services/bestpractice-service';
import { Constants } from '../constant/constants';
import { ToastrService } from 'ngx-toastr'; 

@Component({
  selector: 'app-project-information',
  templateUrl: './project-information.component.html',
  styleUrls: ['./project-information.component.css']
})
export class ProjectInformationComponent implements OnInit, OnDestroy {

  projectObject: ProjectObject = new ProjectObject();
  projectObjectCopy: ProjectObject = new ProjectObject();
  sssObject: SSSObject = new SSSObject();
  storeFunctionalAreaContext = {};
  dotVICUserList = {};
  
  assignUserPermission = false;
  addStorePermission = false;
  editProjectPermission = false;
  createProjectPermission = false;  
  adminPermission = false;
  deleteStorePermission = false;
  
  managerList : any [];
  hasEnterpriseStore : boolean;
  managerListFiltered : any [];  
  storesReceived = false;
  currentStatus : string;
  storesList : StoreObject[]=[];
  storesListCopy : StoreObject[]=[];  
  timer = observableInterval(60 * 1000);
  subscription :any;  
  isDealerDivVisible :boolean=false;
  dealerApproverList:any [];
  dealerApproverListFiltered : any [];  
  CDKU_Coordinators :any[];
  countries:any[];
  CDKU_Domains :any[];
  CDKU_Logins :any[];
  Project_Env :any[];
  languages :any[];
  timezones :any[];
  projectStatus:any[];
  addStore : boolean;
  date : Date = new Date();

  constructor(private projectService: ProjectService, private storeService: StoreService, private functionalAreaService: FunctionalAreaService,
          private authService: AuthService, private route : ActivatedRoute, private dialog: MatDialog, private router: Router,
          private bestPracticeService: BestPracticeService, private toastrService: ToastrService) {
      this.projectObject.platform = new PlatformObject();
      this.projectObject.storeIds = [];
      this.projectObject.isProject = 1;
      this.currentStatus = this.projectObject.status;

      this.CDKU_Coordinators = Constants.CDKU_COORDINATORS;
      this.countries=Constants.COUNTRIES;
      this.CDKU_Domains=Constants.CDKU_DOMAINS;
      this.CDKU_Logins=Constants.CDKU_LOGINS;
      this.timezones=Constants.TIMEZONES;
      this.Project_Env=Constants.PROJECT_ENV;
      this.languages=Constants.LANGUAGES;
      this.projectStatus=Constants.PROJECT_STATUS;
      this.addStore = false;
  }

  ngOnInit() {
      this.subscription = this.timer.subscribe(()=> {
    	  this.autoUpdateFunctionalAreaStatus();
      });
      
      this.authService.fetchLoggedInUserAndPermissions().subscribe(() => {
    	  this.getProjectInformation('Fetching project Information.');
    	  
    	  this.authService.fetchCommonServicesUsersWithDotVICRole().subscribe((data: any) => {
              data.forEach(user => {
                  this.dotVICUserList[user.user.loginId] = user.user.firstName + ' ' + user.user.lastName;
              });
          });
          this.authService.fetchCommonServicesUsersWithManagerRole().subscribe((data: any) => {
        	  this.managerList = data;
        	  this.managerListFiltered = this.managerList;  
          });
          
    	  this.assignUserPermission = this.authService.isAuthorised('DOT_ASSIGN_USERS');
    	  this.adminPermission = this.authService.isAuthorised('DOT_ADMIN');
    	  this.deleteStorePermission = this.adminPermission || this.authService.checkIfLoggedInUserIsProjectManager(this.projectObject);
    	  this.createProjectPermission = this.adminPermission || this.authService.isAuthorised('DOT_PROJECT_CREATE'); 
    	  this.addStorePermission = this.adminPermission || this.authService.isAuthorised('DOT_STORE_CREATE');
    	  this.editProjectPermission = this.adminPermission || this.authService.isAuthorised('DOT_PROJECT_UPDATE');
      });
  }
  
  
  getProjectInformation(loaderMessage: string) {
      let loaderDialogRef;
      if (loaderMessage) {
          loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
              width: '300px',
              height: '150px',
              data: { message: loaderMessage }
          });
      }
      this.projectService.getProjectByNumber(this.route.snapshot.params.name)
  	  .subscribe(
  	      project => {
  	    	  this.projectObject = project;
                this.currentStatus = this.projectObject.status;
                if(this.projectObject.projectSourceEnv=="DASH"){
                    this.isDealerDivVisible=true;
                    this.fetchDealerApproverUserList();
                }
  	    	  this.projectObjectCopy = Object.assign({}, this.projectObject);
  	    	  this.getStoresOfProject(loaderDialogRef);
      }, error=> {
            this.toastrService.error('got error' + error);
            loaderDialogRef.close();
      });
  }
  
  private getStoresOfProject(loaderDialogRef: any) {
	  this.projectService.getStoresOfProject(this.projectObject.id)
	  .subscribe(stores => {
		  this.storesReceived = true;
          this.storesList = stores;
          this.storesListCopy = JSON.parse(JSON.stringify(this.storesList))
          this.storesList.forEach(store =>{
        	  if(store.enterpriseStore){
        		  this.hasEnterpriseStore=true;
        	  }
          });
          if (loaderDialogRef) {
              loaderDialogRef.close();
          }
          this.storesList.sort(function(s1,s2) {
        	  return (s1.enterpriseStore === s2.enterpriseStore)? 0 : s1.enterpriseStore? -1 : 1;
          });
          this.getFunctionalAreasOfStore(this.storesList);
	  }, () => {
		  loaderDialogRef.close();
	  });
  }
  
  private getFunctionalAreasOfStore(stores: any[]) {
    let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
        width: '300px',
        height: '150px',
        data: { message: "Fetching functional area details." }
    });
	  let storeIds: string[] = stores.map(store => store.recordType);
  	  let requests = []; 
	  if(storeIds != null && storeIds.length > 0) {
		  storeIds.forEach(storeId => {
			  requests.push(this.storeService.getFunctionalAreasOfStore(storeId));
		  });
		  observableForkJoin(requests)
		  .subscribe(data => {
			  if(storeIds.length === data.length) {
				  storeIds.forEach(storeId => {
					  this.storeFunctionalAreaContext[storeId] = data[storeIds.indexOf(storeId)];
				  });
			  }
			  loaderDialogRef.close();
		  }, ()=> {
			  this.toastrService.warning('Error occurred while saving store.');
			  loaderDialogRef.close();
		  });
	  } else {
		  loaderDialogRef.close();
	  }
  }
    
  ngOnDestroy() {
      this.subscription.unsubscribe();
  }
  
//=======dash Import==========
showDealerDiv(event){
     
    if(event.checked){
     this.isDealerDivVisible=true;
     this.fetchDealerApproverUserList();
    }else{
     this.isDealerDivVisible=false;
     this.projectObject.dealerApproverContact="";
     this.projectObject.dealerApproverRequired=false;
     this.dealerApproverListFiltered=[];
     this.dealerApproverList =[];
    }
}
      
fetchDealerApproverUserList(){
    this.authService.fetchCommonServicesUsersWithDealerApproverRole(this.projectObject.enterpriseId).subscribe((data: any) => {
   this.dealerApproverList = data;
   this.dealerApproverListFiltered = this.dealerApproverList;  
        });
}

//=======dash Import==========

  selectNewStatus(event : any) {
      this.projectObject.status = event.value;
  }
      
  applyPMFilter(value: string) {
	  if (value.trim()) {
		  this.managerListFiltered = Object.assign([], this.managerList).filter(
		      item => item.user.loginId.toLowerCase().indexOf(value.toLowerCase()) > -1
		  );
	  }
	  value = "";
  }
    
  onFocusReloadPMs() {
	  this.managerListFiltered = Object.assign([], this.managerList);
  }  
    
  iconColor(status: string) {
      status = status != null && status != '' ? status : 'Work in Progress'; 
      let style = {'color':'white'};
      if(status === 'OPEN' || status === 'Open' || status === 'Work in Progress') {
          style = {'color':'yellow'};
      } else if(status === 'Transfer to DMS successful') {
          style = {'color':'green'};
      }  else if(status === 'Validation Done' || status === 'Request Approved by Dealer') {
          style = {'color':'blue'};
      }  else if(status === 'Sent to DMS' || status === 'Request Dealer for Approval' ) {
          style = {'color':'orange'};
      } else if(status === 'Validation in Progress') {
          style = {'color':'gray'};
      } else if(status === 'Validation Failed' || status === 'Transfer to DMS failed' || status === 'Request Cancelled by Dealer' ) {
          style = {'color':'red'};
      }
      return style;
  }
  
  openDialogToAddStore(storeRecordType: string) {
    this.addStore = false;
    if(storeRecordType == null){
        if(this.storesList.length != 0){
        this.date = this.storesList[0].lastUpdatedDate;
            this.storesList.forEach(store => {
              if(store.lastUpdatedDate >= this.date){
                  this.date = store.lastUpdatedDate;
                   storeRecordType = store.recordType;
                  this.addStore = true;
              }
            })
        }
      }

      let dialogRef = this.dialog.open(AddStoreComponent, {
          width: '60%',
          height: '80%',
          data: {
            project: this.projectObject,
            storeRecordType: storeRecordType,
            hasEnterpriseStore : this.hasEnterpriseStore,
            addStorePermission : this.addStorePermission,
            addStore : this.addStore
          }
      }); 
      
      dialogRef.afterClosed().subscribe(result => {
          if(result !=Constants.POPUP_CANCEL)
            this.getProjectInformation('Updating project Information.');
      });
  
    }

  editStore(storeName: string) {
    this.openDialogToAddStore(storeName);
  }
  
  cloneStore(store : StoreObject){
  	let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
          width: '300px',
          height: '150px',
          data: { message: 'Cloning Store...' }
      });
      this.storeService.cloneStore(store.id, store.recordType)
      .subscribe(() => {
    	  loaderDialogRef.close();
    	  this.getProjectInformation('Fetching updated Project Information.');
      });
  }
  
  deleteProject(projectObject : ProjectObject){
	  let confirmDialogRef = this.dialog.open(ConfirmDialogComponent, {
          width: '300px',
          height: '160px',
          data: { message: 'Are you sure you want to delete this Project ?' }
      });
	  confirmDialogRef.afterClosed().subscribe(result => {
          if (result) {
      	  	let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
  	          width: '300px',
  	          height: '150px',
  	          data: { message: 'Deleting Project...' }
  	      });
  	      this.projectService.deleteProject(projectObject)
  	        .subscribe(() => {
  	        	loaderDialogRef.close();
  	        	this.router.navigateByUrl('dashboard');
  	        });
          }
      });
  }
  
  deleteStore(store : StoreObject){
	  let confirmDialogRef = this.dialog.open(ConfirmDialogComponent, {
          width: '300px',
          height: '160px',
          data: { message: 'Are you sure you want to delete this Store ?' }
      });
	  confirmDialogRef.afterClosed().subscribe(result => {
          if (result) {
      	  	let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
  	          width: '300px',
  	          height: '150px',
  	          data: { message: 'Deleting Store...' }
  	      });
  	      this.storeService.deleteStore(store)
  	        .subscribe(() => {
  	            loaderDialogRef.close();
  	            this.getProjectInformation('Fetching updated Project Information.');
  	        });
          }
      });
  }

  openDialogToModifyVIC(storeObj:StoreObject) {
    let dialogRef = this.dialog.open(ModifyVICComponent, {
        width: '60%',
        height: '80%',
        data: {
          project: this.projectObject,
          storeObj: storeObj,
          addStorePermission : this.addStorePermission     
                  
        }
    }); 
    
    dialogRef.afterClosed().subscribe(result => {
        if(result !== Constants.POPUP_CANCEL)
          this.getProjectInformation('Updating project Information.');
    });
}

  modifyVIC(store: StoreObject){
    this.openDialogToModifyVIC(store);
  }
 
  updateProject() {
      let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
          width: '300px',
          height: '150px',
          data: { message: 'Updating Project ...' }
      });

      let counter=0;
      let req : ProjectObject =new ProjectObject();
      req=this.projectObject;
      let fieldMessageMap = {
    		  projectNumber: "Project Number",
    		  enterpriseId: "Enterprise Id",
    		  dealerName: "Dealer Name",
    		  cmfNumber: "CMF Number",
    		  ipAddress: "IP Address",
    		  dmsCNumber: "DMS C#",
    		  url: "URL",
    		  status: "Status",
    		  clientManager: "Client Manager",
    		  vic: "VIC",
    		  css: "CSS",
    		  projectManager: "Project Manager",
    		  clientProjectAdvocate: "Client Project Advocate"
      };
      
      if(this.isDealerDivVisible==true){
        req.projectSourceEnv="DASH";
      }else{
        req.projectSourceEnv="";
        req.dealerApproverContact="";
        req.dealerApproverRequired=false;
      }

      this.projectService.createProject(req)
      .subscribe(latestProjectFromDb => {
          this.currentStatus = latestProjectFromDb.status;
          if(latestProjectFromDb.failed){
        	  counter++;
        	  let taskDone =false;
        	  let differences=[];
        	  Object.getOwnPropertyNames(fieldMessageMap).forEach(fieldName => {
        		  if(latestProjectFromDb[fieldName] !== req[fieldName]){
            			differences.push(fieldMessageMap[fieldName]);
        		  }
        	  });
        	  if (confirm("Some other user also have updated project data ["+ differences.toString() + "]. Click 'OK' to keep your data  or 'Cancel' to override your data")) {
        		  this.projectObject=req;
           		  this.projectObject.version=latestProjectFromDb.version;
           		  taskDone=true;
              } else{
            	  this.projectObject=latestProjectFromDb;
                  taskDone=true;
              }
              if(counter<=1 && taskDone===true) {
            	  this.updateProject();
              }
          }
          this.projectObject.version=latestProjectFromDb.version;
          this.projectObjectCopy = Object.assign({}, this.projectObject);
          loaderDialogRef.close();
      });
  }
  
  getFunctionalArea(functionalAreaId : string, storeId : string, enterpriseStore: string) {
      this.router.navigate(['projects/' + this.projectObject.projectNumber + '/stores/' + storeId + 
                            '/functionalAreas/' + functionalAreaId + '/' + enterpriseStore]);
  }

  getSSSDetails(functionalArea : TemplateObject ,store:StoreObject){
    this.sssObject.isStateStandardDialog=true;
    this.sssObject.sssVersion=functionalArea.stateStandardVersionName;
    this.sssObject.sssFaName=functionalArea.functionalAreaName;
    this.sssObject.sssStore=store.storeName;
    this.sssObject.sssName=functionalArea.stateStandardName;
    this.sssObject.projectNumber=this.projectObject.projectNumber;
    this.sssObject.stateStandardVersionRecordType=functionalArea.stateStandardVersionRecordType;
    this.bestPracticeService.getFunctionalAreasOfBpVersion(functionalArea.stateStandardVersionRecordType, true).subscribe(templates => {
        templates.forEach(template => {
          this.sssObject.sssFAId=template.recordType;
          sessionStorage.setItem("sssObject",JSON.stringify(this.sssObject));
          this.router.navigate(['sss/true']);
        });
      },
      ()=>{
            this.toastrService.warning("Error in fetching Best Practice details. Please try later.");
      });
 }
    
  getVicName(functionalArea: any) {
	  if (functionalArea.vic && functionalArea.vic.loginId) {
		  return this.dotVICUserList[functionalArea.vic.loginId];
	  }
	  return "";
  }
    
  getSecondaryVicName(functionalArea: any) {
	  if (functionalArea.secondaryVic && functionalArea.secondaryVic.loginId) {
		  return this.dotVICUserList[functionalArea.secondaryVic.loginId];
      }
      return "";
  }
  
  navigateToLink(url: string) {
	  if (!this.jsonEqual(this.projectObjectCopy, this.projectObject)) {
          if (confirm("You have unsaved data on this page. Click 'OK' to continue , or  'Cancel' to stay on this page")) {
              this.router.navigateByUrl(url);
          }
      } else {
          this.router.navigateByUrl(url);
      }
  }
    
  jsonEqual(a, b) {
	  return JSON.stringify(a) === JSON.stringify(b);
  }
      
  autoUpdateFunctionalAreaStatus() {
	  let functionalAreaList = [];
	  let refreshableStatuses = ['Validation in Progress', 'Sent to DMS'];
	  let storeFunctionalAreaContext = this.storeFunctionalAreaContext;
	  Object.getOwnPropertyNames(storeFunctionalAreaContext).forEach(storeId => {
	      functionalAreaList = functionalAreaList.concat(storeFunctionalAreaContext[storeId].filter(functionalArea => {
			  return refreshableStatuses.indexOf(functionalArea.status) > -1;
		  }));
	  });
	  
	  if(functionalAreaList.length > 0) {
		  let requests: any[] = [];
	  	  functionalAreaList.forEach(functionalArea => {
	  		  requests.push(this.functionalAreaService.getFunctionalAreaById(functionalArea.id, functionalArea.recordType));
	  	  });
	  	  observableForkJoin(requests)
		  .subscribe(responses => {
			  if(requests.length === responses.length) {
                  let templateList:any[] = responses;
                  templateList.forEach((template, index) => {
                  functionalAreaList[index].status = template.status;
                 functionalAreaList[index].lastUpdatedDate = template.lastUpdatedDate;
			   });
			  }
		  });
	  }
  }
    
  functionalAreaContentClass(isFirst: any, isLast: any) {
	  let functionalAreaContentClass = 'pt-2 pb-2';
	  if(isFirst && !isLast) {
		  functionalAreaContentClass = 'pb-2';
	  } else if(!isFirst && isLast) {
		  functionalAreaContentClass = 'pt-2';
	  } else if(isFirst && isLast) {
		  functionalAreaContentClass = '';
	  }
	  return functionalAreaContentClass;
  }
}