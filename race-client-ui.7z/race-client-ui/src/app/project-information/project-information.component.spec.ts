import { CdkTableModule } from '@angular/cdk/table';
import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatDialogRef, MatDividerModule, MatFormFieldModule, MatInputModule, MatListModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatSidenavModule, MatStepperModule, MatTableModule, MAT_DIALOG_DATA } from '@angular/material';
import { By } from '@angular/platform-browser';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router, RouterModule } from '@angular/router';
import { SetLeftFeature } from 'ag-grid';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { of } from 'rxjs';
import { Observable } from 'rxjs';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { ProjectObject } from '../model/project-object';
import { StoreObject } from '../model/store-object';
import { TemplateObject } from '../model/template-object';
import { AuthService } from '../services/auth-service';
import { BestPracticeService } from '../services/bestpractice-service';
import { FunctionalAreaService } from '../services/functional-area-service';
import { ProjectService } from '../services/project-service';
import { StoreService } from '../services/store-service';
import { ProjectInformationComponent } from './project-information.component';
import {interval as observableInterval } from 'rxjs';

describe('ProjectInformationComponent', () => {

    let component : ProjectInformationComponent;
    let fixture: ComponentFixture<ProjectInformationComponent>;
    let authService: AuthService;
    let projectService: ProjectService;
    let storeService: StoreService;
    let functionalAreaService: FunctionalAreaService;
    let bestPracticeService: BestPracticeService;
    let router : Router;
    let routerStub: Router;
    let h1: HTMLElement;

    class MatDialogMock {
      open() {
        return {
          afterClosed: () => Observable.of(true)
        };
      }
    };

    const testUrl = 'dashboard';
    beforeEach(async(() => {

        let mockRouter = {
           navigate: jasmine.createSpy('navigateByUrl')
       } 
       const dialogMock = {
        close: () => { }
      };

      const data={}

       const masterFunctionalAreaServiceSpy = jasmine.createSpyObj('MasterFunctionalAreaService', 
       ['fetchMasterFunctionalAreaList','deleteMasterFunctionalArea']);


        TestBed.configureTestingModule({
          imports: [
            MatStepperModule,
            MatProgressSpinnerModule,
            MatMenuModule,
            MatDividerModule,
            FormsModule,
            MatCardModule,
            FormsModule,
            MatFormFieldModule,
            MatInputModule,
            CdkTableModule,
            MatMenuModule,
            MatTableModule,
            MatPaginatorModule,
            MatDialogModule,
            HttpClientTestingModule,
            ToastrModule.forRoot(),
            RouterModule.forRoot([]),
            NoopAnimationsModule,
            ReactiveFormsModule,
            CommonModule,
            MatSelectModule,
            MatRadioModule,
            MatCheckboxModule,
            MatSidenavModule,
            MatListModule],
          declarations: [ ProjectInformationComponent,LoaderDialogueComponent,ConfirmDialogComponent],
          providers:[
            ProjectService,
            StoreService,
            FunctionalAreaService,
            BestPracticeService,
            AuthService,
           ToastrService,
           { provide: MAT_DIALOG_DATA, useValue: data },
           {provide: MatDialogRef, useValue: MatDialogMock},
          ]
        }).overrideModule(BrowserDynamicTestingModule,
           { set: { entryComponents: [LoaderDialogueComponent,ConfirmDialogComponent]}});

            authService = TestBed.get(AuthService);
            projectService = TestBed.get(ProjectService);
            storeService = TestBed.get(StoreService);
            routerStub  = TestBed.get(Router);
            functionalAreaService = TestBed.get(FunctionalAreaService);
            bestPracticeService = TestBed.get(BestPracticeService);

            fixture = TestBed.createComponent(ProjectInformationComponent);
            component = fixture.componentInstance; 
      }));
    const projectByProjectNumber:ProjectObject = {

      "isProject": 1,
      "enterpriseId": "E218665",
      "projectNumber": "889864",
      "dealerName": "EAGLE RIVER MOTORS",
      "location": null,
      "platform": {
        "platformName": "FLEX",
        "platformCode": "flex",
        "selected": false
      },
      "storeIds":null,
      "status": "OPEN",
      "clientManager": null,
      "vic": null,
      "css": null,
      "projectManager": null,
      "language": "en_US",
      "country": "United States",
      "timezone": "UTC-6: Central Standard Time (CST)",
      "cdku": false,
      "cdku_coordinator": null,
      "cdku_domain": null,
      "cdku_division": null,
      "cdku_login": null,
      "cdku_password": null,
      "clientProjectAdvocate": null,
      "version": 9,
      "failed": false,
      "projectSourceEnv": "DASH",
      "dealerApproverContact": null,
      "dealerApproverRequired": false,
      "createdDate": null,
      "lastUpdatedDate": null,
      "createdBy": null,
      "updatedBy": "terry.campbell@cdk.com",
      "id": "f606e381-ea3a-40c6-9340-afe65fe21498",
      "recordType": "ProjectInfo"
    }
    
    const dealerApprovalRole :any={
      "totalMatches": 0,
      "users": null
    }

    const storesList: any=[
      {
        "storeName": "EAGLE RIVER MOTORS",
        "enterpriseStore": false,
        "storeNumber": "01",
        "id": "f606e381-ea3a-40c6-9340-afe65fe21498",
        "recordType": "03d23794-0ea6-41a9-8519-393739b9e9dc",
        "lastUpdatedDate":"2021-05-26T11:48:29.834+0000"
      },
      {
        "storeName": "EAGLE 2",
        "enterpriseStore": true,
        "storeNumber": null,
        "id": "f606e381-ea3a-40c6-9340-afe65fe21498",
        "recordType": "692b1762-5e44-4141-8e5a-1f26ba6fd831",
        "lastUpdatedDate":"2021-06-26T11:48:29.834+0000"
      },
      {
        "storeName": "Test sales",
        "enterpriseStore": false,
        "storeNumber": "01",
        "id": "f606e381-ea3a-40c6-9340-afe65fe21498",
        "recordType": "e83daa0f-804f-4817-80d9-31a535c3124f",
        "lastUpdatedDate":"2021-07-26T11:48:29.834+0000"
      }
    ]

    const functionalArea: TemplateObject={
      "functionalAreaName": "Parts",
      "functionalAreaType": null,
      "oemName": null,
      "clientSignoffDate": null,
      "selected": false,
      "status": "Work in Progress",
      "platforms": [
        {
          "platformName": "FLEX",
          "platformCode": "flex",
          "selected": true
        }
      ],
      "vic": null,
      "secondaryVic": null,
      "clientFunctionalAreaUser": null,
      "version": 43,
      "isFailed": null,
      "inProcess": false,
      "productCode": "PTS",
      "productVersion": null,
      "bpId": "63f38af3-92e3-4509-81b5-c59365cc7df1",
      "bpVersionId": "70766cde-1b7b-46b1-9c73-a8adf96ceac8",
      "bpTemplateId": "46675d78-a8d5-41ca-8801-c679ef00cff4",
      "isDealerApproved": false,
      "stateStandardId": null,
      "stateStandardName": null,
      "stateStandardVersionRecordType": null,
      "stateStandardVersionName": null,
      "copyRowData": false,
      "showValidateOrTransferButton": false,
      "showProcessValidationResultsButton": true,
      "createdDate": null,
      "lastUpdatedDate": null,
      "screenIds":null,
      "createdBy": null,
      "updatedBy": "Harika.Gajabimkar@cdk.com",
      "incorporateBpChanges": false,
      "isLocked":false,
      "storeId":null,
      "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
      "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
    }

    const functionalAreaOfBPVersion:any[]=[
      {
          "functionalAreaName": "FA_color",
          "functionalAreaType": "BestPracticeFunctionalArea",
          "oemName": null,
          "clientSignoffDate": null,
          "selected": false,
          "status": "Work in Progress",
          "platforms": [
            {
              "id": null,
              "platformName": "FLEX",
              "platformCode": "flex",
              "selected": true
            }
          ],
          "vic": null,
          "secondaryVic": null,
          "clientFunctionalAreaUser": null,
          "version": 0,
          "isFailed": null,
          "inProcess": false,
          "productCode": "PTS",
          "productVersion": "check",
          "masterFAId": "acd18aa6-8eed-456e-b266-c7e3e095c467",
          "bpId": "266a92e4-6e58-421b-a93c-fdbb389090c5",
          "bpVersionId": null,
          "bpTemplateId": null,
          "isDealerApproved": false,
          "stateStandardId": null,
          "stateStandardName": null,
          "stateStandardVersionRecordType": null,
          "stateStandardVersionName": null,
          "copyRowData": false,
          "showValidateOrTransferButton": false,
          "showProcessValidationResultsButton": true,
          "createdDate": null,
          "lastUpdatedDate": null,
          "createdBy": null,
          "updatedBy": null,
          "incorporateBpChanges": false,
          "locked": false,
          "id": "3812951d-983c-4894-b26a-c84b00bb5bec",
          "recordType": "edda3022-7bc5-4844-9cf7-ea772d6533ca"
        }
  ]

    const storeObject: StoreObject={
    	"storeId" : "S000000000",	
        "storeName": "SWANSON FAHRNEY FORD",
        "streetAddress": "3105 HIGHLAND AVE",
        "city": "SELMA",
        "province": "California",
        "zipcode": "93662",
        "templateIds":null,
        "projectId":'123',
        "glCompanyNumber": "5",
        "logonName": "FF-FI",
        "sharedLogonName": null,
        "clientStoreAdvocate": null,
        "language": "en_US",
        "country": "United States",
        "timezone": "UTC-6: Central Standard Time (CST)",
        "cdku_coordinator": null,
        "oem": null,
        "businessPhone": null,
        "enterpriseStore": false,
        "ipAddress": "207.187.74.84",
        "dmsCNumber": "C208605",
        "cmfNumber": "05236540",
        "url": null,
        "storeNumber": null,
        "createdDate": null,
        "lastUpdatedDate": null,
        "createdBy": "Ravi.Musinada@cdk.com",
        "updatedBy": "Ravi.Musinada@cdk.com",
        "locked": false,
        "id": "d6111967-f46e-4bf1-99f7-d877f8655872",
        "recordType": "26573770-757a-42c3-8e11-307f6e8051ac"

    }

    const functionalAreasList : TemplateObject[]=[

      {
        "functionalAreaName": "Parts",
        "functionalAreaType": null,
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Work in Progress",
        "platforms": [
          {
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true
          }
        ],
        "vic": null,
        "secondaryVic": null,
        "clientFunctionalAreaUser": null,
        "version": 43,
        "isFailed": null,
        "inProcess": false,
        "productCode": "PTS",
        "productVersion": null,
        "bpId": "63f38af3-92e3-4509-81b5-c59365cc7df1",
        "bpVersionId": "70766cde-1b7b-46b1-9c73-a8adf96ceac8",
        "bpTemplateId": "46675d78-a8d5-41ca-8801-c679ef00cff4",
        "isDealerApproved": false,
        "stateStandardId": null,
        "stateStandardName": null,
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": false,
        "showValidateOrTransferButton": false,
        "showProcessValidationResultsButton": true,
        "createdDate": null,
        "lastUpdatedDate": null,
        "screenIds":null,
        "createdBy": null,
        "updatedBy": "Harika.Gajabimkar@cdk.com",
        "incorporateBpChanges": false,
        "isLocked":false,
        "storeId":null,
        "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
        "recordType": "03ec6ff3-6af3-46dc-b6a1-ab1f74e74208"
      },
      {
        "functionalAreaName": "Accounting",
        "functionalAreaType": null,
        "oemName": null,
        "clientSignoffDate": null,
        "selected": false,
        "status": "Work in Progress",
        "platforms": [
          {
            "platformName": "FLEX",
            "platformCode": "flex",
            "selected": true
          }
        ],
        "vic": null,
        "secondaryVic": null,
        "clientFunctionalAreaUser": null,
        "version": 26,
        "isFailed": null,
        "inProcess": false,
        "productCode": "ACCT",
        "productVersion": null,
        "bpId": "63f38af3-92e3-4509-81b5-c59365cc7df1",
        "bpVersionId": "70766cde-1b7b-46b1-9c73-a8adf96ceac8",
        "bpTemplateId": "595e4b72-5b2f-4d1f-8d1b-54041ad32886",
        "isDealerApproved": false,
        "stateStandardId": null,
        "stateStandardName": null,
        "stateStandardVersionRecordType": null,
        "stateStandardVersionName": null,
        "copyRowData": false,
        "showValidateOrTransferButton": true,
        "showProcessValidationResultsButton": false,
        "createdDate": null,
        "lastUpdatedDate": null,
        "createdBy": null,
        "updatedBy": "Sagar.Aitla@cdk.com",
        "incorporateBpChanges": false,
        "screenIds":null,
        "isLocked":false,
        "storeId":null,
        "id": "03d23794-0ea6-41a9-8519-393739b9e9dc",
        "recordType": "5a5e175f-276f-47a5-ae44-3c44273392ac"
      }
    ]

    it('test ngOnit',()=>{
     let data : any[] = [
        {
          user:{
            user:{
              loginId:'sagar aitla',
              firstName:'sagar',
              lastName:'aitla'
            }
          }
        }
     ];
     let data1:any[]=[
       {
         user:{
           firstName:'testFirst',
           lastName:'testLast'
         }
       }
     ]
     spyOn(component,'timer').and.returnValue(Observable.of({}))
     spyOn(component,'autoUpdateFunctionalAreaStatus')
     spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of({}));
     spyOn(component,'getProjectInformation');
     spyOn(authService,'fetchCommonServicesUsersWithDotVICRole').and.returnValue(Observable.of(data));
     spyOn(authService,'fetchCommonServicesUsersWithManagerRole').and.returnValue(Observable.of(data1))
     component.ngOnInit();
    });

    it('should create Project Information Component',()=>{
        expect(component).toBeTruthy();
    });

    it('test label value',()=>{
        let labelName = fixture.debugElement.query(By.css("label[class=content-header]"));
        expect(labelName.nativeElement.outerText).toEqual('Project Number');  
    });
    
    it('test getProjectInformation',()=>{

      spyOn(projectService,'getProjectByNumber').and.returnValue(Observable.of(projectByProjectNumber));
      spyOn(component,'fetchDealerApproverUserList');  
      spyOn(projectService,'getStoresOfProject').and.returnValue(Observable.of(storesList));
      spyOn(storeService,'getFunctionalAreasOfStore').and.returnValue(Observable.of(functionalAreasList));
      component.getProjectInformation("Fetching Project Information");
      expect(projectService.getStoresOfProject).toHaveBeenCalledTimes(1);
      expect(storeService.getFunctionalAreasOfStore).toHaveBeenCalledTimes(3);
    });

    it('test getProjectInformation in case of error',()=>{

        spyOn(projectService,'getProjectByNumber').and.returnValue(Observable.throw('error'));
        component.getProjectInformation("Fetching Project Information");
        expect(projectService.getProjectByNumber).toHaveBeenCalledTimes(1);
       
    });

    it('test showDealerDiv',()=>{

        let event:any={
            checked:false
         };
        component.showDealerDiv(event);
        expect(component.projectObject.dealerApproverRequired).toBeFalsy();

        let event1:any={
            checked:true
         };
        spyOn(component,'fetchDealerApproverUserList');
        component.showDealerDiv(event1);
        expect(component.isDealerDivVisible).toBeTruthy();
    });

    it('test fetchDealerApproverUserList',()=>{
        spyOn(authService,'fetchCommonServicesUsersWithDealerApproverRole').and.returnValue(Observable.of(dealerApprovalRole));
        component.fetchDealerApproverUserList();
        expect(authService.fetchCommonServicesUsersWithDealerApproverRole).toHaveBeenCalledTimes(1);
    });
     
    it('test iconColor',()=>{

        let status:string;
        status = 'OPEN';
        let style = component.iconColor(status);
        expect(style.color).toEqual('yellow');

        let status1:string;
        status1= 'Transfer to DMS successful';
        let style1= component.iconColor(status1);
        expect(style1.color).toEqual('green');

        let status2:string;
        status2= 'Validation Done';
        let style2= component.iconColor(status2);
        expect(style2.color).toEqual('blue');

        let status3:string;
        status3= 'Sent to DMS';
        let style3= component.iconColor(status3);
        expect(style3.color).toEqual('orange');

        let status4:string;
        status4= 'Validation in Progress';
        let style4= component.iconColor(status4);
        expect(style4.color).toEqual('gray');
        
        let status5:string;
        status5= 'Validation Failed';
        let style5 = component.iconColor(status5);
        expect(style5.color).toEqual('red');
    });

    it('test selectNewStatus',()=>{
       let event:any={
         value:'OPEN'
       }
       component.selectNewStatus(event);
       expect(component.projectObject.status).toEqual('OPEN');
    });

    it('test applyPMFilter',()=>{
      let managerList : any=[
        {
          user:{
            
              loginId:'Sagar'
          }
        }
      ];
      component.managerList = managerList;
      component.applyPMFilter("Sagar");
     
      
    });

    it('test functionalAreaContentClass',()=>{
      let result = component.functionalAreaContentClass(true,true);
      expect(result).toEqual('');
      let result1 = component.functionalAreaContentClass(false,true);
      expect(result1).toEqual('pt-2');
      let result2 = component.functionalAreaContentClass(true,false);
      expect(result2).toEqual('pb-2');
  });

  
  it('test getSecondaryVicName',()=>{
    let functionalArea: any={
      secondaryVic  :{
         loginId:"sagar.aitla@cdk.com"
       }
    }
    component.getSecondaryVicName(functionalArea);
    expect(component.dotVICUserList).toEqual({});     
  })

  it('test getSecondaryVicName if fa is null',()=>{
    let functionalArea: any={
      secondaryVic  :{}
    }
    let result =  component.getSecondaryVicName(functionalArea);
    expect(result).toBe("")     
  })

   it('test getVicName',()=>{
     let functionalArea: any={
        vic :{
          loginId:"sagar.aitla@cdk.com"
        }
     }
     component.getVicName(functionalArea);
     expect(component.dotVICUserList).toEqual({});     
   })

   
   it('test getVicName  if fa is null',()=>{
    let functionalArea: any={
      vic :{}
   }
    let result = component.getVicName(functionalArea);
    expect(result).toBe("")
  })

   it('test getSSSDetails',()=>{
      spyOn(routerStub, 'navigate');
      spyOn(bestPracticeService,'getFunctionalAreasOfBpVersion').and.returnValue(Observable.of(functionalAreaOfBPVersion));
      component.getSSSDetails(functionalArea,storeObject);
      expect(routerStub.navigate).toHaveBeenCalledWith(['sss/true']);
   });

   it('test getSSSDetails api throw error',()=>{
    spyOn(bestPracticeService,'getFunctionalAreasOfBpVersion').and.returnValue(Observable.throwError('error'));
    component.getSSSDetails(functionalArea,storeObject);
    expect(component['toastrService'].previousToastMessage).toBe('Error in fetching Best Practice details. Please try later.')
 });

   it('test getFunctionalArea',()=>{
    spyOn(routerStub, 'navigate');
    component.projectObject = projectByProjectNumber;
    component.getFunctionalArea("fa123","firstStore",'111');
    expect(routerStub.navigate).toHaveBeenCalledWith(['projects/889864/stores/firstStore/functionalAreas/fa123/111']);
 });


 it('test cloneStore',()=>{
   spyOn(component,'getProjectInformation');
   spyOn(storeService,'cloneStore').and.returnValue(Observable.of({}));
   component.cloneStore(storeObject);

 });
  
it('test openDialogToAddStore',()=>{

  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

  spyOn(component,'getProjectInformation')
  component.openDialogToAddStore("test_store");
  expect(component.getProjectInformation).toHaveBeenCalled();

});

it('test openDialogToAddStore New',()=>{
 component.storesList = storesList;
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
  spyOn(component,'getProjectInformation')
  component.openDialogToAddStore(null);
  expect(component.getProjectInformation).toHaveBeenCalled();
});

it('test openDialogToModifyVIC',()=>{

  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

  spyOn(component,'getProjectInformation')
  component.openDialogToModifyVIC(storeObject);
  expect(component.getProjectInformation).toHaveBeenCalled();

});

it('test editStore',()=>{
  spyOn(component,'openDialogToAddStore')
  component.editStore("store1")
  expect(component.openDialogToAddStore).toHaveBeenCalled();
});


it('test modifyVIC',()=>{
  spyOn(component,'openDialogToModifyVIC')
  component.modifyVIC(storeObject)
  expect(component.openDialogToModifyVIC).toHaveBeenCalled();
});

it('test deleteProject',()=>{
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

  spyOn(projectService,'deleteProject').and.returnValue(Observable.of({}));
  const navigateSpy = spyOn(routerStub, 'navigateByUrl');
  component.deleteProject(projectByProjectNumber);
  expect(navigateSpy).toHaveBeenCalledWith('dashboard');
  expect(projectService.deleteProject).toHaveBeenCalledTimes(1);
});

it('test deleteStore',()=>{
  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

  spyOn(storeService,'deleteStore').and.returnValue(Observable.of({}));
  spyOn(component,'getProjectInformation')

  component.deleteStore(storeObject);

  expect(storeService.deleteStore).toHaveBeenCalledTimes(1);
  expect(component.getProjectInformation).toHaveBeenCalledTimes(1);
});

it('test navigateToLink',()=>{
  spyOn(component,'jsonEqual').and.returnValue(false);
  spyOn(window, 'confirm').and.returnValue(true);
  const navigateSpy = spyOn(routerStub, 'navigateByUrl');
  component.navigateToLink('dashboard/project');
  expect(navigateSpy).toHaveBeenCalledWith('dashboard/project');
});

it('test navigateToLink in case data got changed on project info page',()=>{
  spyOn(component,'jsonEqual').and.returnValue(true);
  const navigateSpy = spyOn(routerStub, 'navigateByUrl');
  component.navigateToLink('dashboard');
  expect(navigateSpy).toHaveBeenCalledWith('dashboard');
});

it('test jsonEqual',()=>{
  component.jsonEqual('test1','test2');
});


it('test updateProject',()=>{

  let latestProjFromDB :any={
    "isProject": 1,
    "enterpriseId": "408772",
    "projectNumber": "PM129292",
    "status": "OPEN",
    "version": 1,
    "failed": false,
    "id": "2f6746e0-0e72-4f84-b06c-2f8e4d8b9e5c",
    "recordType": "ProjectInfo"
  }

  let dialogSpy: jasmine.Spy;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
  dialogRefSpyObj.componentInstance = { body: '' };
  dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);

  component.projectObject = projectByProjectNumber;
  component.isDealerDivVisible = false;
  spyOn(projectService,'createProject').and.returnValue(Observable.of(latestProjFromDB));
  component.updateProject() 

});

it('test autoUpdateFunctionalAreaStatus',()=>{

  let faContext :any={
    "049f755a-c1fc-43b4-b019-b7ab356411ea": [
      {
          "functionalAreaName": "Parts",
          "functionalAreaType": null,
          "oemName": null,
          "clientSignoffDate": null,
          "selected": false,
          "status": "Validation in Progress",
          "platforms": [
              {
                  "id": null,
                  "platformName": "DRIVE",
                  "platformCode": "drive",
                  "selected": true
              }
          ],
          "vic": {
              "firstName": "Harika",
              "lastName": "Gajabimkar",
              "loginId": "Harika.Gajabimkar@cdk.com",
              "employeeId": null
          },
          "secondaryVic": {
              "firstName": "Suresh",
              "lastName": "Vanga",
              "loginId": "Suresh.Vanga@cdk.com",
              "employeeId": null
          },
          "clientFunctionalAreaUser": null,
          "version": 13,
          "isFailed": null,
          "inProcess": false,
          "productCode": "PTS",
          "productVersion": null,
          "masterFAId": "de35c7af-6d70-4d2f-9dae-b51620ff9d7f",
          "bpId": "87c7d8ca-327e-45ba-a592-ebabf475b4a3",
          "bpVersionId": "eac419d3-8afb-45af-a18c-78f043480a59",
          "bpTemplateId": "6462138a-b16c-487b-a5a6-59d50924fcf2",
          "isDealerApproved": false,
          "stateStandardId": null,
          "stateStandardName": null,
          "stateStandardVersionRecordType": null,
          "stateStandardVersionName": null,
          "copyRowData": false,
          "showValidateOrTransferButton": true,
          "showProcessValidationResultsButton": false,
          "createdDate": "2021-05-26T07:39:55.133+0000",
          "lastUpdatedDate": "2021-05-26T11:48:29.834+0000",
          "createdBy": "Sagar.Aitla@cdk.com",
          "updatedBy": "Sagar.Aitla@cdk.com",
          "incorporateBpChanges": false,
          "locked": false,
          "id": "049f755a-c1fc-43b4-b019-b7ab356411ea",
          "recordType": "e10327f0-6fc1-40aa-8621-ab4f89156798"
      }
  ]
  }
  component.storeFunctionalAreaContext = faContext;
  let response: any[] = [
    {
      "functionalAreaName": "Parts",
    }
  ];
  spyOn(functionalAreaService,'getFunctionalAreaById').and.returnValue(Observable.of(response));
  component.autoUpdateFunctionalAreaStatus();
});

it('test onFocusReloadPMs',()=>{
  let managerList :any[]=[
    {
      'EmpName':'Veer'
    }
  ]
  component.onFocusReloadPMs();
});



}); 