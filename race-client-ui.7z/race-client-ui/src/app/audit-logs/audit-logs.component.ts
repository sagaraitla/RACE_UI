import { Component, OnInit, ViewChild } from '@angular/core';

import { AuditLogService } from '../services/audit-log-service';
import { DataTransferService } from '../services/data-transfer-service';
import { AuthService } from '../services/auth-service';
import { Router } from '@angular/router';
import { DataSource } from '@angular/cdk/collections';
import { BehaviorSubject, Observable } from 'rxjs';
import { ProjectObject } from '../model/project-object';
import { PlatformObject } from '../model/platform-object';
import { ScreenObject } from '../model/screen-object';
import { StoreObject } from '../model/store-object';
import { AuditLogsObject } from '../model/audit-logs-object';
import { MatPaginator, MatTableDataSource, MatSort, Sort } from '@angular/material';
import { MatDialog, MatDialogRef } from '@angular/material';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { AuditLogDialogComponent } from  '../audit-log-dialog/audit-log-dialog.component';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-audit-logs',
  templateUrl: './audit-logs.component.html',
  styleUrls: ['./audit-logs.component.css']
})
export class AuditLogsComponent implements OnInit {
    
    @ViewChild(MatPaginator,{static: false}) paginator: MatPaginator;
    
    @ViewChild(MatSort,{static: false}) sort: MatSort;
    
    dataSource : any;
    displayName : string = "";
    

    displayedColumns = ['date', 'projectNumber', 'user','event','more'];
    
    constructor(private auditLogService: AuditLogService, private dataTransferService: DataTransferService, 
           private authService: AuthService,private router: Router, private dialog: MatDialog, private toastrService: ToastrService) { 
   
    }

      
  
    ngOnInit() {
     
           let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
              width: '300px',
              height: '150px',
              data: { message: 'Fetching Audit Logs ..' }
           });  
        
           this.authService.fetchLoggedInUserAndPermissions().subscribe((data: any) => {
           this.auditLogService.getAuditLogs().subscribe(
                   data => { 
                       this.dataSource =  new MatTableDataSource<AuditLogsObject>(data);
                       this.dataSource.data.forEach(element => {
                        for (const key in element) {
                          if (!element[key] || element[key] === null || element[key] === undefined) {
                            element[key] = '';
                          }
                        }
                      });
                      this.dataSource.filterPredicate = function(data, filter: string): boolean {
                        return (data.projectNumber && data.projectNumber.toLowerCase().includes(filter))
                        || (data.user && data.user.toLowerCase().includes(filter))
                        || (data.event && data.event.toLowerCase().includes(filter));
                    };   
                       this.dataSource.paginator = this.paginator;
                       this.dataSource.sort = this.sort;
                       const sortState: Sort = {active: 'date', direction: 'desc'};
                       this.sort.active = sortState.active;
                       this.sort.direction = sortState.direction;
                       this.sort.sortChange.emit(sortState);
                       loaderDialogRef.close();
                   },
               error =>{
                    this.toastrService.warning("Something went wrong...");
                    loaderDialogRef.close();    
               });
           });
    }

    navigate( endpoint : string){
        this.router.navigateByUrl(endpoint);
    }
    applyFilter(filterValue: string) {
            filterValue = filterValue.trim(); // Remove whitespace
            filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
            this.dataSource.filter = filterValue;
    }
    
    openAuditLogDialogue(auditLog : AuditLogsObject, userName : string){
        let dialogRef = this.dialog.open(AuditLogDialogComponent, {
          width: '60%',
          height: '80%',
          data: {
            auditLog: auditLog,
            userName : userName,
            displayName:this.getDisplayName(auditLog)
          }
      }); 
     
    }

    getDisplayName(auditLog:AuditLogsObject){
     
        if(auditLog.event === 'Project Data Modified'){
        this.displayName = "Project Number";
      }else if((auditLog.event === 'Store Data Modified - BP/VIC configured') || (auditLog.event === 'New Store Created - BP configured')|| (auditLog.event === 'Store Data Modified')){
        this.displayName = "Project - Store"
      }
      return this.displayName;
    
    }
    
    getAuditLogs(loaderMessage: string) {
      let loaderDialogRef;
      if (loaderMessage)
      {
              loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
              width: '300px',
              height: '150px',
              data: { message: loaderMessage }
          });
      }
      this.auditLogService
          .getAuditLogs()
              .subscribe(
                data => {
                       this.dataSource =  new MatTableDataSource<AuditLogsObject>(data);   
                       this.dataSource.paginator = this.paginator;
                       this.dataSource.sort = this.sort;
                       loaderDialogRef.close();
                }, error=> {
                    this.toastrService.error('got error' + error.error.message);
                }
          );
  }

  enableMoreOption(auditLog : AuditLogsObject){
   
    if((auditLog.updated === true  &&  auditLog.event === 'Project Data Modified') || (auditLog.event === 'Store Data Modified - BP/VIC configured') || (auditLog.event === 'New Store Created - BP/VIC configured')|| (auditLog.event === 'Store Data Modified')){
      return true;
    } 
    return false;
  }
}
