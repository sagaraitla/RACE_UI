import { Component, OnInit, ViewChild } from '@angular/core';
import { AuditLogService } from '../../services/audit-log-service';
import { DataTransferService } from '../../services/data-transfer-service';
import { AuthService } from '../../services/auth-service';
import { Router } from '@angular/router';
import { DataSource } from '@angular/cdk/collections';
import { BehaviorSubject, Observable } from 'rxjs';
import { AuditLogsVTObject } from '../../model/audit-logsvt-object';
import { MatPaginator, MatTableDataSource, MatSort, Sort } from '@angular/material';
import { MatDialog, MatDialogRef } from '@angular/material';
import { LoaderDialogueComponent } from '../../loader-dialog/loader-dialog.component';
import { ToastrService } from 'ngx-toastr';
import { Constants } from '../../constant/constants';


@Component({
  selector: 'app-audit-logs-propagation',
  templateUrl: './audit-logs-propagation.component.html',
  styleUrls: ['./audit-logs-propagation.component.css']
})
export class AuditLogsPropagationComponent implements OnInit {
    
    @ViewChild(MatPaginator,{static: false}) paginator: MatPaginator;
    
    @ViewChild(MatSort,{static: false}) sort: MatSort;
    
    dataSource : any;    

    displayedColumns = ['date', 'objectIdentifier', 'user','event'];
    
    constructor(private auditLogService: AuditLogService, private dataTransferService: DataTransferService, 
           private authService: AuthService,private router: Router, private dialog: MatDialog, private toastrService: ToastrService) { 
   
    }
    ngOnInit() {
    
           let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
              width: '300px',
              height: '150px',
              data: { message: 'Fetching Propagation Audit Logs ..' }
           });  
           this.authService.fetchLoggedInUserAndPermissions().subscribe((data: any) => {
           this.auditLogService.getAuditLogsChangePropagation().subscribe(genericResponse => { 
              if(genericResponse != null && genericResponse.resultCode===Constants.CDK_200){
                      this.dataSource =  new MatTableDataSource(genericResponse.resultObj);
                       this.dataSource.data.forEach(element => {
                        for (const key in element) {
                          if (!element[key] || element[key] === null || element[key] === undefined) {
                            element[key] = '';
                          }
                        }
                      });
                      this.dataSource.filterPredicate = function(data, filter: string): boolean {
                        return (data.objectIdentifier && data.objectIdentifier.toLowerCase().includes(filter))
                        || (data.user && data.user.toLowerCase().includes(filter))
                        || (data.event && data.event.toLowerCase().includes(filter));
                    };    
                       this.dataSource.paginator = this.paginator;
                       this.dataSource.sort = this.sort;
                       const sortState: Sort = {active: 'date', direction: 'desc'};
                       this.sort.active = sortState.active;
                       this.sort.direction = sortState.direction;
                       this.sort.sortChange.emit(sortState);
                  }
                       loaderDialogRef.close();
                   },
               error => {
                    this.toastrService.warning("Something went wrong...");
                    loaderDialogRef.close();    
               });
               
           });
        
    }

    navigate( endpoint : string){
        this.router.navigateByUrl(endpoint);
    }
    applyFilter(filterValue: string) {
            filterValue = filterValue.trim(); // Remove whitespace
            filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
            this.dataSource.filter = filterValue;
    }
      
    getAuditLogs(loaderMessage: string) {
      let loaderDialogRef;
      if (loaderMessage)
      {
              loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
              width: '300px',
              height: '150px',
              data: { message: loaderMessage }
          });
      }
      this.auditLogService
          .getAuditLogsVT()
              .subscribe(
                data => {
                       this.dataSource =  new MatTableDataSource<AuditLogsVTObject>(data);   
                       this.dataSource.paginator = this.paginator;
                       this.dataSource.sort = this.sort;
                       loaderDialogRef.close();
                }, error=> {
                    this.toastrService.error('got error' + error.error.message);
                }
          );
  }
    
}