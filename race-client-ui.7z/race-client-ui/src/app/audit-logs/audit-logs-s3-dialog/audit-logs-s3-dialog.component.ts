import { Component, Inject, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog, MatDialogRef, MatSnackBar, MatSort, MatTableDataSource, MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuditLogsS3LogContent } from '../../fetch-s3log-content/fetch-s3log-content.component';
import { LoaderDialogueComponent } from '../../loader-dialog/loader-dialog.component';
import { AuditLogsVTObject } from '../../model/audit-logsvt-object';
import { AmazonS3LogsService } from '../../services/amazonS3Logs-service';
import { AuditLogService } from '../../services/audit-log-service';
import { AuthService } from '../../services/auth-service';
import { MasterFunctionalUnitService } from '../../services/master-functional-unit-service';




@Component({
      selector: 'app-audit-logs-s3-dialog',
      templateUrl: './audit-logs-s3-dialog.component.html',
      styleUrls: ['./audit-logs-s3-dialog.component.css']
})

export class AuditLogsS3DialogComponent {
    
      @ViewChild(MatSort,{static: false}) sort: MatSort;
        
      auditLogVT : AuditLogsVTObject;      
      private gridApi;
      private gridColumnApi;
      columnDefs : any;
      rowData : any;
      displayName:string;      
      dataSource: any;
      displayedColumns = ['logs', 'lastModifiedDate', 'size'];
      content: any;
      isDataPresent : boolean = true;
      
      constructor(private auditLogService: AuditLogService, private dialogRef: MatDialogRef<AuditLogsS3DialogComponent>, private authService: AuthService,
              private _formBuilder: FormBuilder, @Inject(MAT_DIALOG_DATA) private data: any,  private dialog: MatDialog,
              private snackBar: MatSnackBar, private router: Router,private functionalUnitService: MasterFunctionalUnitService,private amazonS3LogsService: AmazonS3LogsService, private toastrService : ToastrService ) {
          dialogRef.disableClose = true;
          this.auditLogVT = JSON.parse(JSON.stringify(this.data.auditLogVT));
          this.displayName = this.data.displayName;     
      }

      ngOnInit(){

        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
          width: '300px',
          height: '150px',
          data: { message: 'Fetching list of S3 files...' }
        });
        
        this.amazonS3LogsService.getFileNamesFromS3Bucket(this.auditLogVT.s3LogsPath)
        .subscribe(genericResponse => {
          if(genericResponse != null && genericResponse != undefined && genericResponse.resultDescription == "OK" && genericResponse.resultDescription != null){
            if(genericResponse.resultObj.length == 0)
              this.isDataPresent = false;
            this.dataSource = new MatTableDataSource<String[]>(genericResponse.resultObj);
            this.dataSource.data.forEach(element => {
              for (const key in element) {
                if (!element[key] || element[key] === null || element[key] === undefined) {
                  element[key] = '';
                }
              }
            });

            this.dataSource.sortingDataAccessor = (item, property) => {
            
              switch(property) {
                case 'logs': return item.logFileName;  
                case 'lastModifiedDate': return item.lastModified;
                case 'size': return item.size;
                default: return item[property];
              }
            };
            this.dataSource.sort = this.sort;
            loaderDialogRef.close();
        }else
          loaderDialogRef.close();
        		
        },
        error => {
          this.toastrService.error('Error while fetching the data ' + error.error.message);
          loaderDialogRef.close();
          }
        );
      }

    openDialogToDisplayContent(fileName:string){
      let dialogRef = this.dialog.open(AuditLogsS3LogContent, {
        width: "60%",
        height: "85%",
        data:{
            auditLogVT: this.auditLogVT,
            fileName : fileName,
            displayName:'Project : Store : Functional Area'
        }
      });
    }

    closeDialog() {
          this.dialogRef.close();
    };
      
}
