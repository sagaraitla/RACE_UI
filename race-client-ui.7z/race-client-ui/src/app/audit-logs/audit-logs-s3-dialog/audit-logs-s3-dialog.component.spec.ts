import { CdkTableModule } from "@angular/cdk/table";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCardModule, MatDialog, MatDialogModule, MatDialogRef, MatDividerModule, MatIconModule, MatProgressSpinnerModule, MatSnackBarModule, MatSortModule, MAT_DIALOG_DATA } from "@angular/material";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { of, Observable } from "rxjs";
import { AuditLogsS3LogContent } from "../../fetch-s3log-content/fetch-s3log-content.component";
import { LoaderDialogueComponent } from "../../loader-dialog/loader-dialog.component";
import { GenericResponse } from "../../model/generic-response";
import { AmazonS3LogsService } from "../../services/amazonS3Logs-service";
import { AuditLogService } from "../../services/audit-log-service";
import { AuthService } from "../../services/auth-service";
import { MasterFunctionalUnitService } from "../../services/master-functional-unit-service";
import { ServerCommunicationService } from "../../services/server-communication-service";
import { AuditLogsS3DialogComponent } from "./audit-logs-s3-dialog.component"

describe('AuditLogsS3DialogComponent',() =>{
    let component : AuditLogsS3DialogComponent;
    let fixture : ComponentFixture<AuditLogsS3DialogComponent>;
    let auditLogService :AuditLogService;
    let authService : AuthService;
    let masterFunctionalUnitService : MasterFunctionalUnitService;
    let amazonS3LogsService : AmazonS3LogsService;

    class MatDialogMock {
        open() {
          return {
            afterClosed: () => Observable.of(true)
          };
        }
      };
    
    const testUrl  = 'dashboard';
    beforeEach(async(()=>{

      const dialogMock = {
        close: () => { }
    };

        let mockRouter = {
            navigate: jasmine.createSpy('navigateByUrl')
        } 

        let data = {
            displayName : "Project - Store",
            auditLogVT:'test',
          } 

          const amazonS3LogsServiceSpy = jasmine.createSpyObj('AmazonS3LogsService', ['getFileNamesFromS3Bucket']);  
          TestBed.configureTestingModule({
            imports:[
                MatDialogModule,
                MatIconModule,
                CdkTableModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                ToastrModule.forRoot(),
                MatSnackBarModule,
                MatSortModule,
                SortableModule,
                MatCardModule,
                
            ],
            declarations:[
                AuditLogsS3DialogComponent, LoaderDialogueComponent, AuditLogsS3LogContent
            ],
            providers:[
                AuditLogService,
                AuthService,
                AmazonS3LogsService,
                MasterFunctionalUnitService,
                ToastrService,{ provide: Router, useValue: {url:testUrl} },
                { provide: MAT_DIALOG_DATA, useValue: data },
                { provide: MatDialogRef, useValue: dialogMock },
                ServerCommunicationService
            ]
          }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent, AuditLogsS3LogContent]}});
    
              authService = TestBed.get(AuthService);
              auditLogService = TestBed.get(AuditLogService);
              masterFunctionalUnitService = TestBed.get(MasterFunctionalUnitService);
              amazonS3LogsService = TestBed.get(AmazonS3LogsService);    

              fixture = TestBed.createComponent(AuditLogsS3DialogComponent)
              component = fixture.componentInstance;
    }));
    
    const generic_response : GenericResponse = {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [
          {
            "objectType": "Propagation",
            "date": "2020-10-29T09:56:13.635+0000",
            "objectIdentifier": "ProjOct21 : store1 : Propagate_Fu_To_BP_Drive",
            "user": "Suresh.Vanga@cdk.com",
            "event": undefined,
            "id": "65768c40-62ff-4d0c-ade9-0ebffc74b69a",
            "recordType": "PropagationInfo"
          }
          ],
          "executionTime" : null
      }

      const generic_response_fail : GenericResponse = {
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [
          ],
          "executionTime" : null
      }

      const generic_response2 : GenericResponse = {
        "resultCode": "CDK_200",
        "resultDescription": "NotOK",
        "resultObj": [
          ],
          "executionTime" : null
      }

      it('test ngOnInit method', ()=>{ 
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(amazonS3LogsService,'getFileNamesFromS3Bucket').and.returnValue(Observable.of(generic_response));
        fixture.detectChanges();
      });

      it('test ngOnInit method fail case', async()=>{
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(amazonS3LogsService,'getFileNamesFromS3Bucket').and.returnValue(Observable.of(generic_response_fail));
        fixture.detectChanges();
    });
    
    it('test ngOnInit method fail else case', async()=>{
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(amazonS3LogsService,'getFileNamesFromS3Bucket').and.returnValue(Observable.of(generic_response2));
        fixture.detectChanges();
    }); 

    it('test ngOnInit where get File Names From S3 Bucket api throw error',()=>{
      let error:any={
        error:{
          message:'API Error'
        }
      }
      let dialogSpy: jasmine.Spy;
      let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close:()=>{} });
      dialogRefSpyObj.componentInstance = { body: '' };
      dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
      spyOn(amazonS3LogsService,'getFileNamesFromS3Bucket').and.returnValue(Observable.throwError(error));
      fixture.detectChanges();
      expect(component['toastrService'].previousToastMessage).toBe('Error while fetching the data API Error')
    });

    it('test openDialogToDisplayContent',()=>{
      spyOn(component['dialog'],'open').and.returnValue({})
      component.openDialogToDisplayContent('test');
    });

    it('test close Dialog',()=>{
      component.closeDialog();
    });

})