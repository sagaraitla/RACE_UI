import { CdkTableModule } from "@angular/cdk/table";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCardModule, MatDialog, MatDialogModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatPaginatorModule, MatProgressSpinnerModule, MatSnackBarModule, MatSort, MatSortModule, MatTableDataSource } from "@angular/material";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { of, Observable } from "rxjs";
import { AuditLogDialogComponent } from "../../audit-log-dialog/audit-log-dialog.component";
import { AuditLogGomDialogComponent } from "../../audit-log-gom-dialog-details/audit-log-gom-dialog.component";
import { LoaderDialogueComponent } from "../../loader-dialog/loader-dialog.component";
import { AuditLogsFUObject } from "../../model/audit-logsfu-object";
import { AuditLogService } from "../../services/audit-log-service";
import { AuthService } from "../../services/auth-service";
import { DataTransferService } from "../../services/data-transfer-service";
import { ServerCommunicationService } from "../../services/server-communication-service";
import { AuditLogsFUComponent } from "./audit-logsfu.component";

describe('AuditLogsFUComponent',()=>{
    let component : AuditLogsFUComponent;
    let fixture : ComponentFixture<AuditLogsFUComponent>;
    let auditLogService : AuditLogService;
    let authService : AuthService;

    class MatDialogMock {
        open() {
          return {
            afterClosed: () => Observable.of(true)
          };
        }
      };

      const testUrl  = 'dashboard';
      beforeEach(async() =>{
        let mockRouter = {
            navigate: jasmine.createSpy('navigateByUrl')
        } 
        TestBed.configureTestingModule({
            imports:[
                MatDialogModule,
                MatIconModule,
                CdkTableModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                ToastrModule.forRoot(),
                MatSnackBarModule,
                MatSortModule,
                SortableModule,
                MatCardModule,
                MatPaginatorModule,
                MatFormFieldModule,
                MatInputModule,
                
            ],

            declarations:[
                AuditLogsFUComponent, LoaderDialogueComponent, AuditLogDialogComponent, AuditLogGomDialogComponent
            ],

            providers:[
                AuditLogService,
                DataTransferService, 
                AuthService,
                ToastrService, 
                ServerCommunicationService,
                { provide: Router, useValue: {url:testUrl} },
            ]
      }).overrideModule(BrowserDynamicTestingModule,
        { set: { entryComponents: [LoaderDialogueComponent, AuditLogDialogComponent, AuditLogGomDialogComponent]}});

          authService = TestBed.get(AuthService);
          auditLogService = TestBed.get(AuditLogService);
          fixture = TestBed.createComponent(AuditLogsFUComponent);
          component = fixture.componentInstance;
}); 

    const fu_response_list : AuditLogsFUObject[] = 
        [
            {
              "date": null,
              "fieldsInfo" : [],
              "objectIdentifier": "Tech Data",
              "user": "Jeff.Grence@cdk.com",
              "event": undefined,
              "id": "d4bbd335-9abb-4b06-9b26-5b05ee4cd5c6",
            }
        ];

      it('test ngOnInit method', ()=>{ 
        let data:{}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data));
        spyOn(auditLogService,'getAuditLogsFU').and.returnValue(Observable.of(fu_response_list));
        component.dataSource = new MatTableDataSource<AuditLogsFUObject>(fu_response_list);
        component.sort = new MatSort();
        component.dataSource.sort = component.sort;
        fixture.detectChanges();
        expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(1);
        expect(auditLogService.getAuditLogsFU).toHaveBeenCalledTimes(1);
      });
    
      it('test ngOnInit method error case', ()=>{ 
        let data:{}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(auditLogService,'getAuditLogsFU').and.returnValue(Observable.throwError('error'));
        spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data))
        fixture.detectChanges();
        expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(1);
        expect(auditLogService.getAuditLogsFU).toHaveBeenCalledTimes(1);
      });

      it('test apply filter module', ()=>{
        component.dataSource = new MatTableDataSource<AuditLogsFUObject>(fu_response_list);
        component.applyFilter("filterString");
      });
    
      it('test navigate method', async() =>{
        component.navigate("Dashboard");
      });
    
      it('test open audit log dialog method', ()=>{
        let auditLogObjGom :any = {
            event : "Functional Unit GridOptionModel Modified"
        };

        let auditLogObjFu :any = {
            event : "Functional Unit"
        };
        
        let userName :"userMe";
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        component.openAuditLogDialogue(auditLogObjGom,userName,"AccountingDef");
        component.openAuditLogDialogue(auditLogObjFu,userName,"AccountingDef");
        expect(component.openAuditLogDialogue).toHaveBeenCalled;
      });
    
      it('test enable more option',()=>{
        let auditLog : any = {
            updated : true,
            event : "Functional Unit Modified"
        }
        let auditLogOther : any = {
            updated : false,
            event : "Functional Unit"
        }
        component.enableMoreOption(auditLog);
        component.enableMoreOption(auditLogOther);
        expect(component.enableMoreOption).toHaveBeenCalled;
    
      });
    
      it('test get audit logs method', async()=>{
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(auditLogService,'getAuditLogsFU').and.returnValue(Observable.of(fu_response_list));
        component.getAuditLogsFUnit("loaderMessage");
        expect(auditLogService.getAuditLogsVT).toHaveBeenCalledTimes(0);
        expect(auditLogService.getAuditLogsFU).toHaveBeenCalledTimes(1);
      });

      it('test get audit logs if auditlogs fu throw api error', async()=>{
        let error:any={
          error:{
            message:'API Error'
          }
        }
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(auditLogService,'getAuditLogsFU').and.returnValue(Observable.throwError(error));
        component.getAuditLogsFUnit("loaderMessage");
        expect(auditLogService.getAuditLogsVT).toHaveBeenCalledTimes(0);
        expect(auditLogService.getAuditLogsFU).toHaveBeenCalledTimes(1);
      });

})