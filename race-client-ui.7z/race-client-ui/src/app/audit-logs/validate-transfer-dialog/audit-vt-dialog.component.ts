import { Component, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar, MatTableDataSource , MatSort} from '@angular/material';
import { Router } from '@angular/router';

import { LoaderDialogueComponent } from '../../loader-dialog/loader-dialog.component';
import { AuditLogService } from '../../services/audit-log-service';
import { UserObject } from '../../model/user-object';
import { AuthService } from '../../services/auth-service';
import { AuditLogsVTObject } from '../../model/audit-logsvt-object';
import { ResultsInfoObject } from '../../model/results-info-object';


@Component({
      selector: 'app-audit-log-vt-dialog',
      templateUrl: './audit-vt-dialog.component.html',
      styleUrls: ['./audit-vt-dialog.component.css']
})

export class AuditVTDialogComponent {
    
      @ViewChild(MatSort,{static: false}) sort: MatSort;
        
      auditLogVT : AuditLogsVTObject;      
      private gridApi;
      private gridColumnApi;
      columnDefs : any;
      rowData : any;
      displayName:string;
      

      constructor(private auditLogService: AuditLogService, private dialogRef: MatDialogRef<AuditVTDialogComponent>, private authService: AuthService,
              private _formBuilder: FormBuilder, @Inject(MAT_DIALOG_DATA) private data: any,  private dialog: MatDialog,
              private snackBar: MatSnackBar, private router: Router) {
          dialogRef.disableClose = true;
          this.auditLogVT = JSON.parse(JSON.stringify(this.data.auditLogVT));
          this.displayName = this.data.displayName;      
      }
  
      sizeToFit() {
        this.gridApi.sizeColumnsToFit();
      }
    
      autoSizeAll() {
        var allColumnIds = [];
        this.gridColumnApi.getAllColumns().forEach(function(column) {
          allColumnIds.push(column.colId);
        });
        this.gridColumnApi.autoSizeColumns(allColumnIds);
      }
    
      onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
          width: '300px',
          height: '150px',
          data: { message:  this.auditLogVT.event +' Results Info...' }
          });
          this.auditLogService.getResultsInfoById(this.auditLogVT.id).subscribe(data => {
              this.columnDefs = [
                        {headerName: "Level", field: "level", width:100, suppressSizeToFit:true},
                        {headerName: "Functional Unit", field:"functionalUnit", width:120},
                        {headerName: "Row Index", field: "rowIndex", width:120, minWidth:50, maxWidth:100},
                        {headerName: "Key", field: "key", editable: false, width:120},
                        {headerName: "Value", field: "value", editable:false, width:120},
                        {headerName: "Procedure", field: "procedure", width:150},
                        {headerName: "Message", field:"message", width:200},
                        {headerName: "Time Stamp", field:"timestamp", width:150},
                        {headerName: "Log", field:"log", width:200}
                    ];
              this.rowData = data;  
              loaderDialogRef.close();                    
          },error => {
            loaderDialogRef.close();
         });
          this.autoSizeAll();
      }  
      
      closePopup() {
          this.dialogRef.close();
      };
}