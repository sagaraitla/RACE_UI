import { CdkTableModule } from "@angular/cdk/table";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCardModule, MatDialogModule, MatDialogRef, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatPaginatorModule, MatProgressSpinnerModule, MatSnackBarModule, MatSortModule, MAT_DIALOG_DATA } from "@angular/material";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { GridApi } from "ag-grid";
import { AgGridModule } from "ag-grid-angular";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { Observable } from "rxjs";
import { LoaderDialogueComponent } from "../../loader-dialog/loader-dialog.component";
import { AuditLogService } from "../../services/audit-log-service";
import { AuthService } from "../../services/auth-service";
import { ServerCommunicationService } from "../../services/server-communication-service";
import { AuditVTDialogComponent } from "./audit-vt-dialog.component";

describe('AuditVTDialogComponent',()=>{

    let component : AuditVTDialogComponent;
    let fixture : ComponentFixture<AuditVTDialogComponent>;
    let auditLogService : AuditLogService;
    let authService : AuthService;
    let gridApi:any;
    let gridColumnApi:any;

      const testUrl  = 'dashboard';
      beforeEach(async() =>{

        const dialogMock = {
          close: () => { }
      };
      let data= {
        auditLogVT:{
          event:"Transfer DMS Failed"
          },
        displayName:"Audit_VT_Log"
      }

        let mockRouter = {
            navigate: jasmine.createSpy('navigateByUrl')
        } 
        const gridApiSpy = jasmine.createSpyObj('GridApi',['sizeColumnsToFit']);
        const gridColumnApiSpy = jasmine.createSpyObj('gridColumnApi',['getAllColumns']);
        TestBed.configureTestingModule({
            imports:[
                MatDialogModule,
                MatIconModule,
                CdkTableModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                ToastrModule.forRoot(),
                MatSnackBarModule,
                MatSortModule,
                SortableModule,
                MatCardModule,
                MatPaginatorModule,
                MatFormFieldModule,
                MatInputModule,
                AgGridModule.withComponents(
                  [
                  ])   
            ],
            declarations:[AuditVTDialogComponent, LoaderDialogueComponent],
            providers:[
                AuditLogService,
                AuthService,
                ToastrService, 
                ServerCommunicationService,
                { provide: Router, useValue: {url:testUrl} },
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: dialogMock},
                {provide:GridApi,useValue:gridApiSpy},
                {provide:gridColumnApi,useValue:gridColumnApiSpy}
            ]
      }).overrideModule(BrowserDynamicTestingModule,
        { set: { entryComponents: [LoaderDialogueComponent]}});
          authService = TestBed.get(AuthService);
          auditLogService = TestBed.get(AuditLogService);
          gridApi = TestBed.get(GridApi) as jasmine.SpyObj<GridApi>;  
          gridColumnApi = TestBed.get(gridColumnApi);
      });
      const columnDefs :any[] = [
        {headerName: "Level", field: "level", width:100, suppressSizeToFit:true},
        {headerName: "Functional Unit", field:"functionalUnit", width:120},
        {headerName: "Row Index", field: "rowIndex", width:120, minWidth:50, maxWidth:100},
        {headerName: "Key", field: "key", editable: false, width:120},
        {headerName: "Value", field: "value", editable:false, width:120},
        {headerName: "Procedure", field: "procedure", width:150},
        {headerName: "Message", field:"message", width:200},
        {headerName: "Time Stamp", field:"timestamp", width:150},
        {headerName: "Log", field:"log", width:200}
    ];
    const columns:any[]=[
      {
        columnDef: columnDefs
      }
    ]

    const data:any[]=[
      {
        functionalUnit: null,
        id: "25fe4072-a5cb-4b87-b81a-255cac1346b2",
        key: null,
        level: "error",
        log: "/adp/logs/nj/race/20210407_160010834/20210407_160010834_dot.process.setups.log",
        message: "Install failed for product code ACCT, special developer NO SUCCESS reporting flag is set!!!↵",
        procedure: "dot.process.setups",
        recordType: "280c8b09-529c-44cb-83dc-491272810d7b",
        rowIndex: null,
        timestamp: "20210407_16:00:10:834",
        value: null,
        },
        {
        functionalUnit: "Sales Chains",
        id: "25fe4072-a5cb-4b87-b81a-255cac1346b2",
        key: "478000",
        level: "warning",
        log: "/adp/logs/nj/race/20210407_160010834/Accounting_1_20210407_160010834/api_error_list",
        message: "Account 478000 is not set up for this company. Enter a different account or set up the account with function AGSA.↵",
        procedure: "flex_api",
        recordType: "67e9695f-197c-454c-9993-002874725eaa",
        rowIndex: "none",
        timestamp: "20210407_16:00:10:834",
        value: "500"
        }
    ]
      beforeEach(() => {
      
        fixture = TestBed.createComponent(AuditVTDialogComponent);
        component = fixture.componentInstance;
        component['gridApi']= gridApi;
        component.columnDefs = columnDefs;
        spyOn(auditLogService,'getResultsInfoById').and.returnValue(Observable.of(data));
        fixture.detectChanges();
        expect(component).toBeTruthy();
      }); 
  
      it('test closePopup',()=>{
            component.closePopup();
      }); 

     it('test sizeToFit',()=>{
        component['gridApi']= gridApi;
        component.sizeToFit();
        expect( component['gridApi'].sizeColumnsToFit).toHaveBeenCalledTimes(1);
    }); 


});


