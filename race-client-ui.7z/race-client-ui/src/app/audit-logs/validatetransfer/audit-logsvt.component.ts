import { Component, OnInit, ViewChild } from '@angular/core';
import { AuditLogService } from '../../services/audit-log-service';
import { DataTransferService } from '../../services/data-transfer-service';
import { AuthService } from '../../services/auth-service';
import { Router } from '@angular/router';
import { DataSource } from '@angular/cdk/collections';
import { BehaviorSubject, Observable } from 'rxjs';
import { AuditLogsVTObject } from '../../model/audit-logsvt-object';
import { MatPaginator, MatTableDataSource, MatSort, Sort } from '@angular/material';
import { MatDialog, MatDialogRef } from '@angular/material';
import { LoaderDialogueComponent } from '../../loader-dialog/loader-dialog.component';
import { AuditVTDialogComponent } from  '../validate-transfer-dialog/audit-vt-dialog.component';
import { AuditLogsS3DialogComponent } from '../audit-logs-s3-dialog/audit-logs-s3-dialog.component';
import { ProcessValidationResultsComponent } from '../../process-validation-results/process-validation-results.component';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-audit-logsvt',
  templateUrl: './audit-logsvt.component.html',
  styleUrls: ['./audit-logsvt.component.css']
})
export class AuditLogsVTComponent implements OnInit {
    
    @ViewChild(MatPaginator,{static: false}) paginator: MatPaginator;
    
    @ViewChild(MatSort,{static: false}) sort: MatSort;
    
    dataSource : any;    

    displayedColumns = ['date', 'objectIdentifier', 'user','event','more','s3LogsPath'];
    
    constructor(private auditLogService: AuditLogService, private dataTransferService: DataTransferService, 
           private authService: AuthService,private router: Router, private dialog: MatDialog, private toastrService: ToastrService) { 
   
    }

      
  
    ngOnInit() {
     
           let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
              width: '300px',
              height: '150px',
              data: { message: 'Fetching Audit Logs ..' }
           });  
        
           this.authService.fetchLoggedInUserAndPermissions().subscribe((data: any) => {
           this.auditLogService.getAuditLogsVT().subscribe(
                   data => { 
                       this.dataSource =  new MatTableDataSource<AuditLogsVTObject>(data);
                       this.dataSource.data.forEach(element => {
                        for (const key in element) {
                          if (!element[key] || element[key] === null || element[key] === undefined) {
                            element[key] = '';
                          }
                        }
                      });
                      this.dataSource.filterPredicate = function(data, filter: string): boolean {
                        return (data.objectIdentifier && data.objectIdentifier.toLowerCase().includes(filter))
                        || (data.user && data.user.toLowerCase().includes(filter))
                        || (data.event && data.event.toLowerCase().includes(filter));
                    };    
                       this.dataSource.paginator = this.paginator;
                       this.dataSource.sort = this.sort;
                       const sortState: Sort = {active: 'date', direction: 'desc'};
                       this.sort.active = sortState.active;
                       this.sort.direction = sortState.direction;
                       this.sort.sortChange.emit(sortState);
                       loaderDialogRef.close();
                   },
               error => {
                    this.toastrService.warning("Something went wrong...");
                    loaderDialogRef.close();    
               });
           });
        
    }

    navigate( endpoint : string){
        this.router.navigateByUrl(endpoint);
    }
    applyFilter(filterValue: string) {
            filterValue = filterValue.trim(); // Remove whitespace
            filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
            this.dataSource.filter = filterValue;
    }
    
    openAuditLogDialogue(auditLogVT : AuditLogsVTObject, userName : string, event:string){
      if(event === 'Validation Done' || event === 'Validation Failed' || event === 'Transfer to DMS successful' || event === 'Transfer to DMS failed'){
          let dialogRef = this.dialog.open(AuditVTDialogComponent, {
            width: '60%',
            height: '80%',
            data: {
              auditLogVT: auditLogVT,
              userName : userName,
              displayName:'Project : Store : Functional Area'
            }
        }); 
      }
      if(event === 'ProcessValidationResult'){
          let dialogRef = this.dialog.open(ProcessValidationResultsComponent, {
            width: '60%',
            height: '80%',
            data: {
              auditLogVT: auditLogVT,
              userName : userName,
              displayName:'Project : Store : Functional Area'
            }
        }); 
      }
    }
    openS3LogsPathDialog(auditLogVT : AuditLogsVTObject, userName : string, event:string){
      if(event === 'Validation Done' || event === 'Validation Failed' || event === 'Transfer to DMS successful' || event === 'Transfer to DMS failed'){
          let dialogRef = this.dialog.open(AuditLogsS3DialogComponent, {
            width: '60%',
            height: '85%',
            data: {
              auditLogVT: auditLogVT,
              userName : userName,
              displayName:'Project : Store : Functional Area'
            }
        }); 
      }
    }

      
    getAuditLogs(loaderMessage: string) {
      let loaderDialogRef;
      if (loaderMessage)
      {
              loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
              width: '300px',
              height: '150px',
              data: { message: loaderMessage }
          });
      }
      this.auditLogService
          .getAuditLogsVT()
              .subscribe(
                data => {
                       this.dataSource =  new MatTableDataSource<AuditLogsVTObject>(data);   
                       this.dataSource.paginator = this.paginator;
                       this.dataSource.sort = this.sort;
                       loaderDialogRef.close();
                }, error=> {
                    this.toastrService.error('got error' + error.error.message);
                }
          );
  }

  enableMoreOption(auditLogVT : AuditLogsVTObject):boolean{
    if(auditLogVT.event === 'Validation Done' || auditLogVT.event === 'Validation Failed' || auditLogVT.event === 'Transfer to DMS successful' || auditLogVT.event === 'Transfer to DMS failed' || (auditLogVT.event === 'ProcessValidationResult' && auditLogVT.pvrresultsPresent === true)){
      return true;
    }
    return false;
  }

  enableLogsOption(auditLogVT : AuditLogsVTObject):boolean{
    if((auditLogVT.event === 'Validation Done' || auditLogVT.event === 'Transfer to DMS successful' || auditLogVT.event === 'Transfer to DMS failed' || auditLogVT.event === 'Validation Failed') 
    && (auditLogVT.s3LogsPath !== null && auditLogVT.s3LogsPath !== '')){    
      return true;
    }
    return false;
  }
  
}