import { CdkTableModule } from "@angular/cdk/table";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatPaginatorModule, MatProgressSpinnerModule, MatSnackBarModule, MatSort, MatSortModule, MatTableDataSource } from "@angular/material";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { of, Observable } from "rxjs";
import { LoaderDialogueComponent } from "../../loader-dialog/loader-dialog.component";
import { AuditLogsFUObject } from "../../model/audit-logsfu-object";
import { AuditLogsVTObject } from "../../model/audit-logsvt-object";
import { ProcessValidationResultsComponent } from "../../process-validation-results/process-validation-results.component";
import { AuditLogService } from "../../services/audit-log-service";
import { AuthService } from "../../services/auth-service";
import { DataTransferService } from "../../services/data-transfer-service";
import { ServerCommunicationService } from "../../services/server-communication-service";
import { AuditLogsS3DialogComponent } from "../audit-logs-s3-dialog/audit-logs-s3-dialog.component";
import { AuditVTDialogComponent } from "../validate-transfer-dialog/audit-vt-dialog.component";
import { AuditLogsVTComponent } from "./audit-logsvt.component";
import {  AgGridModule  } from 'ag-grid-angular'; 


describe('AuditLogsVTComponent',()=>{
    let component : AuditLogsVTComponent;
    let fixture : ComponentFixture<AuditLogsVTComponent>;
    let auditLogService : AuditLogService;
    let authService : AuthService;

    class MatDialogMock {
        open() {
          return {
            afterClosed: () => Observable.of(true)
          };
        }
      };

      const testUrl  = 'dashboard';
      beforeEach(async() =>{
        let mockRouter = {
            navigate: jasmine.createSpy('navigateByUrl')
        } 
        TestBed.configureTestingModule({
            imports:[
                MatDialogModule,
                MatIconModule,
                CdkTableModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                ToastrModule.forRoot(),
                MatSnackBarModule,
                MatSortModule,
                SortableModule,
                MatCardModule,
                MatPaginatorModule,
                MatFormFieldModule,
                MatInputModule,
                AgGridModule.withComponents([]),
                MatCheckboxModule
            ],

            declarations:[
                AuditLogsVTComponent, LoaderDialogueComponent, AuditLogsS3DialogComponent, AuditVTDialogComponent, ProcessValidationResultsComponent
            ],

            providers:[
                AuditLogService,
                DataTransferService, 
                AuthService,
                ToastrService, 
                ServerCommunicationService,
                { provide: Router, useValue: {url:testUrl} },
            ]
      }).overrideModule(BrowserDynamicTestingModule,
        { set: { entryComponents: [LoaderDialogueComponent, AuditLogsS3DialogComponent, AuditVTDialogComponent, ProcessValidationResultsComponent]}});

          authService = TestBed.get(AuthService);
          auditLogService = TestBed.get(AuditLogService);
          fixture = TestBed.createComponent(AuditLogsVTComponent);
          component = fixture.componentInstance;
}); 

    const auditlogs_vt_list : AuditLogsVTObject[] = 
        [
           {
                "objectType": "ValidateTransfer",
                "date": null,
                "objectIdentifier": "P2405:STORE1:TestFA_2405",
                "user": "Madhusudhan.Talakokkula@cdk.com",
                "event": "Validation in Progress",
                "s3Source": null,
                "s3LogsPath": null,
                "id": "3bef368f-ffcb-4f15-a490-d9370eb30699",
                "pvrresultsPresent": false,
                "recordType": "ValidateTransferInfo"
            }
        ];

      it('test ngOnInit method', ()=>{ 
        let data:{}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data));
        spyOn(auditLogService,'getAuditLogsVT').and.returnValue(Observable.of(auditlogs_vt_list));
        component.dataSource = new MatTableDataSource<AuditLogsVTObject>(auditlogs_vt_list);
        component.sort = new MatSort();
        component.dataSource.sort = component.sort;
        fixture.detectChanges();
        expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(1);
        expect(auditLogService.getAuditLogsVT).toHaveBeenCalledTimes(1);
      });
    
      it('test ngOnInit method error case', ()=>{ 
        let data:{}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(auditLogService,'getAuditLogsVT').and.returnValue(Observable.throwError('error'));
        spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data))
        fixture.detectChanges();
        expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(1);
        expect(auditLogService.getAuditLogsVT).toHaveBeenCalledTimes(1);
      });

      it('test apply filter module', ()=>{
        component.dataSource = new MatTableDataSource<AuditLogsVTObject>(auditlogs_vt_list);
        component.applyFilter("filterString");
      });
    
      it('test navigate method', async() =>{
        component.navigate("Dashboard");
      });
    
      it('test open audit log dialog method', ()=>{
        let auditLogObj : any = {}
        let userName :"userMe";
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        component.openAuditLogDialogue(auditLogObj,userName,"Validation Done");
        component.openAuditLogDialogue(auditLogObj,userName,"ProcessValidationResult");
        expect(component.openAuditLogDialogue).toHaveBeenCalled;
      });

      it('test open s3 logs path dialogue method', () =>{
        let auditLogObj : any = {}
        let userName :"userMe";
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        component.openS3LogsPathDialog(auditLogObj, userName, "Validation Done");
        expect(component.openS3LogsPathDialog).toHaveBeenCalled;

      })
    
      it('test enable more option',()=>{
        let auditLog : any = {
            updated : true,
            event : "Validation Done"
        }
        let auditLogOther : any = {
            updated : false,
            event : "Functional Unit"
        }
        component.enableMoreOption(auditLog);
        component.enableMoreOption(auditLogOther);
        expect(component.enableMoreOption).toHaveBeenCalled;
    
      });

      it('test enable logs option method', () =>{
        let auditLog : any = {
            updated : true,
            event : "Validation Done",
            s3LogsPath : "s3LogsPath"
        }
        let auditLogOther : any = {
            updated : false,
            event : "Functional Unit"
        }
        component.enableLogsOption(auditLog);
        component.enableLogsOption(auditLogOther);
      })
    
      it('test get audit logs method', async()=>{
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(auditLogService,'getAuditLogsVT').and.returnValue(Observable.of(auditlogs_vt_list));
        component.getAuditLogs("loaderMessage");
        expect(auditLogService.getAuditLogsVT).toHaveBeenCalledTimes(1);
        expect(auditLogService.getAuditLogsFU).toHaveBeenCalledTimes(0);
      });

      it('test get audit logs method where getAuditLogs API throw exception', async()=>{
        let error:any={
          error:{
            message:'API Error'
          }
        }
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(auditLogService,'getAuditLogsVT').and.returnValue(Observable.throwError(error));
        component.getAuditLogs("loaderMessage");
      });

})