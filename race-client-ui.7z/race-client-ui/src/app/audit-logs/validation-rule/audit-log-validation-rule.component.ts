import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, Sort } from '@angular/material';
import { AuditLogService } from '../../services/audit-log-service';
import { AuthService } from '../../services/auth-service';
import { Router } from '@angular/router';
import { LoaderDialogueComponent } from '../../loader-dialog/loader-dialog.component';
import { AuditLogsObject } from '../../model/audit-logs-object';
import { AuditLogDialogDetailsComponent } from '../../audit-log-dialog-details/audit-log-dialog-details.component';
import { Constants } from '../../constant/constants';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-validation-rule',
  templateUrl: './audit-log-validation-rule.component.html',
  styleUrls: ['./audit-log-validation-rule.component.css']
  })
export class AuditLogsVRComponent implements OnInit {

  @ViewChild(MatPaginator,{static: false}) paginator: MatPaginator;
  @ViewChild(MatSort,{static: false}) sort: MatSort;
  dataSource : any;
  displayedColumns = ['date', 'validationRuleDesc', 'user','event','more'];
  constructor(private auditLogService: AuditLogService ,
      private authService: AuthService,private router: Router, private dialog: MatDialog, private toastrService: ToastrService) { 
  }

  ngOnInit() {
   this.authService.fetchLoggedInUserAndPermissions().subscribe(() => {
     this.getAuditlogsVR();
     });
    }
  getAuditlogsVR(){
    let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
      width: '300px',
      height: '150px',
      data: { message: 'Fetching Audit Logs ..' }
   });  
   this.auditLogService.getAuditLogsVR().subscribe(
      genericResponse => { 
        loaderDialogRef.close();
        if(genericResponse != null && genericResponse.resultCode===Constants.CDK_200){
          this.dataSource =  new MatTableDataSource(genericResponse.resultObj);
          this.dataSource.data.forEach(element => {
            for (const key in element) {
              if (!element[key] || element[key] === null || element[key] === undefined) {
                element[key] = '';
              }
            }
          });
          this.dataSource.filterPredicate = function(data, filter: string): boolean {
            return (data.validationRuleDesc && data.validationRuleDesc.toLowerCase().includes(filter))
            || (data.user && data.user.toLowerCase().includes(filter))
            || (data.event && data.event.toLowerCase().includes(filter));
        };    
          this.dataSource.paginator = this.paginator; 
          this.dataSource.sort = this.sort;
          const sortState: Sort = {active: 'date', direction: 'desc'};
          this.sort.active = sortState.active;
          this.sort.direction = sortState.direction;
          this.sort.sortChange.emit(sortState);       
           }
      },
   () =>{
       this.toastrService.warning("Something went wrong...");
       loaderDialogRef.close();    
    });
  }

  navigate( endpoint : string){
    this.router.navigateByUrl(endpoint);
    }
applyFilter(filterValue: string) {
        filterValue = filterValue.trim(); // Remove whitespace
        filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
        this.dataSource.filter = filterValue;
  }

openAuditLogDialogue(auditLog : AuditLogsObject, userName : string){
    let dialogRef = this.dialog.open(AuditLogDialogDetailsComponent, {
      width: '60%',
      height: '80%',
      data: {
        auditLog: auditLog,
        userName : userName,
        displayName:'Validation Rule Message'
      }
  }); 
  }


}
