import { CdkTableModule } from "@angular/cdk/table";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatPaginatorModule, MatProgressSpinnerModule, MatSnackBarModule, MatSort, MatSortModule, MatTableDataSource } from "@angular/material";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router, RouterModule } from "@angular/router";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { of, Observable } from "rxjs";
import { LoaderDialogueComponent } from "../../loader-dialog/loader-dialog.component";
import { AuditLogsFUObject } from "../../model/audit-logsfu-object";
import { AuditLogsVTObject } from "../../model/audit-logsvt-object";
import { ProcessValidationResultsComponent } from "../../process-validation-results/process-validation-results.component";
import { AuditLogService } from "../../services/audit-log-service";
import { AuthService } from "../../services/auth-service";
import { DataTransferService } from "../../services/data-transfer-service";
import { ServerCommunicationService } from "../../services/server-communication-service";
import { AuditLogsS3DialogComponent } from "../audit-logs-s3-dialog/audit-logs-s3-dialog.component";
import { AuditVTDialogComponent } from "../validate-transfer-dialog/audit-vt-dialog.component";
import {  AgGridModule  } from 'ag-grid-angular'; 
import { AuditLogsVRComponent } from "./audit-log-validation-rule.component";
import { GenericResponse } from "../../model/generic-response";


describe('AuditLogsVRComponent',()=>{
    let component : AuditLogsVRComponent;
    let fixture : ComponentFixture<AuditLogsVRComponent>;
    let auditLogService : AuditLogService;
    let authService : AuthService;

      class MockRouter {
        navigateByUrl(url: string) { return url; }
      }

      beforeEach(async() =>{
        TestBed.configureTestingModule({
            imports:[
                MatDialogModule,
                MatIconModule,
                CdkTableModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                ToastrModule.forRoot(),
                MatSnackBarModule,
                MatSortModule,
                SortableModule,
                MatCardModule,
                MatPaginatorModule,
                MatFormFieldModule,
                MatInputModule,
                AgGridModule.withComponents([]),
                MatCheckboxModule,
            ],

            declarations:[
                AuditLogsVRComponent, LoaderDialogueComponent, AuditLogsS3DialogComponent, AuditVTDialogComponent, ProcessValidationResultsComponent
            ],

            providers:[
                AuditLogService,
                DataTransferService, 
                AuthService,
                ToastrService, 
                ServerCommunicationService,
                { provide: Router, useClass : MockRouter },
            ]
      }).overrideModule(BrowserDynamicTestingModule,
        { set: { entryComponents: [LoaderDialogueComponent, AuditLogsS3DialogComponent, AuditVTDialogComponent, ProcessValidationResultsComponent]}});

          authService = TestBed.get(AuthService);
          auditLogService = TestBed.get(AuditLogService);
          fixture = TestBed.createComponent(AuditLogsVRComponent);
          component = fixture.componentInstance;
}); 

const generic_response : GenericResponse = {
    "resultCode": "CDK_200",
    "resultDescription": "OK",
    "resultObj": [
      {
        "objectType": "Propagation",
        "date": "2020-10-29T09:56:13.635+0000",
        "objectIdentifier": "ProjOct21 : store1 : Propagate_Fu_To_BP_Drive",
        "user": "Suresh.Vanga@cdk.com",
        "event": undefined,
        "id": "65768c40-62ff-4d0c-ade9-0ebffc74b69a",
        "recordType": "PropagationInfo"
      }
      ],
      "executionTime" : null
  }
      
      it('test ng on init method', () =>{
        let data :{}
        spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data));
        fixture.detectChanges();
      })  

      it('test get audit logs VR method', ()=>{ 
        let data:{}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data));
        spyOn(auditLogService,'getAuditLogsVR').and.returnValue(Observable.of(generic_response));
        component.dataSource = new MatTableDataSource<GenericResponse>(generic_response.resultObj);
        component.sort = new MatSort();
        component.dataSource.sort = component.sort;
        component.getAuditlogsVR();
        expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(0);
        expect(auditLogService.getAuditLogsVR).toHaveBeenCalledTimes(1);
      });
    
      it('test get audit logs VR error case', ()=>{ 
        let data:{}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(auditLogService,'getAuditLogsVR').and.returnValue(Observable.throwError('error'));
        spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data))
        component.getAuditlogsVR();
        expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(0);
        expect(auditLogService.getAuditLogsVR).toHaveBeenCalledTimes(1);
      });

      it('test apply filter module', ()=>{
        component.dataSource = new MatTableDataSource<GenericResponse>(generic_response.resultObj);
        component.applyFilter("filterString");
      });
    
      it('test navigate method', async() =>{
        component.navigate("Dashboard");
      });
    
      it('test open audit log dialog method', ()=>{
        let auditLogObj : any = {}
        let userName :"userMe";
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        component.openAuditLogDialogue(auditLogObj,userName);
        expect(component.openAuditLogDialogue).toHaveBeenCalled;
      });

})