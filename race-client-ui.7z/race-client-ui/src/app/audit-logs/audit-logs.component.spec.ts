import { CdkTableModule } from "@angular/cdk/table";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialog, MatDialogModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatPaginatorModule, MatProgressSpinnerModule, MatSnackBarModule, MatSort, MatSortModule, MatTableDataSource } from "@angular/material";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { of, Observable } from "rxjs";
import {  AgGridModule  } from 'ag-grid-angular'; 
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { AuditLogsVTObject } from "../model/audit-logsvt-object";
import { ProcessValidationResultsComponent } from "../process-validation-results/process-validation-results.component";
import { AuditLogService } from "../services/audit-log-service";
import { AuthService } from "../services/auth-service";
import { DataTransferService } from "../services/data-transfer-service";
import { ServerCommunicationService } from "../services/server-communication-service";
import { AuditLogsS3DialogComponent } from "./audit-logs-s3-dialog/audit-logs-s3-dialog.component";
import { AuditLogsComponent } from "./audit-logs.component";
import { AuditVTDialogComponent } from "./validate-transfer-dialog/audit-vt-dialog.component";
import { AuditLogsObject } from "../model/audit-logs-object";


describe('AuditLogsComponent',()=>{
    let component : AuditLogsComponent;
    let fixture : ComponentFixture<AuditLogsComponent>;
    let auditLogService : AuditLogService;
    let authService : AuthService;

    class MockRouter {
        navigateByUrl(url: string) { return url; }
      }

      const testUrl  = 'dashboard';
      beforeEach(async() =>{
        let mockRouter = {
            navigate: jasmine.createSpy('navigateByUrl')
        } 
        TestBed.configureTestingModule({
            imports:[
                MatDialogModule,
                MatIconModule,
                CdkTableModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                ToastrModule.forRoot(),
                MatSnackBarModule,
                MatSortModule,
                SortableModule,
                MatCardModule,
                MatPaginatorModule,
                MatFormFieldModule,
                MatInputModule,
                AgGridModule.withComponents([]),
                MatCheckboxModule
            ],

            declarations:[
                AuditLogsComponent, LoaderDialogueComponent, AuditLogsS3DialogComponent, AuditVTDialogComponent, ProcessValidationResultsComponent
            ],

            providers:[
                AuditLogService,
                DataTransferService, 
                AuthService,
                ToastrService, 
                ServerCommunicationService,
                { provide: Router, useClass: MockRouter },
            ]
      }).overrideModule(BrowserDynamicTestingModule,
        { set: { entryComponents: [LoaderDialogueComponent, AuditLogsS3DialogComponent, AuditVTDialogComponent, ProcessValidationResultsComponent]}});

          authService = TestBed.get(AuthService);
          auditLogService = TestBed.get(AuditLogService);
          fixture = TestBed.createComponent(AuditLogsComponent);
          component = fixture.componentInstance;
}); 

    const auditlogs_list : AuditLogsObject[] = 
    [
        {
          
          "date": null,
          "projectNumber": "P000002",
          "user": "Beth.Maupin@cdk.com",
          "event": "Project Data Modified",
          "enterpriseId": "E0000022",
          "id": "444f49d1-d6ce-4c8b-9df8-7dbd8845587b",
          "updated": false,
          "recordType": "ProjectInfo",
          "fieldsInfo" : [],
          "validationRuleDesc" : "",
          "bestPracticeName" : "GM"

        }
        ];

      it('test ngOnInit method', ()=>{ 
        let data:{}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data));
        spyOn(auditLogService,'getAuditLogs').and.returnValue(Observable.of(auditlogs_list));
        component.dataSource = new MatTableDataSource<AuditLogsObject>(auditlogs_list);
        component.sort = new MatSort();
        component.dataSource.sort = component.sort;
        fixture.detectChanges();
        expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(1);
        expect(auditLogService.getAuditLogs).toHaveBeenCalledTimes(1);
      });
    
      it('test ngOnInit method error case', ()=>{ 
        let data:{}
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(auditLogService,'getAuditLogs').and.returnValue(Observable.throwError('error'));
        spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data))
        fixture.detectChanges();
        expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(1);
        expect(auditLogService.getAuditLogs).toHaveBeenCalledTimes(1);
      });

      it('test apply filter module', ()=>{
        component.dataSource = new MatTableDataSource<AuditLogsObject>(auditlogs_list);
        component.applyFilter("filterString");
      });
    
      it('test navigate method', async() =>{
        component.navigate("Dashboard");
      });
    
      it('test open audit log dialog method', ()=>{
        let auditLogObj : any = {}
        let userName :"userMe";
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        component.openAuditLogDialogue(auditLogObj,userName);
        expect(component.openAuditLogDialogue).toHaveBeenCalled;
      });

      it('get display name method', () =>{
          let auditLog = {   
            "date": null,
            "projectNumber": "P000002",
            "user": "Beth.Maupin@cdk.com",
            "event": "Store Data Modified - BP/VIC configured",
            "enterpriseId": "E0000022",
            "id": "444f49d1-d6ce-4c8b-9df8-7dbd8845587b",
            "updated": false,
            "recordType": "ProjectInfo",
            "fieldsInfo" : [],
            "validationRuleDesc" : "",
            "bestPracticeName" : "GM"
          }
          component.getDisplayName(auditlogs_list[0]);
          component.getDisplayName(auditLog);
      })
    
      it('test enable more option',()=>{
        let auditLog : any = {
            updated : true,
            event : "Project Data Modified"
        }
        let auditLogOther : any = {
            updated : false,
            event : "Functional Unit"
        }
        component.enableMoreOption(auditLog);
        component.enableMoreOption(auditLogOther);
        expect(component.enableMoreOption).toHaveBeenCalled;
    
      });
    
      it('test get audit logs method', async()=>{
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(auditLogService,'getAuditLogs').and.returnValue(Observable.of(auditlogs_list));
        component.getAuditLogs("loaderMessage");
        expect(auditLogService.getAuditLogs).toHaveBeenCalledTimes(1);
        expect(auditLogService.getAuditLogsFU).toHaveBeenCalledTimes(0);
      });

})