import { CdkTableModule } from "@angular/cdk/table";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCardModule, MatDialog, MatDialogModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatPaginatorModule, MatProgressSpinnerModule, MatSnackBarModule, MatSort, MatSortModule, MatTableDataSource } from "@angular/material";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { of, Observable } from "rxjs";
import { AuditLogDialogDetailsComponent } from "../../audit-log-dialog-details/audit-log-dialog-details.component";
import { FuPropagationAuditLogDialogComponent } from "../../fu-propagation-audit-log-details/fu-propagation-audit-log-dialog.component";
import { LoaderDialogueComponent } from "../../loader-dialog/loader-dialog.component";
import { AuditLogsObject } from "../../model/audit-logs-object";
import { GenericResponse } from "../../model/generic-response";
import { AuditLogService } from "../../services/audit-log-service";
import { AuthService } from "../../services/auth-service";
import { ServerCommunicationService } from "../../services/server-communication-service";
import { AuditLogsBPComponent } from "./audit-log-bestpractice.component"

describe('AuditLogBestPracticeComponent',()=>{
    let component : AuditLogsBPComponent;
    let fixture :ComponentFixture<AuditLogsBPComponent>;
    let auditLogService : AuditLogService;
    let authService : AuthService;
    let router : Router
    
    class MatDialogMock {
        open() {
          return {
            afterClosed: () => Observable.of(true)
          };
        }
      };

      const testUrl  = 'dashboard';
      beforeEach(async() =>{
        let mockRouter = {
            navigate: jasmine.createSpy('navigateByUrl')
        } 
        TestBed.configureTestingModule({
            imports:[
                MatDialogModule,
                MatIconModule,
                CdkTableModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                ToastrModule.forRoot(),
                MatSnackBarModule,
                MatSortModule,
                SortableModule,
                MatCardModule,
                MatPaginatorModule,
                MatFormFieldModule,
                MatInputModule,
                
            ],

            declarations:[
                AuditLogsBPComponent, AuditLogDialogDetailsComponent, LoaderDialogueComponent, FuPropagationAuditLogDialogComponent
            ],

            providers:[
                AuditLogService,
                AuthService, 
                ToastrService, 
                ServerCommunicationService,
                { provide: Router, useValue: {url:testUrl} },
            ]
      }).overrideModule(BrowserDynamicTestingModule,
        { set: { entryComponents: [LoaderDialogueComponent, AuditLogDialogDetailsComponent, FuPropagationAuditLogDialogComponent]}});

          authService = TestBed.get(AuthService);
          auditLogService = TestBed.get(AuditLogService);
          fixture = TestBed.createComponent(AuditLogsBPComponent);
          component = fixture.componentInstance;
});

const generic_response : GenericResponse = {
    "resultCode": "CDK_200",
    "resultDescription": "OK",
    "resultObj": [
      {
        "objectType": "Propagation",
        "date": "2020-10-29T09:56:13.635+0000",
        "objectIdentifier": "ProjOct21 : store1 : Propagate_Fu_To_BP_Drive",
        "user": "Suresh.Vanga@cdk.com",
        "event": undefined,
        "id": "65768c40-62ff-4d0c-ade9-0ebffc74b69a",
        "recordType": "PropagationInfo"
      }
      ],
      "executionTime" : null
  }

  it('test ngOnInit method', ()=>{ 
      let data:{}
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    spyOn(auditLogService,'getAuditLogsBP').and.returnValue(Observable.of(generic_response));
    spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data));
    component.dataSource = new MatTableDataSource(generic_response.resultObj);
    component.sort = new MatSort();
    component.dataSource.sort = component.sort;
    fixture.detectChanges();
    expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(1);
  });

  afterAll(() => {
    TestBed.resetTestingModule();
  });

  it('test get AUditLogs bp method', async() =>{
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    spyOn(auditLogService,'getAuditLogsBP').and.returnValue(Observable.throwError('error'));
    spyOn(authService,'fetchLoggedInUserAndPermissions').and.callThrough();
    component.getAuditlogsBP();
    expect(auditLogService.getAuditLogsBP).toHaveBeenCalledTimes(1);
  });

  it('test open audit log dialog method', () =>{
    let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        let auditlog : any = {
          id: "123456"
        }
        component.openAuditLogDialogue(auditlog,"user1","Functional Units changes propagated to BP");
        component.openAuditLogDialogue(auditlog,"user2","anyString");

        expect(component.openAuditLogDialogue(auditlog,"","")).toHaveBeenCalled;
  });

  it('test enable more option test', ()=>{
    let auditlog : any = {
      id: "123456",
      event : "updated"
    }

    component.enableMoreOption(auditlog);
    component.enableMoreOption(null);
    expect(component.enableMoreOption(auditlog)).toHaveBeenCalled;

  })

  it('test apply filter module', ()=>{
    component.dataSource = new MatTableDataSource<GenericResponse>(generic_response.resultObj);
    component.applyFilter("filterString");
    
  })

  it('test navigate method', async() =>{
      component.navigate("Dashboard");
  });

})