import { CdkTableModule } from "@angular/cdk/table";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCardModule, MatDialog, MatDialogModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatPaginatorModule, MatProgressSpinnerModule, MatSnackBarModule, MatSort, MatSortModule, MatTableDataSource } from "@angular/material";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { SortableModule } from "ngx-bootstrap";
import { ToastrModule, ToastrService } from "ngx-toastr";
import { of, Observable } from "rxjs";
import { LoaderDialogueComponent } from "../../loader-dialog/loader-dialog.component";
import { AuditLogsFAObject } from "../../model/audit-logsfa-object";
import { AuditLogService } from "../../services/audit-log-service";
import { AuthService } from "../../services/auth-service";
import { DataTransferService } from "../../services/data-transfer-service";
import { ServerCommunicationService } from "../../services/server-communication-service";
import { AuditLogsFAComponent } from "./audit-logsfa.component";


describe('AuditLogsFAComponent',()=>{
    let component : AuditLogsFAComponent;
    let fixture : ComponentFixture<AuditLogsFAComponent>;
    let auditLogService : AuditLogService;
    let authService : AuthService;

      const testUrl  = 'dashboard';
      beforeEach(async() =>{
        let mockRouter = {
            navigate: jasmine.createSpy('navigateByUrl')
        } 
        TestBed.configureTestingModule({
            imports:[
                MatDialogModule,
                MatIconModule,
                CdkTableModule,
                MatDividerModule,
                MatProgressSpinnerModule,
                HttpClientTestingModule,
                NoopAnimationsModule,
                FormsModule,
                ReactiveFormsModule,
                BrowserModule,
                ToastrModule.forRoot(),
                MatSnackBarModule,
                MatSortModule,
                SortableModule,
                MatCardModule,
                MatPaginatorModule,
                MatFormFieldModule,
                MatInputModule,
                
            ],

            declarations:[
                AuditLogsFAComponent, LoaderDialogueComponent
            ],

            providers:[
                AuditLogService,
                DataTransferService, 
                AuthService,
                ToastrService, 
                ServerCommunicationService,
                { provide: Router, useValue: {url:testUrl} },
            ]
      }).overrideModule(BrowserDynamicTestingModule,
        { set: { entryComponents: [LoaderDialogueComponent]}});

          authService = TestBed.get(AuthService);
          auditLogService = TestBed.get(AuditLogService);
          fixture = TestBed.createComponent(AuditLogsFAComponent);
          component = fixture.componentInstance;
}); 

  const fa_response : AuditLogsFAObject[] = 
      [
          {
            "date": null,
            "fieldsInfo" : [],
            "objectIdentifier": "Service",
            "user": "Jeff.Grence@cdk.com",
            "event": "Functional Area Updated",
            "id": "28896db3-4d4d-4df0-b1f5-26c730f0d561",
          }
      ]
  

  it('test ngOnInit method', ()=>{ 
    let data:{}
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    spyOn(auditLogService,'getAuditLogsFA').and.returnValue(Observable.of(fa_response));
    spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data));
    component.dataSource = new MatTableDataSource<AuditLogsFAObject>(fa_response);
    component.sort = new MatSort();
    component.dataSource.sort = component.sort;
    fixture.detectChanges();
    expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(1);
    expect(auditLogService.getAuditLogsFA).toHaveBeenCalledTimes(1);
  }); 

  it('test ngOnInit method error case', ()=>{ 
    let data:{}
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    spyOn(auditLogService,'getAuditLogsFA').and.returnValue(Observable.throwError('error'));
    spyOn(authService,'fetchLoggedInUserAndPermissions').and.returnValue(Observable.of(data));
    fixture.detectChanges();
    expect(authService.fetchLoggedInUserAndPermissions).toHaveBeenCalledTimes(1);
    expect(auditLogService.getAuditLogsFA).toHaveBeenCalledTimes(1);
  });

  it('test apply filter module', ()=>{
    component.dataSource = new MatTableDataSource<AuditLogsFAObject>(fa_response);
    component.applyFilter("filterString");
  });

  it('test navigate method', async() =>{
    component.navigate("Dashboard");
  });

  it('test open audit log dialog method', ()=>{
    let auditLogObj :any = {};
    let userName :"userMe";
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    component.openAuditLogDialogue(auditLogObj,userName);
    expect(component.openAuditLogDialogue).toHaveBeenCalled;
  });

  it('test enable more option',()=>{
    let auditLog : any = {
        updated : true,
        event : "Functional Area Updated"
    }
    let auditLogOther : any = {
        updated : false,
        event : "Functional Area"
    }
    component.enableMoreOption(auditLog);
    component.enableMoreOption(auditLogOther);
    expect(component.enableMoreOption).toHaveBeenCalled;

  });

  it('test get audit logs method', async()=>{
    let dialogSpy: jasmine.Spy;
    let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
    dialogRefSpyObj.componentInstance = { body: '' };
    dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
    spyOn(auditLogService,'getAuditLogsFA').and.returnValue(Observable.of(fa_response));
    component.getAuditLogs("loaderMessage");
    expect(auditLogService.getAuditLogsVT).toHaveBeenCalledTimes(0);
    expect(auditLogService.getAuditLogsFA).toHaveBeenCalledTimes(1);
  });


})