import { Component, OnInit, ViewChild } from '@angular/core';

import { AuditLogService } from '../../services/audit-log-service';
import { DataTransferService } from '../../services/data-transfer-service';
import { AuthService } from '../../services/auth-service';
import { Router } from '@angular/router';
import { DataSource } from '@angular/cdk/collections';
import { BehaviorSubject, Observable } from 'rxjs';
import { ProjectObject } from '../../model/project-object';
import { PlatformObject } from '../../model/platform-object';
import { ScreenObject } from '../../model/screen-object';
import { StoreObject } from '../../model/store-object';
import { AuditLogsObject } from '../../model/audit-logs-object';
import { AuditLogsFAObject } from '../../model/audit-logsfa-object';
import { MatPaginator, MatTableDataSource, MatSort, Sort } from '@angular/material';
import { MatDialog, MatDialogRef } from '@angular/material';
import { LoaderDialogueComponent } from '../../loader-dialog/loader-dialog.component';
import { AuditLogDialogComponent } from  '../../audit-log-dialog/audit-log-dialog.component';
import { ToastrService } from 'ngx-toastr';
import { timeStamp } from 'console';
import { AuditLogDialogDetailsComponent } from '../../audit-log-dialog-details/audit-log-dialog-details.component';

@Component({
  selector: 'app-audit-logsfa',
  templateUrl: './audit-logsfa.component.html',
  styleUrls: ['./audit-logsfa.component.css']
})
export class AuditLogsFAComponent implements OnInit {
    
    @ViewChild(MatPaginator,{static: false}) paginator: MatPaginator;
    
    @ViewChild(MatSort,{static: false}) sort: MatSort;
    
    dataSource : any;    

    displayedColumns = ['date', 'objectIdentifier', 'user','event','more'];
    
    constructor(private auditLogService: AuditLogService, private dataTransferService: DataTransferService, 
           private authService: AuthService,private router: Router, private dialog: MatDialog, private toastrService: ToastrService) { 
   
    }

      
  
    ngOnInit() {
     
           let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
              width: '300px',
              height: '150px',
              data: { message: 'Fetching Audit Logs ..' }
           });  
        
           this.authService.fetchLoggedInUserAndPermissions().subscribe((data: any) => {
           this.auditLogService.getAuditLogsFA().subscribe(
                   data => { 
                       this.dataSource =  new MatTableDataSource<AuditLogsFAObject>(data);
                       this.dataSource.data.forEach(element => {
                        for (const key in element) {
                          if (!element[key] || element[key] === null || element[key] === undefined) {
                            element[key] = '';
                          }
                        }
                      });
                      this.dataSource.filterPredicate = function(data, filter: string): boolean {
                        return (data.objectIdentifier && data.objectIdentifier.toLowerCase().includes(filter))
                        || (data.user && data.user.toLowerCase().includes(filter))
                        || (data.event && data.event.toLowerCase().includes(filter));
                    };    
                       this.dataSource.paginator = this.paginator;
                       this.dataSource.sort = this.sort;
                       const sortState: Sort = {active: 'date', direction: 'desc'};
                       this.sort.active = sortState.active;
                       this.sort.direction = sortState.direction;
                       this.sort.sortChange.emit(sortState);
                       loaderDialogRef.close();
                   },
               error =>{
                    this.toastrService.warning("Something went wrong...");
                    loaderDialogRef.close();    
               });
           });
         

  
    }

    navigate( endpoint : string){
        this.router.navigateByUrl(endpoint);
    }
    applyFilter(filterValue: string) {
            filterValue = filterValue.trim(); // Remove whitespace
            filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
            this.dataSource.filter = filterValue;
    }
    
    openAuditLogDialogue(auditLog : AuditLogsObject, userName : string){
        let dialogRef = this.dialog.open(AuditLogDialogComponent, {
          width: '60%',
          height: '80%',
          data: {
            auditLog: auditLog,
            userName : userName,
            displayName:'Functional Area'
          }
      }); 
   
    }
    
    enableMoreOption(auditLog : AuditLogsObject){
      if(auditLog.updated === true  &&  auditLog.event === 'Functional Area Updated'){
        return true;
      } 
      return false;
    }
    
    
    
    getAuditLogs(loaderMessage: string) {
      let loaderDialogRef;
      if (loaderMessage)
      {
              loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
              width: '300px',
              height: '150px',
              data: { message: loaderMessage }
          });
      }
      this.auditLogService
          .getAuditLogsFA()
              .subscribe(
                data => {
                       this.dataSource =  new MatTableDataSource<AuditLogsFAObject>(data);   
                       this.dataSource.paginator = this.paginator;
                       this.dataSource.sort = this.sort;
                       loaderDialogRef.close();
                }, error=> {
                    this.toastrService.error('got error' + error.error.message);
                }
          );
  }
}
