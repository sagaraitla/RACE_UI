import { CdkTableModule } from "@angular/cdk/table";
import { CommonModule } from "@angular/common";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCardModule, MatCheckboxModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatPaginatorModule, MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatTableModule } from "@angular/material";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { ToastrModule } from "ngx-toastr";
import { Observable, of } from "rxjs";
import { LoaderDialogueComponent } from "../loader-dialog/loader-dialog.component";
import { ProcessValidationResults } from "../model/process-validation-results";
import { AuditLogService } from "../services/audit-log-service";
import { AuthService } from "../services/auth-service";
import { ServerCommunicationService } from "../services/server-communication-service";
import { ValidationRuleService } from "../services/validation-rule-service";
import { WarningAcknowledgementComponent } from "../warning-acknowledgement/warning-acknowledgement.component";
import { ProcessValidationResultsComponent } from "./process-validation-results.component";

describe('ProcessValidationResultsComponent', () => {

    let component : ProcessValidationResultsComponent;
    let fixture: ComponentFixture<ProcessValidationResultsComponent>;
    let validationRuleService: ValidationRuleService;
    let  auditLogService: AuditLogService;

    beforeEach(() => {

        let data= {
            auditLogVT:"test",
            displayName:"auditLog"
        }
        const dialogMock = {
            close: () => { },
        };
        
        TestBed.configureTestingModule({
            imports: [
                MatDialogModule,
                MatFormFieldModule,
                MatRadioModule,
                FormsModule,
                MatFormFieldModule,
                MatInputModule,
                CdkTableModule,
                MatInputModule,
                MatTableModule,
                MatPaginatorModule,
                MatDialogModule,
                HttpClientTestingModule,
                ToastrModule.forRoot(),
                NoopAnimationsModule,
                MatProgressSpinnerModule ,
                ReactiveFormsModule,
                CommonModule,
                MatSelectModule,
                MatCheckboxModule,
                MatCardModule
            ],
            declarations: [ProcessValidationResultsComponent,LoaderDialogueComponent,WarningAcknowledgementComponent],
            providers:[
                ValidationRuleService,
                AuditLogService,
                ServerCommunicationService,
                AuthService,
                { provide: MAT_DIALOG_DATA, useValue: data },
                {provide: MatDialogRef, useValue: dialogMock},
            ]
        }).overrideModule(BrowserDynamicTestingModule,
            { set: { entryComponents: [LoaderDialogueComponent,WarningAcknowledgementComponent]}});

            validationRuleService = TestBed.get(ValidationRuleService);
            auditLogService = TestBed.get(AuditLogService);

            fixture = TestBed.createComponent(ProcessValidationResultsComponent);
            component = fixture.componentInstance;
    });
    
    const genericResponse1 :any ={
        "resultCode": "CDK_200",
        "resultDescription": "OK",
        "resultObj": [
            {
            "status": "Success",
            "description": "Price code missing or not valid",
            "validationRuleId": "68f94261-69e8-4916-ae86-ab746477260e"
            },
            {
            "status": "Warning",
            "description": "Price code missing or not valid",
            "validationRuleId": "ea8257a8-a887-4b44-bb37-8cb99905ab7e"
            },
            {
            "status": "Success",
            "description": "Price code missing or not valid",
            "validationRuleId": "9cb8d4b8-c776-4166-ae61-7f2538a2c0ef"
            }
            ],
            "executionTime": 101
      }

    it('test ngOnInit',()=>{
        component.isPVRAudit = false;
        spyOn(component,'updateRequiredValues');
        spyOn(component,'processingValidationRules');
        fixture.detectChanges();
        expect(component.updateRequiredValues).toHaveBeenCalledTimes(1);
        expect(component.processingValidationRules).toHaveBeenCalledTimes(1);
    });

    it('test ngOnInit if isPVRAudit is true',()=>{
        component.isPVRAudit = true;
        spyOn(component,'getProcessValidationRuleResultInfo');
        spyOn(component,'updateRequiredValues');
        fixture.detectChanges();
        expect(component.getProcessValidationRuleResultInfo).toHaveBeenCalledTimes(1);
        expect(component.updateRequiredValues).toHaveBeenCalledTimes(1);
    });


    it('test updateRequiredValues',()=>{
        component['data'].projectName = "test Project";
        component['data'].storeName = "test store";
        component['data'].functionalAreaName = "test functional Area name";
        component['data'].sourceProductCode = "test sourceProductCode";
        component['data'].faId = "321dd998-944b-44d9-a973-7e9159c26db7";;
        component['data'].storeId = "ew1dd998-944b-44d9-a973-7e9159c26db0";
        component.updateRequiredValues({});
    });

    it('test statusIcon',()=>{

        let statusValue ="Success";
        let result = component.statusIcon(statusValue);
        expect(result).toEqual('fa fa-check rowSuccess');

        let statusValue1 ="Warning";
        let result1 = component.statusIcon(statusValue1);
        expect(result1).toEqual('fa fa-exclamation-triangle rowWarn');
    
        let statusValue2 ="Failed";
        let result2 = component.statusIcon(statusValue2);
        expect(result2).toEqual('fa fa-close rowError');
       
        let statusValue3;
        let result3 = component.statusIcon(statusValue3);
        expect(result3).toEqual(undefined);
       
    });

    it('test updateCounter',()=>{
    
        let processValidationResults: ProcessValidationResults[]=[
            {
                 "status": 'Success',
                 "description":'test description',
                "validationRuleId":'321dd998-944b-44d9-a973-7e9159c26db7'
            },
            {
                "status": 'Failed',
                "description":'test description',
               "validationRuleId":'321dd998-944b-44d9-a973-7e9159c26db9'
           },
           {
            "status": 'Warning',
            "description":'test description',
           "validationRuleId":'321dd998-944b-44d9-a973-7e9159c26db9'
       }
        ]

        component.updateCounter(processValidationResults);        
    });

    it('test closeDialog',()=>{
        component.errorCount = 0;
        component.warningCount =0;
        component.closeDialog();
    })

    it('test openDialogToWarningAcknowledgment if event is Acknowledge',()=>{
        let result :any={
            processValidationCompleteOrOverridden:'test',
            event:'Acknowledge'
            
        }
        component.overrideWarningsSelected = true;
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(result), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        component.openDialogToWarningAcknowledgment();
    });

    it('test openDialogToWarningAcknowledgment if event is Close',()=>{
        let result :any={
            processValidationCompleteOrOverridden:'test',
            event:'Close'
            
        }
        component.overrideWarningsSelected = true;
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(result), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        component.openDialogToWarningAcknowledgment();
    });


    it('test processingValidationRules if api response is null',()=>{
    
        const genericResponse :any =null;
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(validationRuleService,'getProcessingValidationResults').and.returnValue(Observable.of(genericResponse))
        component.processingValidationRules();
    });

    
    it('test processingValidationRules if api throw error',()=>{
    
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(validationRuleService,'getProcessingValidationResults').and.returnValue(Observable.throwError('error'))
        component.processingValidationRules();
    });


    it('test getProcessValidationRuleResultInfo if api response is null',()=>{
    
        const genericResponse :any =null;
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(auditLogService,'getPVRResultsInfoById').and.returnValue(Observable.of(genericResponse))
        component.getProcessValidationRuleResultInfo();
    });

    it('test getProcessValidationRuleResultInfo if api throw error',()=>{
    
        let dialogSpy: jasmine.Spy;
        let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(true), close: null });
        dialogRefSpyObj.componentInstance = { body: '' };
        dialogSpy = spyOn(TestBed.get(MatDialog), 'open').and.returnValue(dialogRefSpyObj);
        spyOn(auditLogService,'getPVRResultsInfoById').and.returnValue(Observable.throwError('error'))
        component.getProcessValidationRuleResultInfo();
    });

    
});