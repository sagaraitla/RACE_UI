import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { ProcessValidationResults } from '../model/process-validation-results';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { WarningAcknowledgementComponent } from '../warning-acknowledgement/warning-acknowledgement.component';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { LoaderDialogueComponent } from '../loader-dialog/loader-dialog.component';
import { ValidationRuleService } from '../services/validation-rule-service';
import { AuditLogsVTObject } from '../model/audit-logsvt-object';
import { AuditLogService } from '../services/audit-log-service';
import { GenericResponse } from '../model/generic-response';


@Component({
    selector: 'app-process-validation-results',
    templateUrl: './process-validation-results.component.html',
    styleUrls: ['./process-validation-results.component.css']
}
)
export class ProcessValidationResultsComponent implements OnInit {
    displayedColumns: string[] = ['status', 'description'];


    @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
    @ViewChild(MatSort, { static: true }) sort: MatSort;
    dataSource: any;
    projectName: string;
    storeName: string;
    functionalAreaName: string;
    overrideWarningsSelected: boolean = false;
    processValidationResultsList: ProcessValidationResults[];
    successCount: number;
    errorCount: number;
    warningCount: number;
    platformName: string;
    sourceProductCode: string;
    faId: string;
    storeId: string;
    projectId: string;
    auditLogVT : AuditLogsVTObject; 
    isPVRAudit : boolean = false; 
    displayName : string;



    constructor(private dialogRef: MatDialogRef<ProcessValidationResultsComponent>,
        @Inject(MAT_DIALOG_DATA) private data: any, private dialog: MatDialog, private validationRuleService: ValidationRuleService,
        private auditLogService: AuditLogService) {
        dialogRef.disableClose = true;       
        if(this.data.auditLogVT != null && this.data.auditLogVT != undefined){
            this.auditLogVT = JSON.parse(JSON.stringify(this.data.auditLogVT));
            this.isPVRAudit = true;
            this.displayName = this.data.displayName;  
        }
    }

    ngOnInit() {
        if(!this.isPVRAudit){
            this.updateRequiredValues(this.data);
            this.processingValidationRules();
        } else{
            this.getProcessValidationRuleResultInfo();
            this.updateRequiredValues(this.data);
        }
    }
    getProcessValidationRuleResultInfo() {
        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
            width: '300px',
            height: '150px',
            data: { message: 'Processing Validation Rules Results Info ...' }
        });
    
        this.auditLogService.getPVRResultsInfoById(this.auditLogVT.id).subscribe(genericResponse =>{
            if (genericResponse != null && genericResponse != undefined && genericResponse.resultDescription == "OK") {
                this.dataSource = new MatTableDataSource<ProcessValidationResults>(genericResponse.resultObj); 
                this.dataSource.sortingDataAccessor = (item, property) => {
                    switch (property) {
                        case 'status': return item.status;
                        case 'description': return item.description;
                        default: return item[property];
                    }
                };
                this.dataSource.paginator = this.paginator;
                this.dataSource.sort = this.sort;
                this.updateCounter(genericResponse.resultObj);
                loaderDialogRef.close();
            }else {
                loaderDialogRef.close();
            }
        },error => {
            console.log(error);
            loaderDialogRef.close();
        })
    }

    openDialogToWarningAcknowledgment() {
        if (this.overrideWarningsSelected) {
            let dialogRef = this.dialog.open(WarningAcknowledgementComponent, {
                width: "28%",
                height: "41%",
                data:{
                    projectName:this.projectName,
                    storeName:this.storeName,
                    functionalAreaName:this.functionalAreaName
                }

            });
            dialogRef.afterClosed().subscribe(result => {
                let processValidationCompleteOrOverridden = result.processValidationCompleteOrOverridden;
                if(result.event == 'Acknowledge'){
                    this.dialogRef.close({processValidationCompleteOrOverridden});
                  }else if(result.event == 'Close'){
                    this.overrideWarningsSelected = result.overrideWarningsSelected;
                  }
            });
        }
    }

    updateCounter(results: ProcessValidationResults[]) {
        if (results != null && results != undefined) {
            results.filter(vr => vr != null && vr != undefined).forEach(pvr => {
                if (pvr.status === 'Success') {
                    ++this.successCount;
                } else if (pvr.status === 'Failed') {
                    ++this.errorCount;
                } else if (pvr.status === 'Warning') {
                    ++this.warningCount;
                }
            }
            );
        }

    }

    statusIcon(statusValue: string): string {
        let style: string;
        if (statusValue === 'Success') {
            style = 'fa fa-check rowSuccess';
        } else if (statusValue === 'Warning') {
            style = 'fa fa-exclamation-triangle rowWarn';
        } else if (statusValue === 'Failed') {
            style = 'fa fa-close rowError';
        }
        return style;
    }

    processingValidationRules() {
        let loaderDialogRef = this.dialog.open(LoaderDialogueComponent, {
            width: '300px',
            height: '150px',
            data: { message: 'Processing Validation Rules ..' }
        });
        this.validationRuleService.getProcessingValidationResults(this.platformName, this.sourceProductCode, this.faId, this.storeId, this.projectId).subscribe(genericResponse => {
            if (genericResponse != null && genericResponse != undefined && genericResponse.resultDescription == "OK") {
                this.dataSource = new MatTableDataSource<ProcessValidationResults>(genericResponse.resultObj);
                this.dataSource.sortingDataAccessor = (item, property) => {
                    switch (property) {
                        case 'status': return item.status;
                        case 'description': return item.description;
                        default: return item[property];
                    }
                };
                this.dataSource.paginator = this.paginator;
                this.dataSource.sort = this.sort;
                this.updateCounter(genericResponse.resultObj);
                loaderDialogRef.close();

            }
            else {
                loaderDialogRef.close();
            }
        }, error => {
            console.log(error);
            loaderDialogRef.close();
        });

    }

    updateRequiredValues(data: any) {

        this.overrideWarningsSelected = false;
        this.projectName = data.projectName;
        this.storeName = data.storeName;
        this.functionalAreaName = data.functionalAreaName;
        this.platformName = data.platformName;
        this.sourceProductCode = data.sourceProductCode;
        this.faId = data.faId;
        this.storeId = data.storeId;
        this.projectId = data.projectId;
        this.successCount = 0;
        this.errorCount = 0;
        this.warningCount = 0;
    }

    closeDialog(){
        let processValidationCompleteOrOverridden:boolean = false;
        if(this.errorCount === 0 && this.warningCount === 0){
            processValidationCompleteOrOverridden =true;
        }
        this.dialogRef.close({processValidationCompleteOrOverridden});
      }

}